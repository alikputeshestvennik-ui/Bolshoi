package com.example.speechfilter.pipeline

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Offline Gemma engine placeholder (MediaPipe LLM Inference API / GGUF later).
 *
 * Expected model path: filesDir/models/gemma-model.{task|gguf|bin}
 */
class GemmaEngine(private val context: Context) {

    companion object {
        // Sanity floor so a wrong/partial file pick doesn't get accepted as a model.
        // Real quantized Gemma checkpoints (.task/.gguf) are realistically >100MB;
        // 20MB just rejects obviously-wrong picks (images, docs, etc).
        private const val MIN_MODEL_BYTES = 20L * 1024L * 1024L
        private val EXTS = setOf("task", "gguf", "bin")
    }

    private val warmed = AtomicBoolean(false)

    fun modelDir(): File = File(context.filesDir, "models").apply { mkdirs() }

    private fun isGemmaFile(f: File): Boolean {
        val n = f.name.lowercase()
        return n.startsWith("gemma") && EXTS.any { n.endsWith(".$it") }
    }

    private fun existingModelFile(): File? = modelDir().listFiles()?.firstOrNull(::isGemmaFile)

    fun modelReady(): Boolean = existingModelFile()?.let { it.length() > MIN_MODEL_BYTES } == true

    fun modelFile(): File? = existingModelFile()

    /** Import a user-selected Gemma model (.task / .gguf / .bin) into app-private storage. */
    @Synchronized
    fun importModel(uri: Uri, displayName: String?): Result<File> = runCatching {
        release()
        val ext = displayName
            ?.substringAfterLast('.', "")
            ?.lowercase()
            ?.takeIf { it in EXTS } ?: "task"

        // Replace any previously imported Gemma model (whatever extension it had).
        modelDir().listFiles()?.forEach { if (isGemmaFile(it)) it.delete() }

        val out = File(modelDir(), "gemma-model.$ext")
        val tmp = File(modelDir(), "gemma-model.$ext.tmp")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(tmp).use { output -> input.copyTo(output) }
        } ?: error("Не удалось открыть выбранный файл")
        if (tmp.length() < MIN_MODEL_BYTES) {
            tmp.delete()
            error("Файл слишком маленький для модели Gemma: ${tmp.length()} байт")
        }
        if (!tmp.renameTo(out)) {
            tmp.copyTo(out, overwrite = true)
            tmp.delete()
        }
        out
    }

    @Synchronized
    fun warmUp(): String {
        if (!modelReady()) {
            warmed.set(false)
            return "Gemma: модель не найдена в ${modelDir().absolutePath}"
        }
        warmed.set(true)
        return "Gemma: прогрев OK (инференс пока заглушка, см. generate())"
    }

    /**
     * Run prompt+text. Replace with MediaPipe/llama.cpp generate().
     */
    @Synchronized
    fun generate(promptTemplate: String, text: String): Result<String> {
        if (text.isBlank()) return Result.success("")
        if (!modelReady()) {
            return Result.failure(IllegalStateException("Нет модели Gemma в ${modelDir()}"))
        }
        if (!warmed.get()) warmUp()
        val prompt = PromptStore.fill(promptTemplate, text)
        // TODO: real offline generate(prompt)
        return Result.failure(
            UnsupportedOperationException(
                "Gemma в пайплайне; офлайн-инференс — следующий шаг. Промпт length=${prompt.length}"
            )
        )
    }

    fun release() {
        warmed.set(false)
    }
}
