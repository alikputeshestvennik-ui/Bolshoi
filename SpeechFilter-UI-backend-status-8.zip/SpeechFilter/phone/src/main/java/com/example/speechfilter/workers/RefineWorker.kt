package com.example.speechfilter.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.data.PipelineLogEntity
import com.example.speechfilter.data.RefinedTextEntity
import com.example.speechfilter.pipeline.DayKeys
import com.example.speechfilter.pipeline.GemmaEngine
import com.example.speechfilter.pipeline.GemmaOutput
import com.example.speechfilter.pipeline.PromptStore

/** Every 33 minutes: Gemma refine pending transcripts. */
class RefineWorker(
    ctx: Context,
    params: WorkerParameters
) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val db = AppDatabase.get(applicationContext)
        val gemma = GemmaEngine(applicationContext)
        return try {
            db.logs().insert(PipelineLogEntity(worker = "refine", message = gemma.warmUp()))
            val pending = db.transcripts().byStatus("pending", 20)
            var n = 0
            var keptOriginal = 0
            for (t in pending) {
                if (db.refined().countForTranscript(t.id) > 0) {
                    db.transcripts().setStatus(t.id, "refined")
                    continue
                }
                val r = gemma.generate(PromptStore.refinePrompt, t.text)
                if (r.isSuccess) {
                    val raw = r.getOrDefault("").trim()
                    val out = GemmaOutput.acceptRefine(t.text, raw)
                    if (out == t.text.trim() && raw.isNotEmpty() && raw != out) {
                        keptOriginal++
                    }
                    if (out.isNotEmpty()) {
                        db.refined().insert(
                            RefinedTextEntity(
                                transcriptId = t.id,
                                text = out,
                                processedAt = System.currentTimeMillis(),
                                dayKey = DayKeys.of(t.createdAt)
                            )
                        )
                    }
                    db.transcripts().setStatus(t.id, "refined")
                    n++
                } else {
                    db.logs().insert(
                        PipelineLogEntity(
                            worker = "refine",
                            message = "id=${t.id}: ${r.exceptionOrNull()?.message}"
                        )
                    )
                }
            }
            val msg = if (keptOriginal > 0) {
                "Обработано: $n (Gemma отклонён, оставлен Whisper: $keptOriginal)"
            } else {
                "Обработано: $n"
            }
            db.logs().insert(PipelineLogEntity(worker = "refine", message = msg))
            Result.success()
        } catch (t: Throwable) {
            db.logs().insert(PipelineLogEntity(worker = "refine", message = "crash: ${t.message}"))
            Result.retry()
        } finally {
            gemma.release()
            PipelineScheduler.reschedule(
                applicationContext,
                PipelineScheduler.UNIQUE_REFINE,
                RefineWorker::class.java,
                33
            )
        }
    }
}
