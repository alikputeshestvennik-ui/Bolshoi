package com.example.speechfilter.pipeline

/**
 * Post-filters for on-device Gemma output. Small local models often:
 * - prepend "Вот ваш текст:"
 * - inject CJK / Latin noise into Russian speech transcripts
 * - echo category labels instead of facts for the "important" task
 */
object GemmaOutput {

    private val PREFIXES = listOf(
        "вот ваш текст:",
        "вот исправленный текст:",
        "исправленный текст:",
        "отредактированный текст:",
        "результат:",
        "ответ:",
        "here is the text:",
        "corrected text:",
    )

    /** Category labels the important-prompt model kept repeating. */
    private val BARE_CATEGORIES = setOf(
        "поддержку", "поддержка",
        "вопросы", "вопрос",
        "решения", "решение",
        "даты", "дата",
        "имена", "имя",
        "задачи", "задача",
        "договорённости", "договоренности", "договорённость", "договоренность",
        "подключение", "темы", "сводка", "сводки нет", "нет",
    )

    private val CJK = Regex("[\\u3040-\\u30ff\\u3400-\\u4dbf\\u4e00-\\u9fff\\uf900-\\ufaff]")
    private val CYRILLIC = Regex("[А-Яа-яЁё]")

    fun stripPrefix(raw: String): String {
        var s = raw.trim()
        // Drop leading markdown / quotes
        s = s.trimStart('"', '\'', '`', '«', '»', ' ')
        val lower = s.lowercase()
        for (p in PREFIXES) {
            if (lower.startsWith(p)) {
                s = s.substring(p.length).trimStart(' ', '\n', '\r', '"', '\'', '«')
                break
            }
        }
        return s.trim()
    }

    fun cjkRatio(s: String): Double {
        if (s.isEmpty()) return 0.0
        val cjk = CJK.findAll(s).count()
        return cjk.toDouble() / s.length
    }

    fun cyrillicRatio(s: String): Double {
        val letters = s.count { it.isLetter() }
        if (letters == 0) return 0.0
        return CYRILLIC.findAll(s).count().toDouble() / letters
    }

    /**
     * For refine: keep original Whisper text if Gemma output is polluted
     * or clearly worse (language switch, heavy CJK, empty, etc.).
     */
    fun acceptRefine(original: String, generated: String): String {
        val out = stripPrefix(generated)
        if (out.isBlank()) return original
        // Language guard: input is Russian speech → reject CJK pollution
        if (cjkRatio(out) > 0.02) return original
        if (cyrillicRatio(original) > 0.5 && cyrillicRatio(out) < 0.35) return original
        // Don't accept drastic shortening that drops meaning
        if (original.length > 40 && out.length < original.length * 0.35) return original
        // Don't accept huge expansion (hallucination)
        if (out.length > original.length * 3 + 80) return original
        return out
    }

    /**
     * Parse important-extraction lines; drop bare categories, "НЕТ", empties.
     */
    fun importantLines(generated: String): List<String> {
        val cleaned = stripPrefix(generated)
        if (cleaned.equals("НЕТ", ignoreCase = true)) return emptyList()
        if (cleaned.equals("нет", ignoreCase = true)) return emptyList()

        return cleaned.lines()
            .map { it.trim().trimStart('-', '•', '*', '–', '—', ' ', '\t') }
            .map { it.trimEnd('.', ' ') }
            .filter { it.isNotEmpty() }
            .filter { line ->
                val key = line.lowercase()
                    .trimStart('•', '-', '*', ' ')
                    .trimEnd('.', ' ')
                key !in BARE_CATEGORIES && key.length >= 8
            }
            .distinctBy { it.lowercase() }
    }
}
