package com.example.speechfilter.pipeline

/**
 * Prompts for on-device Gemma.
 *
 * Keep them short and strict: small local models otherwise echo category
 * lists, switch language, or invent content.
 */
object PromptStore {
    /** Light cleanup of Whisper transcript. Must stay in the same language. */
    @Volatile
    var refinePrompt: String = """
Отредактируй расшифровку устной речи на русском.

Разрешено:
- исправить очевидные ошибки распознавания и пунктуацию;
- убрать слова-паразиты (ну, э-э, типа) и чистые повторы;
- разбить на нормальные предложения.

Запрещено:
- переводить на другой язык или вставлять иероглифы/латиницу вместо русских слов;
- добавлять факты, имена, цифры, которых нет во входе;
- писать вступления вроде «Вот ваш текст», «Исправленный вариант»;
- сокращать смысл.

Верни только итоговый русский текст, ничего больше.

Текст:
{{text}}
    """.trimIndent()

    /**
     * Extract concrete facts only. Listing bare category names
     * (задачи / даты / имена …) is explicitly forbidden — that was the
     * failure mode that filled the UI with repeated template labels.
     */
    @Volatile
    var importantPrompt: String = """
Из текста ниже выпиши только конкретные факты, которые человеку полезно помнить:
- договорённости с кем и о чём;
- задачи (кто / что / когда);
- имена и роли;
- даты, время, числа;
- принятые решения;
- открытые вопросы, требующие ответа.

Правила:
1. Каждый пункт — одна короткая строка с фактом из текста, не названием категории.
2. Нельзя писать просто «Задачи», «Даты», «Имена», «Вопросы», «Решения», «Договорённости».
3. Если в тексте нет ни одного конкретного факта — верни ровно одно слово: НЕТ
4. Язык — русский. Без комментариев и заголовков.

Текст:
{{text}}
    """.trimIndent()

    @Volatile
    var dailySummaryPrompt: String = """
Кратко перескажи день по расшифровкам на русском.
Только то, что есть в тексте. Без выдумок.
Структура: темы; договорённости; открытые вопросы.
Если материала почти нет — напиши «Сводки нет».

Материалы:
{{text}}
    """.trimIndent()

    fun fill(template: String, text: String): String =
        template.replace("{{text}}", text)
}
