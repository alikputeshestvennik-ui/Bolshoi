package com.example.speechfilter.ui

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.speechfilter.R
import com.example.speechfilter.data.RecordingStatus
import java.io.File

/** Everything one card needs, already resolved (no DB / file access while binding). */
data class RecordItem(
    val id: String,
    val file: File,
    val timeLabel: String,
    val fromWatch: Boolean,
    val text: String?,
    val important: Boolean,
    val status: RecordingStatus,
    val statusLabel: String,
    /** audio is loaded in the player (playing or paused) */
    val active: Boolean,
    val playing: Boolean
) {
    val playable: Boolean get() = status != RecordingStatus.RECORDING
}

class RecordsAdapter(
    private val onTap: (RecordItem) -> Unit,
    private val onMore: (RecordItem, View) -> Unit
) : ListAdapter<RecordItem, RecordsAdapter.VH>(Diff) {

    object Diff : DiffUtil.ItemCallback<RecordItem>() {
        override fun areItemsTheSame(a: RecordItem, b: RecordItem) = a.id == b.id
        override fun areContentsTheSame(a: RecordItem, b: RecordItem) = a == b
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: ViewGroup = v as ViewGroup
        val overlay: View = v.findViewById(R.id.playingOverlay)
        val sourceIcon: ImageView = v.findViewById(R.id.sourceIcon)
        val time: TextView = v.findViewById(R.id.time)
        val equalizer: EqualizerView = v.findViewById(R.id.equalizer)
        val more: ImageView = v.findViewById(R.id.more)
        val bodyRow: View = v.findViewById(R.id.bodyRow)
        val statusIcon: ImageView = v.findViewById(R.id.statusIcon)
        val body: TextView = v.findViewById(R.id.body)
        val progress: View = v.findViewById(R.id.progress)
        var item: RecordItem? = null
        var iconAnim: ObjectAnimator? = null

        init {
            overlay.post { overlay.pivotY = overlay.height / 2f }
        }

        fun stopIconAnim() {
            iconAnim?.cancel()
            iconAnim = null
            statusIcon.alpha = 1f
            statusIcon.rotation = 0f
        }

        fun setProgress(f: Float) {
            progress.pivotX = 0f
            progress.scaleX = f
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val h = VH(LayoutInflater.from(parent.context).inflate(R.layout.item_record, parent, false))
        Ui.nudge(h.bodyRow, h.body)
        h.bodyRow.setOnClickListener { h.item?.let { if (it.playable) onTap(it) } }
        h.more.setOnClickListener { h.item?.let { i -> onMore(i, h.more) } }
        return h
    }

    override fun onViewRecycled(h: VH) {
        h.stopIconAnim()
        h.item = null
        super.onViewRecycled(h)
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = getItem(position)
        val ctx = h.itemView.context
        val isUpdate = h.item?.id == item.id
        val prev = h.item
        if (isUpdate && prev != null && (prev.text != item.text || prev.status != item.status)) {
            TransitionManager.beginDelayedTransition(h.card, AutoTransition().setDuration(240))
        }
        h.item = item

        h.time.text = item.timeLabel
        h.sourceIcon.setImageResource(if (item.fromWatch) R.drawable.ic_watch else R.drawable.ic_phone)
        Ui.tint(h.sourceIcon, ctx.getColor(R.color.ink_muted))

        if (item.text != null) {
            h.stopIconAnim()
            h.statusIcon.visibility = View.GONE
            h.body.text = item.text
            h.body.setTextColor(ctx.getColor(R.color.ink))
        } else {
            h.statusIcon.visibility = View.VISIBLE
            h.body.text = item.statusLabel
            h.body.setTextColor(ctx.getColor(R.color.ink_muted))
            bindStatusIcon(h, item.status, isUpdate && prev?.status == item.status)
        }

        // playback state: accent bar grows on the left, tint sweeps across the row
        val on = if (item.active) 1f else 0f
        h.overlay.pivotY = h.overlay.height / 2f
        if (isUpdate) {
            h.overlay.animate().scaleY(on).setDuration(280)
                .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
            h.progress.animate().alpha(on).setDuration(220).start()
        } else {
            h.overlay.animate().cancel(); h.progress.animate().cancel()
            h.overlay.scaleY = on
            h.progress.alpha = on
        }
        if (!item.active) h.setProgress(0f)
        Ui.setVisibleAnimated(h.equalizer, item.playing)
    }

    private fun bindStatusIcon(h: VH, status: RecordingStatus, keepAnim: Boolean) {
        val ctx = h.itemView.context
        val (res, color) = when (status) {
            RecordingStatus.RECORDING -> R.drawable.ic_status_recording to R.color.accent_red
            RecordingStatus.RECOGNIZING -> R.drawable.ic_status_processing to R.color.ink
            RecordingStatus.PROCESSING -> R.drawable.ic_status_processing to R.color.ink
            RecordingStatus.QUEUED -> R.drawable.ic_status_queue to R.color.ink_muted
            RecordingStatus.DONE -> R.drawable.ic_status_done to R.color.accent_green
            RecordingStatus.FAILED -> R.drawable.ic_status_error to R.color.accent_red
        }
        h.statusIcon.setImageResource(res)
        Ui.tint(h.statusIcon, ctx.getColor(color))
        if (keepAnim && h.iconAnim != null) return
        h.stopIconAnim()
        when (status) {
            RecordingStatus.RECORDING ->
                h.iconAnim = ObjectAnimator.ofFloat(h.statusIcon, View.ALPHA, 1f, 0.3f).apply {
                    duration = 800
                    repeatCount = ValueAnimator.INFINITE
                    repeatMode = ValueAnimator.REVERSE
                    start()
                }
            RecordingStatus.RECOGNIZING, RecordingStatus.PROCESSING ->
                h.iconAnim = ObjectAnimator.ofFloat(h.statusIcon, View.ROTATION, 0f, 360f).apply {
                    duration = 1000
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    start()
                }
            else -> {
                // one soft pop when a final status appears
                h.statusIcon.scaleX = 0.6f; h.statusIcon.scaleY = 0.6f
                h.statusIcon.animate().scaleX(1f).scaleY(1f).setDuration(260)
                    .setInterpolator(android.view.animation.OvershootInterpolator(2.4f)).start()
            }
        }
    }
}
