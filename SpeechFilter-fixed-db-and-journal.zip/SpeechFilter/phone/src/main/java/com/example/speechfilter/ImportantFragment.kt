package com.example.speechfilter

import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import com.example.speechfilter.data.RecordingsRepository
import com.example.speechfilter.ui.BaseListFragment
import com.example.speechfilter.ui.TextCard
import com.example.speechfilter.ui.TextCardAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** User-owned important recordings. Nothing is inferred automatically. */
class ImportantFragment : BaseListFragment() {

    override val titleText = "Важное"
    override val emptyMessage = "Вы ещё ничего не отметили"
    override val refreshMs = 2500L
    override val emptyIconRes = R.drawable.ic_nav_important

    private val adapter = TextCardAdapter()

    override fun setupList(rv: RecyclerView) {
        rv.adapter = adapter
        subtitle.text = "Отмечено вами"
    }

    override fun refresh() {
        val ctx = context ?: return
        lifecycleScope.launch {
            val rows = withContext(Dispatchers.IO) { RecordingsRepository.loadImportantRows(ctx) }
            if (!isAdded) return@launch
            val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
            adapter.submitList(rows.map { row ->
                TextCard(
                    id = "imp:${row.file.absolutePath}",
                    header = fmt.format(Date(row.startedAt)),
                    body = row.displayText ?: "Запись ещё не расшифрована",
                    iconRes = R.drawable.ic_nav_important,
                    iconColorRes = R.color.accent_amber
                )
            })
            subtitle.text = if (rows.isEmpty()) "Отмечено вами" else "${rows.size} отмечено вами"
            onContentShown(empty = rows.isEmpty())
        }
    }
}
