package com.example.speechfilter.data

import android.content.Context
import com.example.speechfilter.RecordingService
import com.example.speechfilter.pipeline.Transcriber
import java.io.File

enum class RecordingStatus { RECORDING, RECOGNIZING, QUEUED, PROCESSING, DONE, FAILED }

data class RecordingRow(
    val file: File,
    val transcript: TranscriptEntity?,
    val important: Boolean
) {
    val fromWatch: Boolean get() = file.name.contains("_watch_")

    val startedAt: Long
        get() = Regex("(\\d{13})").findAll(file.name).lastOrNull()?.value?.toLongOrNull()
            ?: file.lastModified()

    val displayText: String?
        get() = transcript?.text?.takeIf { it.isNotBlank() }

    val status: RecordingStatus
        get() = when {
            transcript == null && file.name == RecordingService.recordingFileName -> RecordingStatus.RECORDING
            transcript == null && file.name == Transcriber.processingFileName -> RecordingStatus.RECOGNIZING
            transcript == null -> RecordingStatus.QUEUED
            transcript.status == "refined" -> RecordingStatus.DONE
            transcript.status == "failed" -> RecordingStatus.FAILED
            else -> RecordingStatus.PROCESSING
        }

    val statusLabel: String
        get() = when (status) {
            RecordingStatus.RECORDING -> "Идёт запись"
            RecordingStatus.RECOGNIZING -> "Распознаётся"
            RecordingStatus.QUEUED -> "В очереди на распознавание"
            RecordingStatus.PROCESSING -> "В обработке"
            RecordingStatus.DONE -> "Обработано"
            RecordingStatus.FAILED -> "Ошибка распознавания"
        }
}

object RecordingsRepository {

    fun recordingsDir(context: Context): File =
        File(context.getExternalFilesDir(null), "SpeechFilter")

    suspend fun loadRows(context: Context): List<RecordingRow> {
        val db = AppDatabase.get(context)
        val files = recordingsDir(context)
            .listFiles { f -> f.isFile && f.extension.equals("wav", true) }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
        return files.map { f ->
            RecordingRow(f, db.transcripts().byPath(f.absolutePath), db.important().isMarked(f.absolutePath))
        }
    }

    suspend fun loadImportantRows(context: Context): List<RecordingRow> {
        val db = AppDatabase.get(context)
        return db.important().recent(200).mapNotNull { mark ->
            val file = File(mark.filePath)
            if (!file.exists()) {
                db.important().unmark(mark.filePath)
                return@mapNotNull null
            }
            RecordingRow(file, db.transcripts().byPath(file.absolutePath), true)
        }
    }

    suspend fun setImportant(context: Context, file: File, important: Boolean) {
        val dao = AppDatabase.get(context).important()
        if (important) dao.mark(ImportantRecordingEntity(file.absolutePath))
        else dao.unmark(file.absolutePath)
    }

    suspend fun deleteRecording(context: Context, row: RecordingRow) {
        val db = AppDatabase.get(context)
        row.transcript?.let { db.transcripts().deleteById(it.id) }
        db.important().unmark(row.file.absolutePath)
        if (row.file.exists()) row.file.delete()
    }
}
