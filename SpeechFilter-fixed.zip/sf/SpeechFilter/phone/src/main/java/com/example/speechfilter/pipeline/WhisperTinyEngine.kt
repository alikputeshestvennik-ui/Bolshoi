package com.example.speechfilter.pipeline

import android.content.Context
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Offline Whisper-tiny placeholder with warm-up API.
 *
 * Drop model files into filesDir/models/:
 *   - whisper-tiny.bin  (ggml)  OR  whisper-tiny.onnx
 *
 * Wire native whisper.cpp / ONNX session in [transcribeFile] when models are ready.
 * Until then returns a clear status so the pipeline and Room still run end-to-end.
 */
class WhisperTinyEngine(private val context: Context) {

    private val warmed = AtomicBoolean(false)

    fun modelDir(): File = File(context.filesDir, "models").apply { mkdirs() }

    fun modelReady(): Boolean {
        val dir = modelDir()
        return File(dir, "whisper-tiny.bin").exists() ||
            File(dir, "ggml-tiny.bin").exists() ||
            File(dir, "whisper-tiny.onnx").exists()
    }

    /** Preload weights into memory (called by TranscribeWorker every ~10 min). */
    @Synchronized
    fun warmUp(): String {
        if (!modelReady()) {
            warmed.set(false)
            return "Whisper tiny: модель не найдена в ${modelDir().absolutePath}"
        }
        // TODO: load native/ONNX session once
        warmed.set(true)
        return "Whisper tiny: прогрев OK"
    }

    /**
     * Transcribe a 16-bit PCM WAV (our app writes 16 kHz mono).
     * Replace body with real inference when model is integrated.
     */
    @Synchronized
    fun transcribeFile(wav: File): Result<String> {
        if (!wav.exists() || wav.length() < 1000) {
            return Result.failure(IllegalArgumentException("Пустой или короткий файл"))
        }
        if (!modelReady()) {
            return Result.failure(
                IllegalStateException(
                    "Нет модели Whisper tiny. Положите whisper-tiny.bin в ${modelDir()}"
                )
            )
        }
        if (!warmed.get()) warmUp()
        // TODO: real offline inference
        return Result.failure(
            UnsupportedOperationException(
                "Движок Whisper подключён к пайплайну; нативная/ONNX-инференс — следующий шаг"
            )
        )
    }

    fun release() {
        warmed.set(false)
    }
}
