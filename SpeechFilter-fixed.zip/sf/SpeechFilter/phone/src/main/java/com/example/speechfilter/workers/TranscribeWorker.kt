package com.example.speechfilter.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.data.PipelineLogEntity
import com.example.speechfilter.data.TranscriptEntity
import com.example.speechfilter.pipeline.WhisperTinyEngine
import java.io.File

/** Every 10 minutes: warm Whisper and transcribe new WAV files. */
class TranscribeWorker(
    ctx: Context,
    params: WorkerParameters
) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val db = AppDatabase.get(applicationContext)
        val whisper = WhisperTinyEngine(applicationContext)
        return try {
            val warm = whisper.warmUp()
            db.logs().insert(PipelineLogEntity(worker = "transcribe", message = warm))

            val dir = File(applicationContext.getExternalFilesDir(null), "SpeechFilter")
            val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".wav", true) }
                ?.sortedBy { it.lastModified() }
                ?: emptyList()

            var ok = 0
            var skip = 0
            var fail = 0
            for (f in files) {
                if (db.transcripts().byPath(f.absolutePath) != null) {
                    skip++
                    continue
                }
                val source = when {
                    f.name.contains("_watch_") -> "watch"
                    f.name.contains("_phone_") -> "phone"
                    else -> "unknown"
                }
                val r = whisper.transcribeFile(f)
                if (r.isSuccess) {
                    db.transcripts().insert(
                        TranscriptEntity(
                            filePath = f.absolutePath,
                            fileName = f.name,
                            sourceTag = source,
                            text = r.getOrDefault(""),
                            createdAt = f.lastModified(),
                            transcribedAt = System.currentTimeMillis(),
                            status = "pending"
                        )
                    )
                    ok++
                } else {
                    fail++
                    db.logs().insert(
                        PipelineLogEntity(
                            worker = "transcribe",
                            message = "${f.name}: ${r.exceptionOrNull()?.message}"
                        )
                    )
                }
            }
            db.logs().insert(
                PipelineLogEntity(
                    worker = "transcribe",
                    message = "Готово: +$ok, пропуск=$skip, ошибка=$fail, файлов=${files.size}"
                )
            )
            Result.success()
        } catch (t: Throwable) {
            db.logs().insert(
                PipelineLogEntity(worker = "transcribe", message = "crash: ${t.message}")
            )
            Result.retry()
        } finally {
            whisper.release()
            PipelineScheduler.reschedule(
                applicationContext,
                PipelineScheduler.UNIQUE_TRANSCRIBE,
                TranscribeWorker::class.java,
                10
            )
        }
    }
}
