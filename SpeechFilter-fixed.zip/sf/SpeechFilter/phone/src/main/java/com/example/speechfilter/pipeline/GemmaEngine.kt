package com.example.speechfilter.pipeline

import android.content.Context
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Offline Gemma engine placeholder (MediaPipe LLM / GGUF later).
 *
 * Expected model path: filesDir/models/gemma-*.task or gemma-*.gguf
 */
class GemmaEngine(private val context: Context) {

    private val warmed = AtomicBoolean(false)

    fun modelDir(): File = File(context.filesDir, "models").apply { mkdirs() }

    fun modelReady(): Boolean {
        val dir = modelDir()
        return dir.listFiles()?.any {
            val n = it.name.lowercase()
            (n.contains("gemma") && (n.endsWith(".task") || n.endsWith(".gguf") || n.endsWith(".bin")))
        } == true
    }

    @Synchronized
    fun warmUp(): String {
        if (!modelReady()) {
            warmed.set(false)
            return "Gemma: модель не найдена в ${modelDir().absolutePath}"
        }
        warmed.set(true)
        return "Gemma: прогрев OK"
    }

    /**
     * Run prompt+text. Replace with MediaPipe/llama.cpp generate().
     */
    @Synchronized
    fun generate(promptTemplate: String, text: String): Result<String> {
        if (text.isBlank()) return Result.success("")
        if (!modelReady()) {
            return Result.failure(IllegalStateException("Нет модели Gemma в ${modelDir()}"))
        }
        if (!warmed.get()) warmUp()
        val prompt = PromptStore.fill(promptTemplate, text)
        // TODO: real offline generate(prompt)
        return Result.failure(
            UnsupportedOperationException(
                "Gemma в пайплайне; офлайн-инференс — следующий шаг. Промпт length=${prompt.length}"
            )
        )
    }

    fun release() {
        warmed.set(false)
    }
}
