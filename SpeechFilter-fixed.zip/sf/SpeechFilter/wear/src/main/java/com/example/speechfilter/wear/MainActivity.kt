package com.example.speechfilter.wear

import android.app.Activity
import android.os.Bundle

/** Shows only the brand logo. Recording is controlled from the phone. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
