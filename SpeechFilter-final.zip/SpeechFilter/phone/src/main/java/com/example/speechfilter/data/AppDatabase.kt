package com.example.speechfilter.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        TranscriptEntity::class,
        ImportantRecordingEntity::class,
        PipelineLogEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transcripts(): TranscriptDao
    abstract fun important(): ImportantRecordingDao
    abstract fun logs(): PipelineLogDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS important_recordings (filePath TEXT NOT NULL PRIMARY KEY, markedAt INTEGER NOT NULL)")
                db.execSQL("DROP TABLE IF EXISTS important_items")
                db.execSQL("DROP TABLE IF EXISTS daily_summaries")
                db.execSQL("DROP TABLE IF EXISTS refined_texts")
            }
        }

        fun get(ctx: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    ctx.applicationContext,
                    AppDatabase::class.java,
                    "filter_pipeline.db"
                ).addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { instance = it }
            }
    }
}
