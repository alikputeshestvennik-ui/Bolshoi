package com.example.speechfilter

import android.Manifest
import android.animation.ValueAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.speechfilter.pipeline.PowerMode
import com.example.speechfilter.ui.PulseRingView
import com.example.speechfilter.ui.Ui

/** Recording control screen: source can be switched without stopping the session. */
class LaunchFragment : Fragment(R.layout.fragment_launch) {

    private lateinit var status: TextView
    private lateinit var button: ImageView
    private lateinit var pulse: PulseRingView
    private lateinit var sourceLabel: TextView
    private lateinit var sourceDetail: TextView
    private lateinit var sourceIcon: ImageView
    private lateinit var modeBadge: TextView
    private lateinit var modeSubline: TextView
    private lateinit var rows: Map<String, SourceRow>
    private var running = false
    private var buttonColor: Int = 0
    private var shownIndicator: String? = null

    private class SourceRow(val root: View, val icon: ImageView, val label: TextView, val check: ImageView)

    companion object {
        private var selected = "PHONE"
    }

    private val permissionRequest = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) startRecording()
        else setStatus("Нужно разрешение микрофона")
    }

    private val sourceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (view == null) return
            val src = intent?.getStringExtra(RecordingService.EXTRA_SOURCE) ?: return
            val detail = intent.getStringExtra(RecordingService.EXTRA_DETAIL) ?: ""
            if (src == "PHONE" || src == "WATCH") select(src, animate = true, sendToService = false)
            updateSourceIndicator(src, detail)
            setRunning(src != "IDLE" && src != "STOPPED", animate = true)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        status = view.findViewById(R.id.status)
        button = view.findViewById(R.id.startStop)
        pulse = view.findViewById(R.id.pulse)
        sourceLabel = view.findViewById(R.id.sourceLabel)
        sourceDetail = view.findViewById(R.id.sourceDetail)
        sourceIcon = view.findViewById(R.id.sourceIcon)
        modeBadge = view.findViewById(R.id.modeBadge)
        modeSubline = view.findViewById(R.id.modeSubline)
        buttonColor = requireContext().getColor(R.color.ink)

        rows = mapOf(
            "PHONE" to SourceRow(
                view.findViewById(R.id.phoneSource), view.findViewById(R.id.phoneIcon),
                view.findViewById(R.id.phoneLabel), view.findViewById(R.id.phoneCheck)
            ),
            "WATCH" to SourceRow(
                view.findViewById(R.id.watchSource), view.findViewById(R.id.watchIcon),
                view.findViewById(R.id.watchLabel), view.findViewById(R.id.watchCheck)
            )
        )
        rows.forEach { (key, row) ->
            Ui.nudge(row.root, row.label)
            row.root.setOnClickListener {
                select(key, animate = true, sendToService = running)
            }
        }
        select(selected, animate = false, sendToService = false)

        Ui.pressable(button, 0.92f)
        button.setOnClickListener { if (!running) requestStart() else stopRecording() }

        updateModeHero()
        syncFromService()
        Ui.staggerIn(Ui.children(view.findViewById<LinearLayout>(R.id.launchContent)))
    }

    override fun onStart() {
        super.onStart()
        val f = IntentFilter(RecordingService.ACTION_SOURCE)
        if (Build.VERSION.SDK_INT >= 33) {
            requireContext().registerReceiver(sourceReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            requireContext().registerReceiver(sourceReceiver, f)
        }
    }

    override fun onStop() {
        try { requireContext().unregisterReceiver(sourceReceiver) } catch (_: Exception) {}
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        updateModeHero()
        syncFromService()
    }

    private fun updateModeHero() {
        if (!::modeBadge.isInitialized) return
        val ctx = requireContext()
        val active = PowerMode.effective(ctx)
        val accent = if (active == PowerMode.AC) R.color.accent_green else R.color.ink
        modeBadge.text = active.shortTitle
        modeBadge.setTextColor(ctx.getColor(accent))
        modeSubline.text = when (active) {
            PowerMode.ENERGY -> "VAD + запись · Whisper вручную"
            PowerMode.BALANCED -> "VAD + YAMNet · Whisper вручную"
            PowerMode.PERFORMANCE -> "Полная фильтрация · Whisper автоматически"
            PowerMode.AC -> "Максимум · питание подключено"
        }
    }

    private fun select(key: String, animate: Boolean, sendToService: Boolean) {
        if (key != "PHONE" && key != "WATCH") return
        selected = key
        val ctx = requireContext()
        val on = ctx.getColor(R.color.ink)
        val off = ctx.getColor(R.color.ink_muted)
        rows.forEach { (k, row) ->
            val sel = k == key
            val color = if (sel) on else off
            Ui.tint(row.icon, color)
            Ui.tint(row.check, on)
            row.label.setTextColor(color)
            row.label.setTypeface(null, if (sel) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
            val a = if (sel) 1f else 0f
            val sc = if (sel) 1f else 0.4f
            if (animate) {
                row.check.animate().alpha(a).scaleX(sc).scaleY(sc).setDuration(220)
                    .setInterpolator(OvershootInterpolator(2f)).start()
            } else {
                row.check.alpha = a; row.check.scaleX = sc; row.check.scaleY = sc
            }
        }
        if (sendToService) switchSource(key)
    }

    private fun switchSource(key: String) {
        val ctx = requireContext()
        try {
            ContextCompat.startForegroundService(
                ctx,
                Intent(ctx, RecordingService::class.java).putExtra("source", key)
            )
            setStatus(if (key == "WATCH") "Переключаюсь на часы…" else "Переключаюсь на телефон…")
        } catch (_: Exception) {
            setStatus("Не удалось переключить источник")
        }
    }

    private fun requestStart() {
        val need = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) {
            permissionRequest.launch(need.toTypedArray())
            return
        }
        startRecording()
    }

    private fun startRecording() {
        ContextCompat.startForegroundService(
            requireContext(),
            Intent(requireContext(), RecordingService::class.java).putExtra("source", selected)
        )
        setRunning(true, animate = true)
        updateSourceIndicator(selected, "запуск…")
    }

    private fun stopRecording() {
        val i = Intent(requireContext(), RecordingService::class.java)
            .putExtra(RecordingService.EXTRA_STOP, true)
        try {
            ContextCompat.startForegroundService(requireContext(), i)
        } catch (_: Exception) {
            requireContext().stopService(Intent(requireContext(), RecordingService::class.java))
        }
        setRunning(false, animate = true)
        updateSourceIndicator("STOPPED", "")
    }

    private fun syncFromService() {
        if (view == null) return
        val active = RecordingService.sessionActive && RecordingService.activeSource != "IDLE"
        setRunning(active, animate = false)
        if (active) {
            val src = RecordingService.activeSource
            if (src == "WATCH" || src == "PHONE") select(src, animate = false, sendToService = false)
            updateSourceIndicator(src, "")
        } else {
            updateSourceIndicator("IDLE", "")
        }
    }

    private fun setRunning(value: Boolean, animate: Boolean) {
        if (running == value && animate) return
        val changed = running != value
        running = value
        val ctx = requireContext()
        val target = ctx.getColor(if (value) R.color.accent_red else R.color.ink)
        val icon = if (value) R.drawable.ic_stop else R.drawable.ic_play

        pulse.setRingColor(target)
        pulse.setActive(value)
        if (!animate || !changed) {
            button.setImageResource(icon)
            Ui.tint(button, ctx.getColor(R.color.paper_bg))
            button.backgroundTintList = ColorStateList.valueOf(target)
            buttonColor = target
            return
        }
        button.animate().cancel()
        button.animate().scaleX(0.7f).scaleY(0.7f).setDuration(120).withEndAction {
            if (view == null) return@withEndAction
            button.setImageResource(icon)
            Ui.tint(button, ctx.getColor(R.color.paper_bg))
            button.animate().scaleX(1f).scaleY(1f).setDuration(260)
                .setInterpolator(OvershootInterpolator(2.6f)).start()
        }.start()
        val from = buttonColor
        buttonColor = target
        ValueAnimator.ofArgb(from, target).apply {
            duration = 320
            addUpdateListener { button.backgroundTintList = ColorStateList.valueOf(it.animatedValue as Int) }
            start()
        }
    }

    private fun updateSourceIndicator(src: String, detail: String) {
        val ctx = requireContext()
        data class Look(val label: String, val icon: Int, val color: Int, val status: String?)
        val look = when (src) {
            "WATCH" -> Look("Источник: Galaxy Watch 8", R.drawable.ic_watch, R.color.accent_green, "Идёт запись с часов")
            "PHONE" -> Look("Источник: микрофон телефона", R.drawable.ic_phone, R.color.accent_green, "Идёт запись с телефона")
            "STOPPED" -> Look("Источник не активен", R.drawable.ic_empty, R.color.ink_muted, "Запись завершена")
            "IDLE" -> Look("Источник не активен", R.drawable.ic_empty, R.color.ink_muted, null)
            else -> Look("Источник: $src", R.drawable.ic_empty, R.color.ink_muted, null)
        }
        setTextAnimated(sourceLabel, look.label)
        if (detail.isBlank()) {
            if (sourceDetail.visibility == View.VISIBLE) Ui.setVisibleAnimated(sourceDetail, false)
        } else {
            sourceDetail.text = detail
            Ui.setVisibleAnimated(sourceDetail, true)
        }
        Ui.tint(sourceIcon, ctx.getColor(look.color))
        if (shownIndicator != look.label) {
            shownIndicator = look.label
            sourceIcon.setImageResource(look.icon)
            sourceIcon.scaleX = 0.6f; sourceIcon.scaleY = 0.6f
            sourceIcon.animate().scaleX(1f).scaleY(1f).setDuration(260)
                .setInterpolator(OvershootInterpolator(2.4f)).start()
        }
        look.status?.let { setStatus(it) }
        if (src == "IDLE" && look.status == null) setStatus("Готов")
    }

    private fun setStatus(text: String) = setTextAnimated(status, text)

    private fun setTextAnimated(tv: TextView, text: String) {
        if (tv.text.toString() == text) return
        tv.animate().cancel()
        tv.animate().alpha(0f).setDuration(90).withEndAction {
            tv.text = text
            tv.animate().alpha(1f).setDuration(180).start()
        }.start()
    }
}
