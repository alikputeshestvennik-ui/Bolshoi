package com.example.speechfilter

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.data.PipelineLogEntity
import com.example.speechfilter.pipeline.PowerMode
import com.example.speechfilter.pipeline.ReadinessCheck
import com.example.speechfilter.pipeline.WhisperEngine
import com.example.speechfilter.ui.Ui
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Settings: compact power selector, model/readiness window and worker journal. */
class SettingsFragment : Fragment(R.layout.fragment_settings) {

    private lateinit var processingModeEffective: TextView
    private lateinit var modeDescription: TextView
    private lateinit var modeSelector: FrameLayout
    private lateinit var modeIndicator: View
    private lateinit var modeEnergy: TextView
    private lateinit var modeBalanced: TextView
    private lateinit var modePerformance: TextView
    private lateinit var modeAc: TextView

    private val whisper by lazy { WhisperEngine(requireContext().applicationContext) }
    private var modelDialog: Dialog? = null
    private var logDialog: Dialog? = null
    private var logTextView: TextView? = null

    private val uiHandler = Handler(Looper.getMainLooper())
    private val logRefreshRunnable = object : Runnable {
        override fun run() {
            val tv = logTextView
            if (tv != null && logDialog?.isShowing == true) {
                refreshLog(tv)
                uiHandler.postDelayed(this, 2500L)
            }
        }
    }

    private val whisperModelPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        val tv = modelDialog?.findViewById<TextView>(R.id.whisperModelStatus)
        tv?.text = "Whisper: импортирую…"
        lifecycleScope.launch {
            val message = withContext(Dispatchers.IO) {
                whisper.importModel(uri).fold(
                    onSuccess = {
                        val backend = try { whisper.backendInfo() } catch (_: Throwable) { "?" }
                        "Whisper: модель готова (${it.length() / (1024 * 1024)} MB) · $backend"
                    },
                    onFailure = { "Whisper: ошибка импорта — ${it.message}" }
                )
            }
            if (isAdded) tv?.text = message
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        processingModeEffective = view.findViewById(R.id.processingModeEffective)
        modeDescription = view.findViewById(R.id.modeDescription)
        modeSelector = view.findViewById(R.id.modeSelector)
        modeIndicator = view.findViewById(R.id.modeSelectorIndicator)
        modeEnergy = view.findViewById(R.id.modeEnergy)
        modeBalanced = view.findViewById(R.id.modeBalanced)
        modePerformance = view.findViewById(R.id.modePerformance)
        modeAc = view.findViewById(R.id.modeAc)

        modeEnergy.setOnClickListener { setUserMode(PowerMode.ENERGY, animate = true) }
        modeBalanced.setOnClickListener { setUserMode(PowerMode.BALANCED, animate = true) }
        modePerformance.setOnClickListener { setUserMode(PowerMode.PERFORMANCE, animate = true) }

        view.findViewById<View>(R.id.modelsToolsRow).setOnClickListener { showModelToolsDialog() }
        view.findViewById<View>(R.id.logRow).setOnClickListener { showLogDialog() }

        updateProcessingModeUi(animate = false)
        Ui.staggerIn(Ui.children(view.findViewById<LinearLayout>(R.id.settingsContent)), step = 60)
    }

    override fun onResume() {
        super.onResume()
        updateProcessingModeUi(animate = false)
    }

    override fun onStop() {
        uiHandler.removeCallbacks(logRefreshRunnable)
        super.onStop()
    }

    private fun setUserMode(mode: PowerMode, animate: Boolean) {
        val ctx = requireContext()
        PowerMode.setUserSelected(ctx, mode)
        ctx.sendBroadcast(Intent(RecordingService.ACTION_MODE_CHANGED).setPackage(ctx.packageName))
        updateProcessingModeUi(animate)
    }

    private fun updateProcessingModeUi(animate: Boolean) {
        if (!::modeSelector.isInitialized) return
        val ctx = requireContext()
        val user = PowerMode.userSelected(ctx).let { if (it == PowerMode.AC) PowerMode.BALANCED else it }
        val effective = PowerMode.effective(ctx)
        val charging = effective == PowerMode.AC
        val targetIndex = when {
            charging -> 3
            effective == PowerMode.ENERGY && user != PowerMode.ENERGY -> 0
            else -> userIndex(user)
        }

        modeSelector.post {
            val width = modeSelector.width
            if (width <= 0) return@post
            val segment = width / 4f
            modeIndicator.layoutParams = modeIndicator.layoutParams.apply {
                this.width = (segment - Ui.dp(modeSelector, 6)).toInt()
            }
            modeIndicator.translationX = Ui.dp(modeSelector, 3).toFloat() + segment * targetIndex
            modeIndicator.backgroundTintList = android.content.res.ColorStateList.valueOf(
                ctx.getColor(if (charging) R.color.accent_green else R.color.ink)
            )
            if (animate) {
                modeIndicator.animate().cancel()
                modeIndicator.animate()
                    .translationX(Ui.dp(modeSelector, 3).toFloat() + segment * targetIndex)
                    .setDuration(300)
                    .setInterpolator(android.view.animation.OvershootInterpolator(1.4f))
                    .start()
            }
        }

        val selected = listOf(modeEnergy, modeBalanced, modePerformance, modeAc)
        selected.forEachIndexed { index, tv ->
            val active = index == targetIndex
            tv.setTextColor(ctx.getColor(if (active) R.color.paper_bg else R.color.ink_muted))
            tv.alpha = if (charging && index == 3) 1f else 1f
            tv.setTypeface(null, if (active) Typeface.BOLD else Typeface.NORMAL)
        }
        modeAc.setTextColor(ctx.getColor(if (charging) R.color.paper_bg else R.color.ink_muted))

        processingModeEffective.text = when {
            charging -> "Сейчас: Максимум — питание подключено."
            effective == PowerMode.ENERGY && user != PowerMode.ENERGY ->
                "Сейчас: Эко+ — заряд ${batteryPercent()}%, автоматический порог ${PowerMode.lowBatteryThresholdPercent()}%."
            else -> "Сейчас: ${user.title}."
        }
        modeDescription.text = when (user) {
            PowerMode.ENERGY -> "Минимум вычислений. VAD и запись работают постоянно; Whisper запускается только вручную."
            PowerMode.BALANCED -> "VAD + YAMNet. Whisper остаётся ручным, чтобы не держать CPU под нагрузкой 24/7."
            PowerMode.PERFORMANCE -> "Полная фильтрация и автоматическая расшифровка после каждого речевого сегмента."
            PowerMode.AC -> "Полная обработка при питании от сети. Используется автоматически при подключении зарядки."
        }
    }

    private fun userIndex(mode: PowerMode): Int = when (mode) {
        PowerMode.ENERGY -> 0
        PowerMode.BALANCED -> 1
        PowerMode.PERFORMANCE -> 2
        PowerMode.AC -> 3
    }

    private fun batteryPercent(): Int {
        val bm = requireContext().getSystemService(android.os.BatteryManager::class.java)
        return try { bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1 } catch (_: Throwable) { -1 }
    }

    private fun showModelToolsDialog() {
        if (modelDialog?.isShowing == true) return
        val dialog = Dialog(requireContext())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_model_tools)
        dialog.setCancelable(true)
        modelDialog = dialog

        dialog.findViewById<Button>(R.id.importWhisperModel).setOnClickListener {
            whisperModelPicker.launch(arrayOf("application/octet-stream", "application/x-binary", "*/*"))
        }
        dialog.findViewById<Button>(R.id.runReadinessTest).setOnClickListener { runReadinessTest(dialog) }
        dialog.findViewById<TextView>(R.id.modelToolsClose).setOnClickListener { dialog.dismiss() }
        updateDialogModelStatus(dialog)

        dialog.setOnDismissListener {
            modelDialog = null
        }
        dialog.show()
        styleDialog(dialog, widthFraction = 0.92f, heightFraction = 0.76f)
    }

    private fun updateDialogModelStatus(dialog: Dialog) {
        val whisperTv = dialog.findViewById<TextView>(R.id.whisperModelStatus)
        whisperTv.text = if (whisper.modelReady()) {
            val mb = whisper.modelDir().resolve("whisper.base").length() / (1024 * 1024)
            val backend = try { whisper.backendInfo() } catch (_: Throwable) { "?" }
            "Whisper: модель готова ($mb MB) · $backend"
        } else "Whisper: модель не импортирована"
    }

    private fun runReadinessTest(dialog: Dialog) {
        val btn = dialog.findViewById<Button>(R.id.runReadinessTest)
        btn.isEnabled = false
        btn.text = "Проверка…"
        lifecycleScope.launch {
            val items = withContext(Dispatchers.IO) {
                ReadinessCheck.run(requireContext().applicationContext)
            }
            if (!isAdded || !dialog.isShowing) return@launch
            showReadiness(dialog.findViewById(R.id.readinessRows), items)
            btn.isEnabled = true
            btn.text = "Проверить"
        }
    }

    private fun showReadiness(container: LinearLayout, items: List<ReadinessCheck.Item>) {
        container.removeAllViews()
        val overall = ReadinessCheck.overallLabel(items)
        val worst = when {
            items.any { it.level == ReadinessCheck.Level.FAIL } -> ReadinessCheck.Level.FAIL
            items.any { it.level == ReadinessCheck.Level.WARN } -> ReadinessCheck.Level.WARN
            else -> ReadinessCheck.Level.OK
        }
        val views = mutableListOf<View>()
        views += readinessRow(worst, overall, bold = true)
        items.forEach { views += readinessRow(it.level, it.label, bold = false) }
        views.forEach { container.addView(it) }
        Ui.staggerIn(views, step = 40)
    }

    private fun readinessRow(level: ReadinessCheck.Level, text: String, bold: Boolean): View {
        val ctx = requireContext()
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            setPadding(0, Ui.dp(this, 9), 0, 0)
        }
        val (res, color) = when (level) {
            ReadinessCheck.Level.OK -> R.drawable.ic_status_done to R.color.accent_green
            ReadinessCheck.Level.WARN -> R.drawable.ic_status_queue to R.color.accent_amber
            ReadinessCheck.Level.FAIL -> R.drawable.ic_status_error to R.color.accent_red
        }
        val icon = ImageView(ctx).apply {
            setImageResource(res)
            Ui.tint(this, ctx.getColor(color))
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        row.addView(icon, LinearLayout.LayoutParams(Ui.dp(row, 20), Ui.dp(row, 20)).apply { topMargin = Ui.dp(row, 1) })
        val tv = TextView(ctx).apply {
            this.text = text
            textSize = if (bold) 15f else 14f
            setTextColor(ctx.getColor(if (bold) R.color.ink else R.color.ink_muted))
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
        row.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(row, 10)
        })
        return row
    }

    private fun showLogDialog() {
        if (logDialog?.isShowing == true) return
        val dialog = Dialog(requireContext())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_worker_log)
        dialog.setCancelable(true)
        logDialog = dialog
        logTextView = dialog.findViewById(R.id.pipelineLogText)
        dialog.findViewById<TextView>(R.id.logClose).setOnClickListener { dialog.dismiss() }
        dialog.setOnDismissListener {
            uiHandler.removeCallbacks(logRefreshRunnable)
            logTextView = null
            logDialog = null
        }
        dialog.show()
        styleDialog(dialog, widthFraction = 0.94f, heightFraction = 0.82f)
        refreshLog(logTextView!!)
        uiHandler.removeCallbacks(logRefreshRunnable)
        uiHandler.postDelayed(logRefreshRunnable, 2500L)
    }

    private fun refreshLog(tv: TextView) {
        val ctx = context ?: return
        lifecycleScope.launch {
            val since = System.currentTimeMillis() - ONE_HOUR_MS
            val logs = withContext(Dispatchers.IO) { AppDatabase.get(ctx).logs().recentSince(since) }
            if (!isAdded || logTextView !== tv) return@launch
            tv.text = if (logs.isEmpty()) {
                "За последний час записей нет"
            } else {
                logs.joinToString("\n") { log: PipelineLogEntity ->
                    "[${formatTime(log.at)}] ${workerLabel(log.worker)}: ${log.message}"
                }
            }
        }
    }

    private fun workerLabel(worker: String): String = when (worker) {
        "record" -> "Запись"
        "transcribe" -> "Транскрипция"
        "refine" -> "Обработка"
        "important" -> "Важное"
        "daily" -> "Сводка дня"
        else -> worker
    }

    private fun formatTime(ms: Long): String =
        SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(ms))

    private fun displayNameOf(uri: Uri): String? =
        requireContext().contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
        }

    private fun styleDialog(dialog: Dialog, widthFraction: Float, heightFraction: Float) {
        dialog.window?.let { window ->
            window.setBackgroundDrawableResource(R.drawable.bg_card_static)
            window.decorView.setPadding(0, 0, 0, 0)
            val metrics = resources.displayMetrics
            window.setLayout(
                (metrics.widthPixels * widthFraction).toInt(),
                (metrics.heightPixels * heightFraction).toInt()
            )
        }
    }

    private companion object {
        const val ONE_HOUR_MS = 60L * 60L * 1000L
    }
}
