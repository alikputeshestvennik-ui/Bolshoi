package com.example.speechfilter

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.view.animation.OvershootInterpolator
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

/**
 * Thin shell hosting four pages: Launch, Records, Important and Settings.
 * The bottom bar is icon-only.
 */
class MainActivity : AppCompatActivity() {

    private class Tab(val id: Int, val create: () -> Fragment)

    private val tabs = listOf(
        Tab(R.id.nav_launch) { LaunchFragment() },
        Tab(R.id.nav_records) { RecordsFragment() },
        Tab(R.id.nav_important) { ImportantFragment() },
        Tab(R.id.nav_settings) { SettingsFragment() }
    )

    private var currentIndex = 0
    private lateinit var nav: BottomNavigationView
    private lateinit var indicator: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        val container = findViewById<View>(R.id.screenContainer)
        val navBar = findViewById<View>(R.id.navBar)
        nav = findViewById(R.id.bottomNav)
        indicator = findViewById(R.id.navIndicator)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { _, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            container.updatePadding(top = bars.top, left = bars.left, right = bars.right)
            navBar.updatePadding(bottom = bars.bottom, left = bars.left, right = bars.right)
            insets
        }

        currentIndex = savedInstanceState?.getInt(KEY_TAB, 0) ?: 0

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.screenContainer, tabs[0].create())
                .commit()
            requestIgnoreBatteryOptimizations()
        } else {
            nav.selectedItemId = tabs[currentIndex].id
        }

        nav.setOnItemSelectedListener { item ->
            val idx = tabs.indexOfFirst { it.id == item.itemId }
            if (idx < 0) return@setOnItemSelectedListener false
            showTab(idx)
            true
        }

        // keep the sliding indicator glued to the selected icon (also after rotation)
        nav.addOnLayoutChangeListener { _, left, _, right, _, oldLeft, _, oldRight, _ ->
            if (right - left != oldRight - oldLeft) moveIndicator(currentIndex, animate = false)
        }
        nav.post { moveIndicator(currentIndex, animate = false) }
    }

    private fun showTab(idx: Int) {
        if (idx == currentIndex) return
        val forward = idx > currentIndex
        currentIndex = idx
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(
                if (forward) R.anim.tab_in_from_right else R.anim.tab_in_from_left,
                if (forward) R.anim.tab_out_to_left else R.anim.tab_out_to_right
            )
            .replace(R.id.screenContainer, tabs[idx].create())
            .commit()
        moveIndicator(idx, animate = true)
        // small bounce of the tapped icon
        nav.findViewById<View>(tabs[idx].id)?.let { v ->
            v.scaleX = 0.8f; v.scaleY = 0.8f
            v.animate().scaleX(1f).scaleY(1f).setDuration(320)
                .setInterpolator(OvershootInterpolator(3f)).start()
        }
    }

    private fun moveIndicator(idx: Int, animate: Boolean) {
        val w = nav.width
        if (w == 0) return
        val itemW = w / tabs.size.toFloat()
        val target = itemW * (idx + 0.5f) - indicator.width / 2f
        if (animate) {
            indicator.animate().translationX(target).setDuration(320)
                .setInterpolator(OvershootInterpolator(1.6f)).start()
        } else {
            indicator.animate().cancel()
            indicator.translationX = target
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_TAB, currentIndex)
    }

    /**
     * For "start and forget, 24/7, just keep it charged" to actually hold up,
     * Android's own Doze battery optimization must not be allowed to kill
     * RecordingService in the background. This asks for the standard
     * exemption once, on first launch.
     *
     * NOTE this does NOT cover Samsung's separate OneUI "Sleeping apps" /
     * "Deep sleeping apps" battery manager — that's a Samsung-specific list
     * with no public API to set programmatically. If recording still stops
     * unexpectedly after granting this, also open Settings → Battery →
     * Background usage limits and move this app to "Never sleeping apps".
     */
    private fun requestIgnoreBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        try {
            val pm = getSystemService(PowerManager::class.java)
            if (pm?.isIgnoringBatteryOptimizations(packageName) == true) return
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        PlaybackController.release()
        super.onDestroy()
    }

    private companion object {
        const val KEY_TAB = "tab"
    }
}
