package ru.routeplanner

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var runOcr: Button
    private var selected: List<Uri> = emptyList()
    private var tess: TessBaseAPI? = null

    private val picker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        selected = uris
        runOcr.isEnabled = uris.isNotEmpty()
        status.text = if (uris.isEmpty()) "Фото не выбраны." else "Выбрано страниц: ${uris.size}"
        result.text = ""
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        result = findViewById(R.id.result)
        runOcr = findViewById(R.id.runOcr)

        findViewById<Button>(R.id.selectPhotos).setOnClickListener {
            picker.launch(arrayOf("image/jpeg", "image/png", "image/webp"))
        }
        runOcr.setOnClickListener { runOcr() }
    }

    private fun runOcr() {
        runOcr.isEnabled = false
        status.text = "Подготовка OCR…"
        lifecycleScope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    prepareTessdata()
                    val api = TessBaseAPI()
                    tess = api
                    val ok = api.init(filesDir.absolutePath, "rus")
                    if (!ok) error("Не удалось инициализировать русский OCR")

                    val out = StringBuilder()
                    selected.forEachIndexed { index, uri ->
                        val original = loadBitmap(uri)
                        val prepared = preprocessForOcr(original)
                        out.append("\n===== СТРАНИЦА ${index + 1} =====\n")
                        out.append("\n--- Табличный режим ---\n")
                        api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SPARSE_TEXT)
                        api.setVariable("preserve_interword_spaces", "1")
                        api.setImage(prepared)
                        out.append(api.getUTF8Text() ?: "")
                        api.clear()

                        out.append("\n--- Режим страницы ---\n")
                        api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
                        api.setImage(prepared)
                        out.append(api.getUTF8Text() ?: "")
                        api.clear()

                        prepared.recycle()
                        if (original !== prepared) original.recycle()
                    }
                    api.end()
                    out.toString()
                }
                result.text = text
                status.text = "OCR завершён. Страниц: ${selected.size}"
            } catch (e: Exception) {
                status.text = "Ошибка OCR"
                result.text = e.stackTraceToString()
            } finally {
                runOcr.isEnabled = selected.isNotEmpty()
            }
        }
    }

    private fun prepareTessdata() {
        val dir = File(filesDir, "tessdata")
        if (!dir.exists()) dir.mkdirs()
        val rus = File(dir, "rus.traineddata")
        if (!rus.exists()) {
            assets.open("tessdata/rus.traineddata").use { input ->
                FileOutputStream(rus).use { output -> input.copyTo(output) }
            }
        }
    }

    private fun loadBitmap(uri: Uri): Bitmap {
        val input = contentResolver.openInputStream(uri) ?: error("Не удалось открыть $uri")
        val original = input.use { BitmapFactory.decodeStream(it) }
            ?: error("Не удалось декодировать изображение")
        return rotateFromExif(uri, original)
    }

    private fun rotateFromExif(uri: Uri, bitmap: Bitmap): Bitmap {
        return try {
            val input = contentResolver.openInputStream(uri) ?: return bitmap
            val orientation = androidx.exifinterface.media.ExifInterface(input).getAttributeInt(
                androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,
                androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL
            )
            input.close()
            val degrees = when (orientation) {
                androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (degrees == 0f) bitmap else {
                val matrix = Matrix().apply { postRotate(degrees) }
                Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                    .also { if (it !== bitmap) bitmap.recycle() }
            }
        } catch (_: Exception) {
            bitmap
        }
    }

    /** Подготовка фотографии маршрутного листа: масштабирование + grayscale + контраст. */
    private fun preprocessForOcr(source: Bitmap): Bitmap {
        val maxSide = 2600
        val scale = minOf(1f, maxSide.toFloat() / maxOf(source.width, source.height))
        val w = (source.width * scale).toInt().coerceAtLeast(1)
        val h = (source.height * scale).toInt().coerceAtLeast(1)
        val scaled = if (w != source.width || h != source.height) {
            Bitmap.createScaledBitmap(source, w, h, true)
        } else source

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(w * h)
        scaled.getPixels(pixels, 0, w, 0, 0, w, h)
        for (i in pixels.indices) {
            val c = pixels[i]
            val r = Color.red(c)
            val g = Color.green(c)
            val b = Color.blue(c)
            var gray = (0.299f * r + 0.587f * g + 0.114f * b).toInt()
            // Умеренное усиление контраста вокруг середины серого.
            gray = ((gray - 128) * 1.35f + 128f).toInt().coerceIn(0, 255)
            pixels[i] = Color.rgb(gray, gray, gray)
        }
        out.setPixels(pixels, 0, w, 0, 0, w, h)
        if (scaled !== source) scaled.recycle()
        return out
    }

    override fun onDestroy() {
        tess?.end()
        tess = null
        super.onDestroy()
    }
}
