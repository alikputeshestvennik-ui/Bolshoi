package com.example.speechfilter.ui

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.speechfilter.R
import com.example.speechfilter.data.RecordingStatus
import com.example.speechfilter.pipeline.Seg
import com.example.speechfilter.pipeline.WordSpan
import com.example.speechfilter.search.RecordSearch
import java.io.File

/** Everything one card needs, already resolved (no DB / file access while binding). */
data class RecordItem(
    val id: String,
    val file: File,
    val timeLabel: String,
    val fromWatch: Boolean,
    val compressed: Boolean,
    val text: String?,
    val important: Boolean,
    val status: RecordingStatus,
    val statusLabel: String,
    /** audio is loaded in the player (playing or paused) */
    val active: Boolean,
    val playing: Boolean,
    /** normalized search words to highlight in [text] */
    val highlight: List<String> = emptyList(),
    /** Whisper segments that contain the search words (tappable timecodes) */
    val hits: List<Seg> = emptyList(),
    /** every word with its position in [text] and its time in the audio (tap a word / karaoke) */
    val words: List<WordSpan> = emptyList()
) {
    val playable: Boolean get() = status != RecordingStatus.RECORDING
}

class RecordsAdapter(
    private val onTap: (RecordItem) -> Unit,
    private val onMore: (RecordItem, View) -> Unit,
    private val onHit: (RecordItem, Seg) -> Unit = { _, _ -> },
    private val onWord: (RecordItem, WordSpan) -> Unit = { _, _ -> }
) : ListAdapter<RecordItem, RecordsAdapter.VH>(Diff) {

    object Diff : DiffUtil.ItemCallback<RecordItem>() {
        override fun areItemsTheSame(a: RecordItem, b: RecordItem) = a.id == b.id
        override fun areContentsTheSame(a: RecordItem, b: RecordItem) = a == b
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: ViewGroup = v as ViewGroup
        val overlay: View = v.findViewById(R.id.playingOverlay)
        val sourceIcon: ImageView = v.findViewById(R.id.sourceIcon)
        val time: TextView = v.findViewById(R.id.time)
        val equalizer: EqualizerView = v.findViewById(R.id.equalizer)
        val compressedBadge: View = v.findViewById(R.id.compressedBadge)
        val compressedIcon: ImageView = v.findViewById(R.id.compressedIcon)
        val importantStar: ImageView = v.findViewById(R.id.importantStar)
        val more: ImageView = v.findViewById(R.id.more)
        val bodyRow: View = v.findViewById(R.id.bodyRow)
        val statusIcon: ImageView = v.findViewById(R.id.statusIcon)
        val body: TextView = v.findViewById(R.id.body)
        val progress: View = v.findViewById(R.id.progress)
        val hitsScroll: View = v.findViewById(R.id.hitsScroll)
        val hits: android.widget.LinearLayout = v.findViewById(R.id.hits)
        var item: RecordItem? = null
        var iconAnim: ObjectAnimator? = null

        // tap-a-word / karaoke state
        var words: List<WordSpan> = emptyList()
        var touchX = 0f
        var touchY = 0f
        var curWord = -1
        private var curBg: Any? = null
        private var curFg: Any? = null

        /** The word under the last touch, or null when the tap was beside the text. */
        fun wordAtTouch(): WordSpan? {
            if (words.isEmpty()) return null
            val lay = body.layout ?: return null
            val x = touchX - body.totalPaddingLeft + body.scrollX
            val y = touchY - body.totalPaddingTop + body.scrollY
            if (y < 0 || y > lay.height) return null
            val line = lay.getLineForVertical(y.toInt())
            val off = lay.getOffsetForHorizontal(line, x)
            return words.firstOrNull { off >= it.start && off <= it.end }
        }

        fun resetWord() {
            curWord = -1; curBg = null; curFg = null
        }

        /** Karaoke: mark the word being spoken at [posMs] (no bold, so the text never reflows). */
        fun updateWord(posMs: Long) {
            if (words.isEmpty()) return
            var lo = 0; var hi = words.size - 1; var idx = -1
            while (lo <= hi) {
                val mid = (lo + hi) ushr 1
                if (words[mid].startMs <= posMs) { idx = mid; lo = mid + 1 } else hi = mid - 1
            }
            setCurrentWord(idx)
        }

        fun setCurrentWord(idx: Int) {
            if (idx == curWord) return
            val sp = body.text as? android.text.Spannable ?: return
            curBg?.let { sp.removeSpan(it) }
            curFg?.let { sp.removeSpan(it) }
            curBg = null; curFg = null
            curWord = idx
            val w = words.getOrNull(idx) ?: return
            if (w.end > sp.length) return
            val ctx = body.context
            curBg = android.text.style.BackgroundColorSpan(ctx.getColor(R.color.search_chip_bg))
            curFg = android.text.style.ForegroundColorSpan(ctx.getColor(R.color.accent_search))
            sp.setSpan(curBg, w.start, w.end, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sp.setSpan(curFg, w.start, w.end, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }

        init {
            overlay.post { overlay.pivotY = overlay.height / 2f }
        }

        fun stopIconAnim() {
            iconAnim?.cancel()
            iconAnim = null
            statusIcon.alpha = 1f
            statusIcon.rotation = 0f
        }

        fun setProgress(f: Float) {
            progress.pivotX = 0f
            progress.scaleX = f
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val h = VH(LayoutInflater.from(parent.context).inflate(R.layout.item_record, parent, false))
        Ui.nudge(h.bodyRow, h.body)
        // remember where the finger went down (the touch itself still falls through to bodyRow)
        h.body.setOnTouchListener { _, e ->
            if (e.actionMasked == android.view.MotionEvent.ACTION_DOWN) { h.touchX = e.x; h.touchY = e.y }
            false
        }
        h.bodyRow.setOnClickListener {
            val rec = h.item ?: return@setOnClickListener
            if (!rec.playable) return@setOnClickListener
            val w = h.wordAtTouch()
            val idx = if (w == null) -1 else h.words.indexOf(w)
            // a word: play from it; the word that is already highlighted, or empty space: play/pause
            if (w != null && !(rec.active && idx == h.curWord)) onWord(rec, w) else onTap(rec)
        }
        h.more.setOnClickListener { h.item?.let { i -> onMore(i, h.more) } }
        return h
    }

    override fun onViewRecycled(h: VH) {
        h.stopIconAnim()
        h.item = null
        super.onViewRecycled(h)
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = getItem(position)
        val ctx = h.itemView.context
        val isUpdate = h.item?.id == item.id
        val prev = h.item
        if (isUpdate && prev != null && (prev.text != item.text || prev.status != item.status)) {
            TransitionManager.beginDelayedTransition(h.card, AutoTransition().setDuration(240))
        }
        h.item = item

        h.time.text = item.timeLabel
        h.sourceIcon.setImageResource(if (item.fromWatch) R.drawable.ic_watch else R.drawable.ic_phone)
        Ui.tint(h.sourceIcon, ctx.getColor(R.color.ink_muted))

        if (item.compressed) {
            h.compressedBadge.visibility = View.VISIBLE
            Ui.tint(h.compressedIcon, ctx.getColor(R.color.ink_muted))
        } else {
            h.compressedBadge.visibility = View.GONE
        }

        // Star next to the three-dot menu when the card is marked important
        if (item.important) {
            h.importantStar.visibility = View.VISIBLE
            Ui.tint(h.importantStar, ctx.getColor(R.color.accent_amber))
        } else {
            h.importantStar.visibility = View.GONE
        }

        if (item.text != null) {
            h.stopIconAnim()
            h.statusIcon.visibility = View.GONE
            val shown: CharSequence = if (item.highlight.isEmpty()) item.text else
                RecordSearch.highlight(
                    item.text, item.highlight,
                    ctx.getColor(R.color.search_highlight_bg), ctx.getColor(R.color.accent_search)
                )
            h.words = item.words
            h.resetWord()
            h.body.setText(shown, TextView.BufferType.SPANNABLE)
            h.body.setTextColor(ctx.getColor(R.color.ink))
        } else {
            h.statusIcon.visibility = View.VISIBLE
            h.words = emptyList()
            h.resetWord()
            h.body.text = item.statusLabel
            h.body.setTextColor(ctx.getColor(R.color.ink_muted))
            bindStatusIcon(h, item.status, isUpdate && prev?.status == item.status)
        }

        bindHits(h, item)

        // playback state: accent bar grows on the left, tint sweeps across the row
        val on = if (item.active) 1f else 0f
        h.overlay.pivotY = h.overlay.height / 2f
        if (isUpdate) {
            h.overlay.animate().scaleY(on).setDuration(280)
                .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
            h.progress.animate().alpha(on).setDuration(220).start()
        } else {
            h.overlay.animate().cancel(); h.progress.animate().cancel()
            h.overlay.scaleY = on
            h.progress.alpha = on
        }
        if (!item.active) h.setProgress(0f)
        Ui.setVisibleAnimated(h.equalizer, item.playing)
    }

    /** Colored timecode chips under the text: tap plays just that phrase. */
    private fun bindHits(h: VH, item: RecordItem) {
        val ctx = h.itemView.context
        val hasHits = item.text != null && item.hits.isNotEmpty()
        val d = ctx.resources.displayMetrics.density
        h.bodyRow.setPadding(
            (20 * d).toInt(), (4 * d).toInt(), (20 * d).toInt(),
            ((if (hasHits) 10 else 18) * d).toInt()
        )
        h.hits.removeAllViews()
        if (!hasHits) {
            h.hitsScroll.visibility = View.GONE
            return
        }
        h.hitsScroll.visibility = View.VISIBLE
        val accent = ctx.getColor(R.color.accent_search)
        for (seg in item.hits) {
            val chip = TextView(ctx).apply {
                text = RecordSearch.formatTime(seg.startMs)
                setTextColor(accent)
                textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = android.view.Gravity.CENTER_VERTICAL
                compoundDrawablePadding = (5 * d).toInt()
                setPadding((10 * d).toInt(), (6 * d).toInt(), (12 * d).toInt(), (6 * d).toInt())
                setBackgroundResource(R.drawable.bg_chip_hit)
                val icon = androidx.core.graphics.drawable.DrawableCompat.wrap(
                    ctx.getDrawable(R.drawable.ic_play)!!.mutate()
                )
                androidx.core.graphics.drawable.DrawableCompat.setTint(icon, accent)
                val sz = (11 * d).toInt()
                icon.setBounds(0, 0, sz, sz)
                setCompoundDrawablesRelative(icon, null, null, null)
                contentDescription = "Воспроизвести с ${RecordSearch.formatTime(seg.startMs)}"
                setOnClickListener { onHit(item, seg) }
            }
            val lp = android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = (8 * d).toInt() }
            h.hits.addView(chip, lp)
        }
    }

    private fun bindStatusIcon(h: VH, status: RecordingStatus, keepAnim: Boolean) {
        val ctx = h.itemView.context
        val (res, color) = when (status) {
            RecordingStatus.RECORDING -> R.drawable.ic_status_recording to R.color.accent_red
            RecordingStatus.RECOGNIZING -> R.drawable.ic_status_processing to R.color.ink
            RecordingStatus.PROCESSING -> R.drawable.ic_status_processing to R.color.ink
            RecordingStatus.QUEUED -> R.drawable.ic_status_queue to R.color.ink_muted
            RecordingStatus.DONE -> R.drawable.ic_status_done to R.color.accent_green
            RecordingStatus.FAILED -> R.drawable.ic_status_error to R.color.accent_red
        }
        h.statusIcon.setImageResource(res)
        Ui.tint(h.statusIcon, ctx.getColor(color))
        if (keepAnim && h.iconAnim != null) return
        h.stopIconAnim()
        when (status) {
            RecordingStatus.RECORDING ->
                h.iconAnim = ObjectAnimator.ofFloat(h.statusIcon, View.ALPHA, 1f, 0.3f).apply {
                    duration = 800
                    repeatCount = ValueAnimator.INFINITE
                    repeatMode = ValueAnimator.REVERSE
                    start()
                }
            RecordingStatus.RECOGNIZING, RecordingStatus.PROCESSING ->
                h.iconAnim = ObjectAnimator.ofFloat(h.statusIcon, View.ROTATION, 0f, 360f).apply {
                    duration = 1000
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    start()
                }
            else -> {
                // one soft pop when a final status appears
                h.statusIcon.scaleX = 0.6f; h.statusIcon.scaleY = 0.6f
                h.statusIcon.animate().scaleX(1f).scaleY(1f).setDuration(260)
                    .setInterpolator(android.view.animation.OvershootInterpolator(2.4f)).start()
            }
        }
    }
}
