package com.example.speechfilter

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.speechfilter.data.RecordingRow
import com.example.speechfilter.data.RecordingsRepository
import com.example.speechfilter.ui.BaseListFragment
import com.example.speechfilter.pipeline.SegmentsCodec
import com.example.speechfilter.pipeline.WordSpan
import com.example.speechfilter.pipeline.WordTimes
import com.example.speechfilter.search.ParsedQuery
import com.example.speechfilter.search.RecordSearch
import com.example.speechfilter.ui.RecordItem
import com.example.speechfilter.ui.SearchBarController
import com.example.speechfilter.ui.RecordsAdapter
import com.example.speechfilter.ui.Ui
import com.example.speechfilter.pipeline.PowerMode
import com.example.speechfilter.pipeline.Transcriber
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * The feed of recordings. Each recording is one seamless card: date/time and a
 * three-dot menu (copy text / export / delete) as the header, the transcript or
 * the processing status below. Tapping the text or status plays / pauses audio.
 */
class RecordsFragment : BaseListFragment() {

    override val titleText = "Записи"
    override val emptyMessage = "Записей пока нет"
    override val refreshMs = 2000L
    override val emptyIconRes = R.drawable.ic_nav_records

    private lateinit var adapter: RecordsAdapter
    private var rows: List<RecordingRow> = emptyList()
    private var menuPopup: PopupWindow? = null
    private var search: SearchBarController? = null
    private var parsed: ParsedQuery = ParsedQuery.EMPTY
    private var scrollTopNext = false

    /** word spans per file; recomputed only when the transcript text or its segments change */
    private class WordsEntry(val text: String, val segments: String?, val spans: List<WordSpan>)
    private val wordsCache = HashMap<String, WordsEntry>()

    private val progressTick = object : Runnable {
        override fun run() {
            var any = false
            if (view == null) return
            for (i in 0 until list.childCount) {
                val h = list.getChildViewHolder(list.getChildAt(i)) as? RecordsAdapter.VH ?: continue
                val item = h.item ?: continue
                if (item.active) {
                    any = true
                    h.setProgress(PlaybackController.progress(item.file))
                    h.updateWord(PlaybackController.positionMs(item.file))
                }
            }
            if (any) list.postOnAnimation(this)
        }
    }

    override fun setupList(rv: RecyclerView) {
        adapter = RecordsAdapter(
            onTap = { PlaybackController.toggle(requireContext(), it.file) },
            onMore = { item, anchor -> showMenu(item, anchor) },
            onHit = { item, seg ->
                // the found word plus a little context on both sides
                PlaybackController.playRange(requireContext(), item.file, seg.startMs - 800, seg.endMs + 1500)
            },
            onWord = { item, w ->
                PlaybackController.playFrom(requireContext(), item.file, w.startMs - 250)
            }
        )
        rv.adapter = adapter
        search = SearchBarController(this, requireView()) { q ->
            parsed = RecordSearch.parse(q)
            scrollTopNext = true
            publish()
        }
        subtitle.text = "Нажмите на слово, чтобы слушать с него"
    }

    override fun onStart() {
        super.onStart()
        PlaybackController.listener = {
            publish()
        }
    }

    override fun onDestroyView() {
        search?.release()
        search = null
        super.onDestroyView()
    }

    override fun onStop() {
        PlaybackController.listener = null
        menuPopup?.dismiss()
        list.removeCallbacks(progressTick)
        super.onStop()
    }

    override fun refresh() {
        val ctx = context ?: return
        lifecycleScope.launch {
            val loaded = withContext(Dispatchers.IO) { RecordingsRepository.loadRows(ctx) }
            if (!isAdded) return@launch
            rows = loaded
            publish()
        }
    }

    private fun publish() {
        if (!isAdded || view == null) return
        val lm = list.layoutManager as LinearLayoutManager
        val wasAtTop = lm.findFirstCompletelyVisibleItemPosition() <= 0
        val q = parsed
        val searching = !q.isEmpty
        val visible = if (searching) rows.filter { RecordSearch.matches(q, it.startedAt, it.displayText) } else rows
        val items = visible.map { toItem(it, q) }
        val toTop = scrollTopNext
        scrollTopNext = false
        adapter.submitList(items) {
            if ((wasAtTop || toTop) && view != null) list.scrollToPosition(0)
        }
        emptyText.text = if (searching) "Ничего не найдено" else emptyMessage
        onContentShown(empty = items.isEmpty())
        subtitle.text = when {
            searching -> "Найдено ${items.size} из ${rows.size}" + (q.label?.let { " · $it" } ?: "")
            items.isEmpty() -> "Нажмите на слово, чтобы слушать с него"
            else -> "${items.size} ${plural(items.size)} · нажмите на слово, чтобы слушать с него"
        }
        if (items.any { it.active }) {
            list.removeCallbacks(progressTick)
            list.postOnAnimation(progressTick)
        }
    }

    private fun plural(n: Int): String {
        val m10 = n % 10; val m100 = n % 100
        return when {
            m10 == 1 && m100 != 11 -> "запись"
            m10 in 2..4 && m100 !in 12..14 -> "записи"
            else -> "записей"
        }
    }

    private fun toItem(r: RecordingRow, q: ParsedQuery = ParsedQuery.EMPTY) = RecordItem(
        id = r.file.absolutePath,
        file = r.file,
        timeLabel = formatWhen(r.startedAt),
        fromWatch = r.fromWatch,
        compressed = r.compressed,
        text = r.displayText,
        important = r.important,
        status = r.status,
        statusLabel = r.statusLabel,
        active = PlaybackController.isLoaded(r.file),
        playing = PlaybackController.isPlaying(r.file),
        highlight = q.words,
        hits = if (q.words.isEmpty()) emptyList()
               else RecordSearch.matchedSegments(q, SegmentsCodec.decode(r.transcript?.segments)),
        words = wordsFor(r)
    )

    private fun wordsFor(r: RecordingRow): List<WordSpan> {
        val t = r.transcript ?: return emptyList()
        if (t.text.isBlank() || t.segments.isNullOrEmpty()) return emptyList()
        val key = r.file.absolutePath
        val hit = wordsCache[key]
        if (hit != null && hit.text == t.text && hit.segments == t.segments) return hit.spans
        val spans = WordTimes.spans(t.text, SegmentsCodec.decode(t.segments))
        wordsCache[key] = WordsEntry(t.text, t.segments, spans)
        return spans
    }

    private fun formatWhen(ms: Long): String {
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ms))
        val now = Calendar.getInstance()
        val then = Calendar.getInstance().apply { timeInMillis = ms }
        val sameYear = now.get(Calendar.YEAR) == then.get(Calendar.YEAR)
        val dayDiff = now.get(Calendar.DAY_OF_YEAR) - then.get(Calendar.DAY_OF_YEAR)
        return when {
            sameYear && dayDiff == 0 -> "Сегодня, $time"
            sameYear && dayDiff == 1 -> "Вчера, $time"
            else -> SimpleDateFormat(if (sameYear) "d MMM, HH:mm" else "d MMM yyyy, HH:mm", Locale("ru"))
                .format(Date(ms))
        }
    }

    // ---- three-dot menu -----------------------------------------------------

    private fun showMenu(item: RecordItem, anchor: View) {
        menuPopup?.dismiss()
        val ctx = requireContext()
        val content = LayoutInflater.from(ctx).inflate(R.layout.popup_record_menu, null)
        val row = rows.firstOrNull { it.file.absolutePath == item.id } ?: return
        val popup = PopupWindow(content, Ui.dp(anchor, 220), android.view.ViewGroup.LayoutParams.WRAP_CONTENT, true)
        popup.setBackgroundDrawable(ctx.getDrawable(R.drawable.bg_popup))
        popup.elevation = Ui.dpf(anchor, 10f)
        popup.animationStyle = R.style.PopupAnim
        popup.isOutsideTouchable = true

        val hasText = item.text != null
        val copy = content.findViewById<View>(R.id.menuCopy)
        if (!hasText) {
            copy.alpha = 0.4f
            copy.isEnabled = false
        }
        copy.setOnClickListener {
            popup.dismiss()
            copyText(item.text ?: return@setOnClickListener)
        }
        val edit = content.findViewById<View>(R.id.menuEdit)
        if (!hasText) {
            edit.alpha = 0.4f
            edit.isEnabled = false
        } else {
            edit.setOnClickListener {
                popup.dismiss()
                showEditDialog(row)
            }
        }
        val important = content.findViewById<View>(R.id.menuImportant)
        val importantText = content.findViewById<TextView>(R.id.menuImportantText)
        val importantIcon = content.findViewById<ImageView>(R.id.menuImportantIcon)
        importantText.text = if (row.important) "Снять важное" else "Отметить важным"
        Ui.tint(importantIcon, ctx.getColor(if (row.important) R.color.accent_amber else R.color.ink))
        important.setOnClickListener {
            popup.dismiss()
            lifecycleScope.launch {
                withContext(Dispatchers.IO) { RecordingsRepository.setImportant(ctx.applicationContext, row.file, !row.important) }
                if (isAdded) refresh()
            }
        }

        val transcribe = content.findViewById<View>(R.id.menuTranscribe)
        val manualAllowed = PowerMode.effective(ctx) == PowerMode.ENERGY || PowerMode.effective(ctx) == PowerMode.BALANCED
        if (!manualAllowed || hasText) {
            transcribe.alpha = 0.4f
            transcribe.isEnabled = false
        } else {
            transcribe.setOnClickListener {
                popup.dismiss()
                Transcriber.enqueueFile(ctx.applicationContext, row.file)
                Toast.makeText(ctx, "Расшифровка поставлена в очередь", Toast.LENGTH_SHORT).show()
            }
        }
        content.findViewById<View>(R.id.menuExport).setOnClickListener {
            popup.dismiss(); shareFile(row)
        }
        content.findViewById<View>(R.id.menuDelete).setOnClickListener {
            popup.dismiss(); confirmDelete(row)
        }
        menuPopup = popup
        popup.showAsDropDown(anchor, Ui.dp(anchor, 4), -Ui.dp(anchor, 8), Gravity.END)
    }

    // ---- edit transcript ----------------------------------------------------

    private fun showEditDialog(row: RecordingRow) {
        val ctx = requireContext()
        val current = row.displayText ?: return
        val input = android.widget.EditText(ctx).apply {
            setText(current)
            setSelection(current.length)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            minLines = 3
            maxLines = 10
            gravity = Gravity.TOP or Gravity.START
            textSize = 16f
            setTextColor(ctx.getColor(R.color.ink))
            background = null
        }
        val pad = Ui.dp(input, 22)
        val box = android.widget.FrameLayout(ctx).apply {
            setPadding(pad, Ui.dp(input, 8), pad, 0)
            addView(input)
        }
        val dialog = MaterialAlertDialogBuilder(ctx)
            .setTitle("Править текст")
            .setView(box)
            .setPositiveButton("Сохранить", null) // set below so an empty text keeps the dialog open
            .setNegativeButton("Отмена", null)
            .create()
        dialog.setOnShowListener {
            input.requestFocus()
            dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
            dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val text = input.text.toString().trim()
                if (text.isEmpty()) {
                    Toast.makeText(ctx, "Текст не может быть пустым", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                dialog.dismiss()
                if (text == current) return@setOnClickListener
                val app = ctx.applicationContext
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) { RecordingsRepository.updateText(app, row, text) }
                    if (isAdded) refresh()
                }
            }
        }
        dialog.show()
    }

    private fun copyText(text: String) {
        val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Расшифровка", text))
        Toast.makeText(requireContext(), "Текст скопирован", Toast.LENGTH_SHORT).show()
    }

    private fun confirmDelete(row: RecordingRow) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Удалить запись?")
            .setMessage("Аудиофайл, расшифровка и связанные заметки «Важное» будут удалены вместе.")
            .setPositiveButton("Удалить") { _, _ -> deleteRow(row) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun deleteRow(row: RecordingRow) {
        val ctx = requireContext().applicationContext
        PlaybackController.stopIfPlaying(row.file)
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { RecordingsRepository.deleteRecording(ctx, row) }
            if (isAdded) {
                rows = rows.filterNot { it.file.absolutePath == row.file.absolutePath }
                publish()
            }
        }
    }

    private fun shareFile(row: RecordingRow) {
        val ctx = requireContext()
        try {
            val uri = FileProvider.getUriForFile(ctx, "${BuildConfig.APPLICATION_ID}.fileprovider", row.file)
            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = when (row.file.extension.lowercase()) {
                            "opus", "ogg" -> "audio/ogg"
                            else -> "audio/wav"
                        }
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    },
                    "Экспорт записи"
                )
            )
        } catch (e: Exception) {
            Toast.makeText(ctx, "Не удалось экспортировать файл", Toast.LENGTH_SHORT).show()
        }
    }
}
