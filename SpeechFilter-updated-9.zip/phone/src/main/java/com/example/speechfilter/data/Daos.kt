package com.example.speechfilter.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface TranscriptDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(e: TranscriptEntity): Long

    @Query("SELECT * FROM transcripts WHERE filePath = :path LIMIT 1")
    suspend fun byPath(path: String): TranscriptEntity?

    @Query("SELECT * FROM transcripts WHERE status = :status ORDER BY transcribedAt ASC LIMIT :limit")
    suspend fun byStatus(status: String, limit: Int = 50): List<TranscriptEntity>

    @Query("UPDATE transcripts SET status = :status WHERE id = :id")
    suspend fun setStatus(id: Long, status: String)

    @Query("SELECT * FROM transcripts ORDER BY transcribedAt DESC LIMIT :limit")
    suspend fun recent(limit: Int = 100): List<TranscriptEntity>

    @Query("SELECT * FROM transcripts WHERE id = :id LIMIT 1")
    suspend fun byId(id: Long): TranscriptEntity?

    @Query("SELECT * FROM transcripts")
    suspend fun all(): List<TranscriptEntity>

    @Query("UPDATE transcripts SET text = :text, segments = :segments WHERE id = :id")
    suspend fun setTextAndSegments(id: Long, text: String, segments: String?)

    @Query("UPDATE transcripts SET segments = :segments WHERE id = :id")
    suspend fun setSegments(id: Long, segments: String?)

    @Query("DELETE FROM transcripts WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE transcripts SET filePath = :newPath, fileName = :newName WHERE filePath = :oldPath")
    suspend fun updatePath(oldPath: String, newPath: String, newName: String)
}

@Dao
interface ImportantRecordingDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun mark(e: ImportantRecordingEntity)

    @Query("DELETE FROM important_recordings WHERE filePath = :path")
    suspend fun unmark(path: String)

    @Query("SELECT EXISTS(SELECT 1 FROM important_recordings WHERE filePath = :path)")
    suspend fun isMarked(path: String): Boolean

    @Query("SELECT * FROM important_recordings ORDER BY markedAt DESC LIMIT :limit")
    suspend fun recent(limit: Int = 200): List<ImportantRecordingEntity>
}

@Dao
interface PipelineLogDao {
    @Insert
    suspend fun insert(e: PipelineLogEntity)

    @Query("SELECT * FROM pipeline_log ORDER BY at DESC LIMIT :limit")
    suspend fun recent(limit: Int = 50): List<PipelineLogEntity>

    @Query("SELECT * FROM pipeline_log WHERE at >= :since ORDER BY at DESC")
    suspend fun recentSince(since: Long): List<PipelineLogEntity>
}
