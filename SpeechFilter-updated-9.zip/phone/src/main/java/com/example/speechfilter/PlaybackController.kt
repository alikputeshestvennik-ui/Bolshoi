package com.example.speechfilter

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.io.File

/**
 * Single shared ExoPlayer instance for recording playback. Kept outside any
 * Fragment/Activity so play/pause state survives navigating between screens.
 * Screens subscribe through [listener] (set in onStart, cleared in onStop).
 */
object PlaybackController {
    private var player: ExoPlayer? = null
    var playingFile: File? = null
        private set

    /** Called on the main thread whenever play/pause/stop state changes. */
    @Volatile var listener: (() -> Unit)? = null

    fun isPlaying(file: File): Boolean =
        playingFile?.absolutePath == file.absolutePath && player?.isPlaying == true

    /** 0f..1f progress of the loaded file, or 0f if [file] is not loaded. */
    fun progress(file: File): Float {
        val p = player ?: return 0f
        if (playingFile?.absolutePath != file.absolutePath) return 0f
        val d = p.duration
        if (d <= 0) return 0f
        return (p.currentPosition.toFloat() / d).coerceIn(0f, 1f)
    }

    fun isLoaded(file: File): Boolean = playingFile?.absolutePath == file.absolutePath && player != null

    private val handler = Handler(Looper.getMainLooper())
    private var rangeEndMs = -1L

    private val rangeCheck = object : Runnable {
        override fun run() {
            val p = player
            if (p == null || rangeEndMs < 0) return
            if (p.currentPosition >= rangeEndMs) {
                rangeEndMs = -1L
                p.pause()
                listener?.invoke()
                return
            }
            handler.postDelayed(this, 50)
        }
    }

    private fun clearRange() {
        rangeEndMs = -1L
        handler.removeCallbacks(rangeCheck)
    }

    fun toggle(context: Context, file: File) {
        clearRange()
        val same = playingFile?.absolutePath == file.absolutePath
        val current = player
        if (same && current != null) {
            if (current.isPlaying) current.pause() else current.play()
            listener?.invoke()
            return
        }
        load(context, file).play()
        listener?.invoke()
    }

    /** Current position of the loaded [file] in ms (0 if it is not loaded). */
    fun positionMs(file: File): Long {
        val p = player ?: return 0L
        if (playingFile?.absolutePath != file.absolutePath) return 0L
        return p.currentPosition
    }

    /** Start (or jump to) [startMs] of [file] and keep playing to the end. */
    fun playFrom(context: Context, file: File, startMs: Long) {
        clearRange()
        val same = playingFile?.absolutePath == file.absolutePath
        val exo = if (same && player != null) player!! else load(context, file)
        exo.seekTo(startMs.coerceAtLeast(0L))
        exo.play()
        listener?.invoke()
    }

    /** Play only [startMs]..[endMs] of [file] (a found phrase), then pause. */
    fun playRange(context: Context, file: File, startMs: Long, endMs: Long) {
        clearRange()
        val same = playingFile?.absolutePath == file.absolutePath
        val exo = if (same && player != null) player!! else load(context, file)
        val from = startMs.coerceAtLeast(0L)
        exo.seekTo(from)
        exo.play()
        rangeEndMs = maxOf(endMs, from + 800L)
        handler.postDelayed(rangeCheck, 50)
        listener?.invoke()
    }

    private fun load(context: Context, file: File): ExoPlayer {
        release()
        playingFile = file
        return ExoPlayer.Builder(context.applicationContext).build().also { exo ->
            player = exo
            exo.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    // Tell the recording service to ignore the mic while we're
                    // playing this back through the speaker, so it doesn't
                    // re-capture its own output.
                    RecordingService.selfPlaybackActive = isPlaying
                    listener?.invoke()
                }

                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_ENDED) {
                        release()
                        listener?.invoke()
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    release()
                    listener?.invoke()
                }
            })
            exo.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
            exo.prepare()
        }
    }

    /** Call before deleting a recording so a deleted file is never left playing. */
    fun stopIfPlaying(file: File) {
        if (playingFile?.absolutePath == file.absolutePath) {
            release()
            listener?.invoke()
        }
    }

    fun release() {
        clearRange()
        player?.release()
        player = null
        playingFile = null
        RecordingService.selfPlaybackActive = false
    }
}
