package com.example.speechfilter.pipeline

import org.json.JSONArray

/** Stores Whisper segments in the transcripts table as compact JSON: [[startMs,endMs,"text"],...]. */
object SegmentsCodec {

    fun encode(segments: List<Seg>): String? {
        if (segments.isEmpty()) return null
        val arr = JSONArray()
        for (s in segments) {
            arr.put(JSONArray().put(s.startMs).put(s.endMs).put(s.text))
        }
        return arr.toString()
    }

    fun decode(json: String?): List<Seg> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).mapNotNull { i ->
                val a = arr.optJSONArray(i) ?: return@mapNotNull null
                Seg(a.optLong(0), a.optLong(1), a.optString(2))
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
