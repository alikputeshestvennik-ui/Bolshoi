package com.example.speechfilter.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Raw Whisper transcript of one WAV file. */
@Entity(
    tableName = "transcripts",
    indices = [Index(value = ["filePath"], unique = true)]
)
data class TranscriptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val filePath: String,
    val fileName: String,
    val sourceTag: String,
    val text: String,
    val createdAt: Long,
    val transcribedAt: Long,
    /** pending | refined | failed */
    val status: String = "pending",
    /** Whisper segments with timecodes as JSON [[startMs,endMs,"text"],...]; null for older rows. */
    val segments: String? = null
)

/** A recording explicitly marked important by the user. */
@Entity(
    tableName = "important_recordings",
    indices = [Index(value = ["filePath"], unique = true)]
)
data class ImportantRecordingEntity(
    @PrimaryKey val filePath: String,
    val markedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "pipeline_log")
data class PipelineLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val worker: String,
    val message: String,
    val at: Long = System.currentTimeMillis()
)
