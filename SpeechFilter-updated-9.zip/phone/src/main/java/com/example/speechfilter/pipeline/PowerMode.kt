package com.example.speechfilter.pipeline

import android.content.Context
import android.os.BatteryManager

/** Processing policy for the 24/7 recorder. */
enum class PowerMode(
    val key: String,
    val title: String,
    val description: String,
    val whisperThreads: Int
) {
    ENERGY("energy", "Энергосбережение", "Минимальная нагрузка: VAD и запись. Whisper запускается только вручную.", 1),
    BALANCED("balanced", "Баланс", "VAD + YAMNet для отбора речи. Whisper запускается только вручную.", 2),
    PERFORMANCE("performance", "Производительность", "Полная фильтрация и автоматическая расшифровка после закрытия сегмента.", 4),
    AC("ac", "От сети", "Полная обработка при питании от сети. Whisper работает с максимальным числом потоков.", Int.MAX_VALUE);

    val shortTitle: String
        get() = when (this) {
            ENERGY -> "Эко+"
            BALANCED -> "Стандарт"
            PERFORMANCE -> "Комфорт"
            AC -> "Максимум"
        }

    companion object {
        private const val PREFS = "processing_mode"
        private const val KEY = "selected"
        private const val LOW_BATTERY_PERCENT = 15

        fun userSelected(context: Context): PowerMode {
            val key = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY, BALANCED.key)
            return values().firstOrNull { it.key == key } ?: BALANCED
        }

        fun setUserSelected(context: Context, mode: PowerMode) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY, mode.key).apply()
        }

        /** Charging and low battery are automatic overrides. */
        fun effective(context: Context): PowerMode {
            val bm = context.getSystemService(BatteryManager::class.java)
            val charging = try {
                // BatteryManager.isCharging() is famously false once the battery
                // reaches 100% even though the phone is still plugged in — a
                // phone left on the charger overnight then reports "not charging"
                // for most of that time. EXTRA_PLUGGED (from the sticky battery
                // intent) stays true for as long as the cable/pad is connected,
                // which is what "От сети" is actually supposed to track.
                bm?.isCharging == true || isPluggedIn(context)
            } catch (_: Throwable) {
                false
            }
            if (charging) return AC

            val percent = try {
                val level = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
                level
            } catch (_: Throwable) {
                -1
            }
            if (percent in 0..LOW_BATTERY_PERCENT) return ENERGY
            return userSelected(context)
        }

        fun isAutomaticOverride(context: Context): Boolean {
            val effective = effective(context)
            return effective == ENERGY && userSelected(context) != ENERGY || effective == AC
        }

        private fun isPluggedIn(context: Context): Boolean = try {
            val sticky = context.registerReceiver(
                null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED)
            )
            (sticky?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        } catch (_: Throwable) {
            false
        }

        fun lowBatteryThresholdPercent(): Int = LOW_BATTERY_PERCENT
    }
}
