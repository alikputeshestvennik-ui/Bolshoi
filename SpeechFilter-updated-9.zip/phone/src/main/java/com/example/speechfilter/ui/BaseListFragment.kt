package com.example.speechfilter.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.speechfilter.R

/**
 * Shared shell of the list pages (records / important): page title,
 * subtitle, a RecyclerView with soft item animations, an animated empty state
 * and a periodic refresh that only runs while the page is on screen.
 */
abstract class BaseListFragment : Fragment(R.layout.fragment_cards) {

    protected lateinit var list: RecyclerView
    protected lateinit var subtitle: TextView
    private lateinit var emptyView: LinearLayout
    protected lateinit var emptyText: TextView
    private var firstContent = true

    protected abstract val titleText: String
    protected abstract val emptyMessage: String
    protected abstract val refreshMs: Long
    protected abstract val emptyIconRes: Int

    protected abstract fun setupList(rv: RecyclerView)
    protected abstract fun refresh()

    protected val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, refreshMs)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val title = view.findViewById<TextView>(R.id.pageTitle)
        subtitle = view.findViewById(R.id.pageSubtitle)
        list = view.findViewById(R.id.list)
        emptyView = view.findViewById(R.id.emptyView)
        emptyText = view.findViewById(R.id.emptyText)
        title.text = titleText
        emptyText.text = emptyMessage
        val icon = view.findViewById<ImageView>(R.id.emptyIcon)
        icon.setImageResource(emptyIconRes)
        Ui.tint(icon, requireContext().getColor(R.color.ink_faint))

        list.layoutManager = LinearLayoutManager(requireContext())
        list.itemAnimator = DefaultItemAnimator().apply {
            supportsChangeAnimations = false
            addDuration = 320
            removeDuration = 220
            moveDuration = 260
        }
        firstContent = true
        setupList(list)
        Ui.staggerIn(listOf(title, subtitle), step = 70)
    }

    override fun onStart() {
        super.onStart()
        ui.removeCallbacks(tick)
        ui.post(tick)
    }

    override fun onStop() {
        ui.removeCallbacks(tick)
        super.onStop()
    }

    /** Call after submitting a list; plays the staggered entrance once. */
    protected fun onContentShown(empty: Boolean) {
        if (!isAdded || view == null) return
        Ui.setVisibleAnimated(emptyView, empty)
        if (!empty && firstContent) {
            firstContent = false
            list.layoutAnimation =
                android.view.animation.AnimationUtils.loadLayoutAnimation(requireContext(), R.anim.layout_list_enter)
            list.scheduleLayoutAnimation()
        }
    }
}
