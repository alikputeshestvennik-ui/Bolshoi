package com.example.speechfilter.pipeline

/** One word with its time in the audio. */
data class TimedWord(val word: String, val startMs: Long, val endMs: Long)

/** A word's character range in the transcript text plus its time in the audio. */
data class WordSpan(val start: Int, val end: Int, val startMs: Long, val endMs: Long)

/**
 * Glue between the transcript text and Whisper's per-word segments:
 *  - [spans]  : for tap-a-word / karaoke — where each word sits in the text and when it is spoken;
 *  - [align]  : after the user edits the text, carries the old timings over to the new words.
 *
 * Invariant kept everywhere: the non-whitespace characters of all stored segments,
 * concatenated, are exactly the non-whitespace characters of the text.
 */
object WordTimes {

    fun tokens(text: String): List<IntRange> {
        val out = ArrayList<IntRange>()
        var i = 0
        while (i < text.length) {
            while (i < text.length && text[i].isWhitespace()) i++
            if (i >= text.length) break
            val s = i
            while (i < text.length && !text[i].isWhitespace()) i++
            out += s until i
        }
        return out
    }

    private fun compact(s: String): String = buildString { for (c in s) if (!c.isWhitespace()) append(c) }

    private fun key(w: String): String = buildString {
        for (c in w) if (c.isLetterOrDigit()) append(if (c == 'ё' || c == 'Ё') 'е' else c.lowercaseChar())
    }

    /** Empty when there are no segments or they don't reproduce [text]. */
    fun spans(text: String, segs: List<Seg>): List<WordSpan> {
        if (segs.isEmpty() || text.isBlank()) return emptyList()
        val segCompact = segs.map { compact(it.text) }
        if (segCompact.joinToString("") != compact(text)) return emptyList()
        val ends = IntArray(segs.size)
        var acc = 0
        for (i in segs.indices) { acc += segCompact[i].length; ends[i] = acc }
        fun segOf(ord: Int): Int {
            var lo = 0; var hi = ends.size - 1
            while (lo < hi) {
                val mid = (lo + hi) ushr 1
                if (ends[mid] > ord) hi = mid else lo = mid + 1
            }
            return lo
        }
        val out = ArrayList<WordSpan>()
        var ord = 0
        for (r in tokens(text)) {
            val len = r.last - r.first + 1
            val s0 = segOf(ord)
            val s1 = segOf(ord + len - 1)
            out += WordSpan(r.first, r.last + 1, segs[s0].startMs, segs[s1].endMs)
            ord += len
        }
        return out
    }

    fun timedWords(text: String, segs: List<Seg>): List<TimedWord> =
        spans(text, segs).map { TimedWord(text.substring(it.start, it.end), it.startMs, it.endMs) }

    /**
     * Words of [newText] with times taken from [old]: identical words (ignoring case,
     * punctuation, ё/е) keep their time via LCS; new or changed words get a time
     * interpolated between their neighbours. Returns per-word segments, or null when
     * there is nothing to align.
     */
    fun align(old: List<TimedWord>, newText: String): List<Seg>? {
        if (old.isEmpty()) return null
        val toks = tokens(newText)
        if (toks.isEmpty()) return null
        val nw = toks.map { newText.substring(it.first, it.last + 1) }
        val a = old.map { key(it.word) }
        val b = nw.map { key(it) }
        val n = a.size
        val m = b.size

        val dp = Array(n + 1) { IntArray(m + 1) }
        for (i in n - 1 downTo 0) for (j in m - 1 downTo 0) {
            dp[i][j] = if (a[i].isNotEmpty() && a[i] == b[j]) dp[i + 1][j + 1] + 1
            else maxOf(dp[i + 1][j], dp[i][j + 1])
        }
        val match = IntArray(m) { -1 }
        var i = 0
        var j = 0
        while (i < n && j < m) {
            if (a[i].isNotEmpty() && a[i] == b[j]) { match[j] = i; i++; j++ }
            else if (dp[i + 1][j] >= dp[i][j + 1]) i++ else j++
        }

        val st = LongArray(m)
        val en = LongArray(m)
        val firstStart = old.first().startMs
        val lastEnd = old.last().endMs
        var j0 = 0
        while (j0 < m) {
            if (match[j0] >= 0) {
                st[j0] = old[match[j0]].startMs
                en[j0] = old[match[j0]].endMs
                j0++
                continue
            }
            var j1 = j0
            while (j1 < m && match[j1] < 0) j1++
            val from = if (j0 > 0) en[j0 - 1] else firstStart
            val to = if (j1 < m) old[match[j1]].startMs else lastEnd
            val cnt = j1 - j0
            val span = maxOf(to - from, cnt * 200L)
            for (k in 0 until cnt) {
                st[j0 + k] = from + span * k / cnt
                en[j0 + k] = from + span * (k + 1) / cnt
            }
            j0 = j1
        }
        return nw.mapIndexed { idx, w -> Seg(st[idx], en[idx], if (idx > 0) " $w" else w) }
    }

    /**
     * True when the row should get (better) per-word timecodes: no segments yet,
     * phrase-sized segments from an older build, or segments that no longer match the text.
     * "[]" means "already tried, Whisper gave no words" and is not retried.
     */
    fun needsRetime(text: String, segmentsJson: String?): Boolean {
        if (text.isBlank()) return false
        if (segmentsJson == "[]") return false
        val segs = SegmentsCodec.decode(segmentsJson)
        if (segs.isEmpty()) return true
        if (segs.any { it.text.trim().contains(' ') }) return true
        return spans(text, segs).isEmpty()
    }
}
