package com.example.speechfilter.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import com.example.speechfilter.R

/**
 * Header search: a colored magnifier at the right of the page title. Tapping it
 * animates the icon's container into a full-width field that covers the title;
 * the close button clears the text first and collapses on the second tap.
 */
class SearchBarController(
    private val fragment: Fragment,
    root: View,
    private val onQuery: (String) -> Unit
) {
    private val ctx: Context = root.context
    private val header: View = root.findViewById(R.id.headerRow)
    private val title: View = root.findViewById(R.id.pageTitle)
    private val bar: FrameLayout = root.findViewById(R.id.searchBar)
    private val icon: ImageView = root.findViewById(R.id.searchIcon)
    private val close: ImageView = root.findViewById(R.id.searchClose)
    private val input: EditText = root.findViewById(R.id.searchInput)

    private val collapsedW = Ui.dp(bar, 44)
    private var anim: ValueAnimator? = null
    private val debounce = Runnable { onQuery(input.text.toString()) }

    var isOpen = false
        private set

    private val back = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = collapse()
    }

    init {
        bar.visibility = View.VISIBLE
        bar.background = ctx.getDrawable(R.drawable.bg_search_field)!!.mutate().also { it.alpha = 0 }
        Ui.tint(icon, ctx.getColor(R.color.accent_search))
        Ui.tint(close, ctx.getColor(R.color.ink_muted))

        icon.setOnClickListener { if (isOpen) focusInput() else expand() }
        close.setOnClickListener {
            if (input.text.isNotEmpty()) input.setText("") else collapse()
        }
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                input.removeCallbacks(debounce)
                input.postDelayed(debounce, 120)
            }
        })
        input.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_SEARCH) { hideIme(); true } else false
        }
        fragment.requireActivity().onBackPressedDispatcher
            .addCallback(fragment.viewLifecycleOwner, back)
    }

    fun expand() {
        if (isOpen) return
        isOpen = true
        back.isEnabled = true
        input.visibility = View.VISIBLE
        close.visibility = View.VISIBLE
        animateTo(open = true)
        input.postDelayed({ focusInput() }, 140)
    }

    fun collapse() {
        if (!isOpen) return
        isOpen = false
        back.isEnabled = false
        hideIme()
        input.removeCallbacks(debounce)
        if (input.text.isNotEmpty()) input.setText("")
        onQuery("")
        animateTo(open = false)
    }

    fun release() {
        anim?.cancel()
        input.removeCallbacks(debounce)
    }

    private fun animateTo(open: Boolean) {
        anim?.cancel()
        val full = header.width.takeIf { it > collapsedW } ?: return finishInstantly(open)
        val from = bar.layoutParams.width.takeIf { it > 0 } ?: collapsedW
        val to = if (open) full else collapsedW
        anim = ValueAnimator.ofInt(from, to).apply {
            duration = 300
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { a ->
                val w = a.animatedValue as Int
                val lp = bar.layoutParams
                lp.width = w
                bar.layoutParams = lp
                val f = ((w - collapsedW).toFloat() / (full - collapsedW)).coerceIn(0f, 1f)
                bar.background.alpha = (f * 255).toInt()
                title.alpha = 1f - f
                input.alpha = f
                close.alpha = f
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    if (!open) {
                        input.visibility = View.INVISIBLE
                        close.visibility = View.INVISIBLE
                    }
                }
            })
            start()
        }
    }

    private fun finishInstantly(open: Boolean) {
        val lp = bar.layoutParams
        lp.width = if (open) FrameLayout.LayoutParams.MATCH_PARENT else collapsedW
        bar.layoutParams = lp
        bar.background.alpha = if (open) 255 else 0
        title.alpha = if (open) 0f else 1f
        input.alpha = if (open) 1f else 0f
        close.alpha = input.alpha
        if (!open) { input.visibility = View.INVISIBLE; close.visibility = View.INVISIBLE }
    }

    private fun focusInput() {
        input.requestFocus()
        (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideIme() {
        (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
        input.clearFocus()
    }
}
