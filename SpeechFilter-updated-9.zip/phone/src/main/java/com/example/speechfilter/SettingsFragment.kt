package com.example.speechfilter

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.SwitchCompat
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.data.PipelineLogEntity
import com.example.speechfilter.data.RecordingsRepository
import com.example.speechfilter.pipeline.Transcriber
import com.example.speechfilter.pipeline.PowerMode
import com.example.speechfilter.pipeline.ReadinessCheck
import com.example.speechfilter.pipeline.WhisperEngine
import com.example.speechfilter.ui.Ui
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Settings: compact power selector, model/readiness window and worker journal. */
class SettingsFragment : Fragment(R.layout.fragment_settings) {

    private lateinit var processingModeEffective: TextView
    private lateinit var modeDescription: TextView
    private lateinit var modeSelector: FrameLayout
    private lateinit var modeIndicator: View
    private lateinit var modeEnergy: TextView
    private lateinit var modeBalanced: TextView
    private lateinit var modePerformance: TextView
    private lateinit var modeAc: TextView

    private lateinit var retimeSubtitle: TextView
    private var retimeCandidates = -1

    private val retimeTick = object : Runnable {
        override fun run() {
            if (view == null) return
            if (Transcriber.retimeRunning) {
                retimeSubtitle.text = "Идёт: ${Transcriber.retimeDone} из ${Transcriber.retimeTotal}…"
                uiHandler.postDelayed(this, 1000L)
            } else {
                refreshRetimeInfo()
            }
        }
    }

    private val whisper by lazy { WhisperEngine(requireContext().applicationContext) }
    private var modelDialog: Dialog? = null
    private var logDialog: Dialog? = null
    private var logTextView: TextView? = null

    private val uiHandler = Handler(Looper.getMainLooper())
    private val logRefreshRunnable = object : Runnable {
        override fun run() {
            val tv = logTextView
            if (tv != null && logDialog?.isShowing == true) {
                refreshLog(tv)
                uiHandler.postDelayed(this, 2500L)
            }
        }
    }

    private val whisperModelPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        val tv = modelDialog?.findViewById<TextView>(R.id.whisperModelStatus)
        tv?.text = "Whisper: импортирую…"
        lifecycleScope.launch {
            val message = withContext(Dispatchers.IO) {
                whisper.importModel(uri).fold(
                    onSuccess = {
                        val backend = try { whisper.backendInfo() } catch (_: Throwable) { "?" }
                        "Whisper: модель готова (${it.length() / (1024 * 1024)} MB) · $backend"
                    },
                    onFailure = { "Whisper: ошибка импорта — ${it.message}" }
                )
            }
            if (isAdded) tv?.text = message
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        processingModeEffective = view.findViewById(R.id.processingModeEffective)
        modeDescription = view.findViewById(R.id.modeDescription)
        modeSelector = view.findViewById(R.id.modeSelector)
        modeIndicator = view.findViewById(R.id.modeSelectorIndicator)
        modeEnergy = view.findViewById(R.id.modeEnergy)
        modeBalanced = view.findViewById(R.id.modeBalanced)
        modePerformance = view.findViewById(R.id.modePerformance)
        modeAc = view.findViewById(R.id.modeAc)

        modeEnergy.setOnClickListener { setUserMode(PowerMode.ENERGY, animate = true) }
        modeBalanced.setOnClickListener { setUserMode(PowerMode.BALANCED, animate = true) }
        modePerformance.setOnClickListener { setUserMode(PowerMode.PERFORMANCE, animate = true) }

        val autoSwitch = view.findViewById<SwitchCompat>(R.id.autoStartChargeSwitch)
        autoSwitch.isChecked = AppPrefs.isAutoStartOnCharge(requireContext())
        autoSwitch.setOnCheckedChangeListener { _, checked ->
            AppPrefs.setAutoStartOnCharge(requireContext(), checked)
        }
        view.findViewById<View>(R.id.autoStartChargeRow).setOnClickListener {
            autoSwitch.isChecked = !autoSwitch.isChecked
        }

        val compressSwitch = view.findViewById<SwitchCompat>(R.id.compressOnChargeSwitch)
        compressSwitch.isChecked = AppPrefs.isCompressOnCharge(requireContext())
        compressSwitch.setOnCheckedChangeListener { _, checked ->
            AppPrefs.setCompressOnCharge(requireContext(), checked)
            if (checked) {
                // Kick a compress pass if already on charger
                com.example.speechfilter.pipeline.OpusCompressor.enqueue(requireContext())
            }
        }
        view.findViewById<View>(R.id.compressOnChargeRow).setOnClickListener {
            compressSwitch.isChecked = !compressSwitch.isChecked
        }

        view.findViewById<View>(R.id.modelsToolsRow).setOnClickListener { showModelToolsDialog() }
        view.findViewById<View>(R.id.logRow).setOnClickListener { showLogDialog() }

        retimeSubtitle = view.findViewById(R.id.retimeSubtitle)
        view.findViewById<View>(R.id.retimeRow).setOnClickListener { onRetimeClick() }

        updateProcessingModeUi(animate = false)
        Ui.staggerIn(Ui.children(view.findViewById<LinearLayout>(R.id.settingsContent)), step = 60)
    }

    override fun onResume() {
        super.onResume()
        uiHandler.removeCallbacks(retimeTick)
        if (Transcriber.retimeRunning) uiHandler.post(retimeTick) else refreshRetimeInfo()
        updateProcessingModeUi(animate = false)
        view?.findViewById<SwitchCompat>(R.id.autoStartChargeSwitch)?.isChecked =
            AppPrefs.isAutoStartOnCharge(requireContext())
        view?.findViewById<SwitchCompat>(R.id.compressOnChargeSwitch)?.isChecked =
            AppPrefs.isCompressOnCharge(requireContext())
    }

    override fun onStop() {
        uiHandler.removeCallbacks(retimeTick)
        uiHandler.removeCallbacks(logRefreshRunnable)
        super.onStop()
    }

    private fun refreshRetimeInfo() {
        val ctx = context?.applicationContext ?: return
        lifecycleScope.launch {
            val n = withContext(Dispatchers.IO) { RecordingsRepository.retimeCandidates(ctx).size }
            if (!isAdded || view == null) return@launch
            retimeCandidates = n
            retimeSubtitle.text = if (n == 0) "У всех записей есть тайм-коды по словам"
            else "Без точных тайм-кодов: $n · нажмите, чтобы обновить"
        }
    }

    private fun onRetimeClick() {
        val ctx = requireContext()
        if (Transcriber.retimeRunning) {
            Toast.makeText(ctx, "Уже идёт: ${Transcriber.retimeDone} из ${Transcriber.retimeTotal}", Toast.LENGTH_SHORT).show()
            return
        }
        val n = retimeCandidates
        if (n <= 0) {
            Toast.makeText(ctx, "Обновлять нечего", Toast.LENGTH_SHORT).show()
            return
        }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(ctx)
            .setTitle("Обновить тайм-коды?")
            .setMessage(
                "Whisper заново прослушает записей: $n (только WAV, не сжатые в Opus). " +
                "Тексты не изменятся, включая ваши правки — обновятся только моменты, " +
                "когда произнесено каждое слово. Это долго и нагружает процессор, лучше на зарядке."
            )
            .setPositiveButton("Обновить") { _, _ ->
                Transcriber.startRetime(ctx.applicationContext)
                uiHandler.removeCallbacks(retimeTick)
                retimeSubtitle.text = "Запускаю…"
                uiHandler.postDelayed(retimeTick, 400L)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun setUserMode(mode: PowerMode, animate: Boolean) {
        val ctx = requireContext()
        PowerMode.setUserSelected(ctx, mode)
        ctx.sendBroadcast(Intent(RecordingService.ACTION_MODE_CHANGED).setPackage(ctx.packageName))
        updateProcessingModeUi(animate)
    }

    private fun updateProcessingModeUi(animate: Boolean) {
        if (!::modeSelector.isInitialized) return
        val ctx = requireContext()
        val user = PowerMode.userSelected(ctx).let { if (it == PowerMode.AC) PowerMode.BALANCED else it }
        val effective = PowerMode.effective(ctx)
        val charging = effective == PowerMode.AC
        val targetIndex = when {
            charging -> 3
            effective == PowerMode.ENERGY && user != PowerMode.ENERGY -> 0
            else -> userIndex(user)
        }

        modeSelector.post {
            val width = modeSelector.width
            if (width <= 0) return@post
            val segment = width / 4f
            val targetX = Ui.dp(modeSelector, 3).toFloat() + segment * targetIndex
            modeIndicator.layoutParams = modeIndicator.layoutParams.apply {
                this.width = (segment - Ui.dp(modeSelector, 6)).toInt()
            }
            modeIndicator.backgroundTintList = android.content.res.ColorStateList.valueOf(
                ctx.getColor(if (charging) R.color.accent_green else R.color.ink)
            )
            if (animate) {
                modeIndicator.animate().cancel()
                modeIndicator.animate()
                    .translationX(targetX)
                    .setDuration(280)
                    .setInterpolator(android.view.animation.DecelerateInterpolator(1.6f))
                    .start()
            } else {
                modeIndicator.animate().cancel()
                modeIndicator.translationX = targetX
            }
        }

        val selected = listOf(modeEnergy, modeBalanced, modePerformance, modeAc)
        selected.forEachIndexed { index, tv ->
            val active = index == targetIndex
            tv.setTextColor(ctx.getColor(if (active) R.color.paper_bg else R.color.ink_muted))
            tv.setTypeface(null, if (active) Typeface.BOLD else Typeface.NORMAL)
        }
        modeAc.setTextColor(ctx.getColor(if (charging) R.color.paper_bg else R.color.ink_muted))

        // "Сейчас:" line only for automatic overrides — selection is already clear from the pill
        when {
            charging -> {
                processingModeEffective.visibility = View.VISIBLE
                processingModeEffective.text = "Питание подключено — автоматически «Максимум»."
            }
            effective == PowerMode.ENERGY && user != PowerMode.ENERGY -> {
                processingModeEffective.visibility = View.VISIBLE
                processingModeEffective.text =
                    "Низкий заряд ${batteryPercent()}% — автоматически «Эко+» (порог ${PowerMode.lowBatteryThresholdPercent()}%)."
            }
            else -> {
                processingModeEffective.visibility = View.GONE
                processingModeEffective.text = ""
            }
        }
        // Describe the user-selected mode (Максимум is automatic-only; explain vs Комфорт)
        modeDescription.text = when {
            charging -> "Максимум: та же полная фильтрация и авто-расшифровка, что в «Комфорт», но с максимальным числом потоков Whisper, пока идёт зарядка."
            else -> when (user) {
                PowerMode.ENERGY -> "Минимум вычислений. VAD и запись постоянно; Whisper — только вручную."
                PowerMode.BALANCED -> "VAD + YAMNet для отбора речи. Whisper остаётся ручным, без постоянной нагрузки CPU."
                PowerMode.PERFORMANCE -> "Полная фильтрация и автоматическая расшифровка после каждого речевого сегмента (на батарее)."
                PowerMode.AC -> "Полная обработка при питании от сети — включается автоматически при зарядке."
            }
        }
    }

    private fun userIndex(mode: PowerMode): Int = when (mode) {
        PowerMode.ENERGY -> 0
        PowerMode.BALANCED -> 1
        PowerMode.PERFORMANCE -> 2
        PowerMode.AC -> 3
    }

    private fun batteryPercent(): Int {
        val bm = requireContext().getSystemService(android.os.BatteryManager::class.java)
        return try { bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1 } catch (_: Throwable) { -1 }
    }

    private fun showModelToolsDialog() {
        if (modelDialog?.isShowing == true) return
        val dialog = Dialog(requireContext())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_model_tools)
        dialog.setCancelable(true)
        modelDialog = dialog

        dialog.findViewById<Button>(R.id.importWhisperModel).setOnClickListener {
            whisperModelPicker.launch(arrayOf("application/octet-stream", "application/x-binary", "*/*"))
        }
        dialog.findViewById<Button>(R.id.runReadinessTest).setOnClickListener { runReadinessTest(dialog) }
        dialog.findViewById<TextView>(R.id.modelToolsClose).setOnClickListener { dialog.dismiss() }
        updateDialogModelStatus(dialog)

        dialog.setOnDismissListener {
            modelDialog = null
        }
        dialog.show()
        styleDialog(dialog, widthFraction = 0.92f)
    }

    private fun updateDialogModelStatus(dialog: Dialog) {
        val whisperTv = dialog.findViewById<TextView>(R.id.whisperModelStatus)
        whisperTv.text = if (whisper.modelReady()) {
            val mb = whisper.modelDir().resolve("whisper.base").length() / (1024 * 1024)
            val backend = try { whisper.backendInfo() } catch (_: Throwable) { "?" }
            "Whisper: модель готова ($mb MB) · $backend"
        } else "Whisper: модель не импортирована"
    }

    private fun runReadinessTest(dialog: Dialog) {
        val btn = dialog.findViewById<Button>(R.id.runReadinessTest)
        btn.isEnabled = false
        btn.text = "Проверка…"
        lifecycleScope.launch {
            val items = withContext(Dispatchers.IO) {
                ReadinessCheck.run(requireContext().applicationContext)
            }
            if (!isAdded || !dialog.isShowing) return@launch
            showReadiness(dialog.findViewById(R.id.readinessRows), items)
            btn.isEnabled = true
            btn.text = "Проверить"
        }
    }

    private fun showReadiness(container: LinearLayout, items: List<ReadinessCheck.Item>) {
        container.removeAllViews()
        val overall = ReadinessCheck.overallLabel(items)
        val worst = when {
            items.any { it.level == ReadinessCheck.Level.FAIL } -> ReadinessCheck.Level.FAIL
            items.any { it.level == ReadinessCheck.Level.WARN } -> ReadinessCheck.Level.WARN
            else -> ReadinessCheck.Level.OK
        }
        val views = mutableListOf<View>()
        views += readinessRow(worst, overall, bold = true)
        items.forEach { views += readinessRow(it.level, it.label, bold = false) }
        views.forEach { container.addView(it) }
        Ui.staggerIn(views, step = 40)
    }

    private fun readinessRow(level: ReadinessCheck.Level, text: String, bold: Boolean): View {
        val ctx = requireContext()
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            setPadding(0, Ui.dp(this, 9), 0, 0)
        }
        val (res, color) = when (level) {
            ReadinessCheck.Level.OK -> R.drawable.ic_status_done to R.color.accent_green
            ReadinessCheck.Level.WARN -> R.drawable.ic_status_queue to R.color.accent_amber
            ReadinessCheck.Level.FAIL -> R.drawable.ic_status_error to R.color.accent_red
        }
        val icon = ImageView(ctx).apply {
            setImageResource(res)
            Ui.tint(this, ctx.getColor(color))
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        row.addView(icon, LinearLayout.LayoutParams(Ui.dp(row, 20), Ui.dp(row, 20)).apply { topMargin = Ui.dp(row, 1) })
        val tv = TextView(ctx).apply {
            this.text = text
            textSize = if (bold) 15f else 14f
            setTextColor(ctx.getColor(if (bold) R.color.ink else R.color.ink_muted))
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
        row.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(row, 10)
        })
        return row
    }

    private fun showLogDialog() {
        if (logDialog?.isShowing == true) return
        val dialog = Dialog(requireContext())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_worker_log)
        dialog.setCancelable(true)
        logDialog = dialog
        logTextView = dialog.findViewById(R.id.pipelineLogText)
        dialog.findViewById<TextView>(R.id.logClose).setOnClickListener { dialog.dismiss() }
        dialog.setOnDismissListener {
            uiHandler.removeCallbacks(logRefreshRunnable)
            logTextView = null
            logDialog = null
        }
        dialog.show()
        styleDialog(dialog, widthFraction = 0.94f)
        refreshLog(logTextView!!)
        uiHandler.removeCallbacks(logRefreshRunnable)
        uiHandler.postDelayed(logRefreshRunnable, 2500L)
    }

    private fun refreshLog(tv: TextView) {
        val ctx = context ?: return
        lifecycleScope.launch {
            val since = System.currentTimeMillis() - ONE_HOUR_MS
            val logs = withContext(Dispatchers.IO) { AppDatabase.get(ctx).logs().recentSince(since) }
            if (!isAdded || logTextView !== tv) return@launch
            tv.text = if (logs.isEmpty()) {
                "За последний час записей нет"
            } else {
                logs.joinToString("\n") { log: PipelineLogEntity ->
                    "[${formatTime(log.at)}] ${workerLabel(log.worker)}: ${log.message}"
                }
            }
        }
    }

    private fun workerLabel(worker: String): String = when (worker) {
        "record" -> "Запись"
        "transcribe" -> "Транскрипция"
        "refine" -> "Обработка"
        "important" -> "Важное"
        "daily" -> "Сводка дня"
        else -> worker
    }

    private fun formatTime(ms: Long): String =
        SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(ms))

    private fun displayNameOf(uri: Uri): String? =
        requireContext().contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
        }

    private fun styleDialog(dialog: Dialog, widthFraction: Float) {
        dialog.window?.let { window ->
            window.setBackgroundDrawableResource(R.drawable.bg_card_static)
            window.decorView.setPadding(0, 0, 0, 0)
            val metrics = resources.displayMetrics
            window.setLayout(
                (metrics.widthPixels * widthFraction).toInt(),
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
    }

    private companion object {
        const val ONE_HOUR_MS = 60L * 60L * 1000L
    }
}
