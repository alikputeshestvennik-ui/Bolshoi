package com.example.speechfilter.search

import android.graphics.Typeface
import android.text.SpannableString
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import com.example.speechfilter.pipeline.Seg
import java.util.Calendar

/**
 * A parsed search string. Free words are matched against the transcript
 * (case-insensitive, «ё» = «е», substring so word endings don't matter);
 * "сегодня / вчера / позавчера / 27.09", "14:30" and "в 14" narrow by when the
 * recording started.
 */
data class ParsedQuery(
    val words: List<String>,
    val dayStart: Long?,
    val dayEnd: Long?,
    val minuteOfDay: Int?,
    val hourOnly: Boolean,
    val label: String?
) {
    val isEmpty: Boolean get() = words.isEmpty() && dayStart == null && minuteOfDay == null

    companion object {
        val EMPTY = ParsedQuery(emptyList(), null, null, null, false, null)
    }
}

object RecordSearch {

    /** Same length as the input, so indexes in the result are valid in the original text. */
    fun norm(s: String): String {
        val out = CharArray(s.length)
        for (i in s.indices) {
            val c = s[i]
            out[i] = if (c == 'ё' || c == 'Ё') 'е' else c.lowercaseChar()
        }
        return String(out)
    }

    private val TIME = Regex("^(\\d{1,2}):(\\d{2})$")
    private val HOUR = Regex("^\\d{1,2}$")
    private val DATE = Regex("^(\\d{1,2})\\.(\\d{1,2})(?:\\.(\\d{2,4}))?$")

    fun parse(raw: String, now: Long = System.currentTimeMillis()): ParsedQuery {
        val tokens = norm(raw).split(Regex("\\s+")).filter { it.isNotBlank() }
        val words = ArrayList<String>()
        var dayStart: Long? = null
        var dayEnd: Long? = null
        var minute: Int? = null
        var hourOnly = false
        val labels = ArrayList<String>()

        fun setDay(cal: Calendar, label: String) {
            cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
            dayStart = cal.timeInMillis
            cal.add(Calendar.DAY_OF_YEAR, 1)
            dayEnd = cal.timeInMillis
            labels.add(label)
        }

        var i = 0
        while (i < tokens.size) {
            val t = tokens[i]
            val cal = Calendar.getInstance().apply { timeInMillis = now }
            when {
                t == "сегодня" -> setDay(cal, "сегодня")
                t == "вчера" -> { cal.add(Calendar.DAY_OF_YEAR, -1); setDay(cal, "вчера") }
                t == "позавчера" -> { cal.add(Calendar.DAY_OF_YEAR, -2); setDay(cal, "позавчера") }
                TIME.matches(t) -> {
                    val m = TIME.find(t)!!
                    val h = m.groupValues[1].toInt(); val mm = m.groupValues[2].toInt()
                    if (h in 0..23 && mm in 0..59) {
                        minute = h * 60 + mm; hourOnly = false
                        labels.add("%d:%02d".format(h, mm))
                    } else words.add(t)
                }
                t == "в" && i + 1 < tokens.size && HOUR.matches(tokens[i + 1]) && tokens[i + 1].toInt() in 0..23 -> {
                    val h = tokens[i + 1].toInt()
                    minute = h * 60; hourOnly = true
                    labels.add("в $h ч")
                    i++
                }
                DATE.matches(t) -> {
                    val m = DATE.find(t)!!
                    val d = m.groupValues[1].toInt(); val mo = m.groupValues[2].toInt()
                    if (d in 1..31 && mo in 1..12) {
                        var y = m.groupValues[3].takeIf { it.isNotEmpty() }?.toInt()
                        if (y != null && y < 100) y += 2000
                        val c = Calendar.getInstance().apply { timeInMillis = now }
                        val cur = c.get(Calendar.YEAR)
                        c.set(y ?: cur, mo - 1, d)
                        // no year given and the date is still ahead → it means last year
                        if (y == null && c.timeInMillis > now + 86_400_000L) c.set(Calendar.YEAR, cur - 1)
                        setDay(c, "%02d.%02d".format(d, mo))
                    } else words.add(t)
                }
                else -> words.add(t)
            }
            i++
        }
        return ParsedQuery(words, dayStart, dayEnd, minute, hourOnly, labels.joinToString(" · ").ifEmpty { null })
    }

    /** [text] may be null for recordings that have no transcript yet. */
    fun matches(q: ParsedQuery, startedAt: Long, text: String?): Boolean {
        if (q.isEmpty) return true
        val ds = q.dayStart; val de = q.dayEnd
        if (ds != null && de != null && startedAt !in ds until de) return false
        val target = q.minuteOfDay
        if (target != null) {
            val c = Calendar.getInstance().apply { timeInMillis = startedAt }
            val mod = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
            val ok = if (q.hourOnly) mod / 60 == target / 60 else kotlin.math.abs(mod - target) <= 15
            if (!ok) return false
        }
        if (q.words.isNotEmpty()) {
            if (text.isNullOrBlank()) return false
            val n = norm(text)
            if (!q.words.all { n.contains(it) }) return false
        }
        return true
    }

    /**
     * Whisper segments (words, see whisper_jni.cpp) that contain one of the query
     * words; they become tappable timecodes. Hits closer than 1.5 s are merged.
     */
    fun matchedSegments(q: ParsedQuery, segments: List<Seg>, max: Int = 12): List<Seg> {
        if (q.words.isEmpty()) return emptyList()
        val out = ArrayList<Seg>()
        for (s in segments) {
            val n = norm(s.text)
            if (q.words.none { n.contains(it) }) continue
            if (out.isNotEmpty() && s.startMs - out.last().startMs < 1500) continue
            out += s
            if (out.size >= max) break
        }
        return out
    }

    fun highlight(text: String, words: List<String>, bg: Int, fg: Int): CharSequence {
        val n = norm(text)
        val sp = SpannableString(text)
        for (w in words) {
            if (w.isEmpty()) continue
            var i = n.indexOf(w)
            while (i >= 0) {
                val end = i + w.length
                sp.setSpan(BackgroundColorSpan(bg), i, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sp.setSpan(ForegroundColorSpan(fg), i, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sp.setSpan(StyleSpan(Typeface.BOLD), i, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                i = n.indexOf(w, end)
            }
        }
        return sp
    }

    fun formatTime(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(s / 60, s % 60)
    }
}
