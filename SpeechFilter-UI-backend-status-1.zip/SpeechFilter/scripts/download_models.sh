#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ASSETS="$ROOT/shared/src/main/assets"
WHISPER_DIR="$ROOT/.whisper"
DEPS_DIR="$ROOT/.deps"
WHISPER_VERSION="v1.9.4"
SPIRV_HEADERS_TAG="vulkan-sdk-1.3.296.0"
VULKAN_HPP_TAG="v1.3.296"

mkdir -p "$ASSETS" "$WHISPER_DIR" "$DEPS_DIR"

# ---------------------------------------------------------------------------
# ML runtime models (Silero VAD + YAMNet)
# ---------------------------------------------------------------------------
curl -L --fail --retry 3 \
  "https://github.com/snakers4/silero-vad/raw/master/src/silero_vad/data/silero_vad.onnx" \
  -o "$ASSETS/silero_vad.onnx"

curl -L --fail --retry 3 \
  "https://tfhub.dev/google/lite-model/yamnet/tflite/1?lite-format=tflite" \
  -o "$ASSETS/yamnet.tflite"

curl -L --fail --retry 3 \
  "https://raw.githubusercontent.com/tensorflow/models/master/research/audioset/yamnet/yamnet_class_map.csv" \
  -o "$ASSETS/yamnet_class_map.csv"

# ---------------------------------------------------------------------------
# whisper.cpp sources
# ---------------------------------------------------------------------------
if [ ! -f "$WHISPER_DIR/whisper.cpp/CMakeLists.txt" ]; then
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' EXIT
  curl -L --fail --retry 3 \
    "https://github.com/ggml-org/whisper.cpp/archive/refs/tags/${WHISPER_VERSION}.tar.gz" \
    -o "$tmp/whisper.tar.gz"
  tar -xzf "$tmp/whisper.tar.gz" -C "$tmp"
  rm -rf "$WHISPER_DIR/whisper.cpp"
  mv "$tmp/whisper.cpp-${WHISPER_VERSION#v}" "$WHISPER_DIR/whisper.cpp"
  trap - EXIT
  rm -rf "$tmp"
fi
echo "whisper.cpp $WHISPER_VERSION prepared at $WHISPER_DIR/whisper.cpp"

# ---------------------------------------------------------------------------
# SPIRV-Headers (required by ggml-vulkan find_package(SPIRV-Headers CONFIG))
# Install into a local prefix so CMake can find SPIRV-HeadersConfig.cmake
# ---------------------------------------------------------------------------
SPIRV_SRC="$DEPS_DIR/SPIRV-Headers"
SPIRV_INSTALL="$DEPS_DIR/spirv-headers-install"

if [ ! -f "$SPIRV_INSTALL/share/cmake/SPIRV-Headers/SPIRV-HeadersConfig.cmake" ] && \
   [ ! -f "$SPIRV_INSTALL/lib/cmake/SPIRV-Headers/SPIRV-HeadersConfig.cmake" ]; then
  echo "Downloading SPIRV-Headers ($SPIRV_HEADERS_TAG)..."
  rm -rf "$SPIRV_SRC" "$SPIRV_INSTALL"
  git clone --depth 1 --branch "$SPIRV_HEADERS_TAG" \
    https://github.com/KhronosGroup/SPIRV-Headers.git "$SPIRV_SRC"
  cmake -S "$SPIRV_SRC" -B "$SPIRV_SRC/build" \
    -DCMAKE_INSTALL_PREFIX="$SPIRV_INSTALL" \
    -DSPIRV_HEADERS_ENABLE_TESTS=OFF \
    -DSPIRV_HEADERS_ENABLE_INSTALL=ON
  cmake --build "$SPIRV_SRC/build" --target install
  echo "SPIRV-Headers installed to $SPIRV_INSTALL"
else
  echo "SPIRV-Headers already installed at $SPIRV_INSTALL"
fi

# ---------------------------------------------------------------------------
# Vulkan-Hpp (vulkan.hpp) — NDK only ships vulkan_core.h (C API)
# ggml-vulkan.cpp includes <vulkan/vulkan.hpp>
# ---------------------------------------------------------------------------
VULKAN_HPP_SRC="$DEPS_DIR/Vulkan-Hpp"
if [ ! -f "$VULKAN_HPP_SRC/vulkan/vulkan.hpp" ]; then
  echo "Downloading Vulkan-Hpp ($VULKAN_HPP_TAG)..."
  rm -rf "$VULKAN_HPP_SRC"
  git clone --depth 1 --branch "$VULKAN_HPP_TAG" \
    https://github.com/KhronosGroup/Vulkan-Hpp.git "$VULKAN_HPP_SRC"
  echo "Vulkan-Hpp prepared at $VULKAN_HPP_SRC"
else
  echo "Vulkan-Hpp already present at $VULKAN_HPP_SRC"
fi

echo "All dependencies ready."
