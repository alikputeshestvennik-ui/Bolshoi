package com.example.speechfilter.pipeline

/**
 * Prompts for on-device Gemma. Keep short: small models ignore long rules.
 */
object PromptStore {
    @Volatile
    var refinePrompt: String = """
Исправь только явные ошибки в русской расшифровке. Сохрани почти все слова как есть.

Нельзя:
- писать «Вот ваш текст» или любой комментарий;
- пересказывать своими словами;
- менять смысл;
- переводить;
- брать текст в кавычки.

Верни только исправленный текст.

{{text}}
    """.trimIndent()

    @Volatile
    var importantPrompt: String = """
Выпиши только конкретные факты из текста (кто/что/когда).
Не пиши названия категорий (Задачи, Даты, Имена…).
Если фактов нет — ответь: НЕТ

{{text}}
    """.trimIndent()

    @Volatile
    var dailySummaryPrompt: String = """
Краткий пересказ на русском. Только факты из текста. Без выдумок.
Если почти пусто — «Сводки нет».

{{text}}
    """.trimIndent()

    fun fill(template: String, text: String): String =
        template.replace("{{text}}", text)
}
