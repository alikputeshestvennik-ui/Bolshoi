package com.example.speechfilter.workers

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.ListenableWorker
import androidx.work.OneTimeWorkRequest
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Custom intervals via self-rescheduling OneTimeWork
 * (PeriodicWorkManager minimum is 15 minutes).
 *
 *  - Transcribe: every 10 min (also kicked immediately when a WAV is closed)
 *  - Gemma refine: every 33 min (also ~30s after new transcripts)
 *  - Important extract: every 27 min
 *  - Daily summary: once around 22:00 local
 */
object PipelineScheduler {

    const val UNIQUE_TRANSCRIBE = "pipeline_transcribe"
    const val UNIQUE_REFINE = "pipeline_refine"
    const val UNIQUE_IMPORTANT = "pipeline_important"
    const val UNIQUE_DAILY = "pipeline_daily"

    fun ensureScheduled(context: Context) {
        val wm = WorkManager.getInstance(context.applicationContext)
        scheduleIn(wm, UNIQUE_TRANSCRIBE, TranscribeWorker::class.java, 1)
        scheduleIn(wm, UNIQUE_REFINE, RefineWorker::class.java, 2)
        scheduleIn(wm, UNIQUE_IMPORTANT, ImportantWorker::class.java, 3)
        scheduleDaily(wm)
    }

    fun scheduleIn(
        wm: WorkManager,
        unique: String,
        worker: Class<out ListenableWorker>,
        delayMinutes: Long
    ) {
        val req = OneTimeWorkRequest.Builder(worker)
            .setInitialDelay(delayMinutes, TimeUnit.MINUTES)
            .addTag(unique)
            .build()
        wm.enqueueUniqueWork(unique, ExistingWorkPolicy.KEEP, req)
    }

    fun reschedule(
        context: Context,
        unique: String,
        worker: Class<out ListenableWorker>,
        delayMinutes: Long
    ) {
        val wm = WorkManager.getInstance(context.applicationContext)
        val req = OneTimeWorkRequest.Builder(worker)
            .setInitialDelay(delayMinutes, TimeUnit.MINUTES)
            .addTag(unique)
            .build()
        wm.enqueueUniqueWork(unique, ExistingWorkPolicy.REPLACE, req)
    }

    /** Run as soon as the system allows (new WAV just closed). */
    fun enqueueNow(context: Context, unique: String, worker: Class<out ListenableWorker>) {
        val wm = WorkManager.getInstance(context.applicationContext)
        val req = OneTimeWorkRequest.Builder(worker)
            .addTag(unique)
            .build()
        // REPLACE so a pending delayed run is superseded by an immediate one
        wm.enqueueUniqueWork(unique, ExistingWorkPolicy.REPLACE, req)
    }

    fun enqueueSoon(
        context: Context,
        unique: String,
        worker: Class<out ListenableWorker>,
        delaySeconds: Long
    ) {
        val wm = WorkManager.getInstance(context.applicationContext)
        val req = OneTimeWorkRequest.Builder(worker)
            .setInitialDelay(delaySeconds, TimeUnit.SECONDS)
            .addTag(unique)
            .build()
        wm.enqueueUniqueWork(unique, ExistingWorkPolicy.REPLACE, req)
    }

    private fun scheduleDaily(wm: WorkManager) {
        val now = Calendar.getInstance()
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 22)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            if (before(now)) add(Calendar.DAY_OF_YEAR, 1)
        }
        val delay = next.timeInMillis - now.timeInMillis
        val req = OneTimeWorkRequestBuilder<DailySummaryWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .addTag(UNIQUE_DAILY)
            .build()
        wm.enqueueUniqueWork(UNIQUE_DAILY, ExistingWorkPolicy.KEEP, req)
    }
}
