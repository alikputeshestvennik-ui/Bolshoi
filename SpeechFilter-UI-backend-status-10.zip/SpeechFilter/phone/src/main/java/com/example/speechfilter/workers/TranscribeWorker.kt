package com.example.speechfilter.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.data.PipelineLogEntity
import com.example.speechfilter.data.RefinedTextEntity
import com.example.speechfilter.data.TranscriptEntity
import com.example.speechfilter.pipeline.DayKeys
import com.example.speechfilter.pipeline.WhisperEngine
import java.io.File

/**
 * Transcribe new WAV files with on-device Whisper.
 *
 * Model stays resident in-process (see [WhisperEngine] singleton).
 * If there is nothing new, we skip warmUp entirely so idle runs are cheap.
 */
class TranscribeWorker(
    ctx: Context,
    params: WorkerParameters
) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val db = AppDatabase.get(applicationContext)
        val whisper = WhisperEngine(applicationContext)
        return try {
            val dir = File(applicationContext.getExternalFilesDir(null), "SpeechFilter")
            val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".wav", true) }
                ?.sortedBy { it.lastModified() }
                ?: emptyList()

            val pending = files.filter { db.transcripts().byPath(it.absolutePath) == null }
            if (pending.isEmpty()) {
                db.logs().insert(
                    PipelineLogEntity(
                        worker = "transcribe",
                        message = "Нет новых файлов (всего ${files.size})"
                    )
                )
                return Result.success()
            }

            val warm = whisper.warmUp()
            val already = if (whisper.isLoaded()) " (в RAM)" else ""
            db.logs().insert(
                PipelineLogEntity(worker = "transcribe", message = "$warm$already")
            )
            if (!whisper.isLoaded()) {
                return Result.retry()
            }

            var ok = 0
            var fail = 0
            for (f in pending) {
                val source = when {
                    f.name.contains("_watch_") -> "watch"
                    f.name.contains("_phone_") -> "phone"
                    else -> "unknown"
                }
                val started = System.currentTimeMillis()
                val r = whisper.transcribeFile(f)
                val ms = System.currentTimeMillis() - started
                if (r.isSuccess) {
                    val text = r.getOrDefault("").trim()
                    val tid = db.transcripts().insert(
                        TranscriptEntity(
                            filePath = f.absolutePath,
                            fileName = f.name,
                            sourceTag = source,
                            text = text,
                            createdAt = f.lastModified(),
                            transcribedAt = System.currentTimeMillis(),
                            // Gemma refine disabled — ready for UI / important as-is
                            status = "refined"
                        )
                    )
                    if (tid > 0 && text.isNotEmpty()) {
                        db.refined().insert(
                            RefinedTextEntity(
                                transcriptId = tid,
                                text = text,
                                processedAt = System.currentTimeMillis(),
                                dayKey = DayKeys.of(f.lastModified())
                            )
                        )
                    }
                    ok++
                    db.logs().insert(
                        PipelineLogEntity(
                            worker = "transcribe",
                            message = "${f.name}: ${ms} мс, ${f.length() / 1024} КБ"
                        )
                    )
                } else {
                    fail++
                    db.logs().insert(
                        PipelineLogEntity(
                            worker = "transcribe",
                            message = "${f.name}: ${r.exceptionOrNull()?.message}"
                        )
                    )
                }
            }
            db.logs().insert(
                PipelineLogEntity(
                    worker = "transcribe",
                    message = "Готово: +$ok, ошибка=$fail, новых=${pending.size}"
                )
            )
            // Pass-through refine for any leftover pending
            if (ok > 0) {
                PipelineScheduler.enqueueSoon(
                    applicationContext,
                    PipelineScheduler.UNIQUE_REFINE,
                    RefineWorker::class.java,
                    delaySeconds = 30
                )
            }
            Result.success()
        } catch (t: Throwable) {
            db.logs().insert(
                PipelineLogEntity(worker = "transcribe", message = "crash: ${t.message}")
            )
            Result.retry()
        } finally {
            // Keep model in RAM — only drop on import / explicit unload
            whisper.release(dropShared = false)
            PipelineScheduler.reschedule(
                applicationContext,
                PipelineScheduler.UNIQUE_TRANSCRIBE,
                TranscribeWorker::class.java,
                10
            )
        }
    }
}
