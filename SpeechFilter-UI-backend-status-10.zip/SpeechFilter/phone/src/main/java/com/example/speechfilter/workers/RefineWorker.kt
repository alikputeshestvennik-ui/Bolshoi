package com.example.speechfilter.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.data.PipelineLogEntity
import com.example.speechfilter.data.RefinedTextEntity
import com.example.speechfilter.pipeline.DayKeys

/**
 * Gemma refine is DISABLED: on-device Gemma was rewriting Russian ASR
 * (prefixes like «Вот ваш текст», meaning drift). We keep Whisper text
 * as-is and only mark the pipeline step complete so UI / ImportantWorker
 * still work.
 */
class RefineWorker(
    ctx: Context,
    params: WorkerParameters
) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val db = AppDatabase.get(applicationContext)
        return try {
            val pending = db.transcripts().byStatus("pending", 50)
            var n = 0
            for (t in pending) {
                if (db.refined().countForTranscript(t.id) == 0 && t.text.isNotBlank()) {
                    db.refined().insert(
                        RefinedTextEntity(
                            transcriptId = t.id,
                            text = t.text.trim(),
                            processedAt = System.currentTimeMillis(),
                            dayKey = DayKeys.of(t.createdAt)
                        )
                    )
                }
                db.transcripts().setStatus(t.id, "refined")
                n++
            }
            db.logs().insert(
                PipelineLogEntity(
                    worker = "refine",
                    message = "Gemma refine выключен — оставлен Whisper: $n"
                )
            )
            Result.success()
        } catch (t: Throwable) {
            db.logs().insert(PipelineLogEntity(worker = "refine", message = "crash: ${t.message}"))
            Result.retry()
        } finally {
            PipelineScheduler.reschedule(
                applicationContext,
                PipelineScheduler.UNIQUE_REFINE,
                RefineWorker::class.java,
                33
            )
        }
    }
}
