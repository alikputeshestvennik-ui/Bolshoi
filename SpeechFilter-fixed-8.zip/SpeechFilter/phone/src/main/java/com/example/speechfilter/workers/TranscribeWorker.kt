package com.example.speechfilter.workers

import android.content.Context
import android.os.Process
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.data.PipelineLogEntity
import com.example.speechfilter.data.RefinedTextEntity
import com.example.speechfilter.data.TranscriptEntity
import com.example.speechfilter.pipeline.DayKeys
import com.example.speechfilter.pipeline.WhisperEngine
import java.io.File
import java.io.RandomAccessFile

/**
 * Transcribe new WAV files with on-device Whisper.
 *
 * Model stays resident in-process (see [WhisperEngine] singleton).
 * If there is nothing new, we skip warmUp entirely so idle runs are cheap.
 *
 * This worker is triggered by events, not by a timer:
 *  - RecordingService pushes a run as soon as a segment file closes
 *    (PipelineScheduler.enqueueFileReady)
 *  - the app pushes one catch-up sweep on start (enqueueStartupSweep)
 *
 * It scans the directory rather than accepting a single file argument, so
 * the strongest guarantee available here is "every unprocessed WAV as of
 * this run". That is enough: one surviving trigger picks up everything the
 * pipeline missed, which is why there is no periodic re-run any more.
 *
 * The pipeline step formerly known as "refine" is gone. Whisper's text is
 * used verbatim, and the refined_texts row (plus status="refined") is
 * written right here, in the same loop, so the Records UI and the
 * Important/DailySummary workers keep working unchanged.
 */
class TranscribeWorker(
    ctx: Context,
    params: WorkerParameters
) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        // Whisper is CPU-only now (see whisper_jni.cpp). We now use every
        // core, so the only remaining UI-smoothness lever on the Kotlin side
        // is asking the OS to schedule this below the foreground/UI work
        // instead of competing with it at equal priority.
        try { Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND) } catch (_: Throwable) {}
        val db = AppDatabase.get(applicationContext)
        val whisper = WhisperEngine(applicationContext)
        return try {
            val dir = File(applicationContext.getExternalFilesDir(null), "SpeechFilter")
            val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".wav", true) }
                ?.sortedBy { it.lastModified() }
                ?: emptyList()

            // WavWriter reserves a 44-byte all-zero header at start() and only
            // fills in the real "RIFF"/"WAVE"/... bytes in close(), at the end
            // of the recording — in the SAME target file the whole time (see
            // RecordingService.ensureWav()). So while a segment is still being
            // recorded, its .wav file already exists in this directory but its
            // header is still zeroed out. If this worker picks that file up,
            // whisper.cpp correctly rejects the blank header — logged as "не смог
            // распознать WAV" — even though nothing is actually wrong with the
            // recording; it just isn't finalized yet.
            //
            // This is normal, not an error: with an event-driven queue it
            // simply means the next segment closed while this run was busy.
            // Such files are skipped quietly, and the NEXT run — either the
            // request already chained behind this one by enqueueFileReady,
            // or the startup sweep — will see the real header once
            // RecordingService.closeCurrentWav() has written it.
            val notFinalized = mutableListOf<File>()
            val pending = files.filter { db.transcripts().byPath(it.absolutePath) == null }
                .filter { f ->
                    if (isFinalizedWav(f)) true else { notFinalized += f; false }
                }
            if (pending.isEmpty()) {
                val extra = if (notFinalized.isEmpty()) "" else ", ещё пишется: ${notFinalized.size}"
                db.logs().insert(
                    PipelineLogEntity(
                        worker = "transcribe",
                        message = "Нет новых файлов (всего ${files.size}$extra)"
                    )
                )
                return Result.success()
            }
            if (notFinalized.isNotEmpty()) {
                db.logs().insert(
                    PipelineLogEntity(
                        worker = "transcribe",
                        message = "Ещё пишется (пропущено до след. запуска): ${notFinalized.joinToString { it.name }}"
                    )
                )
            }

            val warm = whisper.warmUp()
            val already = if (whisper.isLoaded()) " (в RAM)" else ""
            db.logs().insert(
                PipelineLogEntity(worker = "transcribe", message = "$warm$already")
            )
            if (!whisper.isLoaded()) {
                return Result.retry()
            }

            var ok = 0
            var fail = 0
            for (f in pending) {
                val source = when {
                    f.name.contains("_watch_") -> "watch"
                    f.name.contains("_phone_") -> "phone"
                    else -> "unknown"
                }
                val started = System.currentTimeMillis()
                val r = whisper.transcribeFile(f)
                val ms = System.currentTimeMillis() - started
                if (r.isSuccess) {
                    val text = r.getOrDefault("").trim()
                    val tid = db.transcripts().insert(
                        TranscriptEntity(
                            filePath = f.absolutePath,
                            fileName = f.name,
                            sourceTag = source,
                            text = text,
                            createdAt = f.lastModified(),
                            transcribedAt = System.currentTimeMillis(),
                            // No refine step any more — text is final as-is
                            status = "refined"
                        )
                    )
                    if (tid > 0 && text.isNotEmpty()) {
                        db.refined().insert(
                            RefinedTextEntity(
                                transcriptId = tid,
                                text = text,
                                processedAt = System.currentTimeMillis(),
                                dayKey = DayKeys.of(f.lastModified())
                            )
                        )
                    }
                    ok++
                    db.logs().insert(
                        PipelineLogEntity(
                            worker = "transcribe",
                            message = "${f.name}: ${ms} мс, ${f.length() / 1024} КБ"
                        )
                    )
                } else {
                    fail++
                    db.logs().insert(
                        PipelineLogEntity(
                            worker = "transcribe",
                            message = "${f.name}: ${r.exceptionOrNull()?.message}"
                        )
                    )
                }
            }
            db.logs().insert(
                PipelineLogEntity(
                    worker = "transcribe",
                    message = "Готово: +$ok, ошибка=$fail, новых=${pending.size}"
                )
            )
            Result.success()
        } catch (t: Throwable) {
            db.logs().insert(
                PipelineLogEntity(worker = "transcribe", message = "crash: ${t.message}")
            )
            Result.retry()
        } finally {
            // Keep the model in RAM — only drop on import / explicit unload.
            //
            // NOTE: there is deliberately NO reschedule() here. This block is
            // what used to lose recordings: it ran reschedule(REPLACE, 10 min)
            // and thereby discarded the immediate request that a just-closed
            // file had enqueued while this run was still busy with the
            // previous one. The queue is now chained by enqueueFileReady
            // (APPEND_OR_REPLACE) and caught up by enqueueStartupSweep.
            whisper.release(dropShared = false)
        }
    }

    /**
     * True once [f] has a real RIFF/WAVE header — i.e. WavWriter.close() has
     * run. False while it's still just the 44-byte zeroed placeholder
     * WavWriter.start() reserves at the very beginning of a recording (see
     * the comment above [pending] for why that matters here).
     */
    private fun isFinalizedWav(f: File): Boolean {
        if (f.length() < 44L) return false
        return try {
            RandomAccessFile(f, "r").use { raf ->
                val magic = ByteArray(4)
                raf.readFully(magic)
                String(magic, Charsets.US_ASCII) == "RIFF"
            }
        } catch (_: Throwable) {
            false
        }
    }
}
