package com.example.speechfilter.workers

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.ListenableWorker
import androidx.work.OneTimeWorkRequest
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Custom intervals via self-rescheduling OneTimeWork
 * (PeriodicWorkManager minimum is 15 minutes).
 *
 *  - Transcribe: NOT periodic any more. A WAV that just closed is pushed
 *    straight into the queue by RecordingService (see [enqueueFileReady]);
 *    [enqueueStartupSweep] is the safety net for anything a process death
 *    swallowed.
 *  - Important extract: every 27 min
 *  - Daily summary: once around 22:00 local
 *
 * There is no refine step: Whisper's text is used as-is, and the "refined"
 * row is written by TranscribeWorker itself so the Records UI keeps working.
 */
object PipelineScheduler {

    const val UNIQUE_TRANSCRIBE = "pipeline_transcribe"
    const val UNIQUE_IMPORTANT = "pipeline_important"
    const val UNIQUE_DAILY = "pipeline_daily"

    fun ensureScheduled(context: Context) {
        val wm = WorkManager.getInstance(context.applicationContext)
        scheduleIn(wm, UNIQUE_IMPORTANT, ImportantWorker::class.java, 3)
        scheduleDaily(wm)
    }

    /**
     * One catch-up transcription pass shortly after app start.
     *
     * Transcription is event-driven now (a closed WAV enqueues itself), so a
     * file whose trigger died with the process would otherwise never be
     * picked up at all. KEEP rather than REPLACE: repeated app starts must
     * not pile up passes, and a sweep that is already queued is exactly what
     * we wanted anyway.
     *
     * Cheap when there is nothing to do — TranscribeWorker returns on
     * pending.isEmpty() before it ever loads the model.
     */
    fun enqueueStartupSweep(context: Context) {
        val wm = WorkManager.getInstance(context.applicationContext)
        val req = OneTimeWorkRequest.Builder(TranscribeWorker::class.java)
            .setInitialDelay(30, TimeUnit.SECONDS)
            .addTag(UNIQUE_TRANSCRIBE)
            .build()
        wm.enqueueUniqueWork(UNIQUE_TRANSCRIBE, ExistingWorkPolicy.KEEP, req)
    }

    fun scheduleIn(
        wm: WorkManager,
        unique: String,
        worker: Class<out ListenableWorker>,
        delayMinutes: Long
    ) {
        val req = OneTimeWorkRequest.Builder(worker)
            .setInitialDelay(delayMinutes, TimeUnit.MINUTES)
            .addTag(unique)
            .build()
        wm.enqueueUniqueWork(unique, ExistingWorkPolicy.KEEP, req)
    }

    fun reschedule(
        context: Context,
        unique: String,
        worker: Class<out ListenableWorker>,
        delayMinutes: Long
    ) {
        val wm = WorkManager.getInstance(context.applicationContext)
        val req = OneTimeWorkRequest.Builder(worker)
            .setInitialDelay(delayMinutes, TimeUnit.MINUTES)
            .addTag(unique)
            .build()
        wm.enqueueUniqueWork(unique, ExistingWorkPolicy.REPLACE, req)
    }

    /**
     * A recording segment just closed: transcribe it now.
     *
     * APPEND_OR_REPLACE, NOT REPLACE. This is the bug that left the newest
     * recording stuck at "⏳ ожидает Whisper" forever. A run already in flight used to end
     * with reschedule(REPLACE, 10 min) in its finally block, which silently
     * discarded the immediate request that a just-closed file had enqueued
     * while that run was still busy with the previous file. APPEND_OR_REPLACE
     * chains the new request behind the running one — nothing is dropped —
     * and only replaces when the chain has already broken.
     *
     * TranscribeWorker scans the whole directory, so the guarantee is "every
     * unprocessed WAV as of this run", not "this one file": a single request
     * that survives covers everything the pipeline missed.
     */
    fun enqueueFileReady(context: Context, unique: String, worker: Class<out ListenableWorker>) {
        val wm = WorkManager.getInstance(context.applicationContext)
        val req = OneTimeWorkRequest.Builder(worker)
            .addTag(unique)
            .build()
        wm.enqueueUniqueWork(unique, ExistingWorkPolicy.APPEND_OR_REPLACE, req)
    }

    fun enqueueSoon(
        context: Context,
        unique: String,
        worker: Class<out ListenableWorker>,
        delaySeconds: Long
    ) {
        val wm = WorkManager.getInstance(context.applicationContext)
        val req = OneTimeWorkRequest.Builder(worker)
            .setInitialDelay(delaySeconds, TimeUnit.SECONDS)
            .addTag(unique)
            .build()
        wm.enqueueUniqueWork(unique, ExistingWorkPolicy.REPLACE, req)
    }

    private fun scheduleDaily(wm: WorkManager) {
        val now = Calendar.getInstance()
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 22)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            if (before(now)) add(Calendar.DAY_OF_YEAR, 1)
        }
        val delay = next.timeInMillis - now.timeInMillis
        val req = OneTimeWorkRequestBuilder<DailySummaryWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .addTag(UNIQUE_DAILY)
            .build()
        wm.enqueueUniqueWork(UNIQUE_DAILY, ExistingWorkPolicy.KEEP, req)
    }
}
