package com.example.speechfilter.wear

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val status = findViewById<TextView>(R.id.status)

        findViewById<Button>(R.id.start).setOnClickListener {
            val need = mutableListOf<String>()
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED
            ) {
                need += Manifest.permission.RECORD_AUDIO
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                need += Manifest.permission.POST_NOTIFICATIONS
            }
            if (need.isNotEmpty()) {
                ActivityCompat.requestPermissions(this, need.toTypedArray(), 20)
                status.text = "Нужен микрофон"
                return@setOnClickListener
            }
            ContextCompat.startForegroundService(
                this, Intent(this, WatchRecordingService::class.java)
            )
            status.text = "ЗАПИСЬ"
        }

        findViewById<Button>(R.id.stop).setOnClickListener {
            stopService(Intent(this, WatchRecordingService::class.java))
            status.text = "СТОП"
        }
    }
}
