package com.example.speechfilter

import android.app.*
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.speechfilter.pipeline.PipelineLog
import com.example.speechfilter.pipeline.PowerMode
import com.example.speechfilter.pipeline.Transcriber
import com.example.speechfilter.shared.*
import com.google.android.gms.wearable.*
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * Stable recording session. Avoids restart storms from Wear messages.
 */
class RecordingService : Service() {

    companion object {
        const val ACTION_SOURCE = "com.example.speechfilter.SOURCE"
        const val EXTRA_SOURCE = "source"
        const val EXTRA_DETAIL = "detail"
        const val EXTRA_STOP = "stop"
        const val ACTION_MODE_CHANGED = "com.example.speechfilter.PROCESSING_MODE_CHANGED"

        @Volatile var sessionActive: Boolean = false
            private set
        @Volatile var activeSource: String = "IDLE"
            private set
        /**
         * false after user STOP until explicit START on phone (or explicit /source/watch from watch button).
         * Prevents watch channel retries from restarting recording ~20s later.
         */
        @Volatile var userArmed: Boolean = false

        /**
         * Set by MainActivity while it plays a recording back through the
         * phone speaker (review playback), so the mic doesn't re-capture the
         * phone's own output and create a feedback loop / duplicate entries.
         */
        @Volatile var selfPlaybackActive: Boolean = false

        /** Name of the WAV that is open for writing right now, or null. */
        @Volatile var recordingFileName: String? = null
            private set

        // How long to keep ignoring mic input after the app stops playing
        // audio back, to cover buffering/room-reverb tail.
        private const val SELF_PLAYBACK_HANGOVER_MS = 800L
        // How often to poll AudioManager for "something on the device is
        // playing audio right now" (music/video/other apps' TTS, etc.) — a
        // Binder call, so it's throttled rather than checked every 32ms frame.
        private const val MUSIC_ACTIVE_POLL_MS = 300L
        private const val MUSIC_ACTIVE_HANGOVER_MS = 600L
    }

    private val io = Executors.newSingleThreadExecutor()
    // Closes the current WAV after FILE_GAP_MS of silence. Previously a file was
    // only closed when the *next* speech arrived after the gap, so a single
    // utterance stayed open (zeroed header -> Whisper rejects it) until STOP.
    // The SpeechEngine currently fed by the phone mic / watch stream. Its
    // `pending` flag tells the idle watcher that an utterance is still waiting
    // for YAMNet (~1 s), so the file must not be closed underneath it.
    @Volatile private var engine: SpeechEngine? = null
    private var droppedSince = 0
    private var lastDropLogAt = 0L

    private val idleWatcher = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "wav-idle-watch").apply { isDaemon = true }
    }
    private var source = "PHONE"
    private val stopping = AtomicBoolean(false)
    private var localThread: Thread? = null
    private var audioRecord: AudioRecord? = null
    private var wav: WavWriter? = null
    private var wavFile: File? = null
    private var bytesWritten = 0L
    private var segmentBytes = 0L
    @Volatile private var lastSpeechAt = 0L
    private var watchStarted = false
    private var channelClient: ChannelClient? = null
    private var channel: ChannelClient.Channel? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var channelRegistered = false
    private var echoCanceler: AcousticEchoCanceler? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var audioManager: AudioManager? = null
    private var deviceAudioHangoverUntil = 0L
    private var selfPlaybackHangoverUntil = 0L
    private var lastMusicActiveCheckAt = 0L

    private val powerReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_POWER_CONNECTED) {
                // Always scan for untranscribed files when charging starts,
                // even while already listening.
                Transcriber.enqueue(applicationContext, worker = "charge_sweep")
            }
            if (stopping.get() || !sessionActive) return
            if (intent?.action != Intent.ACTION_POWER_CONNECTED &&
                intent?.action != Intent.ACTION_POWER_DISCONNECTED &&
                intent?.action != Intent.ACTION_BATTERY_CHANGED &&
                intent?.action != ACTION_MODE_CHANGED) return
            val before = currentMode
            val after = PowerMode.effective(applicationContext)
            if (before != after) {
                currentMode = after
                updateNotification("Режим: ${after.title}")
                restartCurrentSourceForMode()
            }
        }
    }

    @Volatile private var currentMode: PowerMode = PowerMode.BALANCED

    private val channelCallback = object : ChannelClient.ChannelCallback() {
        override fun onChannelOpened(ch: ChannelClient.Channel) {
            if (ch.path != "/speech-audio") return
            if (stopping.get() || !sessionActive || activeSource != "WATCH") return
            // Already reading a channel — ignore duplicates
            if (channel != null && channel?.nodeId == ch.nodeId) return
            channel = ch
            watchStarted = true
            source = "WATCH"
            activeSource = "WATCH"
            publishSource("WATCH", "поток")
            updateNotification("Galaxy Watch 8: поток")
            Wearable.getChannelClient(this@RecordingService).getInputStream(ch)
                .addOnSuccessListener { input ->
                    thread(name = "watch-pcm-reader", isDaemon = true) {
                        try {
                            val models = ModelFiles
                            val mode = currentMode
                            val vad = SileroVad(models.silero(this@RecordingService))
                            val yam = if (mode == PowerMode.ENERGY) null else loadYamnet()
                            val eng = SpeechEngine(
                                vad = vad,
                                yamnet = yam,
                                requireYamnet = mode != PowerMode.ENERGY,
                                energyGate = mode == PowerMode.ENERGY,
                                onSpeechPcm = { pcm -> appendSpeech(pcm) },
                                onDropped = { reason -> logDropped(reason) }
                            )
                            engine = eng
                            val parser = AudioPacket.Parser { _, pcm ->
                                if (!stopping.get() && !shouldSuppressSelfAudio()) eng.acceptPcm16(pcm)
                            }
                            val buf = ByteArray(16 * 1024)
                            while (!stopping.get() && sessionActive && activeSource == "WATCH") {
                                val n = try { input.read(buf) } catch (_: Exception) { break }
                                if (n <= 0) break
                                parser.push(buf.copyOf(n))
                            }
                            if (engine === eng) engine = null
                            try { vad.close() } catch (_: Exception) {}
                            try { yam?.close() } catch (_: Exception) {}
                        } catch (t: Throwable) {
                            updateNotification("Канал: ${t.message}")
                        } finally {
                            try { input.close() } catch (_: Exception) {}
                        }
                    }
                }
                .addOnFailureListener {
                    updateNotification("Канал: нет входного потока")
                }
        }

        override fun onChannelClosed(
            ch: ChannelClient.Channel,
            closeReason: Int,
            appSpecificErrorCode: Int
        ) {
            if (ch.path == "/speech-audio") {
                channel = null
                watchStarted = false
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        enterForeground("Ожидание источника")
        acquireWakeLock()
        currentMode = PowerMode.effective(applicationContext)
        audioManager = getSystemService(AudioManager::class.java)
        idleWatcher.scheduleWithFixedDelay({ closeIfIdle() }, 250, 250, TimeUnit.MILLISECONDS)
        val powerFilter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(powerReceiver, powerFilter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(powerReceiver, powerFilter)
        }
        channelClient = Wearable.getChannelClient(this)
        if (!channelRegistered) {
            channelClient?.registerChannelCallback(channelCallback)
            channelRegistered = true
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Explicit stop
        if (intent?.getBooleanExtra(EXTRA_STOP, false) == true) {
            userStop()
            return START_NOT_STICKY
        }

        val requested = intent?.getStringExtra("source") ?: "PHONE"
        userArmed = true

        // Already running same mode — ignore (stops restart storm)
        if (sessionActive && !stopping.get()) {
            when {
                requested == activeSource -> {
                    updateNotification("Уже запись: $activeSource")
                    return START_STICKY
                }
                requested == "WATCH" && activeSource == "WATCH" -> return START_STICKY
                requested == "PHONE" && activeSource == "PHONE" -> return START_STICKY
                // Source switch: stop local mic or wait for watch without full teardown
                requested == "PHONE" && activeSource != "PHONE" -> {
                    switchToPhone()
                    return START_STICKY
                }
                requested == "WATCH" && activeSource != "WATCH" -> {
                    switchToWatch()
                    return START_STICKY
                }
            }
        }

        stopping.set(false)
        currentMode = PowerMode.effective(applicationContext)
        sessionActive = true
        source = requested
        activeSource = requested
        bytesWritten = 0L
        segmentBytes = 0L
        lastSpeechAt = 0L
        watchStarted = false

        when (requested) {
            "WATCH" -> switchToWatch()
            else -> startPhone()
        }
        return START_STICKY
    }

    /**
     * Ask the watch to (re)start streaming. Sends two layers, deliberately:
     *
     *  1. MessageClient — instant if the watch is reachable right now, but
     *     ephemeral: if the watch's Bluetooth radio is briefly asleep (very
     *     common — Wear OS suspends BT aggressively to save battery) the
     *     message is just dropped with no retry, which is the actual cause
     *     of "recording from the watch doesn't always trigger".
     *  2. DataClient (putDataItem, urgent) — NOT ephemeral: Play Services
     *     keeps this as the current value of "/control/state" and syncs it
     *     to the watch the moment the two devices reconnect, even minutes
     *     later, with no polling/retry loop needed on our side. This is the
     *     backup path that actually makes "start and forget" reliable.
     *
     * [ControlService] on the watch reacts to both.
     */
    private fun sendWatchControl(action: String) {
        val ts = System.currentTimeMillis()
        try {
            Wearable.getDataClient(this)
                .putDataItem(
                    PutDataMapRequest.create("/control/state").apply {
                        dataMap.putString("action", action)
                        dataMap.putLong("ts", ts)
                    }.asPutDataRequest().setUrgent()
                )
        } catch (_: Exception) {}
        if (action != "start") return
        try {
            Wearable.getNodeClient(this).connectedNodes
                .addOnSuccessListener { nodes ->
                    val nearby = nodes.firstOrNull { it.isNearby } ?: nodes.firstOrNull()
                    if (nearby != null) {
                        Wearable.getMessageClient(this)
                            .sendMessage(nearby.id, "/control/start", byteArrayOf())
                    }
                }
        } catch (_: Exception) {}
    }

    private fun switchToWatch() {
        // Stop phone mic and close the previous watch channel before switching.
        stopPhoneMicOnly()
        channel?.let { ch -> try { channelClient?.close(ch) } catch (_: Exception) {} }
        channel = null
        watchStarted = false
        closeCurrentWav()
        source = "WATCH"
        activeSource = "WATCH"
        publishSource("WATCH", "ожидание")
        updateNotification("Ожидание потока с часов…")
        sendWatchControl("start")
        // Same resend pattern as the explicit watch switch: a still-connected phone but a
        // momentarily-asleep watch radio is the common failure mode here.
        io.execute {
            for (attempt in 1..8) {
                try { Thread.sleep(5_000) } catch (_: InterruptedException) { return@execute }
                if (stopping.get() || activeSource != "WATCH" || channel != null) return@execute
                sendWatchControl("start")
            }
        }
    }

    private fun switchToPhone() {
        // Close watch input first so an old channel cannot keep feeding audio.
        channel?.let { ch -> try { channelClient?.close(ch) } catch (_: Exception) {} }
        channel = null
        watchStarted = false
        closeCurrentWav()
        source = "PHONE"
        stopPhoneMicOnly()
        startPhone()
    }

    private fun restartCurrentSourceForMode() {
        if (stopping.get()) return
        when (activeSource) {
            "PHONE" -> {
                stopPhoneMicOnly()
                startPhone()
            }
            "WATCH" -> {
                channel?.let { ch -> try { channelClient?.close(ch) } catch (_: Exception) {} }
                channel = null
                watchStarted = false
                sendWatchControl("start")
            }
        }
    }

    private fun stopPhoneMicOnly() {
        try { audioRecord?.stop() } catch (_: Exception) {}
        try { audioRecord?.release() } catch (_: Exception) {}
        audioRecord = null
        try { echoCanceler?.release() } catch (_: Exception) {}
        echoCanceler = null
        try { noiseSuppressor?.release() } catch (_: Exception) {}
        noiseSuppressor = null
        localThread?.interrupt()
        localThread = null
    }

    /**
     * True while the mic input should be ignored because the sound
     * currently reaching it is very likely the phone's own output rather
     * than the room: either this app is previewing a recording out loud
     * (selfPlaybackActive), or AudioManager reports something is actively
     * playing on the device (music, another app, a call's media stream). A
     * short hangover after either condition ends covers buffering/reverb.
     */
    private fun shouldSuppressSelfAudio(): Boolean {
        val now = System.currentTimeMillis()
        if (selfPlaybackActive) {
            selfPlaybackHangoverUntil = now + SELF_PLAYBACK_HANGOVER_MS
            return true
        }
        if (now < selfPlaybackHangoverUntil) return true

        if (now - lastMusicActiveCheckAt >= MUSIC_ACTIVE_POLL_MS) {
            lastMusicActiveCheckAt = now
            val playing = try {
                audioManager?.isMusicActive == true
            } catch (_: Exception) {
                false
            }
            if (playing) deviceAudioHangoverUntil = now + MUSIC_ACTIVE_HANGOVER_MS
        }
        return now < deviceAudioHangoverUntil
    }

    private fun startPhone() {
        if (localThread?.isAlive == true) return
        if (stopping.get()) return
        source = "PHONE"
        activeSource = "PHONE"
        watchStarted = false
        publishSource("PHONE", "микрофон")
        updateNotification("Телефон: микрофон")
        localThread = thread(name = "phone-audio", isDaemon = true) {
            try {
                val min = AudioRecord.getMinBufferSize(
                    AudioConfig.SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                if (min <= 0) {
                    updateNotification("AudioRecord недоступен")
                    return@thread
                }
                val record = AudioRecord(
                    MediaRecorder.AudioSource.MIC, AudioConfig.SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    (min * 2).coerceAtLeast(AudioConfig.FRAME_SAMPLES * 4 * 2)
                )
                if (record.state != AudioRecord.STATE_INITIALIZED) {
                    updateNotification("Микрофон не инициализирован")
                    record.release()
                    return@thread
                }
                audioRecord = record
                // Hardware/software echo cancellation + noise suppression on
                // this capture session — the platform-level line of defence
                // against the phone hearing its own speaker output.
                try {
                    if (AcousticEchoCanceler.isAvailable()) {
                        echoCanceler = AcousticEchoCanceler.create(record.audioSessionId)
                            ?.apply { enabled = true }
                    }
                } catch (_: Throwable) {}
                try {
                    if (NoiseSuppressor.isAvailable()) {
                        noiseSuppressor = NoiseSuppressor.create(record.audioSessionId)
                            ?.apply { enabled = true }
                    }
                } catch (_: Throwable) {}
                val models = ModelFiles
                val mode = currentMode
                val vad = SileroVad(models.silero(this))
                val yam = if (mode == PowerMode.ENERGY) null else loadYamnet()
                val e = SpeechEngine(
                    vad = vad,
                    yamnet = yam,
                    requireYamnet = mode != PowerMode.ENERGY,
                    energyGate = mode == PowerMode.ENERGY,
                    onSpeechPcm = { pcm -> appendSpeech(pcm) },
                    onDropped = { reason -> logDropped(reason) }
                )
                engine = e
                record.startRecording()
                publishSource("PHONE", "слушаю")
                updateNotification("Слушаю микрофон…")
                val buf = ShortArray(AudioConfig.FRAME_SAMPLES)
                while (!stopping.get() && activeSource == "PHONE") {
                    val n = record.read(buf, 0, buf.size)
                    if (n > 0) {
                        // Drain the mic buffer either way (keeps AudioRecord
                        // from over/underrunning) but only feed it to the
                        // VAD pipeline when it's not our own playback.
                        if (!shouldSuppressSelfAudio()) {
                            e.acceptPcm16(if (n == buf.size) buf else buf.copyOf(n))
                        }
                    } else if (n < 0) break
                }
                if (engine === e) engine = null
                try { record.stop() } catch (_: Exception) {}
                try { record.release() } catch (_: Exception) {}
                try { echoCanceler?.release() } catch (_: Exception) {}
                echoCanceler = null
                try { noiseSuppressor?.release() } catch (_: Exception) {}
                noiseSuppressor = null
                try { vad.close() } catch (_: Exception) {}
                try { yam?.close() } catch (_: Exception) {}
            } catch (t: Throwable) {
                updateNotification("Ошибка: ${t.message}")
            }
        }
    }

    /** Loads YAMNet and says in the worker log whether the filter is really on. */
    private fun loadYamnet(): YamnetClassifier? {
        return try {
            val y = YamnetClassifier(ModelFiles.yamnet(this), ModelFiles.labels(this))
            if (y.labelsLoaded < 500) {
                PipelineLog.add(this, "record", "YAMNet: прочитано меток ${y.labelsLoaded} из 521 — проверьте yamnet_class_map.csv")
            }
            PipelineLog.add(this, "record", "YAMNet: фильтр речи включён")
            y
        } catch (t: Throwable) {
            PipelineLog.add(this, "record", "YAMNet НЕ загрузился (${t.javaClass.simpleName}: ${t.message}) — работает только VAD")
            null
        }
    }

    /**
     * Segments thrown away before they reach a file. Logged at most every 10 s
     * as a counter so continuous water noise can't flood the 30-line window.
     */
    private fun logDropped(reason: String) {
        droppedSince++
        val now = System.currentTimeMillis()
        if (now - lastDropLogAt < 10_000L) return
        lastDropLogAt = now
        PipelineLog.add(this, "record", "Отсеяно: $reason (сегментов: $droppedSince)")
        droppedSince = 0
    }

    @Synchronized
    private fun appendSpeech(pcm: ShortArray) {
        if (stopping.get()) return
        val now = System.currentTimeMillis()
        val gapMs = if (lastSpeechAt == 0L) 0L else now - lastSpeechAt
        if (wav != null && lastSpeechAt != 0L && gapMs >= AudioConfig.FILE_CLOSE_AFTER_LAST_AUDIO_MS.toLong()) {
            closeCurrentWav()
        }
        ensureWav().appendPcm16(pcm)
        val add = pcm.size * 2L
        bytesWritten += add
        segmentBytes += add
        lastSpeechAt = now
    }

    @Synchronized
    private fun ensureWav(): WavWriter {
        wav?.let { return it }
        val dir = File(getExternalFilesDir(null), "SpeechFilter").apply { mkdirs() }
        val tag = if (activeSource == "WATCH" || watchStarted) "watch" else "phone"
        val file = File(dir, "speech_${tag}_${System.currentTimeMillis()}.wav")
        wavFile = file
        segmentBytes = 0L
        recordingFileName = file.name
        PipelineLog.add(this, "record", "Запись файла: ${file.name}")
        return WavWriter(file).also { it.start(); wav = it }
    }

    @Synchronized
    private fun closeIfIdle() {
        if (wav == null || lastSpeechAt == 0L) return
        // An utterance is buffered, waiting for YAMNet: it will be appended to
        // this file in a moment, so the silence before it does not count.
        if (engine?.pending == true) return
        // 5 s of silence counted from the end of the last voiced audio: every
        // segment already ends with POST_ROLL_MS of silence, hence the shorter wait.
        if (System.currentTimeMillis() - lastSpeechAt >= AudioConfig.FILE_CLOSE_AFTER_LAST_AUDIO_MS) closeCurrentWav()
    }

    @Synchronized
    private fun closeCurrentWav() {
        val name = wavFile?.name
        val bytes = segmentBytes
        recordingFileName = null
        try { wav?.close() } catch (_: Exception) {}
        var kept: File? = null
        wavFile?.let { f ->
            if (segmentBytes < 2000 && f.exists()) {
                // drop tiny noise blips (< ~0.06s)
                try { f.delete() } catch (_: Exception) {}
            } else if (f.exists() && segmentBytes >= 2000) {
                kept = f
            }
        }
        wav = null
        wavFile = null
        segmentBytes = 0L
        if (name != null) {
            if (kept != null) {
                val sec = bytes / (AudioConfig.SAMPLE_RATE * 2.0)
                PipelineLog.add(
                    this, "record",
                    "Файл закрыт: $name, ${"%.1f".format(sec)} с, ${bytes / 1024} КБ → на распознавание"
                )
            } else {
                PipelineLog.add(this, "record", "Файл отброшен (слишком короткий): $name")
            }
        }
        // Transcribe ASAP on Transcriber's OWN process-wide queue — not on this
        // service's `io` executor (onDestroy() shuts that down, which killed the
        // run queued by userStop()) and not via WorkManager (which only runs
        // "when the system gets to it"). Transcriber scans oldest-file-first.
        val effectiveAtClose = PowerMode.effective(applicationContext)
        if (kept != null && (effectiveAtClose == PowerMode.PERFORMANCE || effectiveAtClose == PowerMode.AC)) {
            Transcriber.enqueue(applicationContext)
        }
    }

    private fun userStop() {
        userArmed = false
        stopping.set(true)
        sessionActive = false
        activeSource = "IDLE"
        // Tell watch to stop streaming — durable DataItem first (so a watch
        // that reconnects late still sees "stop" and doesn't start recording
        // on a stale "start" it missed while asleep), then the fast message.
        sendWatchControl("stop")
        try {
            Wearable.getNodeClient(this).connectedNodes
                .addOnSuccessListener { nodes ->
                    for (n in nodes) {
                        Wearable.getMessageClient(this)
                            .sendMessage(n.id, "/control/stop", byteArrayOf(1))
                    }
                }
        } catch (_: Exception) {}
        stopPhoneMicOnly()
        channel?.let { ch ->
            try { channelClient?.close(ch) } catch (_: Exception) {}
        }
        channel = null
        closeCurrentWav()
        publishSource("STOPPED")
        updateNotification("Остановлено · расшифровка…")
        // Do NOT stopSelf() right away: onDestroy() would tear the service down
        // while the segment closed above is still waiting for Whisper. Stay in
        // the foreground (process keeps CPU + priority) until the queue is empty.
        Transcriber.whenIdle {
            if (!sessionActive) {
                releaseWakeLock()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    override fun onDestroy() {
        stopping.set(true)
        sessionActive = false
        activeSource = "IDLE"
        // keep userArmed as-is: only userStop clears it; process death clears memory anyway
        stopPhoneMicOnly()
        channel?.let { ch ->
            try { channelClient?.close(ch) } catch (_: Exception) {}
        }
        channel = null
        closeCurrentWav()
        if (channelRegistered) {
            try { channelClient?.unregisterChannelCallback(channelCallback) } catch (_: Exception) {}
            channelRegistered = false
        }
        releaseWakeLock()
        try { unregisterReceiver(powerReceiver) } catch (_: Exception) {}
        idleWatcher.shutdownNow()
        io.shutdownNow()
        publishSource("STOPPED")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun enterForeground(text: String) {
        val n = notification(text)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(42, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(42, n)
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SpeechFilter:Recording").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {}
        wakeLock = null
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("speech", "Фильтр", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    private fun notification(text: String) =
        NotificationCompat.Builder(this, "speech")
            .setContentTitle("Фильтр")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()

    private fun updateNotification(text: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(42, notification(text))
        } catch (_: Exception) {}
    }

    private fun publishSource(src: String, detail: String = "") {
        try {
            sendBroadcast(
                Intent(ACTION_SOURCE)
                    .setPackage(packageName)
                    .putExtra(EXTRA_SOURCE, src)
                    .putExtra(EXTRA_DETAIL, detail)
            )
        } catch (_: Exception) {}
    }
}
