package com.example.speechfilter

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.speechfilter.pipeline.PipelineLog
import com.example.speechfilter.pipeline.AacCompressor
import com.example.speechfilter.pipeline.Transcriber

/**
 * On POWER_CONNECTED:
 *  1. Always trigger Whisper to scan for untranscribed WAVs and start transcription.
 *  2. If auto-start-on-charge is enabled in settings and no session is active,
 *     start recording from the phone mic.
 */
class ChargingReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_POWER_CONNECTED) return

        val app = context.applicationContext

        // Always kick off transcription of pending files when charging begins,
        // regardless of whether listening is active.
        try {
            Transcriber.enqueue(app, worker = "charge_sweep")
            PipelineLog.add(app, "charge", "Зарядка: запуск поиска нерасшифрованных файлов")
        } catch (t: Throwable) {
            PipelineLog.add(app, "charge", "ошибка запуска транскрибации: ${t.message}")
        }

        try {
            AacCompressor.enqueue(app)
        } catch (t: Throwable) {
            PipelineLog.add(app, "charge", "ошибка запуска сжатия: ${t.message}")
        }

        if (!AppPrefs.isAutoStartOnCharge(app)) return
        if (RecordingService.sessionActive) return

        try {
            val start = Intent(app, RecordingService::class.java).putExtra("source", "PHONE")
            ContextCompat.startForegroundService(app, start)
            PipelineLog.add(app, "charge", "Автозапуск прослушивания при зарядке")
        } catch (t: Throwable) {
            PipelineLog.add(app, "charge", "не удалось автозапустить запись: ${t.message}")
        }
    }
}
