package com.example.speechfilter

import android.app.Application
import com.example.speechfilter.workers.PipelineScheduler
import com.example.speechfilter.pipeline.AacCompressor

class FilterApp : Application() {
    override fun onCreate() {
        super.onCreate()
        PipelineScheduler.ensureScheduled(this)
        // Transcription is event-driven now (a closed WAV enqueues itself).
        // Anything whose trigger died with the process is picked up here.
        PipelineScheduler.enqueueStartupSweep(this)
        // Re-check the compression queue on every process start. This is important
        // after an app update/restart: an already-enabled switch must not require
        // the user to toggle it off/on before pending files are picked up.
        AacCompressor.enqueue(this)
    }
}
