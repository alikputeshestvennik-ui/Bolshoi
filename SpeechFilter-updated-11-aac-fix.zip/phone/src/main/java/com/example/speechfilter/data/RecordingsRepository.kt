package com.example.speechfilter.data

import android.content.Context
import com.example.speechfilter.RecordingService
import com.example.speechfilter.pipeline.SegmentsCodec
import com.example.speechfilter.pipeline.Transcriber
import com.example.speechfilter.pipeline.WordTimes
import java.io.File

enum class RecordingStatus { RECORDING, RECOGNIZING, QUEUED, PROCESSING, DONE, FAILED }

data class RecordingRow(
    val file: File,
    val transcript: TranscriptEntity?,
    val important: Boolean
) {
    val fromWatch: Boolean get() = file.name.contains("_watch_")

    /** True when the on-disk file is already M4A/MP4 (post-charge compression). */
    val compressed: Boolean
        get() {
            val ext = file.extension.lowercase()
            return ext == "m4a" || ext == "mp4"
        }

    val startedAt: Long
        get() = Regex("(\\d{13})").findAll(file.name).lastOrNull()?.value?.toLongOrNull()
            ?: file.lastModified()

    val displayText: String?
        get() = transcript?.text?.takeIf { it.isNotBlank() }

    val status: RecordingStatus
        get() = when {
            transcript == null && file.name == RecordingService.recordingFileName -> RecordingStatus.RECORDING
            transcript == null && file.name == Transcriber.processingFileName -> RecordingStatus.RECOGNIZING
            transcript == null -> RecordingStatus.QUEUED
            transcript.status == "refined" -> RecordingStatus.DONE
            transcript.status == "failed" -> RecordingStatus.FAILED
            else -> RecordingStatus.PROCESSING
        }

    val statusLabel: String
        get() = when (status) {
            RecordingStatus.RECORDING -> "Идёт запись"
            RecordingStatus.RECOGNIZING -> "Распознаётся"
            RecordingStatus.QUEUED -> "В очереди на распознавание"
            RecordingStatus.PROCESSING -> "В обработке"
            RecordingStatus.DONE -> "Обработано"
            RecordingStatus.FAILED -> "Ошибка распознавания"
        }
}

object RecordingsRepository {

    fun recordingsDir(context: Context): File =
        File(context.getExternalFilesDir(null), "SpeechFilter")

    suspend fun loadRows(context: Context): List<RecordingRow> {
        val db = AppDatabase.get(context)
        val files = recordingsDir(context)
            .listFiles { f ->
                f.isFile && (
                    f.extension.equals("wav", true) ||
                    f.extension.equals("m4a", true) ||
                    f.extension.equals("mp4", true)
                )
            }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
        return files.map { f ->
            RecordingRow(f, db.transcripts().byPath(f.absolutePath), db.important().isMarked(f.absolutePath))
        }
    }

    suspend fun loadImportantRows(context: Context): List<RecordingRow> {
        val db = AppDatabase.get(context)
        return db.important().recent(200).mapNotNull { mark ->
            val file = File(mark.filePath)
            if (!file.exists()) {
                db.important().unmark(mark.filePath)
                return@mapNotNull null
            }
            RecordingRow(file, db.transcripts().byPath(file.absolutePath), true)
        }
    }

    suspend fun setImportant(context: Context, file: File, important: Boolean) {
        val dao = AppDatabase.get(context).important()
        if (important) dao.mark(ImportantRecordingEntity(file.absolutePath))
        else dao.unmark(file.absolutePath)
    }

    /** Saves an edited transcript and carries the word timecodes over to the new text. */
    suspend fun updateText(context: Context, row: RecordingRow, newText: String): Boolean {
        val t = row.transcript ?: return false
        val clean = newText.trim()
        if (clean.isEmpty()) return false
        val old = WordTimes.timedWords(t.text, SegmentsCodec.decode(t.segments))
        val segs = WordTimes.align(old, clean)
        AppDatabase.get(context).transcripts()
            .setTextAndSegments(t.id, clean, SegmentsCodec.encode(segs.orEmpty()))
        return true
    }

    /** Transcripts whose WAV still exists and that lack (good) word timecodes. */
    suspend fun retimeCandidates(context: Context): List<TranscriptEntity> =
        AppDatabase.get(context).transcripts().all().filter { t ->
            val f = java.io.File(t.filePath)
            WordTimes.needsRetime(t.text, t.segments) && f.isFile && f.extension.equals("wav", true)
        }

    suspend fun deleteRecording(context: Context, row: RecordingRow) {
        val db = AppDatabase.get(context)
        row.transcript?.let { db.transcripts().deleteById(it.id) }
        db.important().unmark(row.file.absolutePath)
        if (row.file.exists()) row.file.delete()
    }
}
