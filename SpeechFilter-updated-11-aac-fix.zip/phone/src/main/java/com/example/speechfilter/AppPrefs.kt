package com.example.speechfilter

import android.content.Context

/** Simple shared preferences for app-level toggles. */
object AppPrefs {
    private const val PREFS = "app_prefs"
    private const val KEY_AUTO_START_ON_CHARGE = "auto_start_on_charge"
    private const val KEY_COMPRESS_ON_CHARGE = "compress_on_charge"

    fun isAutoStartOnCharge(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_AUTO_START_ON_CHARGE, true)

    fun setAutoStartOnCharge(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_AUTO_START_ON_CHARGE, enabled).apply()
    }

    /** After Whisper transcription, compress WAV→M4A while charging and delete the WAV. */
    fun isCompressOnCharge(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_COMPRESS_ON_CHARGE, true)

    fun setCompressOnCharge(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_COMPRESS_ON_CHARGE, enabled).apply()
    }
}
