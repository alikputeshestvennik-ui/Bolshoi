package com.example.speechfilter.pipeline

import java.util.concurrent.ConcurrentHashMap

/**
 * Lightweight in-process progress registry for the Records screen.
 * The UI polls it on the main thread; workers never touch Android Views.
 */
data class PipelineProgressState(
    val path: String,
    val stage: String,
    val current: Int,
    val total: Int,
    val fraction: Float
)

object PipelineProgress {
    private val states = ConcurrentHashMap<String, PipelineProgressState>()

    fun update(path: String, stage: String, current: Int, total: Int, fraction: Float) {
        states[path] = PipelineProgressState(
            path = path,
            stage = stage,
            current = current.coerceAtLeast(1),
            total = total.coerceAtLeast(1),
            fraction = fraction.coerceIn(0f, 1f)
        )
    }

    fun get(path: String): PipelineProgressState? = states[path]

    fun clear(path: String) {
        states.remove(path)
    }

    fun clearAllForStage(stage: String) {
        states.entries.removeIf { it.value.stage == stage }
    }

    fun any(): Boolean = states.isNotEmpty()
    fun snapshot(): List<PipelineProgressState> = states.values.toList()
}
