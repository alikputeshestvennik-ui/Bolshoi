package com.example.speechfilter.shared

import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * YAMNet (521 AudioSet classes, 0.975 s window @ 16 kHz).
 *
 * Label parsing: yamnet_class_map.csv starts with a header row
 * ("index,mid,display_name"). The old code kept that row as label #0, which
 * shifted every label by one — "Speech" was looked up at output[1]
 * (Child speech), "Conversation" at output[3], and so on — so the score it
 * called "speech" was never the real Speech class. Labels are now placed by
 * the index column and the header is ignored.
 */
class YamnetClassifier(modelFile: File, labelsFile: File) : AutoCloseable {

    class Verdict(
        val accept: Boolean,
        val speech: Float,
        val noise: Float,
        val noiseKind: String,
        val topLabel: String,
        val topScore: Float
    ) {
        fun describe(): String = when {
            speech < AudioConfig.YAMNET_SPEECH_MIN && noise >= AudioConfig.YAMNET_NOISE_MIN ->
                "$noiseKind ${fmt(noise)}, речь ${fmt(speech)}"
            speech < AudioConfig.YAMNET_SPEECH_MIN ->
                "не речь: $topLabel ${fmt(topScore)}, речь ${fmt(speech)}"
            else -> "$noiseKind ${fmt(noise)} сильнее речи ${fmt(speech)}"
        }
        private fun fmt(v: Float) = "%.2f".format(v)
    }

    private val interpreter = Interpreter(map(modelFile), Interpreter.Options().apply { setNumThreads(2) })

    private val labels: Array<String> = run {
        val out = Array(CLASSES) { "" }
        labelsFile.forEachLine { line ->
            val p = line.split(',', limit = 3)
            val idx = p.getOrNull(0)?.trim()?.toIntOrNull() ?: return@forEachLine // header / junk
            if (idx in 0 until CLASSES && p.size >= 3) {
                out[idx] = p[2].trim().removeSurrounding("\"")
            }
        }
        out
    }

    private val speechIdx = labels.indices.filter { isSpeech(labels[it]) }.toIntArray()

    /** class index -> Russian name of the artifact family, only for non-speech artifacts. */
    private val artifactKind: Map<Int, String> = buildMap {
        for (i in labels.indices) artifactKindOf(labels[i])?.let { put(i, it) }
    }

    /** Sanity check for logs: how many labels were resolved. */
    val labelsLoaded: Int = labels.count { it.isNotEmpty() }

    fun classify(samples: FloatArray): Verdict {
        require(samples.size == AudioConfig.YAMNET_WINDOW_SAMPLES) { "YAMNet needs ${AudioConfig.YAMNET_WINDOW_SAMPLES} samples" }
        val output = Array(1) { FloatArray(CLASSES) }
        interpreter.run(arrayOf(samples), output)
        val sc = output[0]

        val speech = if (speechIdx.isEmpty()) 0f
        else speechIdx.sumOf { sc[it].toDouble() }.toFloat().coerceAtMost(1f)

        var noise = 0f
        var noiseKind = ""
        for ((i, kind) in artifactKind) {
            if (sc[i] > noise) { noise = sc[i]; noiseKind = kind }
        }
        var top = 0
        for (i in sc.indices) if (sc[i] > sc[top]) top = i

        val notSpeech = speech < AudioConfig.YAMNET_SPEECH_MIN
        val dominated = noise >= AudioConfig.YAMNET_NOISE_MIN && noise > speech * AudioConfig.YAMNET_NOISE_DOMINANCE
        return Verdict(
            accept = !notSpeech && !dominated,
            speech = speech,
            noise = noise,
            noiseKind = noiseKind.ifEmpty { "шум" },
            topLabel = labels[top].ifEmpty { "class $top" },
            topScore = sc[top]
        )
    }

    /** Kept for callers that only need a yes/no. */
    fun isHumanSpeech(samples: FloatArray, threshold: Float = AudioConfig.YAMNET_SPEECH_MIN): Boolean {
        if (samples.size != AudioConfig.YAMNET_WINDOW_SAMPLES) return false
        return classify(samples).let { it.accept && it.speech >= threshold }
    }

    override fun close() = interpreter.close()

    private fun map(file: File): MappedByteBuffer =
        FileInputStream(file).channel.use { ch -> ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size()) }

    private companion object {
        const val CLASSES = 521
        // \brain, not contains("rain"): that would also match "Train".
        val RAIN = Regex("\\brain")

        fun isSpeech(label: String): Boolean {
            val l = label.lowercase()
            if (l.isEmpty() || l.contains("synthesizer")) return false
            return l.contains("speech") || l.contains("conversation") ||
                l.contains("narration") || l.contains("monologue") ||
                l == "whispering"
        }

        fun artifactKindOf(label: String): String? {
            val l = label.lowercase()
            if (l.isEmpty()) return null
            return when {
                l.contains("cough") || l.contains("throat clearing") -> "кашель"
                l.contains("sneeze") -> "чих"
                l.contains("sniff") -> "шмыганье"
                l.contains("hiccup") || l.contains("burping") -> "икота/отрыжка"
                l.contains("breathing") || l.contains("gasp") || l.contains("pant") ||
                    l.contains("wheeze") || l.contains("snoring") || l.contains("sigh") -> "дыхание"
                l.contains("water") || l.contains("trickle") || l.contains("dribble") ||
                    l.contains("stream") || l.contains("splash") || l.contains("splatter") ||
                    l.contains("pour") || l.contains("drip") || l.contains("gurgl") ||
                    l.contains("liquid") || l.contains("sink") || l.contains("bathtub") ||
                    l.contains("toilet") || l.contains("boiling") || RAIN.containsMatchIn(l) ||
                    l.contains("waterfall") -> "вода"
                else -> null
            }
        }
    }
}
