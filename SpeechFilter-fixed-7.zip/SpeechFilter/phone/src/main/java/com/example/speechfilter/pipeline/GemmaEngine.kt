package com.example.speechfilter.pipeline

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession.LlmInferenceSessionOptions
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Offline Gemma engine backed by Google's MediaPipe LLM Inference API
 * (com.google.mediapipe:tasks-genai). Runs a locally imported Gemma
 * checkpoint (.task / .bin, and .gguf as a raw path passthrough) entirely
 * on-device — no network calls, no server round-trip.
 *
 * Model path: filesDir/models/<sanitized-original-name>.{task|gguf|bin} —
 * any MediaPipe-compatible checkpoint, Gemma or otherwise. The original
 * file name is kept (not collapsed to one generic name) because
 * [isGemmaModel] reads it back to decide which chat template to use.
 *
 * The native model is expensive to load (a multi-hundred-MB to multi-GB
 * file), so it is kept in a process-wide singleton shared across every
 * GemmaEngine(context) instance/worker run instead of being reloaded from
 * disk each time RefineWorker/ImportantWorker/DailySummaryWorker fire.
 *
 * IMPORTANT: every call that touches the native LlmInference object
 * (create/close/generateResponse) goes through the single companion
 * [lock], never a per-instance one. RefineWorker/ImportantWorker/
 * DailySummaryWorker each construct their own GemmaEngine, so an
 * instance-level `@Synchronized` would do nothing to stop two different
 * worker threads calling generateResponse() on the *same* shared native
 * object at the same time — MediaPipe's native inference is not
 * reentrant, and a concurrent call there is a real, observed crash
 * (native abort, killing the whole app — not a catchable Kotlin
 * exception). Routing everything through one lock is what actually
 * prevents that.
 */
class GemmaEngine(private val context: Context) {

    companion object {
        // Sanity floor so a wrong/partial file pick doesn't get accepted as a model.
        // Real quantized LLM checkpoints (.task/.gguf/.bin) are realistically
        // >100MB; 20MB just rejects obviously-wrong picks (images, docs, etc).
        private const val MIN_MODEL_BYTES = 20L * 1024L * 1024L
        private val EXTS = setOf("task", "gguf", "bin")

        // Historical: this engine originally only accepted files named
        // "gemma*". Gemma's small on-device checkpoints (2B/3B-class, the
        // only sizes that fit this device) are noticeably weaker at Russian
        // than at English — that's a property of those specific checkpoints,
        // not something a prompt tweak fixes. MediaPipe's LlmInference API
        // itself is model-agnostic (it runs any compatible .task/.gguf/.bin
        // checkpoint, Gemma or not), so the "must be named gemma*" check was
        // an artificial restriction stopping you from ever trying a
        // checkpoint with better Russian support (e.g. a Vikhr/T-lite/
        // Qwen2.5-Instruct .task or .gguf build, or a Russian-finetuned
        // Gemma). It's removed below: any single imported file with one of
        // the extensions above is now accepted as "the" local LLM, whatever
        // it's named.
        private const val MODEL_BASENAME = "llm-model"

        private const val MAX_TOKENS = 1024
        // MaxTopK must be >= default session topK (40) or generateResponse fails:
        // "Top-K value 40 must be <= 8 which is determined by the first created session"
        private const val MAX_TOP_K = 40
        private const val TOP_K = 40
        private const val TEMPERATURE = 0.2f

        // Rough headroom multiplier: loading needs the model's bytes resident
        // plus working memory for activations/kv-cache/tokenizer. If available
        // RAM is clearly short of this, refuse to load instead of letting the
        // native allocator abort the whole process.
        private const val MEMORY_HEADROOM_FACTOR = 1.3

        // Process-wide lock guarding every native call: creation, close, AND
        // generateResponse. Shared with WhisperEngine — see
        // NativeInferenceLock for why (both engines' heavy native work must
        // be mutually exclusive, not just each engine's own calls).
        private val lock = NativeInferenceLock.lock

        @Volatile private var sharedInference: LlmInference? = null
        @Volatile private var sharedInferenceModelPath: String? = null
    }

    private val warmed = AtomicBoolean(false)

    fun modelDir(): File = File(context.filesDir, "models").apply { mkdirs() }

    private fun isLlmFile(f: File): Boolean {
        val n = f.name.lowercase()
        // Whisper's own model file lives in the same directory (see
        // WhisperEngine.modelDir()) but is named "whisper.base" with no
        // .task/.gguf/.bin extension, so it never matches here.
        return EXTS.any { n.endsWith(".$it") }
    }

    private fun existingModelFile(): File? = modelDir().listFiles()?.firstOrNull(::isLlmFile)

    fun modelReady(): Boolean = existingModelFile()?.let { it.length() > MIN_MODEL_BYTES } == true

    fun modelFile(): File? = existingModelFile()

    /**
     * MediaPipe's LlmInference API does not apply a chat template for you —
     * whatever text you hand it is exactly what the tokenizer sees. Gemma's
     * instruction-tuned checkpoints were trained on turns wrapped exactly
     * like this; without it, the model just free-continues off the end of
     * the raw text instead of following the instructions in the prompt.
     *
     * This wrapping is Gemma-specific: `<start_of_turn>`/`<end_of_turn>` are
     * tokens Gemma's tokenizer was trained to treat specially. A different
     * family's tokenizer (Qwen/ChatML uses `<|im_start|>`, Llama 3 uses
     * `<|start_header_id|>`, etc.) would just see that text literally —
     * confusing the model rather than helping it, likely worse than no
     * wrapping at all. So this is only applied when the imported file looks
     * like a Gemma checkpoint (see [isGemmaModel]); anything else gets the
     * plain instruction text unwrapped, which most instruct-tuned models
     * still follow reasonably even without their native template. If you
     * import a specific non-Gemma model and want its exact template wired
     * up for best quality, say which one and it can be added here.
     */
    private fun wrapTurn(prompt: String): String =
        "<start_of_turn>user\n$prompt<end_of_turn>\n<start_of_turn>model\n"

    private fun isGemmaModel(f: File): Boolean = f.name.lowercase().contains("gemma")

    /**
     * Import a user-selected local LLM checkpoint (.task / .gguf / .bin) into
     * app-private storage. Despite the class name, this accepts ANY
     * MediaPipe-compatible checkpoint, not only ones named "gemma*" — see the
     * comment on [MODEL_BASENAME] above for why that restriction was removed.
     * Point this at a Gemma build, a Vikhr/T-lite/Qwen2.5-Instruct build, or
     * anything else you want to try for Russian refine quality.
     */
    fun importModel(uri: Uri, displayName: String?): Result<File> = runCatching {
        release(dropShared = true)
        val ext = displayName
            ?.substringAfterLast('.', "")
            ?.lowercase()
            ?.takeIf { it in EXTS } ?: "task"

        // Keep (a sanitized form of) the original file name rather than
        // collapsing everything to one generic name: isGemmaModel() above
        // reads it back later to decide which chat template to use, and the
        // settings screen shows it so you can tell at a glance which
        // checkpoint is actually loaded.
        val safeStem = displayName
            ?.substringBeforeLast('.')
            ?.lowercase()
            ?.replace(Regex("[^a-z0-9._-]+"), "-")
            ?.trim('-', '.')
            ?.takeIf { it.isNotBlank() }
            ?.take(60)
        val baseName = safeStem ?: MODEL_BASENAME

        // Replace any previously imported LLM checkpoint (whatever it was named).
        modelDir().listFiles()?.forEach { if (isLlmFile(it)) it.delete() }

        val out = File(modelDir(), "$baseName.$ext")
        val tmp = File(modelDir(), "$baseName.$ext.tmp")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(tmp).use { output -> input.copyTo(output) }
        } ?: error("Не удалось открыть выбранный файл")
        if (tmp.length() < MIN_MODEL_BYTES) {
            tmp.delete()
            error("Файл слишком маленький для языковой модели: ${tmp.length()} байт")
        }
        if (!tmp.renameTo(out)) {
            tmp.copyTo(out, overwrite = true)
            tmp.delete()
        }
        out
    }

    private fun availableMemoryBytes(): Long {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            ?: return Long.MAX_VALUE // can't check — don't block on it
        val info = ActivityManager.MemoryInfo()
        return try {
            am.getMemoryInfo(info)
            info.availMem
        } catch (_: Throwable) {
            Long.MAX_VALUE
        }
    }

    /** Loads (or reuses) the shared native LlmInference engine for [modelPath]. Caller holds [lock]. */
    private fun ensureLoadedLocked(modelPath: String, modelBytes: Long) {
        if (sharedInference != null && sharedInferenceModelPath == modelPath) return
        sharedInference?.let { runCatching { it.close() } }
        sharedInference = null
        sharedInferenceModelPath = null

        val need = (modelBytes * MEMORY_HEADROOM_FACTOR).toLong()
        val avail = availableMemoryBytes()
        if (avail < need) {
            error(
                "недостаточно свободной памяти: доступно ${avail / (1024 * 1024)} МБ, " +
                    "нужно ~${need / (1024 * 1024)} МБ — модель не загружена, чтобы не уронить приложение"
            )
        }

        // NOTE: setTopK/setTemperature do NOT exist on LlmInferenceOptions.Builder
        // (only setMaxTopK does — that's just the ceiling every session must
        // stay under, not a value applied to inference). They only exist on
        // LlmInferenceSession.LlmInferenceSessionOptions.Builder, built per
        // session in generate() below. A previous version of this code looked
        // up "setTopK"/"setTemperature" on the wrong builder via reflection,
        // which silently found nothing and did nothing — TOP_K/TEMPERATURE
        // were never actually applied, and every generate() call ran at the
        // API's default temperature (0.8) instead of the intended 0.2.
        val options = LlmInferenceOptions.builder()
            .setModelPath(modelPath)
            .setMaxTokens(MAX_TOKENS)
            .setMaxTopK(MAX_TOP_K)
            .build()
        sharedInference = LlmInference.createFromOptions(context.applicationContext, options)
        sharedInferenceModelPath = modelPath
    }

    fun warmUp(): String {
        val model = existingModelFile()
        if (model == null) {
            warmed.set(false)
            return "Gemma: модель не найдена в ${modelDir().absolutePath}"
        }
        return synchronized(lock) {
            try {
                ensureLoadedLocked(model.absolutePath, model.length())
                warmed.set(true)
                "Gemma: модель загружена (${model.name})"
            } catch (t: Throwable) {
                warmed.set(false)
                "Gemma: ошибка загрузки модели — ${t.message ?: t.toString()}"
            }
        }
    }

    /**
     * Runs prompt+text through the real on-device Gemma model via MediaPipe's
     * LLM Inference API and returns the generated text. Wrapped in the
     * companion [lock] end-to-end (load check + the generateResponse call
     * itself), so it's safe to call from several workers without them ever
     * touching the native object concurrently.
     */
    fun generate(promptTemplate: String, text: String): Result<String> {
        if (text.isBlank()) return Result.success("")
        val model = existingModelFile()
            ?: return Result.failure(IllegalStateException("Нет модели Gemma в ${modelDir()}"))
        return synchronized(lock) {
            try {
                ensureLoadedLocked(model.absolutePath, model.length())
                warmed.set(true)
                val engine = sharedInference
                    ?: return@synchronized Result.failure(IllegalStateException("Gemma engine не инициализирован"))
                val filled = PromptStore.fill(promptTemplate, text)
                val prompt = if (isGemmaModel(model)) wrapTurn(filled) else filled
                // Explicit session per call (closed right after) instead of
                // engine.generateResponse(): that convenience method builds an
                // *implicit* session with default options every time — topK/
                // temperature can't be set on it at all, so it always ran at
                // the API default temperature (0.8), not the TOP_K/TEMPERATURE
                // configured below. A fresh session per call also avoids
                // leaking prior-prompt context between unrelated
                // Refine/Important/DailySummary calls that share this engine.
                val sessionOptions = LlmInferenceSessionOptions.builder()
                    .setTopK(TOP_K)
                    .setTemperature(TEMPERATURE)
                    .build()
                val session = LlmInferenceSession.createFromOptions(engine, sessionOptions)
                val response = try {
                    session.addQueryChunk(prompt)
                    session.generateResponse()
                } finally {
                    runCatching { session.close() }
                }
                Result.success(GemmaOutput.stripPrefix(response?.trim().orEmpty()))
            } catch (t: Throwable) {
                warmed.set(false)
                Result.failure(t)
            }
        }
    }

    /**
     * Marks this handle as not-warm. The shared native model stays resident
     * (loading it is expensive) unless [dropShared] is true, e.g. right
     * before importing a different model file.
     */
    fun release(dropShared: Boolean = false) {
        warmed.set(false)
        if (dropShared) {
            synchronized(lock) {
                sharedInference?.let { runCatching { it.close() } }
                sharedInference = null
                sharedInferenceModelPath = null
            }
        }
    }
}
