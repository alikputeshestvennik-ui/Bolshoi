package com.example.speechfilter.shared

import kotlin.math.min

/**
 * VAD (Silero) + optional YAMNet human-speech check.
 * Emits PCM segments that look like speech.
 */
class SpeechEngine(
    private val vad: SileroVad,
    private val yamnet: YamnetClassifier?,
    private val onSpeechPcm: (ShortArray) -> Unit,
    private val requireYamnet: Boolean = false
) {
    private val hp = HighPassFilter()
    private val preRoll = ShortRingBuffer(AudioConfig.SAMPLE_RATE * AudioConfig.PRE_ROLL_MS / 1000)
    private val candidate = ArrayList<ShortArray>()
    private val yamnetBuffer = ShortArray(AudioConfig.YAMNET_WINDOW_SAMPLES)
    private var yamnetSize = 0
    private var inSpeech = false
    private var confirmed = false
    private var silenceSamples = 0
    private val postRollSamples = AudioConfig.SAMPLE_RATE * AudioConfig.POST_ROLL_MS / 1000

    fun reset() {
        preRoll.clear()
        candidate.clear()
        yamnetSize = 0
        inSpeech = false
        confirmed = false
        silenceSamples = 0
        vad.reset()
        hp.reset()
    }

    fun acceptPcm16(samples: ShortArray) {
        val filtered = samples.copyOf()
        hp.process(filtered)
        preRoll.add(filtered)

        var offset = 0
        while (offset + 512 <= filtered.size) {
            val frame = filtered.copyOfRange(offset, offset + 512)
            offset += 512
            val f = FloatArray(512) { frame[it] / 32768f }
            val p = try {
                vad.probability(f)
            } catch (_: Throwable) {
                // If VAD fails, treat moderate energy as speech candidate
                val energy = f.map { it * it }.average().toFloat()
                if (energy > 1e-4f) 0.7f else 0.1f
            }
            val speech = p >= AudioConfig.VAD_THRESHOLD

            if (!inSpeech && speech) {
                inSpeech = true
                confirmed = !requireYamnet || yamnet == null
                silenceSamples = 0
                candidate.clear()
                yamnetSize = 0
                val previous = preRoll.snapshot()
                if (previous.isNotEmpty()) candidate.add(previous)
            }

            if (inSpeech) {
                candidate.add(frame)
                if (yamnet != null && yamnetSize < yamnetBuffer.size) {
                    val n = min(frame.size, yamnetBuffer.size - yamnetSize)
                    frame.copyInto(yamnetBuffer, yamnetSize, 0, n)
                    yamnetSize += n
                }

                if (!confirmed && yamnet != null && yamnetSize >= yamnetBuffer.size) {
                    val yamnetFloat = FloatArray(yamnetBuffer.size) { yamnetBuffer[it] / 32768f }
                    confirmed = try {
                        yamnet.isHumanSpeech(yamnetFloat, 0.12f)
                    } catch (_: Throwable) {
                        true // if classifier fails, keep VAD decision
                    }
                    if (confirmed) {
                        flushCandidate()
                    } else {
                        yamnetSize = 0
                    }
                } else if (confirmed && candidate.size >= 4) {
                    // Stream confirmed speech out in chunks
                    flushCandidate()
                }

                if (!speech) silenceSamples += frame.size else silenceSamples = 0

                if (silenceSamples >= postRollSamples) {
                    if (confirmed || (!requireYamnet && candidate.isNotEmpty())) {
                        confirmed = true
                        flushCandidate()
                    }
                    candidate.clear()
                    yamnetSize = 0
                    inSpeech = false
                    confirmed = false
                    silenceSamples = 0
                }
            }
        }
    }

    private fun flushCandidate() {
        if (candidate.isEmpty()) return
        for (part in candidate) onSpeechPcm(part)
        candidate.clear()
    }
}
