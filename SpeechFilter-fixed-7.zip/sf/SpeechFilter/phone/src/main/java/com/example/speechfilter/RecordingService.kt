package com.example.speechfilter

import android.app.*
import android.content.Intent
import android.media.*
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.speechfilter.shared.*
import com.google.android.gms.wearable.*
import java.io.File
import java.util.concurrent.Executors
import kotlin.concurrent.thread

class RecordingService : Service() {
    private val io = Executors.newSingleThreadExecutor()
    private var source = "AUTO"
    @Volatile private var stopping = false
    private var localThread: Thread? = null
    private var audioRecord: AudioRecord? = null
    private var wav: WavWriter? = null
    private var wavFile: File? = null
    private var bytesWritten = 0L
    private var segmentBytes = 0L
    @Volatile private var lastSpeechAt = 0L
    private var watchStarted = false
    private var channelClient: ChannelClient? = null
    private var channel: ChannelClient.Channel? = null

    private val channelCallback = object : ChannelClient.ChannelCallback() {
        override fun onChannelOpened(ch: ChannelClient.Channel) {
            if (ch.path != "/speech-audio") return
            channel = ch
            watchStarted = true
            Wearable.getChannelClient(this@RecordingService).getInputStream(ch)
                .addOnSuccessListener { input ->
                    updateNotification("Galaxy Watch 8: поток → фильтр на телефоне")
                    thread(name = "watch-pcm-reader") {
                        try {
                            val models = ModelFiles
                            val vad = SileroVad(models.silero(this@RecordingService))
                            val yam = try {
                                YamnetClassifier(models.yamnet(this@RecordingService), models.labels(this@RecordingService))
                            } catch (_: Throwable) { null }
                            val engine = SpeechEngine(
                                vad = vad,
                                yamnet = yam,
                                requireYamnet = false,
                                onSpeechPcm = { pcm -> appendSpeech(pcm) }
                            )
                            val parser = AudioPacket.Parser { _, pcm ->
                                engine.acceptPcm16(pcm)
                            }
                            val buf = ByteArray(16 * 1024)
                            while (!stopping) {
                                val n = input.read(buf)
                                if (n <= 0) break
                                parser.push(buf.copyOf(n))
                            }
                            vad.close()
                            yam?.close()
                        } catch (t: Throwable) {
                            updateNotification("Канал часов: ${t.message}")
                            if (!stopping && source != "WATCH") startPhone()
                        } finally {
                            try { input.close() } catch (_: Exception) {}
                        }
                    }
                }
                .addOnFailureListener {
                    updateNotification("Не удалось открыть канал часов")
                    if (source != "WATCH") startPhone()
                }
        }

        override fun onChannelClosed(
            ch: ChannelClient.Channel,
            closeReason: Int,
            appSpecificErrorCode: Int
        ) {
            if (!stopping && ch.path == "/speech-audio") {
                updateNotification("Канал часов закрыт")
                if (source != "WATCH") startPhone()
            }
        }
    }


    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(42, notification("Ожидание источника"))
        channelClient = Wearable.getChannelClient(this)
        channelClient?.registerChannelCallback(channelCallback)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopping = false
        bytesWritten = 0L
        source = intent?.getStringExtra("source") ?: "AUTO"
        stopPipelines()
        stopping = false
        lastSpeechAt = 0L
        segmentBytes = 0L
        if (source == "PHONE") startPhone()
        else startWatchOrFallback()
        return START_NOT_STICKY
    }

    private fun startWatchOrFallback() {
        val forceWatch = source == "WATCH"
        updateNotification("Поиск Galaxy Watch…")
        Wearable.getNodeClient(this).connectedNodes
            .addOnSuccessListener { nodes ->
                val nearby = nodes.firstOrNull { it.isNearby } ?: nodes.firstOrNull()
                if (nearby == null) {
                    if (forceWatch) {
                        updateNotification("Часы не найдены. Откройте приложение на Watch и START")
                    } else {
                        updateNotification("Часы не найдены → микрофон телефона")
                        startPhone()
                    }
                    return@addOnSuccessListener
                }
                Wearable.getMessageClient(this)
                    .sendMessage(nearby.id, "/control/start", byteArrayOf())
                    .addOnSuccessListener {
                        updateNotification("Сигнал на Watch отправлен. Ожидание канала…")
                    }
                    .addOnFailureListener {
                        if (forceWatch) {
                            updateNotification("Не удалось связаться с Watch. Запустите запись на часах вручную")
                        } else {
                            updateNotification("Часы недоступны → микрофон телефона")
                            startPhone()
                        }
                    }
                // AUTO: fallback after 12s; WATCH: wait longer, no phone fallback
                io.execute {
                    try { Thread.sleep(if (forceWatch) 20000 else 12000) } catch (_: InterruptedException) { return@execute }
                    if (!stopping && channel == null) {
                        if (forceWatch) {
                            updateNotification("Нет канала с часов. Нажмите START на Watch")
                        } else if (localThread?.isAlive != true) {
                            updateNotification("Таймаут часов → микрофон телефона")
                            startPhone()
                        }
                    }
                }
            }
            .addOnFailureListener {
                if (forceWatch) updateNotification("Wear API ошибка")
                else {
                    updateNotification("Wear API ошибка → микрофон телефона")
                    startPhone()
                }
            }
    }

    private fun startPhone() {
        if (localThread?.isAlive == true) return
        watchStarted = false
        updateNotification("Телефон: запись с микрофона")
        localThread = thread(name = "phone-audio") {
            try {
                val min = AudioRecord.getMinBufferSize(
                    AudioConfig.SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                if (min <= 0) {
                    updateNotification("Ошибка: AudioRecord недоступен ($min)")
                    return@thread
                }
                val record = AudioRecord(
                    MediaRecorder.AudioSource.MIC, AudioConfig.SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    (min * 2).coerceAtLeast(AudioConfig.FRAME_SAMPLES * 4 * 2)
                )
                if (record.state != AudioRecord.STATE_INITIALIZED) {
                    updateNotification("Ошибка: микрофон не инициализирован")
                    record.release()
                    return@thread
                }
                audioRecord = record

                val models = ModelFiles
                val sileroFile = models.silero(this)
                val yamnetFile = models.yamnet(this)
                val labelsFile = models.labels(this)
                updateNotification("Модели: VAD ${sileroFile.length() / 1024}KB, YAMNet ${yamnetFile.length() / 1024}KB")

                val vad = SileroVad(sileroFile)
                val yam = try {
                    YamnetClassifier(yamnetFile, labelsFile)
                } catch (t: Throwable) {
                    updateNotification("YAMNet недоступен, только VAD: ${t.message}")
                    null
                }
                // requireYamnet=false → VAD alone is enough to keep audio
                val e = SpeechEngine(
                    vad = vad,
                    yamnet = yam,
                    requireYamnet = false,
                    onSpeechPcm = { pcm -> appendSpeech(pcm) }
                )
                record.startRecording()
                updateNotification("Слушаю микрофон… говорите")
                val buf = ShortArray(AudioConfig.FRAME_SAMPLES)
                var frames = 0
                while (!stopping) {
                    val n = record.read(buf, 0, buf.size)
                    if (n > 0) {
                        e.acceptPcm16(if (n == buf.size) buf else buf.copyOf(n))
                        frames++
                        if (frames % 50 == 0) {
                            updateNotification("Запись… ${(bytesWritten / 1024)} KB речи")
                        }
                    } else if (n < 0) {
                        updateNotification("Ошибка чтения микрофона: $n")
                        break
                    }
                }
                try { record.stop() } catch (_: Exception) {}
                try { record.release() } catch (_: Exception) {}
                vad.close()
                yam?.close()
                updateNotification("Стоп. Речи: ${bytesWritten / 1024} KB")
            } catch (t: Throwable) {
                updateNotification("Ошибка: ${t.javaClass.simpleName}: ${t.message}")
            }
        }
    }

    /**
     * Append speech PCM. If silence gap since last speech >= 5s,
     * close current file and start a new one on next speech.
     */
    @Synchronized
    private fun appendSpeech(pcm: ShortArray) {
        val now = System.currentTimeMillis()
        val gapMs = if (lastSpeechAt == 0L) 0L else now - lastSpeechAt
        if (wav != null && lastSpeechAt != 0L && gapMs >= AudioConfig.FILE_GAP_MS.toLong()) {
            closeCurrentWav()
            updateNotification("Пауза ${gapMs / 1000}с → новый файл")
        }
        ensureWav().appendPcm16(pcm)
        val add = pcm.size * 2L
        bytesWritten += add
        segmentBytes += add
        lastSpeechAt = now
    }

    @Synchronized
    private fun ensureWav(): WavWriter {
        wav?.let { return it }
        val dir = File(getExternalFilesDir(null), "SpeechFilter").apply { mkdirs() }
        val file = File(dir, "speech_${System.currentTimeMillis()}.wav")
        wavFile = file
        segmentBytes = 0L
        updateNotification("Новый файл: ${file.name}")
        return WavWriter(file).also { it.start(); wav = it }
    }

    @Synchronized
    private fun closeCurrentWav() {
        try { wav?.close() } catch (_: Exception) {}
        wavFile?.let { f ->
            if (segmentBytes == 0L && f.exists() && f.length() <= 44L) {
                f.delete()
            }
        }
        wav = null
        wavFile = null
        segmentBytes = 0L
    }

    private fun stopPipelines() {
        stopping = true
        localThread?.interrupt()
        localThread = null
        try { audioRecord?.stop() } catch (_: Exception) {}
        try { audioRecord?.release() } catch (_: Exception) {}
        audioRecord = null
        channel?.let { ch ->
            try { channelClient?.close(ch) } catch (_: Exception) {}
        }
        channel = null
        closeCurrentWav()
        lastSpeechAt = 0L
    }

    override fun onDestroy() {
        stopPipelines()
        try { channelClient?.unregisterChannelCallback(channelCallback) } catch (_: Exception) {}
        io.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("speech", "Speech Filter", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun notification(text: String) =
        NotificationCompat.Builder(this, "speech")
            .setContentTitle("Speech Filter")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(42, notification(text))
    }
}
