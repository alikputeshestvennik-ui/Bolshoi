package com.example.speechfilter.wear

import android.app.*
import android.content.Intent
import android.media.*
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.speechfilter.shared.AudioConfig
import com.example.speechfilter.shared.AudioPacket
import com.google.android.gms.tasks.Tasks
import com.google.android.gms.wearable.*
import java.io.OutputStream
import kotlin.concurrent.thread

/**
 * Watch side: capture mic and stream PCM frames to the phone.
 * No ML on watch (too heavy for Galaxy Watch).
 */
class WatchRecordingService : Service() {
    @Volatile private var stopping = false
    private var worker: Thread? = null
    private var record: AudioRecord? = null
    private var output: OutputStream? = null
    private var channel: ChannelClient.Channel? = null
    private var sequence = 0

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("watch_speech", "Speech Filter", NotificationManager.IMPORTANCE_LOW)
        )
        startForeground(7, notification("Galaxy Watch: подготовка"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopping = false
        worker?.interrupt()
        worker = thread(name = "watch-audio") { runCapture() }
        return START_NOT_STICKY
    }

    private fun runCapture() {
        try {
            update("Поиск телефона…")
            val nodes = try {
                Tasks.await(Wearable.getNodeClient(this).connectedNodes)
            } catch (t: Throwable) {
                update("Нет связи с телефоном")
                return
            }
            val phone = nodes.firstOrNull { it.isNearby }
                ?: nodes.firstOrNull()
                ?: run {
                    update("Телефон не подключён")
                    return
                }

            val client = Wearable.getChannelClient(this)
            update("Открытие канала…")
            channel = Tasks.await(client.openChannel(phone.id, "/speech-audio"))
            output = Tasks.await(client.getOutputStream(channel!!))

            val min = AudioRecord.getMinBufferSize(
                AudioConfig.SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            if (min <= 0) {
                update("AudioRecord недоступен")
                return
            }
            val r = AudioRecord(
                MediaRecorder.AudioSource.MIC, AudioConfig.SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                (min * 2).coerceAtLeast(AudioConfig.FRAME_SAMPLES * 4 * 2)
            )
            if (r.state != AudioRecord.STATE_INITIALIZED) {
                update("Микрофон не инициализирован")
                r.release()
                return
            }
            record = r
            update("ЗАПИСЬ с часов")
            r.startRecording()
            val buf = ShortArray(AudioConfig.FRAME_SAMPLES)
            var frames = 0
            while (!stopping) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0) {
                    val pcm = if (n == buf.size) buf else buf.copyOf(n)
                    val packet = AudioPacket.encode(sequence++, pcm)
                    output?.write(packet)
                    if (frames % 30 == 0) output?.flush()
                    frames++
                } else if (n < 0) {
                    update("Ошибка чтения: $n")
                    break
                }
            }
            try { r.stop() } catch (_: Exception) {}
            try { r.release() } catch (_: Exception) {}
            update("Стоп")
        } catch (t: Throwable) {
            update("Ошибка: ${t.message ?: t.javaClass.simpleName}")
        } finally {
            try { output?.flush() } catch (_: Exception) {}
            try { output?.close() } catch (_: Exception) {}
            channel?.let { ch ->
                try { Wearable.getChannelClient(this).close(ch) } catch (_: Exception) {}
            }
            output = null
            channel = null
        }
    }

    override fun onDestroy() {
        stopping = true
        try { record?.stop() } catch (_: Exception) {}
        worker?.interrupt()
        worker = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun notification(text: String) =
        NotificationCompat.Builder(this, "watch_speech")
            .setContentTitle("Speech Filter")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

    private fun update(text: String) {
        getSystemService(NotificationManager::class.java).notify(7, notification(text))
    }
}
