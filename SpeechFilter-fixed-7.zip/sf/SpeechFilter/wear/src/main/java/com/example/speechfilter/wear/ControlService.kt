package com.example.speechfilter.wear

import android.content.Intent
import androidx.core.content.ContextCompat
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService

class ControlService : WearableListenerService() {
    override fun onMessageReceived(event: MessageEvent) {
        when (event.path) {
            "/control/start" -> {
                ContextCompat.startForegroundService(
                    this, Intent(this, WatchRecordingService::class.java)
                )
            }
            "/control/stop" -> {
                stopService(Intent(this, WatchRecordingService::class.java))
            }
        }
    }
}
