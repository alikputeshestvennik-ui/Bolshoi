package com.example.speechfilter.wear

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setContentView(R.layout.activity_main)
            status = findViewById(R.id.status)
            status.text = "Готов"

            findViewById<Button>(R.id.start).setOnClickListener { onStartClicked() }
            findViewById<Button>(R.id.stop).setOnClickListener {
                stopService(Intent(this, WatchRecordingService::class.java))
                status.text = "СТОП"
            }
        } catch (t: Throwable) {
            Toast.makeText(this, "UI error: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun onStartClicked() {
        val need = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            need += Manifest.permission.RECORD_AUDIO
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            need += Manifest.permission.POST_NOTIFICATIONS
        }
        if (need.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, need.toTypedArray(), 20)
            status.text = "Разрешите микрофон"
            return
        }
        startWatchRecording()
    }

    private fun startWatchRecording() {
        try {
            ContextCompat.startForegroundService(
                this, Intent(this, WatchRecordingService::class.java)
            )
            status.text = "ЗАПИСЬ"
        } catch (t: Throwable) {
            status.text = "Ошибка: ${t.message}"
            Toast.makeText(this, t.message ?: "start failed", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode == 20 && grantResults.isNotEmpty() &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        ) {
            startWatchRecording()
        } else {
            status.text = "Нет разрешения"
        }
    }
}
