package ru.routeplanner

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.lifecycleScope
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var runOcr: Button
    private var selected: List<Uri> = emptyList()

    private var callsignsMap: Map<String, String> = emptyMap()

    private data class Point(val id: String, val name: String, val address: String)

    private val picker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        selected = uris
        runOcr.isEnabled = uris.isNotEmpty()
        status.text = if (uris.isEmpty()) "Фото не выбраны." else "Выбрано страниц: ${uris.size}"
        result.text = ""
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        result = findViewById(R.id.result)
        runOcr = findViewById(R.id.runOcr)

        findViewById<Button>(R.id.selectPhotos).setOnClickListener {
            picker.launch(arrayOf("image/jpeg", "image/png", "image/webp"))
        }
        runOcr.setOnClickListener { runOcr() }
    }

    private fun publish(msg: String) = runOnUiThread { status.text = msg }

    private fun runOcr() {
        runOcr.isEnabled = false
        status.text = "Распознавание… (до минуты на страницу)"
        lifecycleScope.launch {
            try {
                val text = withContext(Dispatchers.IO) { recognizeAll() }
                result.text = text
                status.text = "Готово. Страниц: ${selected.size}"
            } catch (e: Throwable) {
                status.text = "Ошибка OCR"
                result.text = e.stackTraceToString()
            } finally {
                runOcr.isEnabled = selected.isNotEmpty()
            }
        }
    }

    // =====================================================================
    //  Основной конвейер: фото → ориентация → наклон → OCR → строки → точки
    // =====================================================================

    private fun recognizeAll(): String {
        prepareTessdata()
        val points = loadDatabase()
        val api = TessBaseAPI()
        try {
            val ok = api.init(filesDir.absolutePath + File.separator, "rus", TessBaseAPI.OEM_LSTM_ONLY)
            if (!ok) error("Не удалось инициализировать русский OCR")
            api.setVariable("preserve_interword_spaces", "1")
            api.setVariable("user_defined_dpi", "300")

            class Shot(val n: Int, val words: List<Word>, val imgW: Int, val rot: Float, val skew: Float)
            val shots = ArrayList<Shot>()

            selected.forEachIndexed { index, uri ->
                val n = index + 1
                publish("Страница $n: определяю ориентацию…")
                val oriented = loadBitmap(uri)
                val rot = detectRotation(api, oriented)
                val rotated = rotateBitmap(oriented, rot)
                if (rotated !== oriented) oriented.recycle()

                publish("Страница $n: выравниваю наклон…")
                val skew = estimateSkew(rotated)
                val straight = deskew(rotated, skew)
                if (straight !== rotated) rotated.recycle()

                publish("Страница $n: распознаю текст…")
                val prepared = preprocessForOcr(straight)
                straight.recycle()
                val imgW = prepared.width

                api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SPARSE_TEXT)
                api.setImage(prepared)
                api.getUTF8Text() // запускает распознавание
                shots.add(Shot(n, readWords(api), imgW, rot, skew))
                api.clear()
                prepared.recycle()
            }

            // Заголовок таблицы есть не на каждой странице: берём колонки с любой, где он нашёлся.
            val own = shots.map { detectColumns(it.words, it.imgW) }
            val anyCols = own.firstOrNull { it != null }

            val entries = ArrayList<Entry>()
            val contacts = LinkedHashMap<Int, String>()
            val totals = Totals()
            val dump = StringBuilder()
            shots.forEachIndexed { i, shot ->
                val mine = own[i]
                val page = parsePage(shot.n, shot.words, shot.imgW, mine?.first ?: anyCols?.first, mine?.second)
                entries.addAll(page.entries)
                page.contacts.forEach { (k, v) -> contacts.putIfAbsent(k, v) }
                page.sheetKg?.let { totals.kg = it }
                page.sheetCash?.let { totals.cash = it }

                dump.append("— страница ${shot.n}: поворот ${shot.rot.toInt()}°, наклон ${"%.1f".format(Locale.US, shot.skew)}°, слов ${shot.words.size}, ")
                dump.append(if (mine != null) "заголовок найден" else if (anyCols != null) "заголовок с другой страницы" else "заголовок НЕ найден")
                dump.append(", строк накладных ${page.entries.size} —\n")
                page.entries.forEach {
                    dump.append("${it.callsign ?: "?"} | ${it.invoice ?: "?"} | вес ${it.weight ?: "?"} | факт ${it.cash} | ${it.type ?: "?"} | агент ${it.agent ?: "?"}\n")
                    dump.append("   ${it.raw.take(170)}\n")
                }
                dump.append('\n')
            }
            return formatReport(entries, points, contacts, totals) +
                "\n──────── Отладка ────────\n" + dump
        } finally {
            api.recycle()
        }
    }

    // =====================================================================
    //  Слова
    // =====================================================================

    private class Word(val text: String, val rect: Rect) {
        val cx: Float get() = (rect.left + rect.right) / 2f
        val cy: Float get() = (rect.top + rect.bottom) / 2f
    }

    private fun readWords(api: TessBaseAPI): List<Word> {
        val words = ArrayList<Word>()
        val iter = api.resultIterator ?: return words
        try {
            iter.begin()
            do {
                val t = iter.getUTF8Text(TessBaseAPI.PageIteratorLevel.RIL_WORD)?.trim()
                if (!t.isNullOrEmpty()) {
                    words.add(Word(t, iter.getBoundingRect(TessBaseAPI.PageIteratorLevel.RIL_WORD)))
                }
            } while (iter.next(TessBaseAPI.PageIteratorLevel.RIL_WORD))
        } finally {
            iter.delete()
        }
        return words
    }

    /** Грубая группировка слов в строки: нужна для заголовка, итогов и контактов. */
    private fun buildRows(words: List<Word>): List<List<Word>> {
        if (words.isEmpty()) return emptyList()
        val heights = words.map { it.rect.height() }.sorted()
        val tol = (heights[heights.size / 2] * 0.6f).coerceAtLeast(6f)
        val groups = ArrayList<MutableList<Word>>()
        for (w in words.sortedBy { it.cy }) {
            val last = groups.lastOrNull()
            if (last != null && Math.abs(w.cy - last.map { it.cy }.average()) <= tol) last.add(w)
            else groups.add(mutableListOf(w))
        }
        return groups.map { g -> g.sortedBy { it.rect.left } }
    }

    // =====================================================================
    //  Разбор страницы маршрутного листа
    // =====================================================================

    private class Entry(
        val page: Int,
        val callsign: String?,
        val invoice: String?,
        val weight: Double?,
        val cash: Double,
        val type: String?,
        val agent: Int?,
        val raw: String,
    )

    private class Totals { var kg: Double? = null; var cash: Double? = null }

    private class Page(
        val entries: List<Entry>,
        val columns: Map<String, Float>?,
        val contacts: Map<Int, String>,
        val sheetKg: Double?,
        val sheetCash: Double?,
    )

    private val callsignRegex = Regex("""(?<![0-9a-zа-я])([0-9зобli|]{1,4})(яв|юс|юв)""")
    private val invoiceRegex = Regex("""^([а-я]{3})[-–—]?(\d{5,7})$""")
    private val numRegex = Regex("""^\d{1,7}([.,]\d{1,2})?$""")
    private val agentRegex = Regex("""^(?<![\d.,])(\d)\s?/""")
    private val contactRegex = Regex(
        """(?<![\d+])([1-9])\s+([А-ЯЁ][а-яё]+\s+[А-ЯЁ][а-яё]+(?:\s*\([^)]{1,15}\))?(?:\s+(?:ПУД|сев|СВ|юг))*)\s*\+?(7\d{10})"""
    )

    private fun fixLookalikes(line: String): String {
        val sb = StringBuilder()
        for (ch in line) {
            sb.append(
                when (ch) {
                    'A', 'a' -> 'а'; 'B' -> 'В'; 'C', 'c' -> 'с'; 'E', 'e' -> 'е'
                    'H' -> 'Н'; 'K', 'k' -> 'к'; 'M' -> 'М'; 'O', 'o' -> 'о'
                    'P', 'p' -> 'р'; 'T' -> 'Т'; 'X', 'x' -> 'х'; 'y', 'Y' -> 'у'
                    else -> ch
                }
            )
        }
        return sb.toString()
    }

    private fun norm(s: String) = fixLookalikes(s).lowercase().replace('ё', 'е')
        .trim('.', ',', ':', ';', '|', ' ')

    /** Позывной из слова: допускает типичные «двойники» цифр (З→3, О→0, б→6, l→1) только перед суффиксом юс/яв/юв. */
    private fun callsignOf(raw: String): String? {
        val m = callsignRegex.find(norm(raw)) ?: return null
        val digits = m.groupValues[1].map {
            when (it) { 'з' -> '3'; 'о' -> '0'; 'б' -> '6'; 'l', 'i', '|' -> '1'; else -> it }
        }.joinToString("")
        if (digits.isEmpty() || !digits.all { it.isDigit() }) return null
        return digits + m.groupValues[2]
    }

    private fun num(t: String): Double? =
        if (numRegex.matches(t)) t.replace(',', '.').toDoubleOrNull() else null

    /** Положение колонок (доли ширины фото) и y заголовка таблицы. */
    private fun detectColumns(words: List<Word>, imgW: Int): Pair<Map<String, Float>, Float>? {
        val keyMap = listOf(
            "вес" to "вес", "сумма" to "сумма", "факт" to "факт", "забрать" to "долг",
            "расчет" to "расчет", "замет" to "заметки", "агент" to "агент",
        )
        for (row in buildRows(words)) {
            val found = HashMap<String, Float>()
            for (w in row) {
                val t = norm(w.text)
                for ((prefix, name) in keyMap) {
                    if (t.startsWith(prefix) && !found.containsKey(name)) found[name] = w.cx / imgW
                }
            }
            if (found.size >= 4 && found.containsKey("вес")) {
                return found to row.map { it.cy }.average().toFloat()
            }
        }
        return null
    }

    private fun parsePage(pageNo: Int, words: List<Word>, imgW: Int, cols: Map<String, Float>?, headerY: Float?): Page {
        val rows = buildRows(words)
        val columns = cols

        // --- итоги, граница таблицы, контакты ---
        var cutY = Float.MAX_VALUE
        var sheetKg: Double? = null
        var sheetCash: Double? = null
        val contacts = LinkedHashMap<Int, String>()
        val numAfter = Regex("""\d+[.,]\d+""")
        for (row in rows) {
            val text = row.joinToString(" ") { it.text }
            val low = norm(text)
            val y = row.map { it.cy }.average().toFloat()
            if (low.contains("итого") && low.contains("вес")) {
                cutY = minOf(cutY, y - 4f)
                sheetKg = numAfter.find(low.substringAfter("вес"))?.value?.replace(',', '.')?.toDoubleOrNull()
            }
            if (low.contains("сдаче")) {
                sheetCash = numAfter.find(low.substringAfter("сдаче"))?.value?.replace(',', '.')?.toDoubleOrNull()
            }
            if (low.contains("документ")) cutY = minOf(cutY, y - 4f)
            contactRegex.find(text)?.let { m ->
                val agentNo = m.groupValues[1].toInt()
                contacts.putIfAbsent(agentNo, "${m.groupValues[2].trim()} +${m.groupValues[3]}")
            }
        }

        // --- якоря строк: номера накладных (АСП-…, НФФ-…) ---
        val data = words.filter { it.cy < cutY && (headerY == null || it.cy > headerY) }
        val invoiceWords = data.filter { invoiceRegex.matches(norm(it.text)) }.sortedBy { it.cy }
        val callsignWords = data.filter { callsignOf(it.text) != null }

        class Anchor(val cy: Float, val invoice: Word?)
        val anchors = ArrayList<Anchor>()
        invoiceWords.forEach { anchors.add(Anchor(it.cy, it)) }
        if (anchors.size >= 2) {
            val pitch = anchors.zipWithNext { a, b -> b.cy - a.cy }.sorted().let { it[it.size / 2] }
            val invX = invoiceWords.map { it.cx }.sorted()[invoiceWords.size / 2]
            for (c in callsignWords) {
                if (c.cx < invX && anchors.none { Math.abs(it.cy - c.cy) < pitch * 0.6f }) anchors.add(Anchor(c.cy, null))
            }
        } else {
            callsignWords.forEach { anchors.add(Anchor(it.cy, null)) }
        }
        anchors.sortBy { it.cy }

        val numericCols = listOf("вес", "сумма", "факт", "долг")
        val entries = ArrayList<Entry>()
        for ((i, a) in anchors.withIndex()) {
            val top = if (i == 0) -Float.MAX_VALUE else (anchors[i - 1].cy + a.cy) / 2f
            val bottom = if (i == anchors.lastIndex) Float.MAX_VALUE else (a.cy + anchors[i + 1].cy) / 2f
            val block = data.filter { it.cy >= top && it.cy < bottom }
            val raw = block.sortedWith(compareBy({ Math.round(it.cy / 6f) }, { it.rect.left })).joinToString(" ") { it.text }

            val invText = a.invoice?.let { norm(it.text) }
            val invM = invText?.let { invoiceRegex.find(it) }
            val prefix = invM?.groupValues?.get(1)
            val invoiceStr = invM?.let { it.groupValues[1].uppercase() + "-" + it.groupValues[2] }
            val invX = a.invoice?.cx ?: Float.MAX_VALUE

            // позывной: ближайший слева от накладной
            val cs = block.filter { it.cx < invX && callsignOf(it.text) != null }
                .minByOrNull { Math.abs(it.cy - a.cy) }
                ?.let { callsignOf(it.text) }

            // числа по колонкам
            var weight: Double? = null
            var cash = 0.0
            val numbers = block.mapNotNull { w -> num(w.text.trim('|', ' '))?.let { w to it } }
            if (cols != null && cols.containsKey("вес")) {
                val avail = numericCols.filter { cols.containsKey(it) }
                val weightCands = ArrayList<Pair<Word, Double>>()
                for ((w, v) in numbers) {
                    val x = w.cx / imgW
                    val nearest = avail.minByOrNull { Math.abs(x - cols.getValue(it)) } ?: continue
                    if (Math.abs(x - cols.getValue(nearest)) > 0.05f) continue
                    when (nearest) {
                        "вес" -> weightCands.add(w to v)
                        "факт" -> cash += v
                    }
                }
                weight = weightCands.minByOrNull { Math.abs(it.first.cy - a.cy) }?.second
            } else {
                weight = null // без заголовка колонки не определить
            }

            val low = norm(raw)
            val type = when {
                low.contains("возвр") -> "ВОЗВРАТ"
                low.contains("оборуд") -> "ОБОРУДОВАНИЕ"
                prefix == "асп" -> "АСП"
                prefix == "нфф" -> "НФФ"
                else -> null
            }

            val agentX = cols?.get("агент")
            val agent = block.filter { agentX == null || it.cx / imgW >= agentX - 0.03f }
                .mapNotNull { w -> agentRegex.find(norm(w.text))?.groupValues?.get(1)?.toIntOrNull()?.let { w to it } }
                .minByOrNull { Math.abs(it.first.cy - a.cy) }?.second

            entries.add(Entry(pageNo, cs, invoiceStr, weight, cash, type, agent, raw))
        }
        return Page(entries, columns, contacts, sheetKg, sheetCash)
    }

    // =====================================================================
    //  Проверка маршрута: физические точки
    // =====================================================================

    private class Acc {
        var delivery = 0.0
        var ret = 0.0
        var cash = 0.0
        var invoices = 0
        var equipment = false
        var hasReturn = false
        val parts = ArrayList<String>()
    }

    private fun f(v: Double) = String.format(Locale.US, "%.2f", v)

    private fun formatReport(
        entries: List<Entry>,
        points: Map<String, Point>,
        contacts: Map<Int, String>,
        totals: Totals,
    ): String {
        val acc = LinkedHashMap<String, Acc>()
        val doubtful = ArrayList<String>()
        var doubtfulKg = 0.0

        // Агенты, чей номер ведёт к Маврычеву: доверяем локальной базе без подтверждения.
        val mavAgents = contacts.filterValues { it.lowercase().contains("маврыч") }.keys
            .ifEmpty { setOf(1) }

        for (e in entries) {
            val w = e.weight?.let { f(it) + " кг" } ?: "вес ?"
            val head = "стр.${e.page} · ${e.invoice ?: "накл.?"} · $w"
            val cs = e.callsign
            val pid = cs?.let { callsignsMap[it] }
            val point = pid?.let { points[it] }

            // Подтверждение нужно, если в накладной нет АСП/возврат/оборудование и/или заполнен «Факт».
            // Исключение: агент — Маврычев.
            val typeOk = e.type == "АСП" || e.type == "ВОЗВРАТ" || e.type == "ОБОРУДОВАНИЕ"
            val needConfirm = (!typeOk || e.cash > 0) && e.agent !in mavAgents

            val problem: String? = when {
                cs == null -> "позывной не распознан"
                point == null -> "$cs нет в базе позывных"
                needConfirm -> {
                    val why = ArrayList<String>()
                    if (!typeOk) why.add("в накладной нет АСП/возврат/оборудование (${e.type ?: "тип не распознан"})")
                    if (e.cash > 0) why.add("заполнен «Факт» ${f(e.cash)}")
                    "$cs → ${point.id} ${point.name}: подтвердите, т.к. ${why.joinToString(" и ")}"
                }
                e.weight == null -> "$cs → ${point.id}: вес не распознан"
                else -> null
            }
            if (problem != null) {
                doubtful.add("⚠ $head\n     $problem")
                doubtfulKg += e.weight ?: 0.0
                continue
            }
            val a = acc.getOrPut(point!!.id) { Acc() }
            a.invoices++
            a.cash += e.cash
            a.parts.add("$cs ${e.weight?.let { f(it) } ?: "?"}")
            when (e.type) {
                "ВОЗВРАТ" -> { a.hasReturn = true; a.ret += e.weight ?: 0.0 }
                "ОБОРУДОВАНИЕ" -> a.equipment = true
                else -> a.delivery += e.weight ?: 0.0
            }
        }

        val sb = StringBuilder("ПРОВЕРКА МАРШРУТА\n\n")
        if (contacts.isNotEmpty()) {
            sb.append("📞 Контакты агентов\n")
            contacts.toSortedMap().forEach { (k, v) -> sb.append("   №$k  $v\n") }
            sb.append("   (номера телефонов OCR читает неточно — сверьте с листом)\n")
            sb.append('\n')
        }
        val ordered = acc.keys.sortedWith(compareBy({ it.takeLast(1) }, { it.dropLast(1).toIntOrNull() ?: 0 }))
        var totalKg = 0.0
        var totalCash = 0.0
        for (pid in ordered) {
            val a = acc.getValue(pid)
            val p = points.getValue(pid)
            totalKg += a.delivery
            totalCash += a.cash
            sb.append("✓ $pid  ${p.name}\n")
            sb.append("    ${p.address}\n")
            sb.append("    📦 ${f(a.delivery)} кг · накладных: ${a.invoices}")
            sb.append(if (a.cash > 0) " · 💵 ${f(a.cash)}" else " · 💳 безнал")
            sb.append('\n')
            if (a.hasReturn) sb.append("    ↩ возврат: ${f(a.ret)} кг\n")
            if (a.equipment) sb.append("    🔧 ОБОРУДОВАНИЕ (см. заметки)\n")
            if (a.invoices > 1) sb.append("    └ ${a.parts.joinToString("; ")}\n")
        }
        if (doubtful.isNotEmpty()) {
            sb.append("\n❓ ТРЕБУЕТ ПОДТВЕРЖДЕНИЯ / РЕШЕНИЯ (в точки не включено)\n")
            doubtful.forEach { sb.append(it).append('\n') }
        }
        sb.append("\nТочек: ${ordered.size} · сомнительных строк: ${doubtful.size}\n")
        sb.append("Товар в точках: ${f(totalKg)} кг · в сомнительных: ${f(doubtfulKg)} кг\n")
        sb.append("Наличные в точках: ${f(totalCash)}\n")
        totals.kg?.let { kg ->
            val sum = totalKg + doubtfulKg
            val ok = Math.abs(sum - kg) < 0.05
            sb.append("Контроль веса: по листу ${f(kg)} кг, распознано ${f(sum)} кг ${if (ok) "✓" else "⚠ не сходится"}\n")
        }
        totals.cash?.let { c -> sb.append("Всего к сдаче по листу: ${f(c)}\n") }
        return sb.toString().trimEnd()
    }

    // =====================================================================
    //  База
    // =====================================================================

    private fun loadDatabase(): Map<String, Point> {
        val points = HashMap<String, Point>()
        assets.open("points.csv").bufferedReader(Charsets.UTF_8).useLines { seq ->
            seq.drop(1).forEach { l ->
                val p = l.split(';')
                if (p.size >= 3) points[p[0].trim()] = Point(p[0].trim(), p[1].trim(), p[2].trim())
            }
        }
        val map = HashMap<String, String>()
        assets.open("callsigns.csv").bufferedReader(Charsets.UTF_8).useLines { seq ->
            seq.forEach { l ->
                val p = l.split(',')
                if (p.size >= 2) {
                    val key = p[0].trim().lowercase()
                    map[key] = p[1].trim().lowercase()
                }
            }
        }
        callsignsMap = map
        return points
    }

    // =====================================================================
    //  Модель и изображение
    // =====================================================================

    private val modelVersion = "tessdata_best-4.1.0"

    private fun prepareTessdata() {
        val dir = File(filesDir, "tessdata")
        if (!dir.exists()) dir.mkdirs()
        val rus = File(dir, "rus.traineddata")
        val marker = File(dir, "rus.version")
        if (!rus.exists() || !marker.exists() || marker.readText() != modelVersion) {
            rus.delete()
            assets.open("tessdata/rus.traineddata").use { input ->
                FileOutputStream(rus).use { output -> input.copyTo(output) }
            }
            marker.writeText(modelVersion)
        }
        if (rus.length() < 1_000_000L) {
            error("В APK отсутствует корректная rus.traineddata (размер: ${rus.length()} байт)")
        }
    }

    private fun loadBitmap(uri: Uri): Bitmap {
        val input = contentResolver.openInputStream(uri) ?: error("Не удалось открыть $uri")
        val original = input.use { BitmapFactory.decodeStream(it) }
            ?: error("Не удалось декодировать изображение")
        return rotateFromExif(uri, original)
    }

    private fun rotateFromExif(uri: Uri, bitmap: Bitmap): Bitmap {
        return try {
            val orientation = contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            rotateBitmap(bitmap, degrees).also { if (it !== bitmap) bitmap.recycle() }
        } catch (_: Exception) {
            bitmap
        }
    }

    private fun scaleLong(src: Bitmap, target: Int): Bitmap {
        val k = target.toFloat() / maxOf(src.width, src.height)
        if (k >= 1f) return src
        return Bitmap.createScaledBitmap(src, (src.width * k).toInt().coerceAtLeast(1), (src.height * k).toInt().coerceAtLeast(1), true)
    }

    private fun rotateBitmap(src: Bitmap, deg: Float): Bitmap {
        if (deg == 0f) return src
        val m = Matrix().apply { postRotate(deg) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    /**
     * Лист часто снят «боком» или вверх ногами (в том числе из-за EXIF). Пробуем 4 поворота
     * на уменьшенной копии и берём тот, где OCR находит больше осмысленных русских слов.
     */
    private fun detectRotation(api: TessBaseAPI, bmp: Bitmap): Float {
        val small = scaleLong(bmp, 2200)
        var best = 0f
        var bestScore = -1
        for (deg in floatArrayOf(0f, 90f, 180f, 270f)) {
            val r = rotateBitmap(small, deg)
            api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SPARSE_TEXT)
            api.setImage(r)
            val text = api.getUTF8Text() ?: ""
            api.clear()
            val score = orientationScore(text)
            if (r !== small) r.recycle()
            if (score > bestScore) { bestScore = score; best = deg }
        }
        if (small !== bmp) small.recycle()
        return best
    }

    private fun orientationScore(text: String): Int {
        val low = text.lowercase()
        val words = Regex("""[а-яё]{4,}""").findAll(low).count()
        val keys = Regex("""асп-|накладн|клиент|адрес|итого|\d(юс|яв|юв)""").findAll(low).count()
        return words + 5 * keys
    }

    private fun toGray(bmp: Bitmap): Triple<ByteArray, Int, Int> {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val gray = ByteArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            gray[i] = ((299 * Color.red(c) + 587 * Color.green(c) + 114 * Color.blue(c)) / 1000).toByte()
        }
        return Triple(gray, w, h)
    }

    /** Адаптивная бинаризация по среднему в окне (интегральное изображение; переполнение Int безопасно). */
    private fun adaptiveBinary(gray: ByteArray, w: Int, h: Int, r: Int, bias: Int): ByteArray {
        val stride = w + 1
        val integral = IntArray(stride * (h + 1))
        for (y in 1..h) {
            var row = 0
            for (x in 1..w) {
                row += gray[(y - 1) * w + (x - 1)].toInt() and 0xFF
                integral[y * stride + x] = integral[(y - 1) * stride + x] + row
            }
        }
        val out = ByteArray(w * h)
        for (y in 0 until h) {
            val y0 = (y - r).coerceAtLeast(0)
            val y1 = (y + r + 1).coerceAtMost(h)
            for (x in 0 until w) {
                val x0 = (x - r).coerceAtLeast(0)
                val x1 = (x + r + 1).coerceAtMost(w)
                val sum = integral[y1 * stride + x1] - integral[y0 * stride + x1] -
                    integral[y1 * stride + x0] + integral[y0 * stride + x0]
                val mean = sum / ((x1 - x0) * (y1 - y0))
                if ((gray[y * w + x].toInt() and 0xFF) < mean - bias) out[y * w + x] = 1
            }
        }
        return out
    }

    /** Угол наклона строк по профилю проекции тёмных точек (градусы, по часовой стрелке для Matrix.postRotate). */
    private fun estimateSkew(src: Bitmap): Float {
        val t = scaleLong(src, 1000)
        val (gray, w, h) = toGray(t)
        if (t !== src) t.recycle()
        val bin = adaptiveBinary(gray, w, h, 12, 10)
        var n = 0
        for (b in bin) if (b.toInt() == 1) n++
        if (n == 0) return 0f
        val dx = IntArray(n)
        val dy = IntArray(n)
        var k = 0
        for (y in 0 until h) for (x in 0 until w) if (bin[y * w + x].toInt() == 1) { dx[k] = x; dy[k] = y; k++ }

        fun score(deg: Float): Double {
            val rad = Math.toRadians(deg.toDouble())
            val s = Math.sin(rad)
            val c = Math.cos(rad)
            val off = w + 10
            val hist = IntArray(h + 2 * off)
            for (i in 0 until n) hist[(dx[i] * s + dy[i] * c + off).toInt()]++
            var sc = 0.0
            for (v in hist) sc += v.toDouble() * v
            return sc
        }

        var best = 0f
        var bestScore = score(0f)
        var a = -6f
        while (a <= 6f) { val s = score(a); if (s > bestScore) { bestScore = s; best = a }; a += 0.5f }
        val center = best
        a = center - 0.5f
        while (a <= center + 0.5f) { val s = score(a); if (s > bestScore) { bestScore = s; best = a }; a += 0.1f }
        return best
    }

    private fun deskew(src: Bitmap, deg: Float): Bitmap {
        if (Math.abs(deg) < 0.15f) return src
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawColor(Color.WHITE)
        val m = Matrix().apply { postRotate(deg, src.width / 2f, src.height / 2f) }
        canvas.drawBitmap(src, m, null)
        return out
    }

    /** Стирает длинные горизонтальные и вертикальные чёрные отрезки (линии таблицы), чтобы они не склеивали текст. */
    private fun removeLines(bin: ByteArray, w: Int, h: Int, minRun: Int) {
        for (y in 0 until h) {
            var x = 0
            while (x < w) {
                if (bin[y * w + x].toInt() == 1) {
                    var e = x
                    while (e < w && bin[y * w + e].toInt() == 1) e++
                    if (e - x >= minRun) for (i in x until e) bin[y * w + i] = 0
                    x = e
                } else x++
            }
        }
        for (x in 0 until w) {
            var y = 0
            while (y < h) {
                if (bin[y * w + x].toInt() == 1) {
                    var e = y
                    while (e < h && bin[e * w + x].toInt() == 1) e++
                    if (e - y >= minRun) for (i in y until e) bin[i * w + x] = 0
                    y = e
                } else y++
            }
        }
    }

    /** Масштаб (только вниз) до 3600 px + адаптивная бинаризация: убирает тени и серые полосы таблицы. */
    private fun preprocessForOcr(source: Bitmap): Bitmap {
        val scaled = scaleLong(source, 3600)
        val (gray, w, h) = toGray(scaled)
        if (scaled !== source) scaled.recycle()
        val r = (minOf(w, h) / 24).coerceAtLeast(15)
        val bin = adaptiveBinary(gray, w, h, r, 12)
        removeLines(bin, w, h, 70)
        val px = IntArray(w * h)
        for (i in px.indices) px[i] = if (bin[i].toInt() == 1) Color.BLACK else Color.WHITE
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }
}
