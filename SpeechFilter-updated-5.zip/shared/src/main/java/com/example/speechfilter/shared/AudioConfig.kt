package com.example.speechfilter.shared

object AudioConfig {
    const val SAMPLE_RATE = 16_000
    const val CHANNELS = 1
    const val BYTES_PER_SAMPLE = 2
    const val FRAME_MS = 32
    const val FRAME_SAMPLES = SAMPLE_RATE * FRAME_MS / 1000
    const val PRE_ROLL_MS = 500
    const val POST_ROLL_MS = 700
    const val VAD_THRESHOLD = 0.45f
    const val YAMNET_WINDOW_SAMPLES = 15_600 // 0.975 s @ 16 kHz
    const val SPEECH_GAP_MERGE_MS = 700
    /** Silence before starting a new WAV file (ms). */
    const val FILE_GAP_MS = 5_000

    /**
     * The 5 s of silence is counted from the end of the last *voiced* audio.
     * Every segment already carries POST_ROLL_MS of trailing silence, so the
     * file is closed this long after the last audio chunk arrived.
     */
    const val FILE_CLOSE_AFTER_LAST_AUDIO_MS = FILE_GAP_MS - POST_ROLL_MS

    /**
     * Minimum amount of Silero-voiced audio a segment must contain. Water
     * drops, clicks and coughs trigger the VAD for 1-3 frames only; the old
     * code still wrote pre-roll + post-roll around them (~1.2 s, ~39 KB
     * files) and fed them to Whisper, which hallucinates on them
     * ("Продолжение следует", "Субтитры сделал ...").
     */
    const val MIN_VOICED_MS = 220

    /** YAMNet summed speech score needed to keep a segment (tune here). */
    const val YAMNET_SPEECH_MIN = 0.20f
    /** Reject when a non-speech class (cough/sneeze/water...) clearly dominates. */
    const val YAMNET_NOISE_MIN = 0.35f
    const val YAMNET_NOISE_DOMINANCE = 1.5f
}
