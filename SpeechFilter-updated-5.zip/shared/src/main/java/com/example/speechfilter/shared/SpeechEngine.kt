package com.example.speechfilter.shared

/**
 * Silero VAD + YAMNet gate. Emits PCM only for segments that are really speech.
 *
 * Per segment (VAD onset -> 0.7 s of silence):
 *
 *  1. Audio is BUFFERED from [PRE_ROLL] before the onset. Nothing is written
 *     until the segment is confirmed, so the ~1 s YAMNet needs to decide
 *     (0.975 s window) costs latency only, never clipped word beginnings.
 *  2. Confirmation = enough voiced frames ([AudioConfig.MIN_VOICED_MS]) AND
 *     a YAMNet verdict of "speech, not cough/sneeze/water". The verdict is
 *     taken on the first full window after onset; segments that end sooner
 *     (short words) are judged at the end on the audio they have, zero-padded
 *     to a full window.
 *  3. A rejected window is dropped (memory stays bounded during long running
 *     water) but its last pre-roll is kept, so speech that starts right after
 *     a cough in the same VAD run is still caught by the next window.
 *
 * [pending] is true while a segment is buffered but not decided yet, so the
 * recorder does not close the WAV file underneath an utterance that is still
 * waiting for YAMNet.
 */
class SpeechEngine(
    private val vad: SileroVad,
    private val yamnet: YamnetClassifier?,
    private val onSpeechPcm: (ShortArray) -> Unit,
    private val requireYamnet: Boolean = true,
    /** Cheap first-stage gate used only by the lowest-power mode. */
    private val energyGate: Boolean = false,
    /** Human-readable reason each time a segment is thrown away (for the worker log). */
    private val onDropped: ((String) -> Unit)? = null
) {
    private val hp = HighPassFilter()
    private val preRoll = ShortRingBuffer(AudioConfig.SAMPLE_RATE * AudioConfig.PRE_ROLL_MS / 1000)
    private val candidate = ArrayList<ShortArray>()
    private var candidateSamples = 0
    private var onsetOffset = 0            // samples of pre-roll at the head of candidate
    private var voicedFrames = 0
    private var carry = ShortArray(0)      // < 512 samples left over from the previous chunk

    private var inSpeech = false
    private var confirmed = false
    private var silenceSamples = 0

    // Conservative RMS gate: only skip Silero when the frame is clearly near
    // the noise floor. It is deliberately low to avoid clipping quiet speech.
    private val energyThreshold = 0.0015f

    private val gateActive get() = requireYamnet && yamnet != null
    private val postRollSamples = AudioConfig.SAMPLE_RATE * AudioConfig.POST_ROLL_MS / 1000
    private val minVoicedFrames =
        (AudioConfig.MIN_VOICED_MS * AudioConfig.SAMPLE_RATE / 1000 + FRAME - 1) / FRAME

    /** Buffered, undecided segment exists. Read from another thread. */
    @Volatile var pending: Boolean = false
        private set

    fun reset() {
        preRoll.clear()
        clearCandidate()
        carry = ShortArray(0)
        inSpeech = false
        confirmed = false
        silenceSamples = 0
        pending = false
        vad.reset()
        hp.reset()
    }

    fun acceptPcm16(samples: ShortArray) {
        val filtered = samples.copyOf()
        hp.process(filtered)

        // Work on whole 512-sample VAD frames; keep the remainder for the next
        // call (the old code silently dropped it — audio from the watch comes
        // in arbitrary packet sizes).
        val data = if (carry.isEmpty()) filtered else carry + filtered
        var offset = 0
        while (offset + FRAME <= data.size) {
            processFrame(data.copyOfRange(offset, offset + FRAME))
            offset += FRAME
        }
        carry = if (offset < data.size) data.copyOfRange(offset, data.size) else ShortArray(0)
    }

    private fun processFrame(frame: ShortArray) {
        val f = FloatArray(FRAME) { frame[it] / 32768f }
        if (energyGate) {
            var sum = 0.0
            for (v in f) sum += v * v
            val rms = kotlin.math.sqrt(sum / f.size).toFloat()
            if (rms < energyThreshold) {
                if (inSpeech) {
                    addCandidate(frame)
                    preRoll.add(frame)
                    silenceSamples += FRAME
                    if (silenceSamples >= postRollSamples) endSegment()
                } else {
                    preRoll.add(frame)
                }
                return
            }
        }
        val p = try {
            vad.probability(f)
        } catch (_: Throwable) {
            // If VAD fails, treat moderate energy as speech candidate
            val energy = f.map { it * it }.average().toFloat()
            if (energy > 1e-4f) 0.7f else 0.1f
        }
        val speech = p >= AudioConfig.VAD_THRESHOLD

        if (!inSpeech && speech) {
            inSpeech = true
            confirmed = !gateActive
            silenceSamples = 0
            clearCandidate()
            voicedFrames = 0
            // Pre-roll holds only frames BEFORE this one (it is added at the
            // end of processFrame) — the old code added the current chunk
            // first and then the frame again, duplicating ~32 ms at every onset.
            val previous = preRoll.snapshot()
            if (previous.isNotEmpty()) addCandidate(previous)
            onsetOffset = previous.size
            pending = gateActive
        }

        var preRollUpdated = false
        if (inSpeech) {
            addCandidate(frame)
            // The frame joins the pre-roll right away so restartWindow() keeps it too.
            preRoll.add(frame)
            preRollUpdated = true
            if (speech) voicedFrames++
            silenceSamples = if (speech) 0 else silenceSamples + FRAME

            if (!confirmed) {
                // First full window after the onset (minus one frame of lead-in).
                if (candidateSamples - onsetOffset >= AudioConfig.YAMNET_WINDOW_SAMPLES) {
                    decide(atEnd = false)
                }
            } else if (candidate.size >= 4) {
                flushCandidate()   // stream confirmed speech out in small chunks
            }

            if (silenceSamples >= postRollSamples) endSegment()
        }

        if (!preRollUpdated) preRoll.add(frame)
    }

    private fun endSegment() {
        if (!confirmed) decide(atEnd = true)
        if (confirmed) flushCandidate()
        clearCandidate()
        inSpeech = false
        confirmed = false
        silenceSamples = 0
        voicedFrames = 0
        pending = false
    }

    /**
     * Decide whether the buffered segment is speech.
     * @param atEnd true when the segment is over (short utterance / last chance).
     */
    private fun decide(atEnd: Boolean) {
        if (voicedFrames < minVoicedFrames) {
            if (atEnd) {
                onDropped?.invoke("слишком коротко: $voicedFrames кадр. голоса (нужно $minVoicedFrames)")
                clearCandidate()
            } else {
                // Long, mostly quiet run: not speech. Restart the window.
                onDropped?.invoke("мало голоса: $voicedFrames кадр. за ${AudioConfig.YAMNET_WINDOW_SAMPLES / 16} мс")
                restartWindow()
            }
            return
        }

        val y = yamnet
        if (y == null) { confirmed = true; pending = false; return }

        val verdict = try {
            y.classify(buildWindow())
        } catch (_: Throwable) {
            null // classifier failure: fall back to the VAD decision, never lose speech
        }
        if (verdict == null || verdict.accept) {
            confirmed = true
            pending = false
            flushCandidate()
        } else {
            onDropped?.invoke(verdict.describe())
            if (atEnd) clearCandidate() else restartWindow()
        }
    }

    /** 15 600 samples starting one frame before the onset; zero-padded if the segment is shorter. */
    private fun buildWindow(): FloatArray {
        val w = AudioConfig.YAMNET_WINDOW_SAMPLES
        val out = FloatArray(w)
        val start = (onsetOffset - FRAME).coerceAtLeast(0)
        var skip = start
        var pos = 0
        loop@ for (part in candidate) {
            var i = 0
            if (skip > 0) {
                val s = minOf(skip, part.size)
                skip -= s
                i = s
            }
            while (i < part.size) {
                if (pos >= w) break@loop
                out[pos++] = part[i++] / 32768f
            }
        }
        return out
    }

    /** Drop the rejected window but keep the last pre-roll as lead-in for the next one. */
    private fun restartWindow() {
        val keep = preRoll.snapshot()   // last PRE_ROLL_MS of audio, incl. this frame's predecessors
        clearCandidate()
        if (keep.isNotEmpty()) addCandidate(keep)
        onsetOffset = keep.size
        voicedFrames = 0
        pending = gateActive
    }

    private fun addCandidate(part: ShortArray) {
        candidate.add(part)
        candidateSamples += part.size
    }

    private fun clearCandidate() {
        candidate.clear()
        candidateSamples = 0
        onsetOffset = 0
    }

    private fun flushCandidate() {
        if (candidate.isEmpty()) return
        val parts = ArrayList(candidate)
        clearCandidate()
        for (part in parts) onSpeechPcm(part)
    }

    private companion object {
        const val FRAME = 512
    }
}
