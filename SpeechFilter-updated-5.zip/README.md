# Speech Filter — Phone + Galaxy Watch 8

Прототип приложения для выделения человеческой речи по схеме:

Microphone → High-Pass Filter → Silero VAD → YAMNet → speech PCM → WAV

## Режимы

- **AUTO** — если рядом подключён Galaxy Watch 8, захват и Silero VAD + YAMNet выполняются на часах; на телефон передаются только подтверждённые speech-сегменты.
- **PHONE** — обработка полностью на телефоне.
- **WATCH** — запрашивает часы; если часы недоступны, автоматически используется телефон.

Для сегментов используются:
- 500 ms pre-roll
- 700 ms post-roll
- 16 kHz / mono / PCM16
- Silero VAD threshold 0.50
- минимум 220 мс голоса (Silero) в сегменте, иначе он отбрасывается (капли, щелчки, короткие всплески)
- YAMNet: сумма классов Speech/Conversation/Narration/Whispering ≥ 0.20 (`AudioConfig.YAMNET_SPEECH_MIN`); сегмент отбрасывается, если кашель / чих / вода / дыхание / музыка / пение (≥ 0.35) сильнее речи в 1.5 раза
- файл закрывается через 5 с тишины, отсчитанных от конца последней речи, и сразу уходит на распознавание

YAMNet работает на 0.975 s окнах при 16 kHz. Это намеренно означает, что подтверждение YAMNet добавляет задержку на старт сегмента, зато выходной файл содержит только кандидаты, прошедшие VAD + YAMNet. Пока сегмент ждёт решения YAMNet, он буферизуется (вместе с pre-roll), поэтому начало фразы не обрезается, а файл в это время не закрывается. Отсеянные сегменты пишутся в «Журнал воркеров» (строка «Запись: Отсеяно: …», не чаще раза в 10 с). Расшифровки-галлюцинации Whisper («Продолжение следует», «Субтитры сделал…») удаляются из списка, а WAV переносится в `SpeechFilter/rejected/` (хранится 3 дня).

## Wear OS transport

Команды: `MessageClient`.

Аудио: `ChannelClient`, path `/speech-audio`, бинарные PCM packets.

Android documentation explicitly describes ChannelClient as stream-oriented and lists microphone voice data as a use case. ChannelClient is connection-oriented and does not provide persistence, поэтому архитектура использует ring buffer/pre-roll на устройстве. 

## Модели

Модели не включены в git-архив, чтобы не тащить бинарные ML-файлы в репозиторий.

Перед сборкой CI скачивает только runtime-модели Silero/YAMNet и исходники whisper.cpp. **Whisper Base не включается в APK и не скачивается CI.** Его пользователь импортирует в приложении как файл модели; приложение сохраняет его как `filesDir/models/whisper.base`.

Для локальной подготовки исходников:

```bash
bash scripts/download_models.sh
```

Это положит в `shared/src/main/assets/`:

- `silero_vad.onnx`
- `yamnet.tflite`
- `yamnet_class_map.csv`

Модель Whisper не является asset APK. В интерфейсе телефона (экран **Настройки**) есть кнопка импорта модели. Выбранный файл копируется в приватное хранилище приложения `filesDir/models/whisper.base` и затем открывается `whisper.cpp` через JNI.

Загрузка модели в приложении не привязана к конкретному размеру — `whisper_init_from_file_with_params` в JNI-коде принимает любой ggml-файл whisper.cpp (tiny/base/small/medium/...), имя `whisper.base` — это только внутреннее имя файла на диске. Поэтому в окне импорта можно выбрать `ggml-small.bin` вместо `ggml-base.bin`: small точнее (особенно на зашумлённой речи), но заметно медленнее на CPU телефона. Для Galaxy Z Flip 7 (Exynos 2500 + Xclipse 950) включены:
- auto-detect языка
- CPU-only whisper.cpp (Vulkan/GPU backend удалён из проекта)
- Flash Attention
- до 6 CPU-потоков (оптимум для 10-ядерного big.LITTLE)
- ARM-флаги `armv8.2-a+fp16+dotprod`

Сборка CPU-only (ARM + FP16 + DotProd). Разумный компромисс по размеру — квантованная `small.q5_1` (~190 MB): точность ближе к small, размер и скорость ближе к base.

Silero VAD используется через ONNX Runtime. Репозиторий Silero публикует ONNX-модели, включая `silero_vad.onnx`; для 16 kHz также доступна отдельная ONNX-модель. YAMNet ожидает mono 16 kHz audio.

## Сборка локально

Требуется JDK 17 и Gradle 8.9+.

```bash
bash scripts/download_models.sh
gradle :phone:assembleDebug :wear:assembleDebug
```

APK:

```text
phone/build/outputs/apk/debug/phone-debug.apk
wear/build/outputs/apk/debug/wear-debug.apk
```

## Постоянная подпись

В репозиторий **не добавляйте keystore**.

GitHub Actions ожидает следующие Secrets:

```text
ANDROID_KEYSTORE_B64
ANDROID_KEY_ALIAS
ANDROID_STORE_PASSWORD
ANDROID_KEY_PASSWORD
```

`ANDROID_KEYSTORE_B64` — base64 вашего постоянного `.jks/.keystore`.

Workflow восстанавливает этот keystore только внутри runner и подписывает оба APK одной и той же ключевой парой. Это важно: Android Wear Data Layer требует совпадения package name и подписи между приложением телефона и приложением часов.

## GitHub Actions

После push workflow:

1. скачивает ML-модели;
2. восстанавливает ваш signing keystore из GitHub Secret;
3. собирает `phone` и `wear`;
4. загружает оба подписанных APK как workflow artifacts.

## Важное ограничение текущего прототипа

Это готовый исходный проект для сборки, но фактическую производительность Silero + YAMNet на конкретном Galaxy Watch 8 нужно измерить. Особенно важны CPU, задержка первого speech-сегмента и расход батареи.

Также Android/Wear OS может ограничивать запуск microphone foreground service из фонового состояния. Для production-версии следует протестировать сценарий «нажать START на телефоне → автоматически запустить захват на часах» на реальном Watch 8 и при необходимости запускать watch recording через видимую watch-side activity.

## Конвейер обработки

Запись → сегмент WAV → расшифровка Whisper → текст в БД.

**Транскрипция событийная, периодического воркера больше нет.** Как только
сегмент закрывается (пауза в речи дольше `AudioConfig.FILE_GAP_MS`, либо STOP
для последнего сегмента), `RecordingService.closeCurrentWav()` сразу ставит
задачу в очередь через `PipelineScheduler.enqueueFileReady()`.

Политика очереди — `APPEND_OR_REPLACE`, и это принципиально. `REPLACE`
отменял уже поставленную мгновенную задачу, если в этот момент воркер был
занят предыдущим файлом; именно так самая свежая запись навсегда оставалась
в состоянии «ожидает расшифровки». `APPEND_OR_REPLACE` ставит новый запрос
цепочкой за работающим — не теряется ничего.

`TranscribeWorker` сканирует каталог целиком и берёт все WAV, которых нет в
таблице `transcripts`. Поэтому гарантия — не «этот файл», а «все
необработанные на момент запуска»: одного выжившего триггера достаточно,
чтобы добрать всё пропущенное.

Страховка на случай смерти процесса: `PipelineScheduler.enqueueStartupSweep()`
вызывается из `FilterApp.onCreate` и `BootReceiver` и делает один догоняющий
проход через 30 секунд после старта. Проход дешёвый — если новых файлов нет,
воркер выходит по `pending.isEmpty()` не загружая модель.

**Шага refine нет.** Текст Whisper используется как есть; строка в
`refined_texts` и статус `refined` пишутся прямо в `TranscribeWorker`, чтобы
интерфейс «Записей» и воркеры «Важное»/«Сводка дня» работали без изменений.

### Декодирование Whisper

- `WHISPER_SAMPLING_GREEDY` (`best_of = 1`) — не beam search. `beam_size = 5`
  был верным для модели small/base, но на large-v3-turbo он даёт доли процента
  точности ценой кратной работы декодера: именно из-за него очередь отставала
  от реального времени (174 КБ ≈ 5.5 с аудио распознавались 33.9 с).
- `n_threads = hardware_concurrency()` — используются все ядра. Раньше стоял
  кламп в 4 потока, чтобы не мешать UI и потоку чтения с часов.
- `use_gpu = false` (`USE_GPU_RUNTIME` в `whisper_jni.cpp`) — CPU-only
  делит ресурс с композитором системного UI, GPU-путь перегревал устройство и
  проигрывал по скорости. Одна константа читается и в `nativeInit`, и в
  `nativeBackendInfo`, поэтому интерфейс показывает реальный режим, а не то,
  что было собрано в бинарник.

## License / model notices

Перед публикацией приложения проверьте лицензии самого приложения, Silero VAD, YAMNet/AudioSet labels и используемых Android/Google Play services компонентов.


## Экраны телефонного приложения

Интерфейс разделён на три экрана (нижняя навигация):

- **Запуск** — выбор источника (авто/телефон/часы), индикатор источника, START/STOP.
- **Записи** — «Важное за сегодня», список записей. Каждая запись показывает аудио и её текст (расшифровку Whisper) вместе, одной карточкой, с кнопками «Экспорт» и «Удалить». Удаление одной записи сразу убирает WAV-файл, транскрипт, refined-текст и связанные с ним заметки «Важное» — не по отдельности.
- **Настройки** — импорт модели Whisper, проверка готовности, журнал воркеров (лог фоновых задач).

## WAV playback

The phone app includes a local recordings list with built-in WAV playback, pause/seek controls and WAV export/share. Playback uses AndroidX Media3 ExoPlayer, which supports WAV progressive playback.

## 24/7 processing modes

The phone recorder supports four processing policies from Settings → Processing mode:

- **Energy saving** — Silero VAD + recording, with a conservative cheap RMS pre-gate. Whisper is manual only from the three-dot menu. Automatically selected at 15% battery or below.
- **Balanced** — Silero VAD + YAMNet. Whisper is manual only from the three-dot menu.
- **Performance** — Silero VAD + YAMNet + automatic Whisper after a segment closes.
- **On AC power** — automatic while external power is connected. Same processing as Performance, with the maximum available Whisper CPU thread count.

The selected user mode is restored after the automatic low-battery / AC overrides end. WakeLock behavior is intentionally unchanged.
