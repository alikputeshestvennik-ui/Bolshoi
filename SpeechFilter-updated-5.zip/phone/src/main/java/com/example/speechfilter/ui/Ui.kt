package com.example.speechfilter.ui

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.res.ColorStateList
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import androidx.core.widget.ImageViewCompat

/** Small animation / sizing helpers shared by all screens. */
object Ui {

    fun dp(view: View, v: Int): Int = (v * view.resources.displayMetrics.density).toInt()
    fun dpf(view: View, v: Float): Float = v * view.resources.displayMetrics.density

    fun tint(iv: ImageView, color: Int) {
        ImageViewCompat.setImageTintList(iv, ColorStateList.valueOf(color))
    }

    /** Fade + rise for a list of views, one after another. */
    fun staggerIn(views: List<View>, startDelay: Long = 0L, step: Long = 60L) {
        views.forEachIndexed { i, v ->
            v.animate().cancel()
            v.alpha = 0f
            v.translationY = dpf(v, 18f)
            v.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(startDelay + i * step)
                .setDuration(380)
                .setInterpolator(DecelerateInterpolator(1.6f))
                .start()
        }
    }

    fun children(group: ViewGroup): List<View> = (0 until group.childCount).map { group.getChildAt(it) }

    /** Soft press feedback: card shrinks slightly while a finger is down. */
    @SuppressLint("ClickableViewAccessibility")
    fun pressable(v: View, scale: Float = 0.97f, target: View = v) {
        v.setOnTouchListener { _, e ->
            val view = target
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(scale).scaleY(scale).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(220)
                        .setInterpolator(OvershootInterpolator(2.2f)).start()
            }
            false
        }
    }

    /** Show/hide with a fade + scale so nothing pops in or out. */
    fun setVisibleAnimated(v: View, visible: Boolean) {
        if (visible) {
            if (v.visibility == View.VISIBLE && v.alpha == 1f) return
            v.animate().cancel()
            if (v.visibility != View.VISIBLE) { v.alpha = 0f; v.scaleX = 0.85f; v.scaleY = 0.85f }
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(200).start()
        } else {
            if (v.visibility != View.VISIBLE) return
            v.animate().cancel()
            v.animate().alpha(0f).scaleX(0.85f).scaleY(0.85f).setDuration(160)
                .withEndAction { if (v.alpha <= 0.01f) v.visibility = View.GONE }.start()
        }
    }

    fun animateColor(from: Int, to: Int, duration: Long = 240, onUpdate: (Int) -> Unit): ValueAnimator =
        ValueAnimator.ofArgb(from, to).apply {
            this.duration = duration
            addUpdateListener { onUpdate(it.animatedValue as Int) }
            start()
        }

    /** Press feedback for full-bleed rows: the content slides a few dp to the right. */
    @SuppressLint("ClickableViewAccessibility")
    fun nudge(v: View, target: View, distanceDp: Float = 5f) {
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    target.animate().translationX(dpf(target, distanceDp)).setDuration(100).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    target.animate().translationX(0f).setDuration(260)
                        .setInterpolator(OvershootInterpolator(2.4f)).start()
            }
            false
        }
    }
}
