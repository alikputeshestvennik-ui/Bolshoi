package com.example.speechfilter.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin

/** Four flat bars that dance while audio is playing. */
class EqualizerView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2B2A30.toInt() }
    private val rect = RectF()
    private var phase = 0f
    private var animator: ValueAnimator? = null

    fun setBarColor(color: Int) { paint.color = color; invalidate() }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { phase = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val bars = 4
        val gap = width * 0.12f
        val bw = (width - gap * (bars - 1)) / bars
        for (i in 0 until bars) {
            val f = 0.3f + 0.7f * (0.5f + 0.5f * sin(2 * PI * (phase + i * 0.23f)).toFloat())
            val h = height * f
            val left = i * (bw + gap)
            rect.set(left, height - h, left + bw, height.toFloat())
            canvas.drawRoundRect(rect, bw / 2, bw / 2, paint)
        }
    }
}
