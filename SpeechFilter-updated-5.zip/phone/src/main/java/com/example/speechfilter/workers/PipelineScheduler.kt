package com.example.speechfilter.workers

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequest
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/** Only the startup transcription safety net remains. */
object PipelineScheduler {
    const val UNIQUE_TRANSCRIBE = "pipeline_transcribe"

    fun ensureScheduled(context: Context) {
        // Nothing periodic is scheduled anymore. User-important marks are immediate Room writes.
    }

    fun enqueueStartupSweep(context: Context) {
        val wm = WorkManager.getInstance(context.applicationContext)
        val req = OneTimeWorkRequest.Builder(TranscribeWorker::class.java)
            .setInitialDelay(30, TimeUnit.SECONDS)
            .addTag(UNIQUE_TRANSCRIBE)
            .build()
        wm.enqueueUniqueWork(UNIQUE_TRANSCRIBE, ExistingWorkPolicy.KEEP, req)
    }

    fun scheduleIn(
        wm: WorkManager,
        unique: String,
        worker: Class<out androidx.work.ListenableWorker>,
        delayMinutes: Long
    ) = Unit

    fun reschedule(
        context: Context,
        unique: String,
        worker: Class<out androidx.work.ListenableWorker>,
        delayMinutes: Long
    ) = Unit

    fun enqueueSoon(
        context: Context,
        unique: String,
        worker: Class<out androidx.work.ListenableWorker>,
        delaySeconds: Long
    ) = Unit
}
