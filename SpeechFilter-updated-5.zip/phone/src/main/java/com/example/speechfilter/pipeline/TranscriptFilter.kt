package com.example.speechfilter.pipeline

/**
 * Last line of defence AFTER Whisper (the first one is SpeechEngine's
 * VAD + YAMNet gate, which keeps such audio away from Whisper entirely).
 *
 * Whisper was trained on subtitled video, so on noise / near-silence it
 * invents subtitle credits and channel outros. The Russian ones seen in this
 * app: "Редактор субтитров А.Семкин Корректор А.Егорова",
 * "Субтитры сделал DimaTorzok", "Продолжение следует...", lone "Спасибо.".
 */
object TranscriptFilter {

    /** Always noise, whatever the clip length. Matched on normalized text (lower case, ё->е, no punctuation). */
    private val CREDITS = listOf(
        "редактор субтитров",
        "корректор а егорова",
        "субтитры сделал",
        "субтитры создавал",
        "субтитры подогнал",
        "субтитры добавил",
        "субтитры делал",
        "спасибо за субтитры",
        "dimatorzok",
        "продолжение следует",
        "подписывайтесь на канал",
        "подписывайся на канал",
        "не забудьте подписаться",
        "ставьте лайки",
        "спасибо за просмотр",
        "благодарю за просмотр",
        "спасибо за внимание",
        "до новых встреч",
        "amara org"
    )

    /** Real speech too, but as the ONLY content of a blip-sized clip it is a hallucination. */
    private val SHORT_CLIP_ONLY = setOf(
        "спасибо", "пока", "всем пока", "до свидания", "все", "конец"
    )

    /** ≤ pre-roll + post-roll + a couple of frames: a VAD blip, not an utterance. */
    private const val BLIP_SECONDS = 1.4

    /** @return null if the text looks like real speech, otherwise a short reason. */
    fun rejectReason(text: String, audioSeconds: Double): String? {
        val t = normalize(text)
        if (t.isEmpty()) return "пусто"
        if (t.none { it.isLetter() }) return "нет букв"
        for (p in CREDITS) if (t.contains(p)) return "титры/субтитры"
        if (audioSeconds <= BLIP_SECONDS && t in SHORT_CLIP_ONLY) return "«$t» на коротком всплеске"
        if (isLoop(t)) return "зацикливание"
        return null
    }

    private fun isLoop(t: String): Boolean {
        val w = t.split(' ').filter { it.isNotEmpty() }
        if (w.size < 4) return false
        if (w.toSet().size == 1) return true
        // same word pair repeated 4+ times ("да да да да", "ну а ну а ну а ну а")
        val pairs = w.windowed(2).groupingBy { it }.eachCount()
        return pairs.values.any { it >= 4 } && w.toSet().size <= 3
    }

    private fun normalize(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s.lowercase()) {
            sb.append(
                when {
                    ch == 'ё' -> 'е'
                    ch.isLetterOrDigit() -> ch
                    else -> ' '
                }
            )
        }
        return sb.toString().trim().replace(Regex("\\s+"), " ")
    }
}
