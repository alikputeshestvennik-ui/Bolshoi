package com.example.speechfilter.pipeline

/**
 * Process-wide lock for heavy native inference.
 *
 * Whisper.cpp is the only heavy native inference path in the application now.
 * Keeping model initialization and transcription serialized leaves a simple
 * guard for any future native inference without adding a second executor.
 */
object NativeInferenceLock {
    val lock = Any()
}
