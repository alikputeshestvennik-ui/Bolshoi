package com.example.speechfilter

import android.app.Application
import com.example.speechfilter.workers.PipelineScheduler

class FilterApp : Application() {
    override fun onCreate() {
        super.onCreate()
        PipelineScheduler.ensureScheduled(this)
        // Transcription is event-driven now (a closed WAV enqueues itself).
        // Anything whose trigger died with the process is picked up here.
        PipelineScheduler.enqueueStartupSweep(this)
    }
}
