package com.example.speechfilter

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.speechfilter.workers.PipelineScheduler

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED ||
            intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            PipelineScheduler.ensureScheduled(context)
            PipelineScheduler.enqueueStartupSweep(context)
        }
    }
}
