package com.example.speechfilter

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.io.File

/**
 * Single shared ExoPlayer instance for recording playback. Kept outside any
 * Fragment/Activity so play/pause state survives navigating between screens.
 * Screens subscribe through [listener] (set in onStart, cleared in onStop).
 */
object PlaybackController {
    private var player: ExoPlayer? = null
    var playingFile: File? = null
        private set

    /** Called on the main thread whenever play/pause/stop state changes. */
    @Volatile var listener: (() -> Unit)? = null

    fun isPlaying(file: File): Boolean =
        playingFile?.absolutePath == file.absolutePath && player?.isPlaying == true

    /** 0f..1f progress of the loaded file, or 0f if [file] is not loaded. */
    fun progress(file: File): Float {
        val p = player ?: return 0f
        if (playingFile?.absolutePath != file.absolutePath) return 0f
        val d = p.duration
        if (d <= 0) return 0f
        return (p.currentPosition.toFloat() / d).coerceIn(0f, 1f)
    }

    fun isLoaded(file: File): Boolean = playingFile?.absolutePath == file.absolutePath && player != null

    fun toggle(context: Context, file: File) {
        val same = playingFile?.absolutePath == file.absolutePath
        val current = player
        if (same && current != null) {
            if (current.isPlaying) current.pause() else current.play()
            listener?.invoke()
            return
        }
        release()
        playingFile = file
        player = ExoPlayer.Builder(context.applicationContext).build().also { exo ->
            exo.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    // Tell the recording service to ignore the mic while we're
                    // playing this back through the speaker, so it doesn't
                    // re-capture its own output.
                    RecordingService.selfPlaybackActive = isPlaying
                    listener?.invoke()
                }

                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_ENDED) {
                        release()
                        listener?.invoke()
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    release()
                    listener?.invoke()
                }
            })
            exo.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
            exo.prepare()
            exo.play()
        }
        listener?.invoke()
    }

    /** Call before deleting a recording so a deleted file is never left playing. */
    fun stopIfPlaying(file: File) {
        if (playingFile?.absolutePath == file.absolutePath) {
            release()
            listener?.invoke()
        }
    }

    fun release() {
        player?.release()
        player = null
        playingFile = null
        RecordingService.selfPlaybackActive = false
    }
}
