package com.example.speechfilter.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator

/** Expanding soft rings behind the big start/stop button while recording. */
class PulseRingView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = resources.displayMetrics.density * 2f
        color = 0xFF2B2A30.toInt()
    }
    private var t = 0f
    private var animator: ValueAnimator? = null
    private var wanted = false

    fun setRingColor(c: Int) { paint.color = c; invalidate() }

    fun setActive(active: Boolean) {
        wanted = active
        if (active) startAnim() else stopAnim()
    }

    private fun startAnim() {
        if (animator != null || !isAttachedToWindow) return
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2200
            repeatCount = ValueAnimator.INFINITE
            interpolator = DecelerateInterpolator(1.2f)
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun stopAnim() {
        animator?.cancel(); animator = null
        t = 0f; invalidate()
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (wanted) startAnim() }
    override fun onDetachedFromWindow() { stopAnim(); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        if (animator == null) return
        val cx = width / 2f
        val cy = height / 2f
        val max = minOf(width, height) / 2f - paint.strokeWidth
        val min = max * 0.62f
        for (k in 0..1) {
            val p = (t + k * 0.5f) % 1f
            paint.alpha = ((1f - p) * 110).toInt()
            canvas.drawCircle(cx, cy, min + (max - min) * p, paint)
        }
    }
}
