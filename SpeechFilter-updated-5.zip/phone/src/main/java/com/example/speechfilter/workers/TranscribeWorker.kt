package com.example.speechfilter.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.speechfilter.pipeline.Transcriber

/**
 * Startup-sweep-only safety net now.
 *
 * The normal path is RecordingService calling Transcriber.runPending()
 * directly on its own `io` executor the moment a WAV segment closes \u2014
 * see the comment on Transcriber and on PipelineScheduler.enqueueStartupSweep
 * for why: WorkManager schedules "when the system gets to it", not "now",
 * even for a foreground process, which is what made transcription look like
 * it only ever ran after STOP.
 *
 * This worker still exists for the one case a direct call can't cover: the
 * process died (crash, killed by the system) before it could transcribe a
 * closed segment. enqueueStartupSweep() queues one run of this, 30s after
 * the next app start, which picks up anything still sitting on disk without
 * a transcript row.
 */
class TranscribeWorker(
    ctx: Context,
    params: WorkerParameters
) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        Transcriber.runPending(applicationContext, worker = "transcribe")
        return Result.success()
    }
}
