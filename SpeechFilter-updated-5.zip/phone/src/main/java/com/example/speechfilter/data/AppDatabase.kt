package com.example.speechfilter.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        TranscriptEntity::class,
        ImportantRecordingEntity::class,
        PipelineLogEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transcripts(): TranscriptDao
    abstract fun important(): ImportantRecordingDao
    abstract fun logs(): PipelineLogDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS important_recordings (filePath TEXT NOT NULL PRIMARY KEY, markedAt INTEGER NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_important_recordings_filePath ON important_recordings(filePath)")
                db.execSQL("CREATE TABLE IF NOT EXISTS pipeline_log (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, worker TEXT NOT NULL, message TEXT NOT NULL, at INTEGER NOT NULL)")
                db.execSQL("DROP TABLE IF EXISTS important_items")
                db.execSQL("DROP TABLE IF EXISTS daily_summaries")
                db.execSQL("DROP TABLE IF EXISTS refined_texts")
            }
        }

        // Version 2 of the app could create important_recordings without the
        // Room-required unique index. Existing installs therefore need a real
        // 2 -> 3 migration; changing only the old migration would not repair
        // databases whose user_version is already 2.
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_important_recordings_filePath ON important_recordings(filePath)")
                db.execSQL("CREATE TABLE IF NOT EXISTS pipeline_log (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, worker TEXT NOT NULL, message TEXT NOT NULL, at INTEGER NOT NULL)")
            }
        }

        // Version 3 already shipped without creating pipeline_log. Existing
        // installations therefore need an explicit 3 -> 4 migration.
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS pipeline_log (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, worker TEXT NOT NULL, message TEXT NOT NULL, at INTEGER NOT NULL)")
            }
        }

        fun get(ctx: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    ctx.applicationContext,
                    AppDatabase::class.java,
                    "filter_pipeline.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { instance = it }
            }
    }
}
