package com.example.speechfilter

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

/**
 * Stable shell for the four pages.
 *
 * Pages are kept as fragments and shown/hidden instead of being replaced on
 * every tap. This avoids recreating long-lived screens and also avoids the
 * transition/lifecycle race that could close the process when switching tabs.
 */
class MainActivity : AppCompatActivity() {

    private data class Tab(val id: Int, val tag: String, val create: () -> Fragment)

    private val tabs = listOf(
        Tab(R.id.nav_launch, "tab_launch") { LaunchFragment() },
        Tab(R.id.nav_records, "tab_records") { RecordsFragment() },
        Tab(R.id.nav_important, "tab_important") { ImportantFragment() },
        Tab(R.id.nav_settings, "tab_settings") { SettingsFragment() }
    )

    private var currentIndex = 0
    private lateinit var nav: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        val container = findViewById<View>(R.id.screenContainer)
        val navBar = findViewById<View>(R.id.navBar)
        nav = findViewById(R.id.bottomNav)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { _, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            container.updatePadding(top = bars.top, left = bars.left, right = bars.right)
            navBar.updatePadding(bottom = bars.bottom, left = bars.left, right = bars.right)
            insets
        }

        currentIndex = (savedInstanceState?.getInt(KEY_TAB, 0) ?: 0)
            .coerceIn(0, tabs.lastIndex)

        if (savedInstanceState == null) {
            showTab(0, animate = false)
            requestIgnoreBatteryOptimizations()
        } else {
            // Fragments are restored by FragmentManager. Do not replace them.
            nav.selectedItemId = tabs[currentIndex].id
        }

        nav.setOnItemSelectedListener { item ->
            val idx = tabs.indexOfFirst { it.id == item.itemId }
            if (idx < 0) return@setOnItemSelectedListener false
            showTab(idx, animate = true)
            true
        }
    }

    private fun showTab(idx: Int, animate: Boolean) {
        if (idx !in tabs.indices) return

        val fm = supportFragmentManager
        val target = tabs[idx]
        val current = if (currentIndex in tabs.indices) tabs[currentIndex] else null

        if (idx == currentIndex) {
            if (fm.findFragmentByTag(target.tag) == null) {
                fm.beginTransaction()
                    .add(R.id.screenContainer, target.create(), target.tag)
                    .commit()
            }
            return
        }

        val targetFragment = fm.findFragmentByTag(target.tag) ?: target.create()
        val tx = fm.beginTransaction()

        if (!targetFragment.isAdded) {
            tx.add(R.id.screenContainer, targetFragment, target.tag)
        } else {
            tx.show(targetFragment)
        }

        current?.let { currentTab ->
            fm.findFragmentByTag(currentTab.tag)?.let { tx.hide(it) }
        }

        // No Fragment transition animation here: switching tabs is instantaneous
        // and does not recreate the page or run overlapping enter/exit animations.
        tx.commit()

        currentIndex = idx
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt(KEY_TAB, currentIndex)
        super.onSaveInstanceState(outState)
    }

    private fun requestIgnoreBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        try {
            val pm = getSystemService(PowerManager::class.java)
            if (pm?.isIgnoringBatteryOptimizations(packageName) == true) return
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {
            // OEMs may block this request; recording itself does not depend on it.
        }
    }

    override fun onDestroy() {
        PlaybackController.release()
        super.onDestroy()
    }

    private companion object {
        const val KEY_TAB = "tab"
    }
}
