package com.example.speechfilter.ui

import android.transition.AutoTransition
import android.transition.TransitionManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.speechfilter.R

data class TextCard(
    val id: String,
    val header: String,
    val body: String,
    val iconRes: Int,
    val iconColorRes: Int,
    val muted: Boolean = false,
    /** When true, show a tappable star that can clear the important flag. */
    val canUnmark: Boolean = false,
    val filePath: String? = null
)

/** Seamless text cards used by the "Сводка дня" and "Важное" pages. */
class TextCardAdapter(
    private val onUnmark: ((TextCard) -> Unit)? = null
) : ListAdapter<TextCard, TextCardAdapter.VH>(Diff) {

    object Diff : DiffUtil.ItemCallback<TextCard>() {
        override fun areItemsTheSame(a: TextCard, b: TextCard) = a.id == b.id
        override fun areContentsTheSame(a: TextCard, b: TextCard) = a == b
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: ViewGroup = v as ViewGroup
        val icon: ImageView = v.findViewById(R.id.icon)
        val header: TextView = v.findViewById(R.id.header)
        val body: TextView = v.findViewById(R.id.body)
        val unmark: ImageView = v.findViewById(R.id.unmark)
        var boundId: String? = null
        var item: TextCard? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val h = VH(LayoutInflater.from(parent.context).inflate(R.layout.item_text_card, parent, false))
        h.unmark.setOnClickListener { h.item?.let { onUnmark?.invoke(it) } }
        return h
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = getItem(position)
        val ctx = h.itemView.context
        if (h.boundId == item.id) {
            TransitionManager.beginDelayedTransition(h.card, AutoTransition().setDuration(220))
        }
        h.boundId = item.id
        h.item = item
        h.icon.setImageResource(item.iconRes)
        Ui.tint(h.icon, ctx.getColor(item.iconColorRes))
        h.header.text = item.header
        h.body.text = item.body
        h.body.setTextColor(ctx.getColor(if (item.muted) R.color.ink_muted else R.color.ink))
        if (item.canUnmark && onUnmark != null) {
            h.unmark.visibility = View.VISIBLE
            Ui.tint(h.unmark, ctx.getColor(R.color.accent_amber))
        } else {
            h.unmark.visibility = View.GONE
        }
    }
}
