package com.example.speechfilter.pipeline

import android.content.Context
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.data.PipelineLogEntity
import java.util.concurrent.Executors

/**
 * Fire-and-forget writer for the "Журнал воркеров" window.
 *
 * Has its own single-thread executor so that callers on the audio thread
 * (RecordingService) never block on Room, and so that log lines keep their
 * order. Never throws.
 *
 * worker keys: "record" (file opened/closed), "transcribe" (Whisper).
 */
object PipelineLog {
    private val exec = Executors.newSingleThreadExecutor { r ->
        Thread(r, "pipeline-log").apply { isDaemon = true }
    }

    fun add(context: Context, worker: String, message: String) {
        val app = context.applicationContext
        val at = System.currentTimeMillis()
        try {
            exec.execute {
                try {
                    kotlinx.coroutines.runBlocking {
                        AppDatabase.get(app).logs()
                            .insert(PipelineLogEntity(worker = worker, message = message, at = at))
                    }
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }
}
