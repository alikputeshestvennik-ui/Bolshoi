package com.example.speechfilter.pipeline

import android.app.ActivityManager
import android.content.Context

/**
 * Shared "do we have enough free RAM to load this model" check.
 *
 * [native inference] already had this guard; [WhisperEngine] did not, so a
 * large imported Whisper model (e.g. large-v3-turbo, as opposed to the
 * tiny/base/small the settings screen recommends) could get handed
 * straight to `whisper_init_from_file_with_params()` with no check at
 * all. If that allocation doesn't fit, whisper.cpp / ggml aborts the
 * process natively (uncatchable from Kotlin) instead of failing
 * gracefully — which is consistent with the app freezing and going to
 * a black screen instead of showing an error.
 */
object DeviceMemory {
    fun availableBytes(context: Context): Long {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            ?: return Long.MAX_VALUE // can't check — don't block on it
        val info = ActivityManager.MemoryInfo()
        return try {
            am.getMemoryInfo(info)
            info.availMem
        } catch (_: Throwable) {
            Long.MAX_VALUE
        }
    }

    /**
     * @param modelBytes size of the model file on disk.
     * @param headroomFactor rough multiplier for the working memory the
     *   native runtime needs on top of the raw weights (activations,
     *   KV-cache, tokenizer, etc).
     * @return null if there is enough free memory, otherwise a
     *   human-readable Russian error describing the shortfall.
     */
    fun checkHeadroom(context: Context, modelBytes: Long, headroomFactor: Double): String? {
        val need = (modelBytes * headroomFactor).toLong()
        val avail = availableBytes(context)
        if (avail < need) {
            return "недостаточно свободной памяти: доступно ${avail / (1024 * 1024)} МБ, " +
                "нужно ~${need / (1024 * 1024)} МБ — модель не загружена, чтобы не уронить приложение"
        }
        return null
    }
}
