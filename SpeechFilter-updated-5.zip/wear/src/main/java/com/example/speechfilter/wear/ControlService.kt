package com.example.speechfilter.wear

import android.content.Intent
import androidx.core.content.ContextCompat
import com.google.android.gms.wearable.DataEventBuffer
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService

/**
 * Background entry: phone sends /control/start or /control/stop.
 *
 * Two delivery paths are handled, matching RecordingService.sendWatchControl
 * on the phone:
 *  - onMessageReceived: instant, but ephemeral — dropped if this watch's BT
 *    radio was asleep at the exact moment it was sent.
 *  - onDataChanged: the durable backup. Phone writes "/control/state" as a
 *    DataItem; Play Services keeps and re-syncs it to this watch as soon as
 *    the two devices reconnect, even if that's well after the phone sent it.
 *    This is what actually makes "start and forget" reliable instead of
 *    depending on both radios being awake at the same instant.
 */
class ControlService : WearableListenerService() {
    override fun onMessageReceived(event: MessageEvent) {
        when (event.path) {
            "/control/start", "/source/watch" -> startCapture()
            "/control/stop", "/source/phone" -> stopCapture()
        }
    }

    override fun onDataChanged(dataEvents: DataEventBuffer) {
        try {
            for (event in dataEvents) {
                if (event.dataItem.uri.path != "/control/state") continue
                val action = DataMapItem.fromDataItem(event.dataItem).dataMap.getString("action")
                when (action) {
                    "start" -> startCapture()
                    "stop" -> stopCapture()
                }
            }
        } finally {
            dataEvents.release()
        }
    }

    private fun startCapture() {
        ContextCompat.startForegroundService(
            this, Intent(this, WatchRecordingService::class.java)
        )
    }

    private fun stopCapture() {
        stopService(Intent(this, WatchRecordingService::class.java))
    }
}
