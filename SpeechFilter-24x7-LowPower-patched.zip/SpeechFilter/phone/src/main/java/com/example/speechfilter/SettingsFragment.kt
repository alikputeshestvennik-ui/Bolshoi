package com.example.speechfilter

import android.net.Uri
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.data.PipelineLogEntity
import com.example.speechfilter.pipeline.PowerMode
import com.example.speechfilter.pipeline.GemmaEngine
import com.example.speechfilter.pipeline.ReadinessCheck
import com.example.speechfilter.pipeline.WhisperEngine
import com.example.speechfilter.ui.Ui

/** Models, readiness check, and the worker log window (last hour only). */
class SettingsFragment : Fragment(R.layout.fragment_settings) {

    private lateinit var whisperModelStatus: TextView
    private lateinit var gemmaModelStatus: TextView
    private lateinit var pipelineLogText: TextView
    private lateinit var readinessRows: LinearLayout
    private lateinit var processingModeEffective: TextView
    private lateinit var processingModeGroup: RadioGroup
    private val whisper by lazy { WhisperEngine(requireContext().applicationContext) }
    private val gemma by lazy { GemmaEngine(requireContext().applicationContext) }

    private val uiHandler = Handler(Looper.getMainLooper())
    private val logRefreshRunnable = object : Runnable {
        override fun run() {
            refreshLog()
            uiHandler.postDelayed(this, 3000L)
        }
    }

    private val whisperModelPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        setText(whisperModelStatus, "Whisper: импортирую…")
        lifecycleScope.launch {
            val message = withContext(Dispatchers.IO) {
                whisper.importModel(uri).fold(
                    onSuccess = {
                        val backend = try { whisper.backendInfo() } catch (_: Throwable) { "?" }
                        "Whisper: модель импортирована (${it.length() / (1024 * 1024)} MB) · $backend"
                    },
                    onFailure = { "Whisper: ошибка импорта — ${it.message}" }
                )
            }
            if (isAdded) setText(whisperModelStatus, message)
        }
    }

    private val gemmaModelPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        setText(gemmaModelStatus, "Gemma: импортирую… (может занять минуту)")
        val name = displayNameOf(uri)
        lifecycleScope.launch {
            val message = withContext(Dispatchers.IO) {
                gemma.importModel(uri, name).fold(
                    onSuccess = { "Gemma: модель импортирована (${it.name}, ${it.length() / (1024 * 1024)} MB)" },
                    onFailure = { "Gemma: ошибка импорта — ${it.message}" }
                )
            }
            if (isAdded) setText(gemmaModelStatus, message)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        whisperModelStatus = view.findViewById(R.id.whisperModelStatus)
        gemmaModelStatus = view.findViewById(R.id.gemmaModelStatus)
        pipelineLogText = view.findViewById(R.id.pipelineLogText)
        readinessRows = view.findViewById(R.id.readinessRows)
        processingModeEffective = view.findViewById(R.id.processingModeEffective)
        processingModeGroup = view.findViewById(R.id.processingModeGroup)
        view.findViewById<Button>(R.id.importWhisperModel).let {
            Ui.pressable(it, 0.97f)
            it.setOnClickListener {
                whisperModelPicker.launch(arrayOf("application/octet-stream", "application/x-binary", "*/*"))
            }
        }
        view.findViewById<Button>(R.id.importGemmaModel).let {
            Ui.pressable(it, 0.97f)
            it.setOnClickListener { gemmaModelPicker.launch(arrayOf("*/*")) }
        }
        view.findViewById<Button>(R.id.runReadinessTest).let {
            Ui.pressable(it, 0.97f)
            it.setOnClickListener { runReadinessTest() }
        }

        updateWhisperModelStatus()
        updateGemmaModelStatus()
        updateProcessingModeUi()
        refreshLog()
        Ui.staggerIn(Ui.children(view.findViewById<LinearLayout>(R.id.settingsContent)), step = 70)
    }

    override fun onStart() {
        super.onStart()
        uiHandler.removeCallbacks(logRefreshRunnable)
        uiHandler.post(logRefreshRunnable)
    }

    override fun onStop() {
        uiHandler.removeCallbacks(logRefreshRunnable)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        updateWhisperModelStatus()
        updateGemmaModelStatus()
        updateProcessingModeUi()
    }

    private fun setUserMode(mode: PowerMode) {
        val ctx = requireContext()
        PowerMode.setUserSelected(ctx, mode)
        ctx.sendBroadcast(Intent(RecordingService.ACTION_MODE_CHANGED).setPackage(ctx.packageName))
    }

    private fun updateProcessingModeUi() {
        if (!::processingModeGroup.isInitialized) return
        val user = PowerMode.userSelected(requireContext())
        val effective = PowerMode.effective(requireContext())
        val userId = when (user) {
            PowerMode.ENERGY -> R.id.modeEnergy
            PowerMode.BALANCED -> R.id.modeBalanced
            PowerMode.PERFORMANCE -> R.id.modePerformance
            PowerMode.AC -> R.id.modeBalanced
        }
        processingModeGroup.setOnCheckedChangeListener(null)
        processingModeGroup.check(userId)
        processingModeGroup.setOnCheckedChangeListener { _, checkedId ->
            val selected = when (checkedId) {
                R.id.modeEnergy -> PowerMode.ENERGY
                R.id.modeBalanced -> PowerMode.BALANCED
                R.id.modePerformance -> PowerMode.PERFORMANCE
                R.id.modeAc -> PowerMode.AC
                else -> return@setOnCheckedChangeListener
            }
            if (selected == PowerMode.AC) {
                updateProcessingModeUi()
                return@setOnCheckedChangeListener
            }
            setUserMode(selected)
            updateProcessingModeUi()
        }
        processingModeEffective.text = when {
            effective == PowerMode.AC -> "Сейчас действует: От сети — питание подключено."
            effective == PowerMode.ENERGY && user != PowerMode.ENERGY -> "Сейчас действует: Энергосбережение — заряд ${batteryPercent()}%, автоматический порог ${PowerMode.lowBatteryThresholdPercent()}%."
            else -> "Сейчас действует: ${effective.title}."
        }
        view?.findViewById<RadioButton>(R.id.modeAc)?.isEnabled = false
    }

    private fun batteryPercent(): Int {
        val bm = requireContext().getSystemService(android.os.BatteryManager::class.java)
        return try { bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1 } catch (_: Throwable) { -1 }
    }

    private fun setText(tv: TextView, text: String) {
        if (tv.text.toString() == text) return
        tv.animate().cancel()
        tv.animate().alpha(0f).setDuration(100).withEndAction {
            tv.text = text
            tv.animate().alpha(1f).setDuration(200).start()
        }.start()
    }

    private fun displayNameOf(uri: Uri): String? =
        requireContext().contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
        }

    private fun updateWhisperModelStatus() {
        val text = if (whisper.modelReady()) {
            val mb = whisper.modelDir().resolve("whisper.base").length() / (1024 * 1024)
            val backend = try { whisper.backendInfo() } catch (_: Throwable) { "?" }
            "Whisper: модель готова ($mb MB) · $backend"
        } else {
            "Whisper: модель не импортирована"
        }
        setText(whisperModelStatus, text)
    }

    private fun updateGemmaModelStatus() {
        val text = if (gemma.modelReady()) {
            val f = gemma.modelFile()
            val mb = (f?.length() ?: 0L) / (1024 * 1024)
            "Gemma: модель готова (${f?.name}, $mb MB)"
        } else {
            "Gemma: модель не импортирована"
        }
        setText(gemmaModelStatus, text)
    }

    // ---- readiness -------------------------------------------------------------

    private fun runReadinessTest() {
        val btn = requireView().findViewById<Button>(R.id.runReadinessTest)
        btn.isEnabled = false
        btn.animate().alpha(0.55f).setDuration(150).start()
        btn.text = "Проверка…"
        lifecycleScope.launch {
            val items = withContext(Dispatchers.IO) { ReadinessCheck.run(requireContext().applicationContext) }
            if (!isAdded) return@launch
            showReadiness(items)
            btn.isEnabled = true
            btn.animate().alpha(1f).setDuration(150).start()
            btn.text = "Проверка готовности"
        }
    }

    private fun showReadiness(items: List<ReadinessCheck.Item>) {
        readinessRows.removeAllViews()
        val overall = ReadinessCheck.overallLabel(items)
        val worst = when {
            items.any { it.level == ReadinessCheck.Level.FAIL } -> ReadinessCheck.Level.FAIL
            items.any { it.level == ReadinessCheck.Level.WARN } -> ReadinessCheck.Level.WARN
            else -> ReadinessCheck.Level.OK
        }
        val views = mutableListOf<View>()
        views += readinessRow(worst, overall, bold = true)
        items.forEach { views += readinessRow(it.level, it.label, bold = false) }
        views.forEach { readinessRows.addView(it) }
        Ui.staggerIn(views, step = 45)
    }

    private fun readinessRow(level: ReadinessCheck.Level, text: String, bold: Boolean): View {
        val ctx = requireContext()
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            setPadding(0, Ui.dp(this, 10), 0, 0)
        }
        val (res, color) = when (level) {
            ReadinessCheck.Level.OK -> R.drawable.ic_status_done to R.color.accent_green
            ReadinessCheck.Level.WARN -> R.drawable.ic_status_queue to R.color.accent_amber
            ReadinessCheck.Level.FAIL -> R.drawable.ic_status_error to R.color.accent_red
        }
        val icon = ImageView(ctx).apply {
            setImageResource(res)
            Ui.tint(this, ctx.getColor(color))
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        row.addView(icon, LinearLayout.LayoutParams(Ui.dp(row, 20), Ui.dp(row, 20)).apply { topMargin = Ui.dp(row, 1) })
        val tv = TextView(ctx).apply {
            this.text = text
            textSize = if (bold) 15f else 14f
            setTextColor(ctx.getColor(if (bold) R.color.ink else R.color.ink_muted))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        row.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Ui.dp(row, 10)
        })
        return row
    }

    // ---- log: everything from the last hour, nothing older ---------------------

    private fun refreshLog() {
        val ctx = context ?: return
        lifecycleScope.launch {
            val since = System.currentTimeMillis() - ONE_HOUR_MS
            val logs = withContext(Dispatchers.IO) { AppDatabase.get(ctx).logs().recentSince(since) }
            if (!isAdded) return@launch
            val text = if (logs.isEmpty()) {
                "За последний час записей нет"
            } else {
                logs.joinToString("\n") { log: PipelineLogEntity ->
                    "[${formatTime(log.at)}] ${workerLabel(log.worker)}: ${log.message}"
                }
            }
            if (pipelineLogText.text.toString() != text) pipelineLogText.text = text
        }
    }

    private fun workerLabel(worker: String): String = when (worker) {
        "record" -> "Запись"
        "transcribe" -> "Транскрипция"
        "refine" -> "Обработка"
        "important" -> "Важное"
        "daily" -> "Сводка дня"
        else -> worker
    }

    private fun formatTime(ms: Long): String {
        val fmt = java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        return fmt.format(java.util.Date(ms))
    }

    private companion object {
        const val ONE_HOUR_MS = 60L * 60L * 1000L
    }
}
