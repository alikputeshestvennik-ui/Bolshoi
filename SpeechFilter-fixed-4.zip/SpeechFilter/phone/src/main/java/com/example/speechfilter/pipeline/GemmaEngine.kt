package com.example.speechfilter.pipeline

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession.LlmInferenceSessionOptions
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Offline Gemma engine backed by Google's MediaPipe LLM Inference API
 * (com.google.mediapipe:tasks-genai). Runs a locally imported Gemma
 * checkpoint (.task / .bin, and .gguf as a raw path passthrough) entirely
 * on-device — no network calls, no server round-trip.
 *
 * Expected model path: filesDir/models/gemma-model.{task|gguf|bin}
 *
 * The native model is expensive to load (a multi-hundred-MB to multi-GB
 * file), so it is kept in a process-wide singleton shared across every
 * GemmaEngine(context) instance/worker run instead of being reloaded from
 * disk each time RefineWorker/ImportantWorker/DailySummaryWorker fire.
 *
 * IMPORTANT: every call that touches the native LlmInference object
 * (create/close/generateResponse) goes through the single companion
 * [lock], never a per-instance one. RefineWorker/ImportantWorker/
 * DailySummaryWorker each construct their own GemmaEngine, so an
 * instance-level `@Synchronized` would do nothing to stop two different
 * worker threads calling generateResponse() on the *same* shared native
 * object at the same time — MediaPipe's native inference is not
 * reentrant, and a concurrent call there is a real, observed crash
 * (native abort, killing the whole app — not a catchable Kotlin
 * exception). Routing everything through one lock is what actually
 * prevents that.
 */
class GemmaEngine(private val context: Context) {

    companion object {
        // Sanity floor so a wrong/partial file pick doesn't get accepted as a model.
        // Real quantized Gemma checkpoints (.task/.gguf/.bin) are realistically
        // >100MB; 20MB just rejects obviously-wrong picks (images, docs, etc).
        private const val MIN_MODEL_BYTES = 20L * 1024L * 1024L
        private val EXTS = setOf("task", "gguf", "bin")

        private const val MAX_TOKENS = 1024
        // MaxTopK must be >= default session topK (40) or generateResponse fails:
        // "Top-K value 40 must be <= 8 which is determined by the first created session"
        private const val MAX_TOP_K = 40
        private const val TOP_K = 40
        private const val TEMPERATURE = 0.2f

        // Rough headroom multiplier: loading needs the model's bytes resident
        // plus working memory for activations/kv-cache/tokenizer. If available
        // RAM is clearly short of this, refuse to load instead of letting the
        // native allocator abort the whole process.
        private const val MEMORY_HEADROOM_FACTOR = 1.3

        // Process-wide lock guarding every native call: creation, close, AND
        // generateResponse. Shared with WhisperEngine — see
        // NativeInferenceLock for why (both engines' heavy native work must
        // be mutually exclusive, not just each engine's own calls).
        private val lock = NativeInferenceLock.lock

        @Volatile private var sharedInference: LlmInference? = null
        @Volatile private var sharedInferenceModelPath: String? = null
    }

    private val warmed = AtomicBoolean(false)

    fun modelDir(): File = File(context.filesDir, "models").apply { mkdirs() }

    private fun isGemmaFile(f: File): Boolean {
        val n = f.name.lowercase()
        return n.startsWith("gemma") && EXTS.any { n.endsWith(".$it") }
    }

    private fun existingModelFile(): File? = modelDir().listFiles()?.firstOrNull(::isGemmaFile)

    fun modelReady(): Boolean = existingModelFile()?.let { it.length() > MIN_MODEL_BYTES } == true

    fun modelFile(): File? = existingModelFile()

    /**
     * Gemma instruction-tuned checkpoints expect turns wrapped like this;
     * a plain .bin checkpoint (as opposed to a .task bundle, which can carry
     * its own baked-in chat template) has no template of its own, so without
     * this the model just free-continues off the end of the raw text instead
     * of following the instructions in the prompt.
     */
    private fun wrapTurn(prompt: String): String =
        "<start_of_turn>user\n$prompt<end_of_turn>\n<start_of_turn>model\n"

    /** Import a user-selected Gemma model (.task / .gguf / .bin) into app-private storage. */
    fun importModel(uri: Uri, displayName: String?): Result<File> = runCatching {
        release(dropShared = true)
        val ext = displayName
            ?.substringAfterLast('.', "")
            ?.lowercase()
            ?.takeIf { it in EXTS } ?: "task"

        // Replace any previously imported Gemma model (whatever extension it had).
        modelDir().listFiles()?.forEach { if (isGemmaFile(it)) it.delete() }

        val out = File(modelDir(), "gemma-model.$ext")
        val tmp = File(modelDir(), "gemma-model.$ext.tmp")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(tmp).use { output -> input.copyTo(output) }
        } ?: error("Не удалось открыть выбранный файл")
        if (tmp.length() < MIN_MODEL_BYTES) {
            tmp.delete()
            error("Файл слишком маленький для модели Gemma: ${tmp.length()} байт")
        }
        if (!tmp.renameTo(out)) {
            tmp.copyTo(out, overwrite = true)
            tmp.delete()
        }
        out
    }

    private fun availableMemoryBytes(): Long {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            ?: return Long.MAX_VALUE // can't check — don't block on it
        val info = ActivityManager.MemoryInfo()
        return try {
            am.getMemoryInfo(info)
            info.availMem
        } catch (_: Throwable) {
            Long.MAX_VALUE
        }
    }

    /** Loads (or reuses) the shared native LlmInference engine for [modelPath]. Caller holds [lock]. */
    private fun ensureLoadedLocked(modelPath: String, modelBytes: Long) {
        if (sharedInference != null && sharedInferenceModelPath == modelPath) return
        sharedInference?.let { runCatching { it.close() } }
        sharedInference = null
        sharedInferenceModelPath = null

        val need = (modelBytes * MEMORY_HEADROOM_FACTOR).toLong()
        val avail = availableMemoryBytes()
        if (avail < need) {
            error(
                "недостаточно свободной памяти: доступно ${avail / (1024 * 1024)} МБ, " +
                    "нужно ~${need / (1024 * 1024)} МБ — модель не загружена, чтобы не уронить приложение"
            )
        }

        // NOTE: setTopK/setTemperature do NOT exist on LlmInferenceOptions.Builder
        // (only setMaxTopK does — that's just the ceiling every session must
        // stay under, not a value applied to inference). They only exist on
        // LlmInferenceSession.LlmInferenceSessionOptions.Builder, built per
        // session in generate() below. A previous version of this code looked
        // up "setTopK"/"setTemperature" on the wrong builder via reflection,
        // which silently found nothing and did nothing — TOP_K/TEMPERATURE
        // were never actually applied, and every generate() call ran at the
        // API's default temperature (0.8) instead of the intended 0.2.
        val options = LlmInferenceOptions.builder()
            .setModelPath(modelPath)
            .setMaxTokens(MAX_TOKENS)
            .setMaxTopK(MAX_TOP_K)
            .build()
        sharedInference = LlmInference.createFromOptions(context.applicationContext, options)
        sharedInferenceModelPath = modelPath
    }

    fun warmUp(): String {
        val model = existingModelFile()
        if (model == null) {
            warmed.set(false)
            return "Gemma: модель не найдена в ${modelDir().absolutePath}"
        }
        return synchronized(lock) {
            try {
                ensureLoadedLocked(model.absolutePath, model.length())
                warmed.set(true)
                "Gemma: модель загружена (${model.name})"
            } catch (t: Throwable) {
                warmed.set(false)
                "Gemma: ошибка загрузки модели — ${t.message ?: t.toString()}"
            }
        }
    }

    /**
     * Runs prompt+text through the real on-device Gemma model via MediaPipe's
     * LLM Inference API and returns the generated text. Wrapped in the
     * companion [lock] end-to-end (load check + the generateResponse call
     * itself), so it's safe to call from several workers without them ever
     * touching the native object concurrently.
     */
    fun generate(promptTemplate: String, text: String): Result<String> {
        if (text.isBlank()) return Result.success("")
        val model = existingModelFile()
            ?: return Result.failure(IllegalStateException("Нет модели Gemma в ${modelDir()}"))
        return synchronized(lock) {
            try {
                ensureLoadedLocked(model.absolutePath, model.length())
                warmed.set(true)
                val engine = sharedInference
                    ?: return@synchronized Result.failure(IllegalStateException("Gemma engine не инициализирован"))
                val prompt = wrapTurn(PromptStore.fill(promptTemplate, text))
                // Explicit session per call (closed right after) instead of
                // engine.generateResponse(): that convenience method builds an
                // *implicit* session with default options every time — topK/
                // temperature can't be set on it at all, so it always ran at
                // the API default temperature (0.8), not the TOP_K/TEMPERATURE
                // configured below. A fresh session per call also avoids
                // leaking prior-prompt context between unrelated
                // Refine/Important/DailySummary calls that share this engine.
                val sessionOptions = LlmInferenceSessionOptions.builder()
                    .setTopK(TOP_K)
                    .setTemperature(TEMPERATURE)
                    .build()
                val session = LlmInferenceSession.createFromOptions(engine, sessionOptions)
                val response = try {
                    session.addQueryChunk(prompt)
                    session.generateResponse()
                } finally {
                    runCatching { session.close() }
                }
                Result.success(GemmaOutput.stripPrefix(response?.trim().orEmpty()))
            } catch (t: Throwable) {
                warmed.set(false)
                Result.failure(t)
            }
        }
    }

    /**
     * Marks this handle as not-warm. The shared native model stays resident
     * (loading it is expensive) unless [dropShared] is true, e.g. right
     * before importing a different model file.
     */
    fun release(dropShared: Boolean = false) {
        warmed.set(false)
        if (dropShared) {
            synchronized(lock) {
                sharedInference?.let { runCatching { it.close() } }
                sharedInference = null
                sharedInferenceModelPath = null
            }
        }
    }
}
