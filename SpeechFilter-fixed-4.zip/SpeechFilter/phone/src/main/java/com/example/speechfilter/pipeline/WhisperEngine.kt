package com.example.speechfilter.pipeline

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Offline Whisper engine (whisper.cpp via JNI).
 *
 * The native model is kept in a **process-wide singleton** (same idea as
 * [GemmaEngine]): loading ~0.5 GB from disk + Vulkan init costs tens of
 * seconds, so workers must not free it after every run.
 *
 * - [warmUp] / [transcribeFile] share one [sharedNativeContext]
 * - [release] with default args only clears the local "warm" flag
 * - [release](dropShared = true) actually unloads the model (import / low memory)
 */
class WhisperEngine(private val context: Context) {

    companion object {
        private const val MODEL_FILE = "whisper.base"

        // Rough headroom multiplier: on top of the raw ggml weights, whisper.cpp
        // needs working memory for mel spectrogram buffers, KV-cache and — on
        // the Vulkan path — GPU staging/shader buffers. Heavier than Gemma's
        // factor because the GPU backend adds its own allocations on top of
        // the CPU-side ones. Without this, a large imported model (small/
        // medium/large-v3-turbo, as opposed to the recommended tiny/base/
        // small) can overrun available RAM and abort the whole process
        // natively — which looks like a freeze + black screen, not a normal
        // crash dialog.
        private const val MEMORY_HEADROOM_FACTOR = 1.8

        // Shared with GemmaEngine — see NativeInferenceLock for why.
        private val lock = NativeInferenceLock.lock
        @Volatile private var sharedNativeContext: Long = 0L
        @Volatile private var sharedModelPath: String? = null

        init {
            System.loadLibrary("whisper")
        }
    }

    private val warmed = AtomicBoolean(false)

    fun modelDir(): File = File(context.filesDir, "models").apply { mkdirs() }

    private fun modelFile(): File = File(modelDir(), MODEL_FILE)

    /** Import the user-selected Whisper model (any ggml size) into app-private storage. */
    fun importModel(uri: Uri): Result<File> = runCatching {
        release(dropShared = true)
        val out = modelFile()
        val tmp = File(modelDir(), "$MODEL_FILE.tmp")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(tmp).use { output -> input.copyTo(output) }
        } ?: error("Не удалось открыть выбранный файл")
        if (tmp.length() < 10L * 1024L * 1024L) {
            tmp.delete()
            error("Файл слишком маленький для модели Whisper: ${tmp.length()} байт")
        }
        if (!tmp.renameTo(out)) {
            tmp.copyTo(out, overwrite = true)
            tmp.delete()
        }
        out
    }

    fun modelReady(): Boolean = modelFile().let { it.isFile && it.length() > 10L * 1024L * 1024L }

    fun modelFilePath(): String = modelFile().absolutePath

    fun isLoaded(): Boolean = synchronized(lock) { sharedNativeContext != 0L }

    /** Backend string for UI (no logcat needed). */
    fun backendInfo(): String = try {
        nativeBackendInfo()
    } catch (_: Throwable) {
        "неизвестно"
    }

    fun warmUp(): String {
        if (!modelReady()) {
            warmed.set(false)
            return "Whisper: модель не импортирована. Импортируйте .bin-файл в настройках."
        }
        val path = modelFile().absolutePath
        return synchronized(lock) {
            try {
                ensureLoadedLocked(path)
                warmed.set(true)
                val backend = backendInfo()
                if (sharedNativeContext != 0L) {
                    "Whisper: загружен · $backend"
                } else {
                    warmed.set(false)
                    "Whisper: не удалось загрузить модель"
                }
            } catch (t: Throwable) {
                warmed.set(false)
                "Whisper: ошибка загрузки — ${t.message ?: t.toString()}"
            }
        }
    }

    private fun ensureLoadedLocked(path: String) {
        if (sharedNativeContext != 0L && sharedModelPath == path) return
        if (sharedNativeContext != 0L) {
            nativeFree(sharedNativeContext)
            sharedNativeContext = 0L
            sharedModelPath = null
        }
        val bytes = File(path).length()
        DeviceMemory.checkHeadroom(context, bytes, MEMORY_HEADROOM_FACTOR)?.let { error(it) }
        sharedNativeContext = nativeInit(path)
        sharedModelPath = if (sharedNativeContext != 0L) path else null
    }

    fun transcribeFile(wav: File): Result<String> {
        if (!wav.exists() || wav.length() < 1000L) {
            return Result.failure(IllegalArgumentException("Пустой или короткий файл"))
        }
        return synchronized(lock) {
            try {
                if (sharedNativeContext == 0L) {
                    if (!modelReady()) {
                        return@synchronized Result.failure(
                            IllegalStateException("Whisper: модель не импортирована")
                        )
                    }
                    ensureLoadedLocked(modelFile().absolutePath)
                }
                if (sharedNativeContext == 0L) {
                    return@synchronized Result.failure(
                        IllegalStateException("Whisper: не удалось загрузить модель")
                    )
                }
                warmed.set(true)
                val text = nativeTranscribe(sharedNativeContext, wav.absolutePath)
                    ?: return@synchronized Result.failure(
                        IllegalStateException("whisper.cpp не смог распознать WAV")
                    )
                Result.success(text.trim())
            } catch (t: Throwable) {
                Result.failure(t)
            }
        }
    }

    /**
     * @param dropShared if true, free the process-wide native model (import /
     *   low-memory). Workers should call [release] without this flag.
     */
    fun release(dropShared: Boolean = false) {
        warmed.set(false)
        if (dropShared) {
            synchronized(lock) {
                if (sharedNativeContext != 0L) {
                    nativeFree(sharedNativeContext)
                    sharedNativeContext = 0L
                    sharedModelPath = null
                }
            }
        }
    }

    private external fun nativeInit(modelPath: String): Long
    private external fun nativeTranscribe(context: Long, wavPath: String): String?
    private external fun nativeFree(context: Long)
    private external fun nativeBackendInfo(): String
}
