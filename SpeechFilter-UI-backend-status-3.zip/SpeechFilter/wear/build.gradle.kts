plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.speechfilter.wear"

    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.speechfilter"
        minSdk = 30
        targetSdk = 33
        versionCode = 2
        versionName = "1.0.1"

        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    signingConfigs {
        create("release") {
            val ks = System.getenv("ANDROID_KEYSTORE_PATH")
            val alias = System.getenv("ANDROID_KEY_ALIAS")
            val storePass = System.getenv("ANDROID_STORE_PASSWORD")
            val keyPass = System.getenv("ANDROID_KEY_PASSWORD")
            if (!ks.isNullOrBlank() && !alias.isNullOrBlank() && !storePass.isNullOrBlank() && !keyPass.isNullOrBlank()) {
                storeFile = file(ks)
                keyAlias = alias
                storePassword = storePass
                keyPassword = keyPass
            }
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            isShrinkResources = false
            val ks = System.getenv("ANDROID_KEYSTORE_PATH")
            if (!ks.isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    packaging {
        jniLibs {
            excludes += listOf(
                "**/libtensorflowlite_jni.so",
                "**/libtensorflowlite_gpu_jni.so",
                "**/libonnxruntime.so",
                "**/libonnxruntime4j_jni.so"
            )
        }
        resources {
            excludes += listOf(
                "**/silero_vad.onnx",
                "**/yamnet.tflite",
                "**/yamnet_class_map.csv"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Only need AudioConfig + AudioPacket from shared; ML natives excluded above
    implementation(project(":shared"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.google.android.gms:play-services-wearable:18.2.0")

    // Ongoing Activity API — keeps the watch-face tappable indicator / Recents
    // chip alive while the recording foreground service is running.
    implementation("androidx.wear:wear-ongoing:1.1.0")
}
