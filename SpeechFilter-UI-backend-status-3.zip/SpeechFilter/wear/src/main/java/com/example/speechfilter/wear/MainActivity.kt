package com.example.speechfilter.wear

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Shows only the brand logo. Recording is controlled from the phone.
 *
 * Also requests POST_NOTIFICATIONS on first launch. On Wear OS 4 / API 33+
 * this is a runtime permission just like on phone; without it granted,
 * WatchRecordingService's foreground notification — and therefore the
 * Ongoing Activity built on top of it (watch-face icon, Recents entry) —
 * is silently suppressed by the system, even though the service itself
 * keeps running.
 */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }
}
