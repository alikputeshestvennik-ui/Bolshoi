package com.example.speechfilter.wear

import android.app.*
import android.content.Intent
import android.media.*
import android.os.IBinder
import android.os.PowerManager
import android.os.Build
import android.os.SystemClock
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import androidx.wear.ongoing.OngoingActivity
import androidx.wear.ongoing.Status
import com.example.speechfilter.shared.AudioConfig
import com.example.speechfilter.shared.AudioPacket
import com.google.android.gms.tasks.Tasks
import com.google.android.gms.wearable.*
import java.io.OutputStream
import kotlin.concurrent.thread

/**
 * Watch mic → Channel /speech-audio → phone.
 * Retries until phone accepts the channel (so START on watch works even if phone starts later).
 *
 * Also publishes an Ongoing Activity (androidx.wear.ongoing) tied to the
 * foreground notification, so the recording session stays visible as the
 * tappable icon on the watch face / Recents even while this app isn't on
 * screen, and shows a live elapsed-time stopwatch once the mic is actually
 * capturing.
 */
class WatchRecordingService : Service() {
    companion object {
        private const val NOTIFICATION_ID = 7
        private const val CHANNEL_ID = "watch_speech"
    }

    @Volatile private var stopping = false
    private var worker: Thread? = null
    private var record: AudioRecord? = null
    private var output: OutputStream? = null
    private var channel: ChannelClient.Channel? = null
    private var sequence = 0
    private var wakeLock: PowerManager.WakeLock? = null

    /** Set once r.startRecording() actually succeeds; drives the Ongoing Activity stopwatch. */
    @Volatile private var recordingStartElapsed: Long? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Фильтр", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val n = buildOngoingNotification("Galaxy Watch: подготовка")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SpeechFilter:WatchRec").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopping = false
        worker?.interrupt()
        worker = thread(name = "watch-audio") { runCapture() }
        return START_STICKY
    }

    private fun findPhone(): Node? {
        return try {
            val nodes = Tasks.await(Wearable.getNodeClient(this).connectedNodes)
            nodes.firstOrNull { it.isNearby } ?: nodes.firstOrNull()
        } catch (_: Throwable) {
            null
        }
    }

    private fun openChannelWithRetry(): Boolean {
        val client = Wearable.getChannelClient(this)
        var attempt = 0
        while (!stopping && attempt < 60) {
            attempt++
            val phone = findPhone()
            if (phone == null) {
                update("Нет телефона (BT?)… $attempt")
                Thread.sleep(1000)
                continue
            }
            // Ask phone to start listening
            try {
                Wearable.getMessageClient(this)
                    .sendMessage(phone.id, "/watch/ready", byteArrayOf(1))
            } catch (_: Throwable) {}

            update("Канал к ${phone.displayName}… ($attempt)")
            try {
                val ch = Tasks.await(client.openChannel(phone.id, "/speech-audio"))
                val out = Tasks.await(client.getOutputStream(ch))
                channel = ch
                output = out
                update("Канал открыт")
                return true
            } catch (t: Throwable) {
                update("Жду телефон… ${t.message ?: ""}".take(40))
                try { Thread.sleep(1000) } catch (_: InterruptedException) { return false }
            }
        }
        return false
    }

    private fun runCapture() {
        try {
            if (!openChannelWithRetry()) {
                update("Не удалось открыть канал")
                return
            }

            val min = AudioRecord.getMinBufferSize(
                AudioConfig.SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            if (min <= 0) {
                update("AudioRecord недоступен")
                return
            }
            val r = AudioRecord(
                MediaRecorder.AudioSource.MIC, AudioConfig.SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                (min * 2).coerceAtLeast(AudioConfig.FRAME_SAMPLES * 4 * 2)
            )
            if (r.state != AudioRecord.STATE_INITIALIZED) {
                update("Микрофон не инициализирован")
                r.release()
                return
            }
            record = r
            r.startRecording()
            recordingStartElapsed = SystemClock.elapsedRealtime()
            update("ЗАПИСЬ с часов")
            val buf = ShortArray(AudioConfig.FRAME_SAMPLES)
            var frames = 0
            while (!stopping) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0) {
                    val pcm = if (n == buf.size) buf else buf.copyOf(n)
                    try {
                        output?.write(AudioPacket.encode(sequence++, pcm))
                        if (frames % 20 == 0) output?.flush()
                    } catch (_: Throwable) {
                        update("Канал оборвался, переподключение…")
                        closeChannel()
                        if (!openChannelWithRetry()) break
                    }
                    frames++
                } else if (n < 0) {
                    update("Ошибка чтения: $n")
                    break
                }
            }
            try { r.stop() } catch (_: Exception) {}
            try { r.release() } catch (_: Exception) {}
            recordingStartElapsed = null
            update("Стоп")
        } catch (t: Throwable) {
            recordingStartElapsed = null
            update("Ошибка: ${t.message ?: t.javaClass.simpleName}")
        } finally {
            closeChannel()
        }
    }

    private fun closeChannel() {
        try { output?.flush() } catch (_: Exception) {}
        try { output?.close() } catch (_: Exception) {}
        channel?.let { ch ->
            try { Wearable.getChannelClient(this).close(ch) } catch (_: Exception) {}
        }
        output = null
        channel = null
    }

    override fun onDestroy() {
        stopping = true
        try { record?.stop() } catch (_: Exception) {}
        worker?.interrupt()
        worker = null
        recordingStartElapsed = null
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun reopenPendingIntent(): PendingIntent {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /**
     * Builds the foreground notification and, in the same step, registers/refreshes
     * the Ongoing Activity tied to it (via OngoingActivity.apply). While the mic is
     * actively capturing (recordingStartElapsed set) the Ongoing Activity surfaces
     * (watch-face icon, Recents) show a live "Запись — mm:ss" stopwatch; otherwise
     * they show the plain status text (searching for phone, opening channel, etc.).
     */
    private fun buildOngoingNotification(text: String): Notification {
        val touchIntent = reopenPendingIntent()
        val notificationBuilder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Фильтр")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(touchIntent)

        val startElapsed = recordingStartElapsed
        val status = if (startElapsed != null) {
            Status.Builder()
                .addTemplate("#type# — #time#")
                .addPart("type", Status.TextPart("Запись"))
                .addPart("time", Status.StopwatchPart(startElapsed))
                .build()
        } else {
            Status.Builder()
                .addTemplate("#status#")
                .addPart("status", Status.TextPart(text))
                .build()
        }

        val ongoingActivity = OngoingActivity.Builder(applicationContext, NOTIFICATION_ID, notificationBuilder)
            .setStaticIcon(android.R.drawable.ic_btn_speak_now)
            .setTouchIntent(touchIntent)
            .setStatus(status)
            .build()
        ongoingActivity.apply(applicationContext)

        return notificationBuilder.build()
    }

    private fun update(text: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildOngoingNotification(text))
        } catch (_: Exception) {}
    }
}
