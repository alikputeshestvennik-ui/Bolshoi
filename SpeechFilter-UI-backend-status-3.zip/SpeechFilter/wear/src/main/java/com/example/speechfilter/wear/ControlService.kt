package com.example.speechfilter.wear

import android.content.Intent
import androidx.core.content.ContextCompat
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService

/**
 * Background entry: phone sends /control/start or /control/stop.
 */
class ControlService : WearableListenerService() {
    override fun onMessageReceived(event: MessageEvent) {
        when (event.path) {
            "/control/start", "/source/watch" -> {
                ContextCompat.startForegroundService(
                    this, Intent(this, WatchRecordingService::class.java)
                )
            }
            "/control/stop", "/source/phone" -> {
                stopService(Intent(this, WatchRecordingService::class.java))
            }
        }
    }
}
