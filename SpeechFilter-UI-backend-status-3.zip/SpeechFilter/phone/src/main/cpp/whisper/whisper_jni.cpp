#include <jni.h>
#include <android/log.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <thread>

#include "whisper.h"

#define TAG "SpeechFilterWhisper"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static bool read_u16(std::ifstream & f, uint16_t & out) {
    unsigned char b[2];
    if (!f.read(reinterpret_cast<char *>(b), 2)) return false;
    out = static_cast<uint16_t>(b[0] | (b[1] << 8));
    return true;
}

static bool read_u32(std::ifstream & f, uint32_t & out) {
    unsigned char b[4];
    if (!f.read(reinterpret_cast<char *>(b), 4)) return false;
    out = static_cast<uint32_t>(b[0] | (b[1] << 8) | (b[2] << 16) | (b[3] << 24));
    return true;
}

static bool read_wav_pcm16_mono_16k(const char * path, std::vector<float> & samples) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;

    char riff[4], wave[4];
    uint32_t riff_size = 0;
    if (!f.read(riff, 4) || !read_u32(f, riff_size) || !f.read(wave, 4)) return false;
    if (std::memcmp(riff, "RIFF", 4) != 0 || std::memcmp(wave, "WAVE", 4) != 0) return false;

    uint16_t audio_format = 0, channels = 0, bits = 0;
    uint32_t sample_rate = 0, data_size = 0;
    std::streampos data_pos = -1;
    bool got_fmt = false, got_data = false;

    while (f && (!got_fmt || !got_data)) {
        char id[4];
        uint32_t size = 0;
        if (!f.read(id, 4) || !read_u32(f, size)) break;
        const std::streampos payload = f.tellg();
        if (std::memcmp(id, "fmt ", 4) == 0) {
            uint32_t byte_rate = 0;
            uint16_t block_align = 0;
            if (!read_u16(f, audio_format) || !read_u16(f, channels) ||
                !read_u32(f, sample_rate) || !read_u32(f, byte_rate) ||
                !read_u16(f, block_align) || !read_u16(f, bits)) return false;
            got_fmt = true;
        } else if (std::memcmp(id, "data", 4) == 0) {
            data_pos = payload;
            data_size = size;
            got_data = true;
        }
        f.seekg(payload + static_cast<std::streamoff>(size + (size & 1u)));
    }

    if (!got_fmt || !got_data || audio_format != 1 || channels != 1 || bits != 16 || sample_rate != 16000) {
        LOGE("Unsupported WAV: fmt=%u channels=%u rate=%u bits=%u", audio_format, channels, sample_rate, bits);
        return false;
    }

    f.clear();
    f.seekg(data_pos);
    const size_t count = data_size / sizeof(int16_t);
    samples.resize(count);
    for (size_t i = 0; i < count; ++i) {
        int16_t s = 0;
        if (!f.read(reinterpret_cast<char *>(&s), sizeof(s))) return false;
        samples[i] = static_cast<float>(s) / 32768.0f;
    }
    return !samples.empty();
}

static std::string jstring_to_string(JNIEnv * env, jstring value) {
    if (!value) return {};
    const char * chars = env->GetStringUTFChars(value, nullptr);
    std::string out = chars ? chars : "";
    if (chars) env->ReleaseStringUTFChars(value, chars);
    return out;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_example_speechfilter_pipeline_WhisperEngine_nativeInit(
        JNIEnv * env, jobject /* thiz */, jstring model_path) {
    const std::string path = jstring_to_string(env, model_path);
    if (path.empty()) return 0;

    whisper_context_params params = whisper_context_default_params();
    // --- Optimized for Samsung Exynos 2500 + Xclipse 950 (Galaxy Z Flip 7) ---
    // Xclipse 950 is RDNA3-based → Vulkan is the preferred acceleration path.
    // If Vulkan backend was compiled in, ggml will pick it when use_gpu=true.
    params.use_gpu    = true;   // try Vulkan first, fall back to CPU
    params.flash_attn = true;   // beneficial on modern GPU + CPU
    // params.gpu_device = 0;   // default = first device (usually the only one)

    whisper_context * ctx = whisper_init_from_file_with_params(path.c_str(), params);
    if (!ctx) {
        LOGE("Failed to load Whisper model: %s", path.c_str());
        return 0;
    }
    // Log that we requested GPU (actual backend is decided inside ggml)
    __android_log_print(ANDROID_LOG_INFO, TAG, "Whisper init: use_gpu=1 flash_attn=1 (Exynos/Xclipse optimized)");
    return reinterpret_cast<jlong>(ctx);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_speechfilter_pipeline_WhisperEngine_nativeTranscribe(
        JNIEnv * env, jobject /* thiz */, jlong context_ptr, jstring wav_path) {
    auto * ctx = reinterpret_cast<whisper_context *>(context_ptr);
    if (!ctx) return nullptr;

    const std::string path = jstring_to_string(env, wav_path);
    std::vector<float> pcmf32;
    if (!read_wav_pcm16_mono_16k(path.c_str(), pcmf32)) {
        return nullptr;
    }

    whisper_full_params params = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    // Optimal for 10-core Exynos 2500 (1xX5 + mid cores): 4-6 threads.
    // More than ~6 often hurts due to big.LITTLE scheduling + thermal.
    const unsigned hc = std::thread::hardware_concurrency();
    params.n_threads = std::max(1u, std::min(6u, hc > 4 ? hc - 2 : hc));
    params.no_context = true;
    params.single_segment = false;
    params.print_realtime = false;
    params.print_progress = false;
    params.print_timestamps = false;
    params.print_special = false;
    params.translate = false;
    params.language = nullptr;  // auto-detect language
    params.temperature = 0.0f;
    params.temperature_inc = 0.2f;

    if (whisper_full(ctx, params, pcmf32.data(), static_cast<int>(pcmf32.size())) != 0) {
        LOGE("whisper_full failed for %s", path.c_str());
        return nullptr;
    }

    std::string result;
    const int n = whisper_full_n_segments(ctx);
    for (int i = 0; i < n; ++i) {
        const char * text = whisper_full_get_segment_text(ctx, i);
        if (text) result += text;
    }

    return env->NewStringUTF(result.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_speechfilter_pipeline_WhisperEngine_nativeFree(
        JNIEnv * /* env */, jobject /* thiz */, jlong context_ptr) {
    auto * ctx = reinterpret_cast<whisper_context *>(context_ptr);
    if (ctx) whisper_free(ctx);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_speechfilter_pipeline_WhisperEngine_nativeBackendInfo(
        JNIEnv * env, jobject /* thiz */) {
    // Compile-time detection of Vulkan backend + runtime preference.
    // Shown in the app UI so the user doesn't need logcat.
#if defined(GGML_USE_VULKAN)
    const char * info = "Vulkan (GPU / Xclipse)";
#else
    const char * info = "CPU (Vulkan не собран)";
#endif
    return env->NewStringUTF(info);
}
