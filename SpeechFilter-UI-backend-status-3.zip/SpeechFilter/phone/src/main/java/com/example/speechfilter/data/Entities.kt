package com.example.speechfilter.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Raw Whisper transcript of one WAV file. */
@Entity(
    tableName = "transcripts",
    indices = [Index(value = ["filePath"], unique = true)]
)
data class TranscriptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val filePath: String,
    val fileName: String,
    val sourceTag: String,          // phone / watch
    val text: String,
    val createdAt: Long,
    val transcribedAt: Long,
    /** pending | refined | failed */
    val status: String = "pending"
)

/** Text after first Gemma pass (prompt A). */
@Entity(tableName = "refined_texts")
data class RefinedTextEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val transcriptId: Long,
    val text: String,
    val processedAt: Long,
    val dayKey: String              // yyyy-MM-dd
)

/** Important snippets from second Gemma pass (prompt B) → "important" Room store. */
@Entity(tableName = "important_items")
data class ImportantItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val sourceRefinedId: Long?,
    val extractedAt: Long,
    val dayKey: String
)

/** End-of-day summary. */
@Entity(
    tableName = "daily_summaries",
    indices = [Index(value = ["dayKey"], unique = true)]
)
data class DailySummaryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dayKey: String,
    val summary: String,
    val createdAt: Long
)

@Entity(tableName = "pipeline_log")
data class PipelineLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val worker: String,
    val message: String,
    val at: Long = System.currentTimeMillis()
)
