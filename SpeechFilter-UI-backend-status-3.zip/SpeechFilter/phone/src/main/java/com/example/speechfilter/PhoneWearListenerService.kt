package com.example.speechfilter

import android.content.Intent
import androidx.core.content.ContextCompat
import com.google.android.gms.wearable.ChannelClient
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService

/**
 * Wear events. After user STOP (userArmed=false), ignore automatic channel/ready
 * so watch retries cannot restart recording. Explicit /source/watch from watch
 * button may arm a new session.
 */
class PhoneWearListenerService : WearableListenerService() {

    override fun onMessageReceived(event: MessageEvent) {
        when (event.path) {
            "/source/watch" -> {
                // Explicit press on watch — allowed to start
                startServiceWith("WATCH")
            }
            "/source/phone" -> {
                if (RecordingService.userArmed || RecordingService.sessionActive) {
                    startServiceWith("PHONE")
                }
            }
            "/watch/ready", "/control/start" -> {
                // Automatic — only if user already armed a session
                if (RecordingService.userArmed && RecordingService.activeSource != "WATCH") {
                    startServiceWith("WATCH")
                }
            }
        }
    }

    override fun onChannelOpened(channel: ChannelClient.Channel) {
        if (channel.path != "/speech-audio") return
        // Channel from watch retry — only accept if user armed
        if (!RecordingService.userArmed && !RecordingService.sessionActive) return
        if (RecordingService.activeSource != "WATCH" || !RecordingService.sessionActive) {
            startServiceWith("WATCH")
        }
    }

    private fun startServiceWith(source: String) {
        val i = Intent(this, RecordingService::class.java)
            .putExtra("source", source)
        try {
            ContextCompat.startForegroundService(this, i)
        } catch (_: Exception) {}
    }
}
