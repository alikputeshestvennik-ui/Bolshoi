package com.example.speechfilter.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.data.DailySummaryEntity
import com.example.speechfilter.data.PipelineLogEntity
import com.example.speechfilter.pipeline.DayKeys
import com.example.speechfilter.pipeline.GemmaEngine
import com.example.speechfilter.pipeline.PromptStore
import java.util.Calendar
import java.util.concurrent.TimeUnit

/** Once a day (~22:00): summary of all refined text for the day. */
class DailySummaryWorker(
    ctx: Context,
    params: WorkerParameters
) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val db = AppDatabase.get(applicationContext)
        val gemma = GemmaEngine(applicationContext)
        return try {
            val day = DayKeys.today()
            db.logs().insert(PipelineLogEntity(worker = "daily", message = gemma.warmUp()))
            val parts = db.refined().forDay(day)
            if (parts.isEmpty()) {
                db.logs().insert(PipelineLogEntity(worker = "daily", message = "Нет текста за $day"))
            } else {
                val joined = parts.joinToString("\n\n") { it.text }
                val r = gemma.generate(PromptStore.dailySummaryPrompt, joined)
                if (r.isSuccess) {
                    db.summaries().upsert(
                        DailySummaryEntity(
                            dayKey = day,
                            summary = r.getOrDefault(""),
                            createdAt = System.currentTimeMillis()
                        )
                    )
                    db.logs().insert(PipelineLogEntity(worker = "daily", message = "Саммари $day OK"))
                } else {
                    db.logs().insert(
                        PipelineLogEntity(
                            worker = "daily",
                            message = r.exceptionOrNull()?.message ?: "fail"
                        )
                    )
                }
            }
            Result.success()
        } catch (t: Throwable) {
            db.logs().insert(PipelineLogEntity(worker = "daily", message = "crash: ${t.message}"))
            Result.retry()
        } finally {
            gemma.release()
            // next day 22:00
            val now = Calendar.getInstance()
            val next = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, 1)
                set(Calendar.HOUR_OF_DAY, 22)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
            }
            val delay = next.timeInMillis - now.timeInMillis
            val req = OneTimeWorkRequestBuilder<DailySummaryWorker>()
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .addTag(PipelineScheduler.UNIQUE_DAILY)
                .build()
            WorkManager.getInstance(applicationContext)
                .enqueueUniqueWork(PipelineScheduler.UNIQUE_DAILY, ExistingWorkPolicy.REPLACE, req)
        }
    }
}
