package com.example.speechfilter

import android.app.Application
import com.example.speechfilter.workers.PipelineScheduler

class FilterApp : Application() {
    override fun onCreate() {
        super.onCreate()
        PipelineScheduler.ensureScheduled(this)
    }
}
