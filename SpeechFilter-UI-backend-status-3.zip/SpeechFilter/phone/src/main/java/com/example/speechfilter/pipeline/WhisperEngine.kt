package com.example.speechfilter.pipeline

import android.content.Context
import java.io.File
import android.net.Uri
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/** Offline Whisper engine backed by whisper.cpp through JNI.
 *  Accepts any ggml Whisper model (tiny/base/small/...); the model
 *  file is just stored under a fixed internal name. */
class WhisperEngine(private val context: Context) {

    companion object {
        private const val MODEL_FILE = "whisper.base"

        init {
            System.loadLibrary("whisper")
        }
    }

    private val warmed = AtomicBoolean(false)
    private var nativeContext: Long = 0L

    fun modelDir(): File = File(context.filesDir, "models").apply { mkdirs() }

    private fun modelFile(): File = File(modelDir(), MODEL_FILE)

    /** Import the user-selected Whisper model (any ggml size) into app-private storage. */
    @Synchronized
    fun importModel(uri: Uri): Result<File> = runCatching {
        release()
        val out = modelFile()
        val tmp = File(modelDir(), "$MODEL_FILE.tmp")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(tmp).use { output -> input.copyTo(output) }
        } ?: error("Не удалось открыть выбранный файл")
        if (tmp.length() < 10L * 1024L * 1024L) {
            tmp.delete()
            error("Файл слишком маленький для модели Whisper: ${tmp.length()} байт")
        }
        if (!tmp.renameTo(out)) {
            tmp.copyTo(out, overwrite = true)
            tmp.delete()
        }
        out
    }

    fun modelReady(): Boolean = modelFile().let { it.isFile && it.length() > 10L * 1024L * 1024L }

    fun modelFilePath(): String = modelFile().absolutePath

    /** Backend string for UI (no logcat needed). */
    fun backendInfo(): String = try {
        nativeBackendInfo()
    } catch (_: Throwable) {
        "неизвестно"
    }

    @Synchronized
    fun warmUp(): String {
        if (!modelReady()) {
            warmed.set(false)
            return "Whisper: модель не импортирована. Импортируйте .bin-файл в настройках."
        }
        if (nativeContext == 0L) {
            nativeContext = nativeInit(modelFile().absolutePath)
        }
        if (nativeContext == 0L) {
            warmed.set(false)
            return "Whisper: не удалось загрузить модель"
        }
        warmed.set(true)
        val backend = backendInfo()
        return "Whisper: загружен · $backend"
    }

    @Synchronized
    fun transcribeFile(wav: File): Result<String> {
        if (!wav.exists() || wav.length() < 1000L) {
            return Result.failure(IllegalArgumentException("Пустой или короткий файл"))
        }
        if (!warmed.get()) {
            val status = warmUp()
            if (!warmed.get()) return Result.failure(IllegalStateException(status))
        }
        val text = nativeTranscribe(nativeContext, wav.absolutePath)
            ?: return Result.failure(IllegalStateException("whisper.cpp не смог распознать WAV"))
        return Result.success(text.trim())
    }

    @Synchronized
    fun release() {
        if (nativeContext != 0L) {
            nativeFree(nativeContext)
            nativeContext = 0L
        }
        warmed.set(false)
    }

    private external fun nativeInit(modelPath: String): Long
    private external fun nativeTranscribe(context: Long, wavPath: String): String?
    private external fun nativeFree(context: Long)
    private external fun nativeBackendInfo(): String
}
