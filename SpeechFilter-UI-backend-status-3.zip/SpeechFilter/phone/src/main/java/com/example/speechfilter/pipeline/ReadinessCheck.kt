package com.example.speechfilter.pipeline

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.StatFs
import androidx.core.content.ContextCompat
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.shared.ModelFiles
import com.example.speechfilter.workers.PipelineScheduler

/**
 * One-shot end-to-end self-test: "would recording → transcription → Gemma
 * pipeline actually work right now if I hit START?"
 *
 * Not a unit test — it pokes the real objects the app uses (permissions,
 * VAD/YamNet assets, whisper.cpp native init, Room, WorkManager schedule,
 * Gemma model presence) and reports a plain-language verdict for each,
 * so a non-developer can see *why* something won't work instead of just
 * "it's broken".
 */
object ReadinessCheck {

    enum class Level { OK, WARN, FAIL }

    data class Item(val level: Level, val label: String)

    private const val MIN_FREE_BYTES = 200L * 1024 * 1024 // 200 MB safety margin for WAV + models

    /** Runs blocking/native calls — always call from a background dispatcher. */
    suspend fun run(context: Context): List<Item> {
        val items = mutableListOf<Item>()

        // --- Permissions -----------------------------------------------------
        val micOk = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        items += Item(
            if (micOk) Level.OK else Level.FAIL,
            if (micOk) "Микрофон: разрешение есть" else "Микрофон: нет разрешения RECORD_AUDIO — запись не запустится"
        )

        if (Build.VERSION.SDK_INT >= 33) {
            val notifOk = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
            items += Item(
                if (notifOk) Level.OK else Level.WARN,
                if (notifOk) "Уведомления: разрешены" else "Уведомления: не разрешены (foreground-сервис может быть убит системой)"
            )
        }

        // --- Free space --------------------------------------------------------
        val free = runCatching { StatFs(context.filesDir.path).availableBytes }.getOrDefault(0L)
        val freeMb = free / (1024 * 1024)
        items += Item(
            if (free >= MIN_FREE_BYTES) Level.OK else Level.WARN,
            "Свободно места: ${freeMb} MB" + if (free < MIN_FREE_BYTES) " (мало, лучше > 200 MB)" else ""
        )

        // --- VAD / YamNet assets ------------------------------------------------
        val vadOk = runCatching {
            val f = ModelFiles.silero(context); f.exists() && f.length() > 0L
        }.getOrDefault(false)
        items += Item(
            if (vadOk) Level.OK else Level.FAIL,
            if (vadOk) "Silero VAD: распакован" else "Silero VAD: не удалось распаковать ассет — определение речи не будет работать"
        )

        val yamOk = runCatching {
            val t = ModelFiles.yamnet(context)
            val l = ModelFiles.labels(context)
            t.exists() && t.length() > 0L && l.exists() && l.length() > 0L
        }.getOrDefault(false)
        items += Item(
            if (yamOk) Level.OK else Level.WARN,
            if (yamOk) "YamNet: распакован" else "YamNet: недоступен (не критично — классификация звука просто выключена)"
        )

        // --- Whisper (actually try to load the native model) --------------------
        val whisper = WhisperEngine(context)
        if (whisper.modelReady()) {
            val warm = runCatching { whisper.warmUp() }.getOrElse { "ошибка инициализации: ${it.message}" }
            val loaded = warm.contains("загружен")
            items += Item(if (loaded) Level.OK else Level.FAIL, "Whisper: $warm")
            whisper.release()
        } else {
            items += Item(Level.FAIL, "Whisper: модель не импортирована — транскрипция работать не будет")
        }

        // --- Gemma (actually try to load the model, like Whisper above) ---------
        val gemma = GemmaEngine(context)
        if (gemma.modelReady()) {
            val warm = runCatching { gemma.warmUp() }.getOrElse { "ошибка инициализации: ${it.message}" }
            val loaded = warm.contains("загружена")
            items += Item(if (loaded) Level.OK else Level.FAIL, "Gemma: $warm")
        } else {
            items += Item(Level.WARN, "Gemma: модель не импортирована (обработка/важное/сводка дня не будут работать)")
        }

        // --- Room database --------------------------------------------------------
        val dbOk = runCatching { AppDatabase.get(context).logs().recent(1); true }.getOrDefault(false)
        items += Item(if (dbOk) Level.OK else Level.FAIL, if (dbOk) "База данных: доступна" else "База данных: ошибка доступа")

        // --- Scheduled background pipeline ------------------------------------
        val wm = WorkManager.getInstance(context)
        val workers = listOf(
            PipelineScheduler.UNIQUE_TRANSCRIBE to "Транскрипция (Whisper)",
            PipelineScheduler.UNIQUE_REFINE to "Обработка (Gemma)",
            PipelineScheduler.UNIQUE_IMPORTANT to "Извлечение важного (Gemma)",
            PipelineScheduler.UNIQUE_DAILY to "Сводка дня (Gemma)"
        )
        for ((unique, label) in workers) {
            val scheduled = runCatching {
                wm.getWorkInfosForUniqueWork(unique).get().any {
                    it.state == WorkInfo.State.ENQUEUED || it.state == WorkInfo.State.RUNNING
                }
            }.getOrDefault(false)
            items += Item(
                if (scheduled) Level.OK else Level.WARN,
                "Планировщик «$label»: ${if (scheduled) "запланирован" else "не запланирован"}"
            )
        }

        return items
    }

    fun format(items: List<Item>): String {
        val icon = { l: Level -> when (l) { Level.OK -> "✅"; Level.WARN -> "⚠️"; Level.FAIL -> "❌" } }
        val overall = when {
            items.any { it.level == Level.FAIL } -> "❌ Готовность: ЕСТЬ ПРОБЛЕМЫ"
            items.any { it.level == Level.WARN } -> "⚠️ Готовность: РАБОТАЕТ С ОГРАНИЧЕНИЯМИ"
            else -> "✅ Готовность: ВСЁ OK"
        }
        return buildString {
            appendLine(overall)
            appendLine()
            items.forEach { appendLine("${icon(it.level)} ${it.label}") }
        }.trim()
    }
}
