package com.example.speechfilter

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment

/** Recording control screen: pick a source, see it live, start/stop. */
class LaunchFragment : Fragment(R.layout.fragment_launch) {

    private lateinit var status: TextView
    private lateinit var button: Button
    private lateinit var sourceLabel: TextView
    private lateinit var sourceDot: TextView
    private lateinit var sourceIndicator: LinearLayout
    private var running = false

    private val permissionRequest = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) startRecording()
        else status.text = "Нужно разрешение микрофона"
    }

    private val sourceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val src = intent?.getStringExtra(RecordingService.EXTRA_SOURCE) ?: return
            val detail = intent.getStringExtra(RecordingService.EXTRA_DETAIL) ?: ""
            updateSourceIndicator(src, detail)
            running = src != "IDLE" && src != "STOPPED"
            button.text = if (running) "STOP" else "START"
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        status = view.findViewById(R.id.status)
        button = view.findViewById(R.id.startStop)
        sourceLabel = view.findViewById(R.id.sourceLabel)
        sourceDot = view.findViewById(R.id.sourceDot)
        sourceIndicator = view.findViewById(R.id.sourceIndicator)
        view.findViewById<RadioButton>(R.id.autoSource).isChecked = true

        button.setOnClickListener { if (!running) requestStart() else stopRecording() }
        syncFromService()
    }

    override fun onStart() {
        super.onStart()
        val f = IntentFilter(RecordingService.ACTION_SOURCE)
        if (Build.VERSION.SDK_INT >= 33) {
            requireContext().registerReceiver(sourceReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            requireContext().registerReceiver(sourceReceiver, f)
        }
    }

    override fun onStop() {
        try { requireContext().unregisterReceiver(sourceReceiver) } catch (_: Exception) {}
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        syncFromService()
    }

    private fun requestStart() {
        val need = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) {
            permissionRequest.launch(need.toTypedArray())
            return
        }
        startRecording()
    }

    private fun startRecording() {
        val source = when {
            view?.findViewById<RadioButton>(R.id.watchSource)?.isChecked == true -> "WATCH"
            view?.findViewById<RadioButton>(R.id.phoneSource)?.isChecked == true -> "PHONE"
            else -> "AUTO"
        }
        ContextCompat.startForegroundService(
            requireContext(),
            Intent(requireContext(), RecordingService::class.java).putExtra("source", source)
        )
        running = true
        button.text = "STOP"
        updateSourceIndicator(source, "запуск…")
    }

    private fun stopRecording() {
        val i = Intent(requireContext(), RecordingService::class.java)
            .putExtra(RecordingService.EXTRA_STOP, true)
        try {
            ContextCompat.startForegroundService(requireContext(), i)
        } catch (_: Exception) {
            requireContext().stopService(Intent(requireContext(), RecordingService::class.java))
        }
        running = false
        button.text = "START"
        updateSourceIndicator("STOPPED", "")
    }

    /** Restore START/STOP UI from real service state (rotation / screen switch). */
    private fun syncFromService() {
        val active = RecordingService.sessionActive && RecordingService.activeSource != "IDLE"
        running = active
        if (active) {
            button.text = "STOP"
            when (RecordingService.activeSource) {
                "WATCH" -> {
                    view?.findViewById<RadioButton>(R.id.watchSource)?.isChecked = true
                    updateSourceIndicator("WATCH", "")
                }
                "PHONE" -> {
                    view?.findViewById<RadioButton>(R.id.phoneSource)?.isChecked = true
                    updateSourceIndicator("PHONE", "")
                }
                "AUTO" -> {
                    view?.findViewById<RadioButton>(R.id.autoSource)?.isChecked = true
                    updateSourceIndicator("AUTO", "")
                }
                else -> updateSourceIndicator(RecordingService.activeSource, "")
            }
        } else {
            button.text = "START"
            updateSourceIndicator("IDLE", "")
        }
    }

    private fun updateSourceIndicator(src: String, detail: String) {
        val (label, color, bg) = when (src) {
            "WATCH" -> Triple(
                "⌚ Источник: Galaxy Watch 8",
                Color.parseColor("#1B5E20"),
                Color.parseColor("#C8E6C9")
            )
            "PHONE" -> Triple(
                "📱 Источник: микрофон телефона",
                Color.parseColor("#0D47A1"),
                Color.parseColor("#BBDEFB")
            )
            "AUTO" -> Triple(
                "🔄 Авто: ожидание часов…",
                Color.parseColor("#E65100"),
                Color.parseColor("#FFE0B2")
            )
            "STOPPED", "IDLE" -> Triple(
                "Источник: не активен",
                Color.parseColor("#616161"),
                Color.parseColor("#E8E8E8")
            )
            else -> Triple(
                "Источник: $src",
                Color.parseColor("#616161"),
                Color.parseColor("#E8E8E8")
            )
        }
        sourceLabel.text = if (detail.isNotBlank()) "$label · $detail" else label
        sourceLabel.setTextColor(color)
        sourceIndicator.setBackgroundColor(bg)
        sourceDot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
        status.text = when (src) {
            "WATCH" -> "Идёт запись с часов"
            "PHONE" -> "Идёт запись с телефона"
            "AUTO" -> "Ожидание источника…"
            "STOPPED" -> "Запись завершена"
            else -> status.text
        }
        when (src) {
            "WATCH" -> view?.findViewById<RadioButton>(R.id.watchSource)?.isChecked = true
            "PHONE" -> view?.findViewById<RadioButton>(R.id.phoneSource)?.isChecked = true
        }
    }
}
