package com.example.speechfilter.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.data.ImportantItemEntity
import com.example.speechfilter.data.PipelineLogEntity
import com.example.speechfilter.pipeline.DayKeys
import com.example.speechfilter.pipeline.GemmaEngine
import com.example.speechfilter.pipeline.PromptStore

/** Every 27 minutes: extract important items from recent refined text. */
class ImportantWorker(
    ctx: Context,
    params: WorkerParameters
) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val db = AppDatabase.get(applicationContext)
        val gemma = GemmaEngine(applicationContext)
        return try {
            db.logs().insert(PipelineLogEntity(worker = "important", message = gemma.warmUp()))
            val since = System.currentTimeMillis() - 3 * 60 * 60 * 1000L
            val batch = db.refined().since(since)
            if (batch.isEmpty()) {
                db.logs().insert(PipelineLogEntity(worker = "important", message = "Нет новых refined"))
                return Result.success()
            }
            val joined = batch.joinToString("\n\n") { it.text }
            val r = gemma.generate(PromptStore.importantPrompt, joined)
            if (r.isSuccess) {
                val lines = r.getOrDefault("").lines().map { it.trim() }.filter { it.isNotEmpty() }
                var n = 0
                for (line in lines) {
                    db.important().insert(
                        ImportantItemEntity(
                            text = line.trimStart('-', '•', '*', ' ').trim(),
                            sourceRefinedId = batch.lastOrNull()?.id,
                            extractedAt = System.currentTimeMillis(),
                            dayKey = DayKeys.today()
                        )
                    )
                    n++
                }
                db.logs().insert(PipelineLogEntity(worker = "important", message = "Важного: $n"))
            } else {
                db.logs().insert(
                    PipelineLogEntity(
                        worker = "important",
                        message = r.exceptionOrNull()?.message ?: "fail"
                    )
                )
            }
            Result.success()
        } catch (t: Throwable) {
            db.logs().insert(PipelineLogEntity(worker = "important", message = "crash: ${t.message}"))
            Result.retry()
        } finally {
            gemma.release()
            PipelineScheduler.reschedule(
                applicationContext,
                PipelineScheduler.UNIQUE_IMPORTANT,
                ImportantWorker::class.java,
                27
            )
        }
    }
}
