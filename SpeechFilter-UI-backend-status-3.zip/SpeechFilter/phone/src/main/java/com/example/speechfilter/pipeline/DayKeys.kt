package com.example.speechfilter.pipeline

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DayKeys {
    private val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    fun today(): String = fmt.format(Date())
    fun of(ms: Long): String = fmt.format(Date(ms))
}
