package com.example.speechfilter

import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.data.DailySummaryEntity
import com.example.speechfilter.data.ImportantItemEntity
import com.example.speechfilter.data.RecordingRow
import com.example.speechfilter.data.RecordingsRepository
import com.example.speechfilter.pipeline.DayKeys

/**
 * Every recording shown as one row: audio playback + its own transcript /
 * refined text together, so the two never appear as separate, unlinked
 * lists. Deleting a row removes the WAV file and every derived text
 * (transcript, refined text, "important" snippets) in one action.
 */
class RecordsFragment : Fragment(R.layout.fragment_records) {

    private lateinit var importantContainer: LinearLayout
    private lateinit var dailySummaryText: TextView
    private lateinit var recordingsContainer: LinearLayout
    private lateinit var playerView: PlayerView

    private val uiHandler = Handler(Looper.getMainLooper())
    private val refreshRunnable = object : Runnable {
        override fun run() {
            refresh()
            uiHandler.postDelayed(this, 2000L)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        importantContainer = view.findViewById(R.id.importantContainer)
        dailySummaryText = view.findViewById(R.id.dailySummaryText)
        recordingsContainer = view.findViewById(R.id.recordingsContainer)
        playerView = view.findViewById(R.id.playerView)
        playerView.visibility = View.GONE
        refresh()
    }

    override fun onStart() {
        super.onStart()
        uiHandler.removeCallbacks(refreshRunnable)
        uiHandler.post(refreshRunnable)
    }

    override fun onStop() {
        uiHandler.removeCallbacks(refreshRunnable)
        super.onStop()
    }

    private fun refresh() {
        val ctx = context ?: return
        lifecycleScope.launch {
            val db = AppDatabase.get(ctx)
            val important: List<ImportantItemEntity>
            val summary: DailySummaryEntity?
            val rows: List<RecordingRow>
            withContext(Dispatchers.IO) {
                important = db.important().forDay(DayKeys.today())
                summary = db.summaries().forDay(DayKeys.today())
                rows = RecordingsRepository.loadRows(ctx)
            }
            if (!isAdded) return@launch

            importantContainer.removeAllViews()
            if (important.isEmpty()) {
                importantContainer.addView(mutedText("Важного за сегодня пока нет"))
            } else {
                important.forEach { item ->
                    importantContainer.addView(TextView(requireContext()).apply {
                        text = "• ${item.text}"
                        textSize = 15f
                        setTextColor(requireContext().getColor(R.color.ink))
                        setPadding(0, 4, 0, 4)
                    })
                }
            }
            dailySummaryText.text = summary?.summary?.takeIf { it.isNotBlank() }
                ?: "Сводки за сегодня пока нет"

            recordingsContainer.removeAllViews()
            if (rows.isEmpty()) {
                recordingsContainer.addView(mutedText("Записей пока нет"))
            } else {
                rows.forEach { recordingsContainer.addView(recordingRow(it)) }
            }
        }
    }

    private fun mutedText(msg: String): TextView = TextView(requireContext()).apply {
        text = msg
        textSize = 14f
        setTextColor(requireContext().getColor(R.color.ink_muted))
        setPadding(0, 4, 0, 4)
    }

    private fun recordingRow(row: RecordingRow): LinearLayout {
        val ctx = requireContext()
        val container = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 12, 0, 12)
        }
        val isPlayingThis = PlaybackController.isPlaying(row.file)
        val title = TextView(ctx).apply {
            val mark = if (row.fromWatch) "⌚ с часов · " else "📱 "
            val playMark = if (isPlayingThis) "⏸ " else "▶ "
            text = playMark + mark + row.file.name.removeSuffix(".wav")
            textSize = 17f
            setTextColor(ctx.getColor(R.color.ink))
            setPadding(0, 8, 0, 4)
            setOnClickListener {
                PlaybackController.toggle(ctx, row.file) { refresh() }
                refresh()
            }
        }
        val meta = TextView(ctx).apply {
            val src = if (row.fromWatch) "с часов" else "с телефона"
            text = "$src · ${formatSize(row.file.length())} · ${formatDate(row.file.lastModified())} · ${row.statusLabel}"
            textSize = 13f
            setTextColor(ctx.getColor(R.color.ink_muted))
        }
        val transcriptText = TextView(ctx).apply {
            val body = row.displayText
            text = body ?: "(расшифровка ещё не готова)"
            textSize = 14f
            setTextColor(if (body != null) ctx.getColor(R.color.ink) else ctx.getColor(R.color.ink_muted))
            setTypeface(typeface, if (row.refinedText != null) Typeface.NORMAL else Typeface.ITALIC)
            setPadding(0, 6, 0, 0)
        }
        val actions = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 8, 0, 0)
        }
        val share = Button(ctx).apply {
            text = "Экспорт"
            setOnClickListener { shareFile(row) }
        }
        val delete = Button(ctx).apply {
            text = "Удалить"
            setOnClickListener { confirmDelete(row) }
        }
        actions.addView(share)
        actions.addView(delete)
        container.addView(title)
        container.addView(meta)
        container.addView(transcriptText)
        container.addView(actions)
        return container
    }

    private fun confirmDelete(row: RecordingRow) {
        AlertDialog.Builder(requireContext())
            .setTitle("Удалить запись?")
            .setMessage("Аудиофайл, расшифровка Whisper, обработка Gemma и связанные заметки «Важное» будут удалены вместе.")
            .setPositiveButton("Удалить") { _, _ -> deleteRow(row) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun deleteRow(row: RecordingRow) {
        val ctx = requireContext()
        PlaybackController.stopIfPlaying(row.file)
        lifecycleScope.launch {
            withContext(Dispatchers.IO) { RecordingsRepository.deleteRecording(ctx, row) }
            if (isAdded) refresh()
        }
    }

    private fun shareFile(row: RecordingRow) {
        val ctx = requireContext()
        val uri = FileProvider.getUriForFile(
            ctx, "${BuildConfig.APPLICATION_ID}.fileprovider", row.file
        )
        startActivity(
            android.content.Intent.createChooser(
                android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = "audio/wav"
                    putExtra(android.content.Intent.EXTRA_STREAM, uri)
                    addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                },
                "Экспорт записи"
            )
        )
    }

    private fun formatSize(bytes: Long): String = when {
        bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB", bytes / 1024f / 1024f)
        else -> String.format(Locale.US, "%.0f KB", bytes / 1024f)
    }

    private fun formatDate(ms: Long): String {
        val fmt = java.text.SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        return fmt.format(java.util.Date(ms))
    }
}
