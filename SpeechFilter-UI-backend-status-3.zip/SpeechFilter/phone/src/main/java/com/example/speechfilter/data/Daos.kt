package com.example.speechfilter.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface TranscriptDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(e: TranscriptEntity): Long

    @Query("SELECT * FROM transcripts WHERE filePath = :path LIMIT 1")
    suspend fun byPath(path: String): TranscriptEntity?

    @Query("SELECT * FROM transcripts WHERE status = :status ORDER BY transcribedAt ASC LIMIT :limit")
    suspend fun byStatus(status: String, limit: Int = 50): List<TranscriptEntity>

    @Query("UPDATE transcripts SET status = :status WHERE id = :id")
    suspend fun setStatus(id: Long, status: String)

    @Query("SELECT * FROM transcripts ORDER BY transcribedAt DESC LIMIT :limit")
    suspend fun recent(limit: Int = 100): List<TranscriptEntity>

    @Query("DELETE FROM transcripts WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface RefinedTextDao {
    @Insert
    suspend fun insert(e: RefinedTextEntity): Long

    @Query("SELECT * FROM refined_texts WHERE processedAt > :since ORDER BY processedAt ASC")
    suspend fun since(since: Long): List<RefinedTextEntity>

    @Query("SELECT * FROM refined_texts WHERE dayKey = :day ORDER BY processedAt ASC")
    suspend fun forDay(day: String): List<RefinedTextEntity>

    @Query("SELECT COUNT(*) FROM refined_texts WHERE transcriptId = :tid")
    suspend fun countForTranscript(tid: Long): Int

    @Query("SELECT * FROM refined_texts WHERE transcriptId = :tid LIMIT 1")
    suspend fun forTranscript(tid: Long): RefinedTextEntity?

    @Query("SELECT * FROM refined_texts WHERE transcriptId = :tid")
    suspend fun allForTranscript(tid: Long): List<RefinedTextEntity>

    @Query("DELETE FROM refined_texts WHERE transcriptId = :tid")
    suspend fun deleteForTranscript(tid: Long)
}

@Dao
interface ImportantItemDao {
    @Insert
    suspend fun insert(e: ImportantItemEntity): Long

    @Query("SELECT * FROM important_items ORDER BY extractedAt DESC LIMIT :limit")
    suspend fun recent(limit: Int = 200): List<ImportantItemEntity>

    @Query("SELECT * FROM important_items WHERE dayKey = :day ORDER BY extractedAt DESC")
    suspend fun forDay(day: String): List<ImportantItemEntity>

    @Query("DELETE FROM important_items WHERE sourceRefinedId = :refinedId")
    suspend fun deleteBySourceRefined(refinedId: Long)
}

@Dao
interface DailySummaryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(e: DailySummaryEntity): Long

    @Query("SELECT * FROM daily_summaries WHERE dayKey = :day LIMIT 1")
    suspend fun forDay(day: String): DailySummaryEntity?

    @Query("SELECT * FROM daily_summaries ORDER BY dayKey DESC LIMIT :limit")
    suspend fun recent(limit: Int = 30): List<DailySummaryEntity>
}

@Dao
interface PipelineLogDao {
    @Insert
    suspend fun insert(e: PipelineLogEntity)

    @Query("SELECT * FROM pipeline_log ORDER BY at DESC LIMIT :limit")
    suspend fun recent(limit: Int = 50): List<PipelineLogEntity>
}
