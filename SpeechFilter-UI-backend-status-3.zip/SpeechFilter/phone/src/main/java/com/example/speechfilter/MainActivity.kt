package com.example.speechfilter

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

/**
 * Thin shell that hosts three screens: Launch (start/stop recording),
 * Records (audio + transcript together, with linked delete), and Settings
 * (models, readiness check, worker log window).
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (savedInstanceState == null) {
            showScreen(LaunchFragment())
        }

        findViewById<BottomNavigationView>(R.id.bottomNav).setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_launch -> { showScreen(LaunchFragment()); true }
                R.id.nav_records -> { showScreen(RecordsFragment()); true }
                R.id.nav_settings -> { showScreen(SettingsFragment()); true }
                else -> false
            }
        }
    }

    private fun showScreen(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.screenContainer, fragment)
            .commit()
    }

    override fun onDestroy() {
        PlaybackController.release()
        super.onDestroy()
    }
}
