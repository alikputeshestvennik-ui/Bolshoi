package com.example.speechfilter.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        TranscriptEntity::class,
        RefinedTextEntity::class,
        ImportantItemEntity::class,
        DailySummaryEntity::class,
        PipelineLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transcripts(): TranscriptDao
    abstract fun refined(): RefinedTextDao
    abstract fun important(): ImportantItemDao
    abstract fun summaries(): DailySummaryDao
    abstract fun logs(): PipelineLogDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(ctx: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    ctx.applicationContext,
                    AppDatabase::class.java,
                    "filter_pipeline.db"
                ).fallbackToDestructiveMigration().build().also { instance = it }
            }
    }
}
