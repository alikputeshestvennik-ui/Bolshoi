package com.example.speechfilter

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.io.File

/**
 * Single shared ExoPlayer instance for recording playback. Kept outside any
 * Fragment/Activity so play/pause state survives navigating between the
 * Launch/Records/Settings screens instead of restarting on every switch.
 */
object PlaybackController {
    private var player: ExoPlayer? = null
    var playingFile: File? = null
        private set

    fun isPlaying(file: File): Boolean =
        playingFile?.absolutePath == file.absolutePath && player?.isPlaying == true

    fun toggle(context: Context, file: File, onChanged: () -> Unit) {
        val same = playingFile?.absolutePath == file.absolutePath
        if (same && player != null) {
            if (player!!.isPlaying) player!!.pause() else player!!.play()
            onChanged()
            return
        }
        release()
        playingFile = file
        player = ExoPlayer.Builder(context.applicationContext).build().also { exo ->
            exo.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
            exo.prepare()
            exo.play()
            exo.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    // Tell the recording service to ignore the mic while we're
                    // playing this back through the phone speaker, so it
                    // doesn't re-capture its own output.
                    RecordingService.selfPlaybackActive = isPlaying
                    onChanged()
                }

                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_ENDED) {
                        release()
                        onChanged()
                    }
                }
            })
        }
        onChanged()
    }

    /** Stops playback if the given file is the one currently loaded — call this
     *  before deleting a recording so a deleted file is never left playing. */
    fun stopIfPlaying(file: File) {
        if (playingFile?.absolutePath == file.absolutePath) release()
    }

    fun release() {
        player?.release()
        player = null
        playingFile = null
        RecordingService.selfPlaybackActive = false
    }
}
