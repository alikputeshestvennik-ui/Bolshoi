package com.example.speechfilter

import android.app.*
import android.content.Intent
import android.media.*
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.speechfilter.shared.*
import com.google.android.gms.wearable.*
import java.io.File
import java.util.concurrent.Executors
import kotlin.concurrent.thread

class RecordingService : Service() {
    private val io = Executors.newSingleThreadExecutor()
    private var source = "AUTO"
    @Volatile private var stopping = false
    private var localThread: Thread? = null
    private var audioRecord: AudioRecord? = null
    private var wav: WavWriter? = null
    private var wavFile: File? = null
    private var bytesWritten = 0L
    private var watchStarted = false
    private var channelClient: ChannelClient? = null
    private var channel: ChannelClient.Channel? = null

    private val channelCallback = object : ChannelClient.ChannelCallback() {
        override fun onChannelOpened(ch: ChannelClient.Channel) {
            if (ch.path != "/speech-audio") return
            channel = ch
            Wearable.getChannelClient(this@RecordingService).getInputStream(ch)
                .addOnSuccessListener { input ->
                    updateNotification("Galaxy Watch 8: поток речи")
                    thread(name = "watch-pcm-reader") {
                        ensureWav()
                        val parser = AudioPacket.Parser { _, pcm ->
                            ensureWav().appendPcm16(pcm)
                            bytesWritten += pcm.size * 2L
                        }
                        val buf = ByteArray(16 * 1024)
                        try {
                            while (!stopping) {
                                val n = input.read(buf)
                                if (n <= 0) break
                                parser.push(buf.copyOf(n))
                            }
                        } catch (_: Exception) {
                            if (!stopping) startPhone()
                        } finally {
                            try { input.close() } catch (_: Exception) {}
                        }
                    }
                }
                .addOnFailureListener { startPhone() }
        }

        override fun onChannelClosed(
            ch: ChannelClient.Channel,
            closeReason: Int,
            appSpecificErrorCode: Int
        ) {
            if (!stopping && ch.path == "/speech-audio") startPhone()
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(42, notification("Ожидание источника"))
        channelClient = Wearable.getChannelClient(this)
        channelClient?.registerChannelCallback(channelCallback)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopping = false
        bytesWritten = 0L
        source = intent?.getStringExtra("source") ?: "AUTO"
        stopPipelines()
        stopping = false
        // Create output file immediately so user always sees a recording entry
        ensureWav()
        if (source == "PHONE") startPhone()
        else startWatchOrFallback()
        return START_NOT_STICKY
    }

    private fun startWatchOrFallback() {
        updateNotification("Поиск Galaxy Watch…")
        Wearable.getNodeClient(this).connectedNodes
            .addOnSuccessListener { nodes ->
                val nearby = nodes.firstOrNull { it.isNearby }
                if (nearby == null) {
                    updateNotification("Часы не найдены → микрофон телефона")
                    startPhone()
                    return@addOnSuccessListener
                }
                watchStarted = true
                Wearable.getMessageClient(this)
                    .sendMessage(nearby.id, "/control/start", byteArrayOf())
                    .addOnSuccessListener {
                        updateNotification("Galaxy Watch 8: ожидание аудиоканала")
                    }
                    .addOnFailureListener {
                        updateNotification("Часы недоступны → микрофон телефона")
                        startPhone()
                    }
                // Fallback to phone if no channel within 8s
                io.execute {
                    try { Thread.sleep(8000) } catch (_: InterruptedException) { return@execute }
                    if (!stopping && localThread?.isAlive != true && channel == null) {
                        updateNotification("Таймаут часов → микрофон телефона")
                        startPhone()
                    }
                }
            }
            .addOnFailureListener {
                updateNotification("Wear API ошибка → микрофон телефона")
                startPhone()
            }
    }

    private fun startPhone() {
        if (localThread?.isAlive == true) return
        watchStarted = false
        updateNotification("Телефон: запись с микрофона")
        localThread = thread(name = "phone-audio") {
            try {
                val min = AudioRecord.getMinBufferSize(
                    AudioConfig.SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                if (min <= 0) {
                    updateNotification("Ошибка: AudioRecord недоступен ($min)")
                    return@thread
                }
                val record = AudioRecord(
                    MediaRecorder.AudioSource.MIC, AudioConfig.SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    (min * 2).coerceAtLeast(AudioConfig.FRAME_SAMPLES * 4 * 2)
                )
                if (record.state != AudioRecord.STATE_INITIALIZED) {
                    updateNotification("Ошибка: микрофон не инициализирован")
                    record.release()
                    return@thread
                }
                audioRecord = record

                val models = ModelFiles
                val sileroFile = models.silero(this)
                val yamnetFile = models.yamnet(this)
                val labelsFile = models.labels(this)
                updateNotification("Модели: VAD ${sileroFile.length() / 1024}KB, YAMNet ${yamnetFile.length() / 1024}KB")

                val vad = SileroVad(sileroFile)
                val yam = try {
                    YamnetClassifier(yamnetFile, labelsFile)
                } catch (t: Throwable) {
                    updateNotification("YAMNet недоступен, только VAD: ${t.message}")
                    null
                }
                // requireYamnet=false → VAD alone is enough to keep audio
                val e = SpeechEngine(
                    vad = vad,
                    yamnet = yam,
                    requireYamnet = false,
                    onSpeechPcm = { pcm ->
                        ensureWav().appendPcm16(pcm)
                        bytesWritten += pcm.size * 2L
                    }
                )
                record.startRecording()
                updateNotification("Слушаю микрофон… говорите")
                val buf = ShortArray(AudioConfig.FRAME_SAMPLES)
                var frames = 0
                while (!stopping) {
                    val n = record.read(buf, 0, buf.size)
                    if (n > 0) {
                        e.acceptPcm16(if (n == buf.size) buf else buf.copyOf(n))
                        frames++
                        if (frames % 50 == 0) {
                            updateNotification("Запись… ${(bytesWritten / 1024)} KB речи")
                        }
                    } else if (n < 0) {
                        updateNotification("Ошибка чтения микрофона: $n")
                        break
                    }
                }
                try { record.stop() } catch (_: Exception) {}
                try { record.release() } catch (_: Exception) {}
                vad.close()
                yam?.close()
                updateNotification("Стоп. Речи: ${bytesWritten / 1024} KB")
            } catch (t: Throwable) {
                updateNotification("Ошибка: ${t.javaClass.simpleName}: ${t.message}")
            }
        }
    }

    private fun ensureWav(): WavWriter {
        wav?.let { return it }
        val dir = File(getExternalFilesDir(null), "SpeechFilter").apply { mkdirs() }
        val file = File(dir, "speech_${System.currentTimeMillis()}.wav")
        wavFile = file
        return WavWriter(file).also { it.start(); wav = it }
    }

    private fun stopPipelines() {
        stopping = true
        localThread?.interrupt()
        localThread = null
        try { audioRecord?.stop() } catch (_: Exception) {}
        try { audioRecord?.release() } catch (_: Exception) {}
        audioRecord = null
        channel?.let { ch ->
            try { channelClient?.close(ch) } catch (_: Exception) {}
        }
        channel = null
        try { wav?.close() } catch (_: Exception) {}
        // Remove empty recordings (header only, no speech data)
        wavFile?.let { f ->
            if (bytesWritten == 0L && f.exists() && f.length() <= 44L) {
                f.delete()
            }
        }
        wav = null
        wavFile = null
    }

    override fun onDestroy() {
        stopPipelines()
        try { channelClient?.unregisterChannelCallback(channelCallback) } catch (_: Exception) {}
        io.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("speech", "Speech Filter", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun notification(text: String) =
        NotificationCompat.Builder(this, "speech")
            .setContentTitle("Speech Filter")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(42, notification(text))
    }
}
