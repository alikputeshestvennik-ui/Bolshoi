package com.example.speechfilter.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.data.PipelineLogEntity
import com.example.speechfilter.data.RefinedTextEntity
import com.example.speechfilter.data.TranscriptEntity
import com.example.speechfilter.pipeline.DayKeys
import com.example.speechfilter.pipeline.WhisperEngine
import java.io.File
import java.io.RandomAccessFile

/**
 * Transcribe new WAV files with on-device Whisper.
 *
 * Model stays resident in-process (see [WhisperEngine] singleton).
 * If there is nothing new, we skip warmUp entirely so idle runs are cheap.
 */
class TranscribeWorker(
    ctx: Context,
    params: WorkerParameters
) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val db = AppDatabase.get(applicationContext)
        val whisper = WhisperEngine(applicationContext)
        return try {
            val dir = File(applicationContext.getExternalFilesDir(null), "SpeechFilter")
            val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".wav", true) }
                ?.sortedBy { it.lastModified() }
                ?: emptyList()

            // WavWriter reserves a 44-byte all-zero header at start() and only
            // fills in the real "RIFF"/"WAVE"/... bytes in close(), at the end
            // of the recording — in the SAME target file the whole time (see
            // RecordingService.ensureWav()). So while a segment is still being
            // recorded, its .wav file already exists in this directory but its
            // header is still zeroed out. If this worker (10-min schedule, or
            // the immediate enqueueNow right after a segment closes racing an
            // *older* still-open file) picks that file up, whisper.cpp
            // correctly rejects the blank header — logged as "не смог
            // распознать WAV" — even though nothing is actually wrong with
            // the recording; it just isn't finalized yet. Skip those quietly
            // instead of counting them as a failure; the next scheduled run
            // will see the real header once RecordingService.closeCurrentWav()
            // has written it.
            val notFinalized = mutableListOf<File>()
            val pending = files.filter { db.transcripts().byPath(it.absolutePath) == null }
                .filter { f ->
                    if (isFinalizedWav(f)) true else { notFinalized += f; false }
                }
            if (notFinalized.isNotEmpty()) {
                db.logs().insert(
                    PipelineLogEntity(
                        worker = "transcribe",
                        message = "Пропущено (ещё пишется): ${notFinalized.joinToString { it.name }}"
                    )
                )
            }
            if (pending.isEmpty()) {
                db.logs().insert(
                    PipelineLogEntity(
                        worker = "transcribe",
                        message = "Нет новых файлов (всего ${files.size})"
                    )
                )
                return Result.success()
            }

            val warm = whisper.warmUp()
            val already = if (whisper.isLoaded()) " (в RAM)" else ""
            db.logs().insert(
                PipelineLogEntity(worker = "transcribe", message = "$warm$already")
            )
            if (!whisper.isLoaded()) {
                return Result.retry()
            }

            var ok = 0
            var fail = 0
            for (f in pending) {
                val source = when {
                    f.name.contains("_watch_") -> "watch"
                    f.name.contains("_phone_") -> "phone"
                    else -> "unknown"
                }
                val started = System.currentTimeMillis()
                val r = whisper.transcribeFile(f)
                val ms = System.currentTimeMillis() - started
                if (r.isSuccess) {
                    val text = r.getOrDefault("").trim()
                    val tid = db.transcripts().insert(
                        TranscriptEntity(
                            filePath = f.absolutePath,
                            fileName = f.name,
                            sourceTag = source,
                            text = text,
                            createdAt = f.lastModified(),
                            transcribedAt = System.currentTimeMillis(),
                            // Gemma refine disabled — ready for UI / important as-is
                            status = "refined"
                        )
                    )
                    if (tid > 0 && text.isNotEmpty()) {
                        db.refined().insert(
                            RefinedTextEntity(
                                transcriptId = tid,
                                text = text,
                                processedAt = System.currentTimeMillis(),
                                dayKey = DayKeys.of(f.lastModified())
                            )
                        )
                    }
                    ok++
                    db.logs().insert(
                        PipelineLogEntity(
                            worker = "transcribe",
                            message = "${f.name}: ${ms} мс, ${f.length() / 1024} КБ"
                        )
                    )
                } else {
                    fail++
                    db.logs().insert(
                        PipelineLogEntity(
                            worker = "transcribe",
                            message = "${f.name}: ${r.exceptionOrNull()?.message}"
                        )
                    )
                }
            }
            db.logs().insert(
                PipelineLogEntity(
                    worker = "transcribe",
                    message = "Готово: +$ok, ошибка=$fail, новых=${pending.size}"
                )
            )
            // Pass-through refine for any leftover pending
            if (ok > 0) {
                PipelineScheduler.enqueueSoon(
                    applicationContext,
                    PipelineScheduler.UNIQUE_REFINE,
                    RefineWorker::class.java,
                    delaySeconds = 30
                )
            }
            Result.success()
        } catch (t: Throwable) {
            db.logs().insert(
                PipelineLogEntity(worker = "transcribe", message = "crash: ${t.message}")
            )
            Result.retry()
        } finally {
            // Keep model in RAM — only drop on import / explicit unload
            whisper.release(dropShared = false)
            PipelineScheduler.reschedule(
                applicationContext,
                PipelineScheduler.UNIQUE_TRANSCRIBE,
                TranscribeWorker::class.java,
                10
            )
        }
    }

    /**
     * True once [f] has a real RIFF/WAVE header — i.e. WavWriter.close() has
     * run. False while it's still just the 44-byte zeroed placeholder
     * WavWriter.start() reserves at the very beginning of a recording (see
     * the comment above [pending] for why that matters here).
     */
    private fun isFinalizedWav(f: File): Boolean {
        if (f.length() < 44L) return false
        return try {
            RandomAccessFile(f, "r").use { raf ->
                val magic = ByteArray(4)
                raf.readFully(magic)
                String(magic, Charsets.US_ASCII) == "RIFF"
            }
        } catch (_: Throwable) {
            false
        }
    }
}
