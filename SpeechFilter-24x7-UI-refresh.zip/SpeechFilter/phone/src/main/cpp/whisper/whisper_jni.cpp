#include <jni.h>
#include <android/log.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <thread>

#include "whisper.h"

#define TAG "SpeechFilterWhisper"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// Single source of truth for the GPU/CPU choice.
//
// nativeBackendInfo() used to answer with a compile-time #if on
// GGML_USE_VULKAN, which reports whether the Vulkan BACKEND WAS BUILT, not
// whether it is USED. On this device the backend is built (the build finds
// libvulkan.so, glslc and SPIRV-Headers), so the UI kept claiming
// "Vulkan (GPU / Xclipse)" long after use_gpu was turned off and Whisper was
// actually running on CPU. One constant, read in both places, cannot drift
// apart like that again.
static constexpr bool USE_GPU_RUNTIME = false;   // Xclipse 950 shares the UI compositor


static bool read_u16(std::ifstream & f, uint16_t & out) {
    unsigned char b[2];
    if (!f.read(reinterpret_cast<char *>(b), 2)) return false;
    out = static_cast<uint16_t>(b[0] | (b[1] << 8));
    return true;
}

static bool read_u32(std::ifstream & f, uint32_t & out) {
    unsigned char b[4];
    if (!f.read(reinterpret_cast<char *>(b), 4)) return false;
    out = static_cast<uint32_t>(b[0] | (b[1] << 8) | (b[2] << 16) | (b[3] << 24));
    return true;
}

static bool read_wav_pcm16_mono_16k(const char * path, std::vector<float> & samples) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;

    char riff[4], wave[4];
    uint32_t riff_size = 0;
    if (!f.read(riff, 4) || !read_u32(f, riff_size) || !f.read(wave, 4)) return false;
    if (std::memcmp(riff, "RIFF", 4) != 0 || std::memcmp(wave, "WAVE", 4) != 0) return false;

    uint16_t audio_format = 0, channels = 0, bits = 0;
    uint32_t sample_rate = 0, data_size = 0;
    std::streampos data_pos = -1;
    bool got_fmt = false, got_data = false;

    while (f && (!got_fmt || !got_data)) {
        char id[4];
        uint32_t size = 0;
        if (!f.read(id, 4) || !read_u32(f, size)) break;
        const std::streampos payload = f.tellg();
        if (std::memcmp(id, "fmt ", 4) == 0) {
            uint32_t byte_rate = 0;
            uint16_t block_align = 0;
            if (!read_u16(f, audio_format) || !read_u16(f, channels) ||
                !read_u32(f, sample_rate) || !read_u32(f, byte_rate) ||
                !read_u16(f, block_align) || !read_u16(f, bits)) return false;
            got_fmt = true;
        } else if (std::memcmp(id, "data", 4) == 0) {
            data_pos = payload;
            data_size = size;
            got_data = true;
        }
        f.seekg(payload + static_cast<std::streamoff>(size + (size & 1u)));
    }

    if (!got_fmt || !got_data || audio_format != 1 || channels != 1 || bits != 16 || sample_rate != 16000) {
        LOGE("Unsupported WAV: fmt=%u channels=%u rate=%u bits=%u", audio_format, channels, sample_rate, bits);
        return false;
    }

    f.clear();
    f.seekg(data_pos);
    const size_t count = data_size / sizeof(int16_t);
    samples.resize(count);
    for (size_t i = 0; i < count; ++i) {
        int16_t s = 0;
        if (!f.read(reinterpret_cast<char *>(&s), sizeof(s))) return false;
        samples[i] = static_cast<float>(s) / 32768.0f;
    }
    return !samples.empty();
}

static std::string jstring_to_string(JNIEnv * env, jstring value) {
    if (!value) return {};
    const char * chars = env->GetStringUTFChars(value, nullptr);
    std::string out = chars ? chars : "";
    if (chars) env->ReleaseStringUTFChars(value, chars);
    return out;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_example_speechfilter_pipeline_WhisperEngine_nativeInit(
        JNIEnv * env, jobject /* thiz */, jstring model_path) {
    const std::string path = jstring_to_string(env, model_path);
    if (path.empty()) return 0;

    whisper_context_params params = whisper_context_default_params();
    // --- Galaxy Z Flip7 (Exynos 2500 + Xclipse 950) ---
    // The Xclipse 950 GPU is the SAME GPU that composites the system UI.
    // Loading a model with use_gpu=true triggers runtime SPIR-V shader
    // compilation + Vulkan context/staging-buffer setup on that GPU, which
    // measurably competes with the UI compositor — this is the actual cause
    // of the "UI freezes while the Whisper model loads" complaint, not a
    // CPU-thread scheduling issue. It also adds a second, harder-to-predict
    // memory budget (GPU staging buffers) on top of the CPU-side headroom
    // check in DeviceMemory, which is part of why a large model could take
    // the whole process down instead of failing cleanly.
    //
    // Transcription here is a background batch job (WorkManager), not a
    // realtime path the user is staring at — so we trade raw speed for a
    // smooth UI and lower heat by running Whisper on CPU only. Flip this
    // back to true only if a future settings toggle explicitly asks for
    // GPU speed over UI smoothness/thermals.
    params.use_gpu    = USE_GPU_RUNTIME;
    params.flash_attn = true;   // still helps on CPU, no GPU contention involved
    // params.gpu_device = 0;   // unused while use_gpu=false

    whisper_context * ctx = whisper_init_from_file_with_params(path.c_str(), params);
    if (!ctx) {
        LOGE("Failed to load Whisper model: %s", path.c_str());
        return 0;
    }
    __android_log_print(ANDROID_LOG_INFO, TAG,
            "Whisper init: use_gpu=%d (CPU-only: avoids UI/thermal contention) flash_attn=1",
            USE_GPU_RUNTIME ? 1 : 0);
    return reinterpret_cast<jlong>(ctx);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_speechfilter_pipeline_WhisperEngine_nativeTranscribe(
        JNIEnv * env, jobject /* thiz */, jlong context_ptr, jstring wav_path, jint requested_threads) {
    auto * ctx = reinterpret_cast<whisper_context *>(context_ptr);
    if (!ctx) return nullptr;

    const std::string path = jstring_to_string(env, wav_path);
    std::vector<float> pcmf32;
    if (!read_wav_pcm16_mono_16k(path.c_str(), pcmf32)) {
        return nullptr;
    }

    // Greedy, not beam search.
    //
    // beam_size = 5 was the right call while this ran a small/base model: it
    // was then the single biggest accuracy lever available without moving to
    // a bigger checkpoint. It is the wrong call now that the model is
    // large-v3-turbo — turbo is accurate enough that beam search buys only a
    // fraction of a percent on Russian, while costing several times the
    // decoder work per file. Running the decoder 5x for nothing is what made
    // the queue fall behind real time (measured: 174 KB of audio, ~5.5 s,
    // took 33.9 s to transcribe).
    whisper_full_params params = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    params.greedy.best_of = 1;
    // The Kotlin side selects the thread budget from the active power mode:
    // low-power/manual modes use fewer workers, while AC power can use all
    // available cores. Never exceed the actual hardware thread count.
    const unsigned hc = std::max(1u, std::thread::hardware_concurrency());
    const unsigned requested = requested_threads > 0 ? static_cast<unsigned>(requested_threads) : hc;
    params.n_threads = static_cast<int>(std::min(hc, requested));
    params.no_context = true;
    params.single_segment = false;
    params.print_realtime = false;
    params.print_progress = false;
    params.print_timestamps = false;
    params.print_special = false;
    params.translate = false;
    params.language = "ru";  // fixed Russian — skip auto-detect
    params.temperature = 0.0f;
    params.temperature_inc = 0.0f;  // no retry ladder — faster
    params.suppress_blank = true;
    params.suppress_nst = true;      // drop non-speech tokens ([music], (шум), etc.)
    params.entropy_thold = 2.4f;
    params.initial_prompt = "Это разговорная речь на русском языке.";

    if (whisper_full(ctx, params, pcmf32.data(), static_cast<int>(pcmf32.size())) != 0) {
        LOGE("whisper_full failed for %s", path.c_str());
        return nullptr;
    }

    std::string result;
    const int n = whisper_full_n_segments(ctx);
    for (int i = 0; i < n; ++i) {
        const char * text = whisper_full_get_segment_text(ctx, i);
        if (text) result += text;
    }

    return env->NewStringUTF(result.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_speechfilter_pipeline_WhisperEngine_nativeFree(
        JNIEnv * /* env */, jobject /* thiz */, jlong context_ptr) {
    auto * ctx = reinterpret_cast<whisper_context *>(context_ptr);
    if (ctx) whisper_free(ctx);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_speechfilter_pipeline_WhisperEngine_nativeBackendInfo(
        JNIEnv * env, jobject /* thiz */) {
    // Compile-time detection of Vulkan backend + runtime preference.
    // Shown in the app UI so the user doesn't need logcat.
#if defined(GGML_USE_VULKAN)
    // Report what is actually in effect, not what was compiled in.
    const char * info = USE_GPU_RUNTIME
            ? "Vulkan (GPU / Xclipse)"
            : "CPU (Vulkan собран, выключен)";
#else
    const char * info = "CPU";
#endif
    return env->NewStringUTF(info);
}
