package com.example.speechfilter

import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.data.ImportantItemEntity
import com.example.speechfilter.pipeline.DayKeys
import com.example.speechfilter.ui.BaseListFragment
import com.example.speechfilter.ui.TextCard
import com.example.speechfilter.ui.TextCardAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** "Важное": snippets the LLM pulled out of today's recordings. */
class ImportantFragment : BaseListFragment() {

    override val titleText = "Важное"
    override val emptyMessage = "Важного за сегодня пока нет"
    override val refreshMs = 4000L
    override val emptyIconRes = R.drawable.ic_nav_important

    private val adapter = TextCardAdapter()

    override fun setupList(rv: RecyclerView) {
        rv.adapter = adapter
        subtitle.text = "За сегодня"
    }

    override fun refresh() {
        val ctx = context ?: return
        lifecycleScope.launch {
            val items: List<ImportantItemEntity> = withContext(Dispatchers.IO) {
                AppDatabase.get(ctx).important().forDay(DayKeys.today())
            }
            if (!isAdded) return@launch
            val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
            adapter.submitList(items.map {
                TextCard(
                    id = "imp:${it.id}",
                    header = fmt.format(Date(it.extractedAt)),
                    body = it.text,
                    iconRes = R.drawable.ic_nav_important,
                    iconColorRes = R.color.accent_amber
                )
            })
            onContentShown(empty = items.isEmpty())
        }
    }
}
