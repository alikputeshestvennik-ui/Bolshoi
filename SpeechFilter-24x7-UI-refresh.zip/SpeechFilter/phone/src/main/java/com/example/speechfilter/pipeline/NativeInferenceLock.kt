package com.example.speechfilter.pipeline

/**
 * Process-wide lock shared by [WhisperEngine] and [GemmaEngine].
 *
 * Both wrap heavy native code — whisper.cpp (Vulkan/GPU on the Xclipse
 * GPU) and MediaPipe's on-device GenAI engine (Gemma). WorkManager runs
 * TranscribeWorker (Whisper) and ImportantWorker / DailySummaryWorker
 * (Gemma) as *independent* unique work chains on its default thread
 * pool, so nothing stopped them from executing at the same moment on
 * the same device — and nothing stopped the "ПРОВЕРКА ГОТОВНОСТИ" flow
 * ([ReadinessCheck]) from warming both engines back-to-back while a
 * scheduled worker is also mid-run.
 *
 * Running Whisper's Vulkan encode/decode and Gemma's native inference
 * at the same time roughly doubles peak GPU/CPU/RAM load on the device,
 * which is the most likely cause of the heating, lag and eventual
 * black-screen (GPU driver reset) users see. Each engine used to guard
 * its *own* native calls with a private per-class lock, which prevented
 * concurrent calls into the *same* engine but did nothing to stop the
 * two different engines from running concurrently.
 *
 * Routing every native call (init/free/transcribe/generate) in BOTH
 * engines through this single shared lock guarantees only one heavy
 * native workload runs on the device at a time.
 */
object NativeInferenceLock {
    val lock = Any()
}
