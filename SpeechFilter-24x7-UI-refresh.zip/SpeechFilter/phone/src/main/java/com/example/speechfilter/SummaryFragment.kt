package com.example.speechfilter

import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.data.DailySummaryEntity
import com.example.speechfilter.pipeline.DayKeys
import com.example.speechfilter.ui.BaseListFragment
import com.example.speechfilter.ui.TextCard
import com.example.speechfilter.ui.TextCardAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** "Сводка дня": today's summary on top, earlier days below. */
class SummaryFragment : BaseListFragment() {

    override val titleText = "Сводка дня"
    override val emptyMessage = "Сводок пока нет"
    override val refreshMs = 5000L
    override val emptyIconRes = R.drawable.ic_nav_summary

    private val adapter = TextCardAdapter()

    override fun setupList(rv: RecyclerView) {
        rv.adapter = adapter
        subtitle.text = SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(Date())
            .replaceFirstChar { it.uppercase() }
    }

    override fun refresh() {
        val ctx = context ?: return
        lifecycleScope.launch {
            val today = DayKeys.today()
            val all: List<DailySummaryEntity> = withContext(Dispatchers.IO) {
                AppDatabase.get(ctx).summaries().recent(8)
            }
            if (!isAdded) return@launch
            val todayRow = all.firstOrNull { it.dayKey == today }
            val cards = mutableListOf<TextCard>()
            cards += TextCard(
                id = "day:$today",
                header = "Сегодня",
                body = todayRow?.summary?.takeIf { it.isNotBlank() } ?: "Сводки за сегодня пока нет",
                iconRes = R.drawable.ic_nav_summary,
                iconColorRes = R.color.ink,
                muted = todayRow?.summary.isNullOrBlank()
            )
            all.filter { it.dayKey != today && it.summary.isNotBlank() }.forEach {
                cards += TextCard(
                    id = "day:${it.dayKey}",
                    header = prettyDay(it.dayKey),
                    body = it.summary,
                    iconRes = R.drawable.ic_nav_summary,
                    iconColorRes = R.color.ink_muted
                )
            }
            adapter.submitList(cards)
            onContentShown(empty = false)
        }
    }

    private fun prettyDay(key: String): String = try {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(key)!!
        SimpleDateFormat("d MMMM, EEEE", Locale("ru")).format(d)
    } catch (_: Exception) { key }
}
