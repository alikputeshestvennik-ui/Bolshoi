package com.example.speechfilter.workers

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.ListenableWorker
import androidx.work.OneTimeWorkRequest
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Custom intervals via self-rescheduling OneTimeWork
 * (PeriodicWorkManager minimum is 15 minutes).
 *
 *  - Transcribe: NOT scheduled through WorkManager any more at all in the
 *    normal case. RecordingService calls Transcriber.runPending() directly
 *    on its own `io` executor the instant a WAV segment closes — see the
 *    comment on RecordingService.closeCurrentWav() for why: WorkManager's
 *    GreedyScheduler runs unconstrained OneTimeWork "when the system gets to
 *    it", not "now", even from a live foreground process, which is what made
 *    this look like it only ever ran after STOP. [enqueueStartupSweep] is
 *    the only place UNIQUE_TRANSCRIBE still goes through WorkManager — it is
 *    the safety net for a WAV whose direct trigger never ran because the
 *    process died first.
 *  - Important extract: every 27 min
 *  - Daily summary: once around 22:00 local
 *
 * There is no refine step: Whisper's text is used as-is, and the "refined"
 * row is written by Transcriber itself so the Records UI keeps working.
 */
object PipelineScheduler {

    const val UNIQUE_TRANSCRIBE = "pipeline_transcribe"
    const val UNIQUE_IMPORTANT = "pipeline_important"
    const val UNIQUE_DAILY = "pipeline_daily"

    fun ensureScheduled(context: Context) {
        val wm = WorkManager.getInstance(context.applicationContext)
        scheduleIn(wm, UNIQUE_IMPORTANT, ImportantWorker::class.java, 3)
        scheduleDaily(wm)
    }

    /**
     * One catch-up transcription pass shortly after app start.
     *
     * The normal path (RecordingService → Transcriber.runPending directly)
     * only runs while the service process is alive. If it died — crash, or
     * killed by the system — before transcribing a closed segment, nothing
     * else would ever pick that file up. This is that backstop. KEEP rather
     * than REPLACE: repeated app starts must not pile up passes, and a sweep
     * that is already queued is exactly what we wanted anyway.
     *
     * Cheap when there is nothing to do — Transcriber returns on
     * pending.isEmpty() before it ever loads the model.
     */
    fun enqueueStartupSweep(context: Context) {
        val wm = WorkManager.getInstance(context.applicationContext)
        val req = OneTimeWorkRequest.Builder(TranscribeWorker::class.java)
            .setInitialDelay(30, TimeUnit.SECONDS)
            .addTag(UNIQUE_TRANSCRIBE)
            .build()
        wm.enqueueUniqueWork(UNIQUE_TRANSCRIBE, ExistingWorkPolicy.KEEP, req)
    }

    fun scheduleIn(
        wm: WorkManager,
        unique: String,
        worker: Class<out ListenableWorker>,
        delayMinutes: Long
    ) {
        val req = OneTimeWorkRequest.Builder(worker)
            .setInitialDelay(delayMinutes, TimeUnit.MINUTES)
            .addTag(unique)
            .build()
        wm.enqueueUniqueWork(unique, ExistingWorkPolicy.KEEP, req)
    }

    fun reschedule(
        context: Context,
        unique: String,
        worker: Class<out ListenableWorker>,
        delayMinutes: Long
    ) {
        val wm = WorkManager.getInstance(context.applicationContext)
        val req = OneTimeWorkRequest.Builder(worker)
            .setInitialDelay(delayMinutes, TimeUnit.MINUTES)
            .addTag(unique)
            .build()
        wm.enqueueUniqueWork(unique, ExistingWorkPolicy.REPLACE, req)
    }

    // NOTE: there used to be an enqueueFileReady() here (APPEND_OR_REPLACE)
    // that RecordingService called on every closed WAV. It fixed the bug
    // where a request got silently cancelled, but not the actual complaint:
    // WorkManager still only ran it "eventually", not immediately, even from
    // a live foreground service. RecordingService now calls
    // Transcriber.runPending() directly instead — see its closeCurrentWav().

    fun enqueueSoon(
        context: Context,
        unique: String,
        worker: Class<out ListenableWorker>,
        delaySeconds: Long
    ) {
        val wm = WorkManager.getInstance(context.applicationContext)
        val req = OneTimeWorkRequest.Builder(worker)
            .setInitialDelay(delaySeconds, TimeUnit.SECONDS)
            .addTag(unique)
            .build()
        wm.enqueueUniqueWork(unique, ExistingWorkPolicy.REPLACE, req)
    }

    private fun scheduleDaily(wm: WorkManager) {
        val now = Calendar.getInstance()
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 22)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            if (before(now)) add(Calendar.DAY_OF_YEAR, 1)
        }
        val delay = next.timeInMillis - now.timeInMillis
        val req = OneTimeWorkRequestBuilder<DailySummaryWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .addTag(UNIQUE_DAILY)
            .build()
        wm.enqueueUniqueWork(UNIQUE_DAILY, ExistingWorkPolicy.KEEP, req)
    }
}
