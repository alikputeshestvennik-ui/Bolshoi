package com.example.speechfilter.pipeline

/**
 * Post-filters for on-device Gemma. Small multilingual checkpoints often:
 * - wrap the answer in "Вот ваш текст: …"
 * - rewrite meaning instead of light cleanup
 * - inject CJK / switch language
 * - echo category labels for "important"
 */
object GemmaOutput {

    private val META_LINE = Regex(
        """(?im)^\s*(вот\s+ваш\s+текст|вот\s+исправленн\w*\s+текст|исправленн\w*\s+текст|отредактированн\w*\s+текст|результат|ответ|here is (the )?text|corrected text)\s*[:：]?\s*$"""
    )

    private val META_INLINE = Regex(
        """(?im)^\s*(вот\s+ваш\s+текст|исправленн\w*\s+текст|отредактированн\w*\s+текст)\s*[:：]\s*"""
    )

    private val BARE_CATEGORIES = setOf(
        "поддержку", "поддержка",
        "вопросы", "вопрос",
        "решения", "решение",
        "даты", "дата",
        "имена", "имя",
        "задачи", "задача",
        "договорённости", "договоренности", "договорённость", "договоренность",
        "подключение", "темы", "сводка", "сводки нет", "нет",
    )

    private val CJK = Regex("[\\u3040-\\u30ff\\u3400-\\u4dbf\\u4e00-\\u9fff\\uf900-\\ufaff]")
    private val CYRILLIC = Regex("[А-Яа-яЁё]")
    private val WORD = Regex("""[A-Za-zА-Яа-яЁё0-9\-]+""")

    fun stripPrefix(raw: String): String {
        var s = raw.trim()
        // Drop whole meta header lines
        s = s.lineSequence()
            .dropWhile { line -> META_LINE.matches(line.trim()) || line.trim().isEmpty() }
            .joinToString("\n")
            .trim()
        // Drop inline "Вот ваш текст:" at the start
        s = META_INLINE.replace(s, "")
        // Unwrap one layer of quotes
        s = s.trim()
        if ((s.startsWith('"') && s.endsWith('"')) ||
            (s.startsWith('«') && s.endsWith('»')) ||
            (s.startsWith('“') && s.endsWith('”'))
        ) {
            s = s.substring(1, s.length - 1).trim()
        }
        return s.trim()
    }

    fun cjkRatio(s: String): Double {
        if (s.isEmpty()) return 0.0
        return CJK.findAll(s).count().toDouble() / s.length
    }

    fun cyrillicRatio(s: String): Double {
        val letters = s.count { it.isLetter() }
        if (letters == 0) return 0.0
        return CYRILLIC.findAll(s).count().toDouble() / letters
    }

    /** Share of original content-words that still appear in the candidate. */
    fun wordOverlap(original: String, candidate: String): Double {
        val stop = setOf(
            "и", "в", "на", "с", "по", "к", "о", "а", "но", "что", "это", "как",
            "я", "мы", "вы", "он", "она", "они", "не", "да", "ну", "вот", "то",
            "для", "из", "от", "за", "же", "бы", "ли", "уже", "ещё", "еще"
        )
        fun words(t: String) = WORD.findAll(t.lowercase())
            .map { it.value }
            .filter { it.length >= 3 && it !in stop }
            .toSet()
        val a = words(original)
        if (a.isEmpty()) return 1.0
        val b = words(candidate)
        return a.count { it in b }.toDouble() / a.size
    }

    /**
     * Prefer Whisper when Gemma wraps, rewrites, or pollutes the text.
     */
    fun acceptRefine(original: String, generated: String): String {
        val src = original.trim()
        var out = stripPrefix(generated)
        if (out.isBlank()) return src

        // Still looks like a chat reply, not an edit
        val lower = out.lowercase()
        if (lower.startsWith("вот ваш") ||
            lower.startsWith("конечно") ||
            lower.startsWith("хорошо") ||
            lower.startsWith("я исправил") ||
            lower.startsWith("исправленный")
        ) {
            out = stripPrefix(out)
        }
        if (out.isBlank()) return src

        if (cjkRatio(out) > 0.01) return src
        if (cyrillicRatio(src) > 0.5 && cyrillicRatio(out) < 0.4) return src

        // Length guards
        if (src.length > 40 && out.length < src.length * 0.4) return src
        if (out.length > src.length * 2.5 + 60) return src

        // Meaning guard: if too few original words survive, it's a rewrite
        if (src.length > 30 && wordOverlap(src, out) < 0.45) return src

        return out
    }

    fun importantLines(generated: String): List<String> {
        val cleaned = stripPrefix(generated)
        if (cleaned.equals("НЕТ", ignoreCase = true)) return emptyList()
        if (cleaned.equals("нет", ignoreCase = true)) return emptyList()

        return cleaned.lines()
            .map { it.trim().trimStart('-', '•', '*', '–', '—', ' ', '\t') }
            .map { it.trimEnd('.', ' ') }
            .filter { it.isNotEmpty() }
            .filter { line ->
                val key = line.lowercase().trimEnd('.', ' ')
                key !in BARE_CATEGORIES && key.length >= 8
            }
            .distinctBy { it.lowercase() }
    }
}
