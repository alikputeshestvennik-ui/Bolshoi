package com.example.speechfilter.pipeline

/**
 * Prompts for the on-device LLM (Gemma today, any MediaPipe-compatible
 * checkpoint in principle). Keep short: small models ignore long rules.
 *
 * There is no refine prompt: that pass is gone, Whisper's text is final.
 * The two prompts below are the ones actually used, by ImportantWorker and
 * DailySummaryWorker.
 */
object PromptStore {
    @Volatile
    var importantPrompt: String = """
Выпиши только конкретные факты из текста (кто/что/когда).
Не пиши названия категорий (Задачи, Даты, Имена…).
Если фактов нет — ответь: НЕТ

{{text}}
    """.trimIndent()

    @Volatile
    var dailySummaryPrompt: String = """
Краткий пересказ на русском. Только факты из текста. Без выдумок.
Если почти пусто — «Сводки нет».

{{text}}
    """.trimIndent()

    fun fill(template: String, text: String): String =
        template.replace("{{text}}", text)
}
