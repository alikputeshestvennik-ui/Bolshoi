package com.example.speechfilter.pipeline

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.StatFs
import java.io.File
import androidx.core.content.ContextCompat
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.shared.ModelFiles
import com.example.speechfilter.workers.PipelineScheduler

/**
 * One-shot end-to-end self-test: "would recording → transcription → LLM
 * pipeline actually work right now if I hit START?"
 *
 * Not a unit test — it pokes the real objects the app uses (permissions,
 * VAD/YamNet assets, whisper.cpp native init, Room, WorkManager schedule,
 * Gemma model presence) and reports a plain-language verdict for each,
 * so a non-developer can see *why* something won't work instead of just
 * "it's broken".
 */
object ReadinessCheck {

    enum class Level { OK, WARN, FAIL }

    data class Item(val level: Level, val label: String)

    private const val MIN_FREE_BYTES = 200L * 1024 * 1024 // 200 MB safety margin for WAV + models

    /** Runs blocking/native calls — always call from a background dispatcher. */
    suspend fun run(context: Context): List<Item> {
        val items = mutableListOf<Item>()

        // --- Permissions -----------------------------------------------------
        val micOk = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        items += Item(
            if (micOk) Level.OK else Level.FAIL,
            if (micOk) "Микрофон: разрешение есть" else "Микрофон: нет разрешения RECORD_AUDIO — запись не запустится"
        )

        if (Build.VERSION.SDK_INT >= 33) {
            val notifOk = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
            items += Item(
                if (notifOk) Level.OK else Level.WARN,
                if (notifOk) "Уведомления: разрешены" else "Уведомления: не разрешены (foreground-сервис может быть убит системой)"
            )
        }

        // --- Free space --------------------------------------------------------
        val free = runCatching { StatFs(context.filesDir.path).availableBytes }.getOrDefault(0L)
        val freeMb = free / (1024 * 1024)
        items += Item(
            if (free >= MIN_FREE_BYTES) Level.OK else Level.WARN,
            "Свободно места: ${freeMb} MB" + if (free < MIN_FREE_BYTES) " (мало, лучше > 200 MB)" else ""
        )

        // --- VAD / YamNet assets ------------------------------------------------
        val vadOk = runCatching {
            val f = ModelFiles.silero(context); f.exists() && f.length() > 0L
        }.getOrDefault(false)
        items += Item(
            if (vadOk) Level.OK else Level.FAIL,
            if (vadOk) "Silero VAD: распакован" else "Silero VAD: не удалось распаковать ассет — определение речи не будет работать"
        )

        val yamOk = runCatching {
            val t = ModelFiles.yamnet(context)
            val l = ModelFiles.labels(context)
            t.exists() && t.length() > 0L && l.exists() && l.length() > 0L
        }.getOrDefault(false)
        items += Item(
            if (yamOk) Level.OK else Level.WARN,
            if (yamOk) "YamNet: распакован" else "YamNet: недоступен (не критично — классификация звука просто выключена)"
        )

        // --- Whisper (actually try to load the native model) --------------------
        val whisper = WhisperEngine(context)
        if (whisper.modelReady()) {
            val warm = runCatching { whisper.warmUp() }.getOrElse { "ошибка инициализации: ${it.message}" }
            val loaded = warm.contains("загружен")
            items += Item(if (loaded) Level.OK else Level.FAIL, "Whisper: $warm")
            whisper.release()
        } else {
            items += Item(Level.FAIL, "Whisper: модель не импортирована — транскрипция работать не будет")
        }

        // --- Local LLM (actually try to load the model, like Whisper above) -----
        val gemma = GemmaEngine(context)
        if (gemma.modelReady()) {
            val warm = runCatching { gemma.warmUp() }.getOrElse { "ошибка инициализации: ${it.message}" }
            val loaded = warm.contains("загружена")
            items += Item(if (loaded) Level.OK else Level.FAIL, "LLM: $warm")
        } else {
            items += Item(Level.WARN, "LLM: модель не импортирована (важное/сводка дня не будут работать)")
        }

        // --- Room database --------------------------------------------------------
        val dbOk = runCatching { AppDatabase.get(context).logs().recent(1); true }.getOrDefault(false)
        items += Item(if (dbOk) Level.OK else Level.FAIL, if (dbOk) "База данных: доступна" else "База данных: ошибка доступа")

        // --- Transcription: event-driven, so there is nothing "scheduled"
        // to assert here. Report the real thing instead: how many recorded
        // WAVs are still waiting for a transcript. ---
        val pendingWavs = runCatching {
            val dir = File(context.getExternalFilesDir(null), "SpeechFilter")
            val db = AppDatabase.get(context)
            dir.listFiles { f -> f.isFile && f.name.endsWith(".wav", true) }?.count { f ->
                db.transcripts().byPath(f.absolutePath) == null
            } ?: 0
        }.getOrDefault(0)
        items += Item(
            if (pendingWavs == 0) Level.OK else Level.WARN,
            if (pendingWavs == 0) "Транскрипция: очередь пуста"
            else "Транскрипция: в очереди $pendingWavs (запустится по закрытию файла/старту)"
        )

        // --- Scheduled background pipeline ------------------------------------
        val wm = WorkManager.getInstance(context)
        val workers = listOf(
            PipelineScheduler.UNIQUE_IMPORTANT to "Извлечение важного (LLM)",
            PipelineScheduler.UNIQUE_DAILY to "Сводка дня (LLM)"
        )
        for ((unique, label) in workers) {
            val scheduled = runCatching {
                wm.getWorkInfosForUniqueWork(unique).get().any {
                    it.state == WorkInfo.State.ENQUEUED || it.state == WorkInfo.State.RUNNING
                }
            }.getOrDefault(false)
            items += Item(
                if (scheduled) Level.OK else Level.WARN,
                "Планировщик «$label»: ${if (scheduled) "запланирован" else "не запланирован"}"
            )
        }

        return items
    }

    /** Plain-text verdict (no symbols); the UI renders its own icons per [Level]. */
    fun overallLabel(items: List<Item>): String = when {
        items.any { it.level == Level.FAIL } -> "Есть проблемы"
        items.any { it.level == Level.WARN } -> "Работает с ограничениями"
        else -> "Всё в порядке"
    }
}
