package com.example.speechfilter.data

import android.content.Context
import com.example.speechfilter.RecordingService
import com.example.speechfilter.pipeline.Transcriber
import java.io.File

/** One recording as shown in the UI: the WAV file plus whatever the pipeline
 *  has produced from it so far. Audio and text are always looked up together
 *  through this class, so the two never drift apart in the UI. */
enum class RecordingStatus { RECORDING, RECOGNIZING, QUEUED, PROCESSING, DONE, FAILED }

data class RecordingRow(
    val file: File,
    val transcript: TranscriptEntity?,
    val refinedText: String?
) {
    val fromWatch: Boolean get() = file.name.contains("_watch_")

    /** Start time is encoded in the file name (epoch millis); fall back to mtime. */
    val startedAt: Long
        get() = Regex("(\\d{13})").findAll(file.name).lastOrNull()?.value?.toLongOrNull()
            ?: file.lastModified()

    val displayText: String?
        get() = refinedText?.takeIf { it.isNotBlank() }
            ?: transcript?.text?.takeIf { it.isNotBlank() }

    val status: RecordingStatus
        get() = when {
            transcript == null && file.name == RecordingService.recordingFileName -> RecordingStatus.RECORDING
            transcript == null && file.name == Transcriber.processingFileName -> RecordingStatus.RECOGNIZING
            transcript == null -> RecordingStatus.QUEUED
            transcript.status == "refined" -> RecordingStatus.DONE
            transcript.status == "failed" -> RecordingStatus.FAILED
            else -> RecordingStatus.PROCESSING
        }

    val statusLabel: String
        get() = when (status) {
            RecordingStatus.RECORDING -> "Идёт запись"
            RecordingStatus.RECOGNIZING -> "Распознаётся"
            RecordingStatus.QUEUED -> "В очереди на распознавание"
            RecordingStatus.PROCESSING -> "В обработке"
            RecordingStatus.DONE -> "Обработано"
            RecordingStatus.FAILED -> "Ошибка распознавания"
        }
}

/** Loads the merged recording+text rows and performs the linked delete:
 *  removing a recording always removes its WAV file, its Whisper transcript,
 *  its text row, and any "important" snippets pulled from that text, in one
 *  call — never just one piece of it. */
object RecordingsRepository {

    fun recordingsDir(context: Context): File =
        File(context.getExternalFilesDir(null), "SpeechFilter")

    suspend fun loadRows(context: Context): List<RecordingRow> {
        val db = AppDatabase.get(context)
        val files = recordingsDir(context)
            .listFiles { f -> f.isFile && f.extension.equals("wav", true) }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
        return files.map { f ->
            val transcript = db.transcripts().byPath(f.absolutePath)
            val refined = transcript?.let { db.refined().forTranscript(it.id)?.text }
            RecordingRow(f, transcript, refined)
        }
    }

    suspend fun deleteRecording(context: Context, row: RecordingRow) {
        val db = AppDatabase.get(context)
        val transcript = row.transcript
        if (transcript != null) {
            db.refined().allForTranscript(transcript.id).forEach { refined ->
                db.important().deleteBySourceRefined(refined.id)
            }
            db.refined().deleteForTranscript(transcript.id)
            db.transcripts().deleteById(transcript.id)
        }
        if (row.file.exists()) row.file.delete()
    }
}
