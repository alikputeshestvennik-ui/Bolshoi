plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.routeplanner"
    compileSdk = 36

    defaultConfig {
        applicationId = "ru.routeplanner"
        minSdk = 24
        targetSdk = 36
        versionCode = 11
        versionName = "1.2.0"
    }

    signingConfigs {
        create("release") {
            val keystorePath = System.getenv("ANDROID_KEYSTORE_PATH")
            val storePasswordEnv = System.getenv("ANDROID_STORE_PASSWORD")
            val keyPasswordEnv = System.getenv("ANDROID_KEY_PASSWORD")
            val keyAliasEnv = System.getenv("ANDROID_KEY_ALIAS")

            if (!keystorePath.isNullOrBlank() &&
                !storePasswordEnv.isNullOrBlank() &&
                !keyPasswordEnv.isNullOrBlank() &&
                !keyAliasEnv.isNullOrBlank()
            ) {
                storeFile = file(keystorePath)
                storePassword = storePasswordEnv
                keyPassword = keyPasswordEnv
                keyAlias = keyAliasEnv
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }

    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a")
            isUniversalApk = true
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("com.google.android.material:material:1.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    // чтение старых .xls (для .xlsx используется собственный разбор)
    implementation("net.sourceforge.jexcelapi:jxl:2.6.12")
}
