plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

/** Секреты из GitHub Actions (env) вшиваются в BuildConfig. Локально без них — пустые строки. */
fun secret(n: String): String = "\"" + (System.getenv(n) ?: "").trim().replace("\\", "\\\\").replace("\"", "\\\"") + "\""

android {
    namespace = "ru.marshrut"
    compileSdk = 34
    defaultConfig {
        applicationId = "ru.marshrut"
        minSdk = 26
        targetSdk = 34
        // Номер растёт с каждой сборкой в GitHub Actions — обновление ставится поверх, без удаления
        versionCode = 12 + (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0)
        versionName = "5.6.1"
        buildConfigField("String", "YANDEX_API_KEY", secret("YANDEX_API_KEY"))
        buildConfigField("String", "DEEPSEEK_MODEL", secret("DEEPSEEK_MODEL"))
        buildConfigField("String", "QWEN_MODEL", secret("QWEN_MODEL"))
        buildConfigField("String", "ORS_API_KEY", secret("ORS_API_KEY"))
        buildConfigField("String", "YANDEX_OAUTH_CLIENT_ID", secret("YANDEX_OAUTH_CLIENT_ID"))
        buildConfigField("String", "YANDEX_OAUTH_CLIENT_SECRET", secret("YANDEX_OAUTH_CLIENT_SECRET"))
        // Общая база: ссылка на чтение и ключ записи, зашифрованный паролем редактора
        buildConfigField("String", "SHARED_DB", secret("SHARED_DB"))
        // Только ARM: библиотеки ML Kit под x86/x86_64 нужны лишь эмуляторам и раздувают APK на ~23 МБ
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    val ksPath: String? = System.getenv("ANDROID_KEYSTORE_PATH")
    signingConfigs {
        if (ksPath != null) {
            create("release") {
                storeFile = file(ksPath)
                storePassword = System.getenv("ANDROID_STORE_PASSWORD")
                keyAlias = System.getenv("ANDROID_KEY_ALIAS")
                keyPassword = System.getenv("ANDROID_KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        release {
            if (ksPath != null) signingConfig = signingConfigs.getByName("release")
        }
    }
    buildFeatures { compose = true; buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.window:window:1.3.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    // Карта в редакторе базы: OpenStreetMap, без ключей и SDK
    implementation("org.osmdroid:osmdroid-android:6.1.18")
    // Сканер документов Google: камера, поиск краёв листа, выравнивание перспективы
    implementation("com.google.android.gms:play-services-mlkit-document-scanner:16.0.0-beta1")
    // Распознавание текста на телефоне — только чтобы понять, как повёрнута страница
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
