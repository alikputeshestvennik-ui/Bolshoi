package ru.routeplanner

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

/** Торговая точка. Идентификатор не нужен: точка определяется названием и адресом. */
class Point(
    val name: String,
    val address: String,
    val lat: Double?,
    val lon: Double?,
    val callsigns: List<String>
)

class PointDb(val points: List<Point>) {
    private val index: Map<String, Point>

    init {
        val m = HashMap<String, Point>()
        for (p in points) {
            for (c in p.callsigns) {
                val k = Callsign.normalize(c)
                if (k.isNotEmpty() && !m.containsKey(k)) m[k] = p
            }
        }
        index = m
    }

    val callsignCount: Int get() = index.size

    fun find(callsign: String?): Point? {
        if (callsign.isNullOrBlank()) return null
        return index[Callsign.normalize(callsign)]
    }
}

object Callsign {
    // цифры (с возможными буквами-двойниками) + суффикс из 2–3 букв
    private val SHAPE = Regex("^([0-9\u0437\u043e\u0431ol]+)([a-z\u0430-\u044f]{2,3})$")
    private val DIGIT_LIKE = mapOf(
        '\u0437' to '3', // з
        '\u043e' to '0', // о
        'o' to '0',
        '\u0431' to '6', // б
        'l' to '1'
    )
    private val LATIN_TO_CYR = mapOf(
        'a' to '\u0430', 'b' to '\u0432', 'c' to '\u0441', 'e' to '\u0435',
        'h' to '\u043d', 'k' to '\u043a', 'm' to '\u043c', 'o' to '\u043e',
        'p' to '\u0440', 't' to '\u0442', 'x' to '\u0445', 'y' to '\u0443'
    )

    /** Приводит позывной к виду для сравнения: «175 ЮС» → «175юс», «l75юс» → «175юс». */
    fun normalize(raw: String?): String {
        if (raw == null) return ""
        val s = raw.lowercase(Locale.ROOT).replace('\u0451', '\u0435').filter { it.isLetterOrDigit() }
        val m = SHAPE.matchEntire(s) ?: return s
        val digits = m.groupValues[1].map { DIGIT_LIKE[it] ?: it }.joinToString("")
        val suffix = m.groupValues[2].map { LATIN_TO_CYR[it] ?: it }.joinToString("")
        return digits + suffix
    }
}

object PointDbStore {
    private const val FILE = "points_db.json"

    fun load(context: Context): PointDb {
        val f = File(context.filesDir, FILE)
        if (f.exists()) {
            try {
                return fromJson(JSONObject(f.readText(Charsets.UTF_8)))
            } catch (_: Throwable) {
                // повреждённый файл — используем встроенную базу
            }
        }
        return loadBundled(context)
    }

    fun save(context: Context, db: PointDb) {
        File(context.filesDir, FILE).writeText(toJson(db).toString(), Charsets.UTF_8)
    }

    private fun loadBundled(context: Context): PointDb {
        val text = context.assets.open("points_db.csv").bufferedReader(Charsets.UTF_8).use { it.readText() }
        return DbImporter.parse(TableReader.parseCsv(text))?.db ?: PointDb(emptyList())
    }

    private fun toJson(db: PointDb): JSONObject {
        val arr = JSONArray()
        for (p in db.points) {
            val o = JSONObject()
                .put("name", p.name)
                .put("address", p.address)
                .put("callsigns", JSONArray(p.callsigns))
            if (p.lat != null) o.put("lat", p.lat)
            if (p.lon != null) o.put("lon", p.lon)
            arr.put(o)
        }
        return JSONObject().put("points", arr)
    }

    private fun fromJson(o: JSONObject): PointDb {
        val arr = o.getJSONArray("points")
        val list = ArrayList<Point>()
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            val cs = ArrayList<String>()
            val ca = p.optJSONArray("callsigns")
            if (ca != null) for (j in 0 until ca.length()) cs.add(ca.getString(j))
            list.add(
                Point(
                    name = p.optString("name"),
                    address = p.optString("address"),
                    lat = if (p.has("lat")) p.optDouble("lat") else null,
                    lon = if (p.has("lon")) p.optDouble("lon") else null,
                    callsigns = cs
                )
            )
        }
        return PointDb(list)
    }
}
