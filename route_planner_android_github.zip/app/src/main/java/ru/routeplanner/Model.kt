package ru.routeplanner

import org.json.JSONObject
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

class Agent(val code: String, val name: String?, val phone: String?)

class SheetRow(
    val rowNumber: Int,
    val page: Int,
    val callSign: String?,
    val invoice: String?,
    val client: String?,
    val address: String?,
    val weight: Double?,
    val fact: Double?,
    val kind: String?,
    val note: String?,
    val agentCode: String?,
    val agentName: String?,
    val rawText: String,
    val confidence: String
)

class SheetDoc(
    val agents: List<Agent>,
    val rows: List<SheetRow>,
    val totalWeight: Double?,
    val totalFact: Double?,
    val notes: List<String>
) {
    fun agentLabel(code: String?): String? {
        if (code == null) return null
        val a = agents.firstOrNull { it.code == code }
        return if (a?.name != null) "$code · ${a.name}" else code
    }
}

object SheetParser {
    private fun JSONObject.str(key: String): String? {
        if (isNull(key)) return null
        val s = optString(key).trim()
        return if (s.isEmpty() || s == "null") null else s
    }

    private fun JSONObject.num(key: String): Double? {
        if (isNull(key)) return null
        val v = opt(key)
        return when (v) {
            is Number -> v.toDouble()
            is String -> v.replace(',', '.').replace(" ", "").toDoubleOrNull()
            else -> null
        }
    }

    fun parse(json: JSONObject): SheetDoc {
        val agents = ArrayList<Agent>()
        val aa = json.optJSONArray("agents")
        if (aa != null) {
            for (i in 0 until aa.length()) {
                val a = aa.optJSONObject(i) ?: continue
                val code = a.str("code") ?: continue
                agents.add(Agent(code, a.str("name"), a.str("phone")))
            }
        }

        val rows = ArrayList<SheetRow>()
        val ra = json.optJSONArray("rows")
        if (ra != null) {
            for (i in 0 until ra.length()) {
                val r = ra.optJSONObject(i) ?: continue
                rows.add(
                    SheetRow(
                        rowNumber = r.optInt("row_number", i + 1),
                        page = r.optInt("source_page", 1),
                        callSign = r.str("call_sign"),
                        invoice = r.str("invoice"),
                        client = r.str("client"),
                        address = r.str("address"),
                        weight = r.num("weight_kg"),
                        fact = r.num("fact"),
                        kind = r.str("kind"),
                        note = r.str("note"),
                        agentCode = r.str("agent_code"),
                        agentName = r.str("agent_name"),
                        rawText = r.optString("raw_text"),
                        confidence = r.optString("confidence")
                    )
                )
            }
        }

        val totals = json.optJSONObject("totals")
        val notes = ArrayList<String>()
        val na = json.optJSONArray("notes")
        if (na != null) for (i in 0 until na.length()) notes.add(na.optString(i))

        return SheetDoc(agents, rows, totals?.num("weight_kg"), totals?.num("fact"), notes)
    }

    /** Что вызывает сомнение в строке (подсвечивается в карточке и расписано в деталях). */
    fun problems(row: SheetRow, db: PointDb): List<String> {
        val out = ArrayList<String>()
        if (row.callSign == null) out.add("позывной не распознан")
        else if (db.find(row.callSign) == null) out.add("позывного «${row.callSign}» нет в базе")
        if (row.weight == null) out.add("вес не распознан")
        if (row.confidence == "low") out.add("низкая уверенность распознавания")
        return out
    }
}

/** Все строки одной торговой точки; вес и факт суммируются. point == null — не найдено в базе. */
class PointGroup(val point: Point?, val label: String, val rows: List<SheetRow>) {
    val weight: Double = rows.sumOf { it.weight ?: 0.0 }
    val hasFact: Boolean = rows.any { it.fact != null }
    val fact: Double = rows.sumOf { it.fact ?: 0.0 }
}

object Matcher {
    fun group(rows: List<SheetRow>, db: PointDb): List<PointGroup> {
        val matched = LinkedHashMap<Point, MutableList<SheetRow>>()
        val unknown = LinkedHashMap<String, MutableList<SheetRow>>()
        for (r in rows) {
            val p = db.find(r.callSign)
            if (p != null) {
                matched.getOrPut(p) { ArrayList() }.add(r)
            } else {
                val key = Callsign.normalize(r.callSign)
                unknown.getOrPut(key) { ArrayList() }.add(r)
            }
        }
        val out = ArrayList<PointGroup>()
        for ((p, list) in matched) out.add(PointGroup(p, p.name, list))
        for ((key, list) in unknown) {
            val label = if (key.isEmpty()) "Без позывного" else (list.first().callSign ?: key)
            out.add(PointGroup(null, label, list))
        }
        return out
    }
}

object Fmt {
    fun num(v: Double): String =
        DecimalFormat("0.##", DecimalFormatSymbols(Locale("ru", "RU"))).format(v)
}
