package ru.routeplanner

import android.content.Context
import android.net.Uri
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.util.Locale
import java.util.zip.ZipInputStream

/** Чтение таблиц: .xlsx (свой разбор), .xls (jxl), .csv. Результат: листы → строки → ячейки. */
object TableReader {
    fun read(context: Context, uri: Uri): List<List<List<String>>> {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: error("Не удалось открыть файл")
        return readBytes(bytes)
    }

    fun readBytes(bytes: ByteArray): List<List<List<String>>> {
        if (bytes.size >= 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte()) return readXlsx(bytes)
        if (bytes.size >= 4 && bytes[0] == 0xD0.toByte() && bytes[1] == 0xCF.toByte()) return readXls(bytes)
        return listOf(parseCsv(decodeText(bytes)))
    }

    // ---------- .xls ----------
    private fun readXls(bytes: ByteArray): List<List<List<String>>> {
        val wb = jxl.Workbook.getWorkbook(ByteArrayInputStream(bytes))
        try {
            val out = ArrayList<List<List<String>>>()
            for (sheet in wb.sheets) {
                val rows = ArrayList<List<String>>()
                for (r in 0 until sheet.rows) {
                    val cells = ArrayList<String>()
                    for (c in 0 until sheet.columns) {
                        cells.add(sheet.getCell(c, r).contents ?: "")
                    }
                    rows.add(cells)
                }
                out.add(rows)
            }
            return out
        } finally {
            wb.close()
        }
    }

    // ---------- .xlsx ----------
    private fun readXlsx(bytes: ByteArray): List<List<List<String>>> {
        val files = HashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val n = entry.name
                if (n == "xl/workbook.xml" || n == "xl/_rels/workbook.xml.rels" ||
                    n == "xl/sharedStrings.xml" ||
                    (n.startsWith("xl/worksheets/") && n.endsWith(".xml"))
                ) {
                    files[n] = zis.readBytes()
                }
                entry = zis.nextEntry
            }
        }
        val sharedData = files["xl/sharedStrings.xml"]
        val shared = if (sharedData != null) parseSharedStrings(sharedData) else emptyList()
        val out = ArrayList<List<List<String>>>()
        for (path in sheetPaths(files)) {
            val data = files[path] ?: continue
            out.add(parseSheet(data, shared))
        }
        return out
    }

    private fun sheetPaths(files: Map<String, ByteArray>): List<String> {
        val fallback = files.keys.filter { it.startsWith("xl/worksheets/") }.sorted()
        val wb = files["xl/workbook.xml"] ?: return fallback
        val rels = files["xl/_rels/workbook.xml.rels"] ?: return fallback
        try {
            val targets = HashMap<String, String>()
            val p = Xml.newPullParser()
            p.setInput(ByteArrayInputStream(rels), "UTF-8")
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && p.name == "Relationship") {
                    val id = p.getAttributeValue(null, "Id")
                    val target = p.getAttributeValue(null, "Target")
                    if (id != null && target != null) {
                        targets[id] = if (target.startsWith("/")) target.substring(1) else "xl/$target"
                    }
                }
                ev = p.next()
            }

            val result = ArrayList<String>()
            val p2 = Xml.newPullParser()
            p2.setInput(ByteArrayInputStream(wb), "UTF-8")
            var ev2 = p2.eventType
            while (ev2 != XmlPullParser.END_DOCUMENT) {
                if (ev2 == XmlPullParser.START_TAG && p2.name == "sheet") {
                    var rid: String? = null
                    for (i in 0 until p2.attributeCount) {
                        if (p2.getAttributeName(i).endsWith(":id")) rid = p2.getAttributeValue(i)
                    }
                    val t = if (rid != null) targets[rid] else null
                    if (t != null && files.containsKey(t)) result.add(t)
                }
                ev2 = p2.next()
            }
            return if (result.isEmpty()) fallback else result
        } catch (_: Throwable) {
            return fallback
        }
    }

    private fun parseSharedStrings(data: ByteArray): List<String> {
        val out = ArrayList<String>()
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(data), "UTF-8")
        var sb: StringBuilder? = null
        var inT = false
        var phonetic = 0
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "si" -> sb = StringBuilder()
                    "rPh" -> phonetic++
                    "t" -> if (phonetic == 0) inT = true
                }
            } else if (ev == XmlPullParser.TEXT) {
                if (inT) sb?.append(p.text)
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name) {
                    "t" -> inT = false
                    "rPh" -> phonetic--
                    "si" -> {
                        out.add(sb?.toString() ?: "")
                        sb = null
                    }
                }
            }
            ev = p.next()
        }
        return out
    }

    private fun parseSheet(data: ByteArray, shared: List<String>): List<List<String>> {
        val rows = ArrayList<List<String>>()
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(data), "UTF-8")
        var cells: ArrayList<String>? = null
        var col = 0
        var type = ""
        val v = StringBuilder()
        val inl = StringBuilder()
        var inV = false
        var inT = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "row" -> {
                        val r = p.getAttributeValue(null, "r")?.toIntOrNull()
                        if (r != null) {
                            while (rows.size < r - 1) rows.add(emptyList())
                        }
                        cells = ArrayList()
                    }
                    "c" -> {
                        val ref = p.getAttributeValue(null, "r")
                        col = if (ref != null) colIndex(ref) else (cells?.size ?: 0)
                        type = p.getAttributeValue(null, "t") ?: ""
                        v.setLength(0)
                        inl.setLength(0)
                    }
                    "v" -> inV = true
                    "t" -> inT = true
                }
            } else if (ev == XmlPullParser.TEXT) {
                if (inV) v.append(p.text) else if (inT) inl.append(p.text)
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name) {
                    "v" -> inV = false
                    "t" -> inT = false
                    "c" -> {
                        val value: String = when (type) {
                            "s" -> {
                                val idx = v.toString().trim().toIntOrNull()
                                if (idx != null) (shared.getOrNull(idx) ?: "") else ""
                            }
                            "inlineStr" -> inl.toString()
                            else -> v.toString()
                        }
                        val list = cells
                        if (list != null) {
                            while (list.size < col) list.add("")
                            if (list.size == col) list.add(value) else list[col] = value
                        }
                    }
                    "row" -> {
                        val done = cells
                        if (done != null) rows.add(done)
                        cells = null
                    }
                }
            }
            ev = p.next()
        }
        return rows
    }

    private fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) {
            if (ch in 'A'..'Z') n = n * 26 + (ch - 'A' + 1)
            else if (ch in 'a'..'z') n = n * 26 + (ch - 'a' + 1)
            else break
        }
        return (n - 1).coerceAtLeast(0)
    }

    // ---------- .csv ----------
    private fun decodeText(bytes: ByteArray): String {
        var start = 0
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) start = 3
        val utf8 = String(bytes, start, bytes.size - start, Charsets.UTF_8)
        if (!utf8.contains('\uFFFD')) return utf8
        return String(bytes, start, bytes.size - start, charset("windows-1251"))
    }

    fun parseCsv(text: String): List<List<String>> {
        val firstLine = text.lineSequence().firstOrNull { it.isNotBlank() } ?: return emptyList()
        val delim = listOf(';', '\t', ',').maxByOrNull { d -> firstLine.count { it == d } } ?: ';'
        val rows = ArrayList<List<String>>()
        var cells = ArrayList<String>()
        val sb = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (inQuotes) {
                if (ch == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') {
                        sb.append('"')
                        i++
                    } else {
                        inQuotes = false
                    }
                } else {
                    sb.append(ch)
                }
            } else if (ch == '"') {
                inQuotes = true
            } else if (ch == delim) {
                cells.add(sb.toString())
                sb.setLength(0)
            } else if (ch == '\n') {
                cells.add(sb.toString())
                sb.setLength(0)
                rows.add(cells)
                cells = ArrayList()
            } else if (ch != '\r') {
                sb.append(ch)
            }
            i++
        }
        if (sb.isNotEmpty() || cells.isNotEmpty()) {
            cells.add(sb.toString())
            rows.add(cells)
        }
        return rows
    }
}

/**
 * Превращает таблицу в базу точек БЕЗ id.
 * Колонки ищутся по заголовкам (Позывной/Название/Адрес/Широта/Долгота) или, если заголовков нет,
 * по содержимому (колонка со значениями вида «175юс»).
 * Одна точка = уникальная пара «название + адрес»; строки с одной точкой и разными позывными склеиваются.
 * Строка только с позывным (объединённые ячейки) относится к предыдущей точке.
 */
object DbImporter {
    class Result(val db: PointDb, val warnings: List<String>)

    private const val LETTERS = "A-Za-z\u0410-\u044f\u0401\u0451"
    private val CS_IN_TEXT = Regex("(\\d{1,6})\\s*[-\u2013]?\\s*([$LETTERS]{2,3})(?![$LETTERS])")
    private val CS_WHOLE = Regex("^(?:\\s*\\d{1,6}\\s*[-\u2013]?\\s*[$LETTERS]{2,3}\\s*[,;/]?)+$")
    private val NAME_KEYS = listOf(
        "назван", "наимен", "точк", "магазин", "клиент", "контрагент", "торгов", "объект", "имя", "name"
    )

    private class Builder(var name: String, var address: String) {
        var lat: Double? = null
        var lon: Double? = null
        val callsigns = LinkedHashSet<String>()
    }

    fun extractCallsigns(text: String): List<String> =
        CS_IN_TEXT.findAll(text).map { it.groupValues[1] + it.groupValues[2].lowercase(Locale.ROOT) }.toList()

    private fun normText(s: String): String =
        s.lowercase(Locale.ROOT).replace('\u0451', '\u0435').replace(Regex("\\s+"), " ").trim()

    private fun low(s: String?): String = (s ?: "").trim().lowercase(Locale.ROOT)

    private fun cellOf(row: List<String>, c: Int): String = if (c >= 0 && c < row.size) row[c].trim() else ""

    private fun coord(s: String): Double? = s.replace(',', '.').replace(" ", "").toDoubleOrNull()

    fun parse(table: List<List<String>>): Result? {
        if (table.isEmpty()) return null
        val width = table.maxOf { it.size }
        if (width == 0) return null

        // 1. строка заголовков (по слову «позывн»)
        var headerRow = -1
        for (i in 0 until minOf(table.size, 20)) {
            if (table[i].any { low(it).contains("позывн") }) {
                headerRow = i
                break
            }
        }

        // 2. колонки с позывными
        val callCols = ArrayList<Int>()
        if (headerRow < 0) {
            for (c in 0 until width) {
                var nonEmpty = 0
                var hit = 0
                for (row in table) {
                    val v = cellOf(row, c)
                    if (v.isEmpty()) continue
                    nonEmpty++
                    if (CS_WHOLE.matches(v)) hit++
                }
                if (hit > 0 && hit * 2 >= nonEmpty) callCols.add(c)
            }
            if (callCols.isEmpty()) return null
            val first = table[0]
            if (callCols.none { extractCallsigns(cellOf(first, it)).isNotEmpty() }) headerRow = 0
        }

        // 3. остальные роли колонок по заголовкам
        var nameCol = -1
        var addrCol = -1
        var latCol = -1
        var lonCol = -1
        val skip = HashSet<Int>()
        if (headerRow >= 0) {
            val hdr = table[headerRow]
            for (c in 0 until width) {
                val h = low(cellOf(hdr, c))
                if (h.isEmpty()) continue
                if (h.contains("позывн") || h == "callsign") {
                    if (c !in callCols) callCols.add(c)
                } else if (h == "id" || h == "№" || h == "#" || h.startsWith("код") || h.startsWith("номер")) {
                    skip.add(c)
                } else if (h.contains("адрес") || h == "address") {
                    if (addrCol < 0) addrCol = c
                } else if (h.contains("широт") || h == "lat" || h == "latitude") {
                    if (latCol < 0) latCol = c
                } else if (h.contains("долгот") || h == "lon" || h == "lng" || h == "longitude") {
                    if (lonCol < 0) lonCol = c
                } else if (nameCol < 0 && NAME_KEYS.any { h.contains(it) }) {
                    nameCol = c
                }
            }
        }

        val dataStart = if (headerRow >= 0) headerRow + 1 else 0

        fun isFreeTextCol(c: Int): Boolean {
            if (c in callCols || c in skip || c == nameCol || c == addrCol || c == latCol || c == lonCol) return false
            var textual = 0
            for (r in dataStart until table.size) {
                val v = cellOf(table[r], c)
                if (v.isNotEmpty() && coord(v) == null) textual++
            }
            return textual > 0
        }
        if (nameCol < 0) nameCol = (0 until width).firstOrNull { isFreeTextCol(it) } ?: -1
        if (addrCol < 0 && headerRow < 0) addrCol = (0 until width).firstOrNull { isFreeTextCol(it) } ?: -1

        // 4. строки данных
        val builders = ArrayList<Builder>()
        val byKey = HashMap<String, Builder>()
        val owner = HashMap<String, Builder>()
        val warnings = ArrayList<String>()
        var last: Builder? = null
        var orphan = 0

        for (r in dataStart until table.size) {
            val row = table[r]
            val name = if (nameCol >= 0) cellOf(row, nameCol) else ""
            val addr = if (addrCol >= 0) cellOf(row, addrCol) else ""
            val cs = ArrayList<String>()
            for (c in callCols) cs.addAll(extractCallsigns(cellOf(row, c)))
            if (name.isEmpty() && addr.isEmpty() && cs.isEmpty()) continue

            val b: Builder
            if (name.isEmpty() && addr.isEmpty()) {
                val prev = last
                if (prev == null) {
                    orphan++
                    continue
                }
                b = prev
            } else {
                val nk = normText(name)
                val ak = normText(addr)
                val key = "$nk|$ak"
                val existing = byKey[key]
                    ?: (if (ak.isEmpty()) builders.firstOrNull { normText(it.name) == nk } else null)
                if (existing != null) {
                    b = existing
                } else {
                    val nb = Builder(name.ifEmpty { addr }, addr)
                    builders.add(nb)
                    byKey[key] = nb
                    b = nb
                }
                last = b
            }

            if (b.lat == null && latCol >= 0) b.lat = coord(cellOf(row, latCol))
            if (b.lon == null && lonCol >= 0) b.lon = coord(cellOf(row, lonCol))

            for (raw in cs) {
                val k = Callsign.normalize(raw)
                val o = owner[k]
                if (o == null) {
                    owner[k] = b
                    b.callsigns.add(raw)
                } else if (o !== b) {
                    warnings.add("Позывной $raw указан у двух точек: «${o.name}» и «${b.name}» — оставлен первый")
                }
            }
        }

        if (orphan > 0) warnings.add("Пропущено строк с позывным, но без точки: $orphan")
        val noCs = builders.count { it.callsigns.isEmpty() }
        if (noCs > 0) warnings.add("Точек без позывных: $noCs (в базу попадут, но по позывному находиться не будут)")
        if (builders.isEmpty()) return null

        val points = builders.map { Point(it.name, it.address, it.lat, it.lon, it.callsigns.toList()) }
        return Result(PointDb(points), warnings)
    }
}
