package ru.routeplanner

import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var dbInfo: TextView
    private lateinit var runOcr: Button
    private lateinit var matchBtn: Button
    private lateinit var folderId: EditText
    private lateinit var apiKey: EditText
    private lateinit var settingsBox: View
    private lateinit var list: RecyclerView

    private var selected: List<Uri> = emptyList()
    private var doc: SheetDoc? = null
    private var docStamp = 0L
    private var db: PointDb = PointDb(emptyList())
    private var pointsMode = false

    private val prefs by lazy { getSharedPreferences("route_qwen", MODE_PRIVATE) }

    private class ImportOutcome(val result: DbImporter.Result?, val error: String?)

    private val photoPicker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        selected = uris
        uris.forEach { uri ->
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Throwable) { }
        }
        runOcr.isEnabled = uris.isNotEmpty()
        status.text = if (uris.isEmpty()) "Фото не выбраны." else "Выбрано страниц: ${uris.size}. Можно распознавать."
    }

    private val dbPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importDb(uri)
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                RecognitionService.ACTION_PROGRESS -> {
                    status.text = intent.getStringExtra(RecognitionService.EXTRA_MESSAGE) ?: "Распознавание…"
                }
                RecognitionService.ACTION_DONE -> {
                    runOcr.isEnabled = selected.isNotEmpty()
                    docStamp = 0L
                    if (loadDocFromDisk()) {
                        pointsMode = false
                        render()
                        status.text = "Готово. Строк: ${doc?.rows?.size ?: 0}"
                    } else {
                        status.text = "Не удалось прочитать результат."
                    }
                }
                RecognitionService.ACTION_ERROR -> {
                    val text = intent.getStringExtra(RecognitionService.EXTRA_RESULT).orEmpty()
                    status.text = "Ошибка: " + text.take(800)
                    runOcr.isEnabled = selected.isNotEmpty()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        dbInfo = findViewById(R.id.dbInfo)
        runOcr = findViewById(R.id.runOcr)
        matchBtn = findViewById(R.id.matchBtn)
        folderId = findViewById(R.id.folderId)
        apiKey = findViewById(R.id.apiKey)
        settingsBox = findViewById(R.id.settingsBox)
        list = findViewById(R.id.list)
        list.layoutManager = LinearLayoutManager(this)

        folderId.setText(prefs.getString("folder_id", ""))
        apiKey.setText(prefs.getString("api_key", ""))
        settingsBox.visibility =
            if (folderId.text.isNullOrBlank() || apiKey.text.isNullOrBlank()) View.VISIBLE else View.GONE

        findViewById<Button>(R.id.toggleSettings).setOnClickListener {
            settingsBox.visibility = if (settingsBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        findViewById<Button>(R.id.selectPhotos).setOnClickListener {
            photoPicker.launch(arrayOf("image/jpeg", "image/png", "image/webp"))
        }
        findViewById<Button>(R.id.importDb).setOnClickListener { dbPicker.launch(arrayOf("*/*")) }
        runOcr.setOnClickListener { startRecognition() }
        matchBtn.setOnClickListener {
            pointsMode = !pointsMode
            render()
        }

        db = PointDbStore.load(this)
        updateDbInfo()
        loadDocFromDisk()
        render()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(RecognitionService.ACTION_PROGRESS)
            addAction(RecognitionService.ACTION_DONE)
            addAction(RecognitionService.ACTION_ERROR)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION") registerReceiver(receiver, filter)
        }
        if (prefs.getBoolean("recognition_running", false)) {
            status.text = "Распознавание выполняется в фоне…"
            runOcr.isEnabled = false
        } else if (loadDocFromDisk()) {
            pointsMode = false
            render()
            status.text = "Последний результат загружен. Строк: ${doc?.rows?.size ?: 0}"
        }
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(receiver) } catch (_: Throwable) { }
    }

    // ---------- результат распознавания ----------
    private fun loadDocFromDisk(): Boolean {
        val f = File(filesDir, RecognitionService.RESULT_FILE)
        if (!f.exists() || f.lastModified() == docStamp) return false
        return try {
            doc = SheetParser.parse(JSONObject(f.readText(Charsets.UTF_8)))
            docStamp = f.lastModified()
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun render() {
        val d = doc
        if (d == null || d.rows.isEmpty()) {
            list.adapter = CardAdapter(emptyList())
            matchBtn.isEnabled = false
            matchBtn.text = "Сопоставить с точками"
            return
        }
        val items = ArrayList<Item>()
        if (!pointsMode) {
            items.add(Item.Header(rowsSummary(d)))
            for (r in d.rows) {
                items.add(Item.RowCard(r, SheetParser.problems(r, db), db.find(r.callSign), d.agentLabel(r.agentCode)))
            }
            matchBtn.text = "Сопоставить с точками"
        } else {
            val groups = Matcher.group(d.rows, db)
            val known = groups.filter { it.point != null }
            val unknown = groups.filter { it.point == null }
            items.add(Item.Header(pointsSummary(d, known, unknown)))
            for (g in known) items.add(Item.PointCard(g))
            if (unknown.isNotEmpty()) {
                items.add(Item.Header("Не найдены в базе: ${unknown.size}"))
                for (g in unknown) items.add(Item.PointCard(g))
            }
            matchBtn.text = "← Назад к строкам листа"
        }
        list.adapter = CardAdapter(items)
        matchBtn.isEnabled = true
    }

    private fun rowsSummary(d: SheetDoc): String {
        val w = d.rows.sumOf { it.weight ?: 0.0 }
        val hasFact = d.rows.any { it.fact != null }
        val sb = StringBuilder("Строк: ${d.rows.size} · вес ${Fmt.num(w)} кг")
        if (hasFact) sb.append(" · факт ").append(Fmt.num(d.rows.sumOf { it.fact ?: 0.0 }))
        val declared = d.totalWeight
        if (declared != null) {
            sb.append("\nИТОГО по листу: ").append(Fmt.num(declared)).append(" кг")
            sb.append(if (kotlin.math.abs(w - declared) < 0.05) " ✓" else " ⚠ не сходится")
        }
        for (n in d.notes) sb.append("\n• ").append(n)
        sb.append("\nНажмите на позывной — подробности.")
        return sb.toString()
    }

    private fun pointsSummary(d: SheetDoc, known: List<PointGroup>, unknown: List<PointGroup>): String {
        val w = d.rows.sumOf { it.weight ?: 0.0 }
        val hasFact = d.rows.any { it.fact != null }
        val sb = StringBuilder("Точек: ${known.size} · строк: ${d.rows.size} · вес ${Fmt.num(w)} кг")
        if (hasFact) sb.append(" · факт ").append(Fmt.num(d.rows.sumOf { it.fact ?: 0.0 }))
        if (unknown.isNotEmpty()) sb.append("\nНе найдено в базе: ${unknown.size}")
        return sb.toString()
    }

    // ---------- импорт базы ----------
    private fun updateDbInfo() {
        dbInfo.text = "База: ${db.points.size} точек · ${db.callsignCount} позывных"
    }

    private fun importDb(uri: Uri) {
        status.text = "Читаю базу…"
        lifecycleScope.launch {
            val outcome = withContext(Dispatchers.IO) {
                try {
                    val sheets = TableReader.read(applicationContext, uri)
                    var best: DbImporter.Result? = null
                    for (rows in sheets) {
                        val r = DbImporter.parse(rows) ?: continue
                        val cur = best
                        if (cur == null || r.db.points.size > cur.db.points.size) best = r
                    }
                    if (best == null) {
                        ImportOutcome(null, "Не нашёл колонку с позывными (значения вида 175юс). Проверьте файл.")
                    } else {
                        ImportOutcome(best, null)
                    }
                } catch (t: Throwable) {
                    ImportOutcome(null, "Не удалось прочитать файл: ${t.message ?: t}. Если это .xls — сохраните как .xlsx.")
                }
            }
            val res = outcome.result
            if (res == null) {
                status.text = outcome.error ?: "Ошибка импорта."
                return@launch
            }
            status.text = "База прочитана. Подтвердите замену."
            val msg = StringBuilder()
            msg.append("Точек: ${res.db.points.size}\nПозывных: ${res.db.callsignCount}")
            if (res.warnings.isNotEmpty()) {
                msg.append("\n\nЗамечания:")
                res.warnings.take(8).forEach { msg.append("\n• ").append(it) }
                if (res.warnings.size > 8) msg.append("\n… и ещё ${res.warnings.size - 8}")
            }
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Импорт базы")
                .setMessage(msg.toString())
                .setPositiveButton("Заменить базу") { _, _ ->
                    db = res.db
                    try { PointDbStore.save(this@MainActivity, db) } catch (_: Throwable) { }
                    updateDbInfo()
                    render()
                    status.text = "База обновлена: ${db.points.size} точек, ${db.callsignCount} позывных."
                }
                .setNegativeButton("Отмена") { _, _ -> status.text = "Импорт отменён." }
                .show()
        }
    }

    // ---------- запуск распознавания ----------
    private fun startRecognition() {
        val folder = folderId.text.toString().trim()
            .removePrefix("gpt://")
            .substringBefore('/')
        val key = apiKey.text.toString().trim()
        if (folder.isBlank() || key.isBlank()) {
            settingsBox.visibility = View.VISIBLE
            status.text = "Введите ID каталога и API-ключ Yandex Cloud (⚙)."
            return
        }
        if (selected.isEmpty()) {
            status.text = "Сначала выберите фото."
            return
        }

        prefs.edit()
            .putString("folder_id", folder)
            .putString("api_key", key)
            .putBoolean("recognition_running", true)
            .apply()

        runOcr.isEnabled = false
        status.text = "Запуск распознавания…"

        val intent = Intent(this, RecognitionService::class.java).apply {
            action = RecognitionService.ACTION_START
            putExtra(RecognitionService.EXTRA_FOLDER_ID, folder)
            putExtra(RecognitionService.EXTRA_API_KEY, key)
            putStringArrayListExtra(
                RecognitionService.EXTRA_URIS,
                ArrayList<String>().apply { selected.forEach { add(it.toString()) } }
            )
        }
        ContextCompat.startForegroundService(this, intent)
    }
}
