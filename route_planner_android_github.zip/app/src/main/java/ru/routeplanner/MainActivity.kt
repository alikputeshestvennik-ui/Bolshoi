package ru.routeplanner

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var runOcr: Button
    private lateinit var folderId: EditText
    private lateinit var apiKey: EditText
    private var selected: List<Uri> = emptyList()

    private val prefs by lazy { getSharedPreferences("route_qwen", MODE_PRIVATE) }

    private val picker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        selected = uris
        uris.forEach { uri ->
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Throwable) { }
        }
        runOcr.isEnabled = uris.isNotEmpty()
        status.text = if (uris.isEmpty()) "Фото не выбраны." else "Выбрано страниц: ${uris.size}. Можно запускать распознавание."
        result.text = ""
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                RecognitionService.ACTION_PROGRESS -> {
                    status.text = intent.getStringExtra(RecognitionService.EXTRA_MESSAGE) ?: "Распознавание…"
                }
                RecognitionService.ACTION_DONE -> {
                    val text = intent.getStringExtra(RecognitionService.EXTRA_RESULT).orEmpty()
                    result.text = text
                    status.text = "Готово. Страниц: ${selected.size}"
                    runOcr.isEnabled = selected.isNotEmpty()
                }
                RecognitionService.ACTION_ERROR -> {
                    val text = intent.getStringExtra(RecognitionService.EXTRA_RESULT).orEmpty()
                    status.text = "Ошибка Qwen API"
                    result.text = text
                    runOcr.isEnabled = selected.isNotEmpty()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        result = findViewById(R.id.result)
        runOcr = findViewById(R.id.runOcr)
        folderId = findViewById(R.id.folderId)
        apiKey = findViewById(R.id.apiKey)

        folderId.setText(prefs.getString("folder_id", ""))
        apiKey.setText(prefs.getString("api_key", ""))

        findViewById<Button>(R.id.selectPhotos).setOnClickListener {
            picker.launch(arrayOf("image/jpeg", "image/png", "image/webp"))
        }

        runOcr.setOnClickListener { startRecognition() }

        val saved = prefs.getString("last_result", null)
        if (!saved.isNullOrBlank()) result.text = saved
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(RecognitionService.ACTION_PROGRESS)
            addAction(RecognitionService.ACTION_DONE)
            addAction(RecognitionService.ACTION_ERROR)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION") registerReceiver(receiver, filter)
        }
        val running = prefs.getBoolean("recognition_running", false)
        if (running) {
            status.text = "Распознавание выполняется в фоне…"
            runOcr.isEnabled = false
        } else {
            prefs.getString("last_result", null)?.let {
                result.text = it
                if (it.isNotBlank()) status.text = "Последний результат готов."
            }
        }
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(receiver) } catch (_: Throwable) { }
    }

    private fun startRecognition() {
        val folder = folderId.text.toString().trim()
            .removePrefix("gpt://")
            .substringBefore('/')
        val key = apiKey.text.toString().trim()
        if (folder.isBlank()) {
            status.text = "Введите ID каталога Yandex Cloud."
            return
        }
        if (key.isBlank()) {
            status.text = "Введите API-ключ Yandex Cloud."
            return
        }
        if (selected.isEmpty()) {
            status.text = "Сначала выберите фото."
            return
        }

        prefs.edit()
            .putString("folder_id", folder)
            .putString("api_key", key)
            .putBoolean("recognition_running", true)
            .apply()

        runOcr.isEnabled = false
        status.text = "Запуск Qwen3.6-35B…"

        val intent = Intent(this, RecognitionService::class.java).apply {
            action = RecognitionService.ACTION_START
            putExtra(RecognitionService.EXTRA_FOLDER_ID, folder)
            putExtra(RecognitionService.EXTRA_API_KEY, key)
            putStringArrayListExtra(
                RecognitionService.EXTRA_URIS,
                ArrayList<String>().apply { selected.forEach { add(it.toString()) } }
            )
        }
        ContextCompat.startForegroundService(this, intent)
    }
}
