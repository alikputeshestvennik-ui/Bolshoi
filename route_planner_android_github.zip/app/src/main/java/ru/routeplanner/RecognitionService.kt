package ru.routeplanner

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import android.util.Base64
import java.io.File

class RecognitionService : Service() {
    companion object {
        const val ACTION_START = "ru.routeplanner.action.START"
        const val ACTION_PROGRESS = "ru.routeplanner.action.PROGRESS"
        const val ACTION_DONE = "ru.routeplanner.action.DONE"
        const val ACTION_ERROR = "ru.routeplanner.action.ERROR"
        const val EXTRA_FOLDER_ID = "folder_id"
        const val EXTRA_API_KEY = "api_key"
        const val EXTRA_URIS = "uris"
        const val EXTRA_MESSAGE = "message"
        const val EXTRA_RESULT = "result"
        const val RESULT_FILE = "last_result.json"
        private const val CHANNEL_ID = "route_recognition"
        private const val NOTIFICATION_ID = 1001
        private const val MODEL_NAME = "qwen3.6-35b-a3b"
        private const val API_URL = "https://ai.api.cloud.yandex.net/v1/responses"
    }

    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var wakeLock: PowerManager.WakeLock? = null
    private var activeJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_upload)
            .setContentTitle("Маршрут — Qwen3.6-35B")
            .setContentText("Распознавание выполняется…")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .build()
        startForeground(NOTIFICATION_ID, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_START) return START_NOT_STICKY
        if (activeJob?.isActive == true) return START_NOT_STICKY

        val folder = intent.getStringExtra(EXTRA_FOLDER_ID).orEmpty()
        val key = intent.getStringExtra(EXTRA_API_KEY).orEmpty()
        val uriStrings = intent.getStringArrayListExtra(EXTRA_URIS).orEmpty()
        if (folder.isBlank() || key.isBlank() || uriStrings.isEmpty()) {
            finishError("Не хватает ID каталога, API-ключа или фотографий.")
            return START_NOT_STICKY
        }

        getSharedPreferences("route_qwen", MODE_PRIVATE)
            .edit().putBoolean("recognition_running", true).apply()

        acquireWakeLock()
        sendProgress("Подготавливаю ${uriStrings.size} страниц…")

        activeJob = scope.launch {
            try {
                val uris = uriStrings.map(Uri::parse)
                val json = recognizeDocument(folder, key, uris)
                File(filesDir, RESULT_FILE).writeText(json.toString(), Charsets.UTF_8)
                getSharedPreferences("route_qwen", MODE_PRIVATE)
                    .edit()
                    .putBoolean("recognition_running", false)
                    .apply()
                sendBroadcast(Intent(ACTION_DONE).setPackage(packageName))
            } catch (t: Throwable) {
                finishError(t.message ?: t.toString())
            } finally {
                releaseWakeLock()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(startId)
            }
        }
        return START_NOT_STICKY
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RoutePlanner:QwenRecognition")
        wakeLock?.setReferenceCounted(false)
        wakeLock?.acquire(60 * 60 * 1000L)
    }

    private fun releaseWakeLock() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Throwable) { }
        wakeLock = null
    }

    private fun sendProgress(message: String) {
        sendBroadcast(Intent(ACTION_PROGRESS).setPackage(packageName).putExtra(EXTRA_MESSAGE, message))
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(
            NOTIFICATION_ID,
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_upload)
                .setContentTitle("Маршрут — Qwen3.6-35B")
                .setContentText(message)
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_PROGRESS)
                .build()
        )
    }

    private fun finishError(message: String) {
        getSharedPreferences("route_qwen", MODE_PRIVATE).edit()
            .putBoolean("recognition_running", false).apply()
        sendBroadcast(Intent(ACTION_ERROR).setPackage(packageName).putExtra(EXTRA_RESULT, message))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Распознавание маршрутного листа", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun recognizeDocument(folderId: String, apiKey: String, uris: List<Uri>): JSONObject {
        val model = "gpt://$folderId/$MODEL_NAME"
        val content = JSONArray()
        content.put(JSONObject().put("type", "input_text").put("text", OCR_PROMPT))

        uris.forEachIndexed { index, uri ->
            sendProgress("Подготавливаю страницу ${index + 1} из ${uris.size}…")
            val data = imageAsDataUrl(uri)
            content.put(
                JSONObject()
                    .put("type", "input_text")
                    .put("text", "Следующее изображение — СТРАНИЦА ${index + 1} из ${uris.size}. Сохрани её номер в source_page.")
            )
            content.put(JSONObject().put("type", "input_image").put("image_url", data).put("detail", "original"))
        }

        val input = JSONArray().put(
            JSONObject()
                .put("type", "message")
                .put("role", "user")
                .put("content", content)
        )

        val schema = jsonSchema()
        val textFormat = JSONObject()
            .put("type", "json_schema")
            .put("name", "route_sheet")
            .put("description", "Строгая структура распознанного маршрутного листа")
            .put("strict", true)
            .put("schema", schema)

        val body = JSONObject()
            .put("model", model)
            .put("instructions", OCR_INSTRUCTIONS)
            .put("input", input)
            .put("temperature", 0.2)
            .put("max_output_tokens", 24000)
            .put("text", JSONObject().put("format", textFormat))

        sendProgress("Отправляю ${uris.size} страниц в Qwen3.6-35B…")
        val responseText = postJson(apiKey, body.toString())
        val response = JSONObject(responseText)
        val outputText = extractOutputText(response)
        if (outputText.isBlank()) {
            val err = response.optJSONObject("error")?.optString("message")
            error(err ?: "Qwen вернул пустой ответ")
        }
        val cleaned = outputText.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return JSONObject(cleaned)
    }

    private fun postJson(apiKey: String, body: String): String {
        val url = URL(API_URL)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout = 15 * 60_000
            doOutput = true
            setRequestProperty("Authorization", "Api-Key $apiKey")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
        }
        return try {
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) error("HTTP $code:\n$text")
            text
        } finally {
            conn.disconnect()
        }
    }

    private fun extractOutputText(response: JSONObject): String {
        response.optString("output_text").takeIf { it.isNotBlank() }?.let { return it }
        val output = response.optJSONArray("output") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val part = content.optJSONObject(j) ?: continue
                val text = part.optString("text")
                if (text.isNotBlank()) sb.append(text)
            }
        }
        return sb.toString()
    }

    private fun imageAsDataUrl(uri: Uri): String {
        val exifOrientation = try {
            contentResolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
                ?: ExifInterface.ORIENTATION_NORMAL
        } catch (_: Throwable) { ExifInterface.ORIENTATION_NORMAL }

        val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            ?: error("Не удалось открыть изображение: $uri")
        val oriented = applyExif(bitmap, exifOrientation)
        if (oriented !== bitmap) bitmap.recycle()

        val maxSide = 3600
        val scaled = scaleLong(oriented, maxSide)
        if (scaled !== oriented) oriented.recycle()

        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 86, out)
        scaled.recycle()
        val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        return "data:image/jpeg;base64,$b64"
    }

    private fun applyExif(src: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1f, 1f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.setRotate(180f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> { matrix.setRotate(180f); matrix.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.setRotate(90f); matrix.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.setRotate(90f)
            ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.setRotate(-90f); matrix.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.setRotate(-90f)
            else -> return src
        }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
    }

    private fun scaleLong(src: Bitmap, maxSide: Int): Bitmap {
        val longest = maxOf(src.width, src.height)
        if (longest <= maxSide) return src
        val k = maxSide.toFloat() / longest
        return Bitmap.createScaledBitmap(
            src,
            (src.width * k).toInt().coerceAtLeast(1),
            (src.height * k).toInt().coerceAtLeast(1),
            true
        )
    }

    private fun jsonSchema(): JSONObject {
        fun nullable(type: String) = JSONArray().put(type).put("null")
        fun prop(type: Any) = JSONObject().put("type", type)
        val rowProps = JSONObject()
            .put("row_number", prop("integer"))
            .put("source_page", prop("integer"))
            .put("call_sign", prop(nullable("string")))
            .put("invoice", prop(nullable("string")))
            .put("client", prop(nullable("string")))
            .put("address", prop(nullable("string")))
            .put("weight_kg", prop(nullable("number")))
            .put("fact", prop(nullable("number")))
            .put("kind", prop(nullable("string")))
            .put("note", prop(nullable("string")))
            .put("agent_code", prop(nullable("string")))
            .put("agent_name", prop(nullable("string")))
            .put("raw_text", prop("string"))
            .put("confidence", JSONObject().put("type", "string").put("enum", JSONArray(listOf("high", "medium", "low"))))

        val row = JSONObject()
            .put("type", "object")
            .put("additionalProperties", false)
            .put("properties", rowProps)
            .put("required", JSONArray(listOf("row_number", "source_page", "call_sign", "invoice", "client", "address", "weight_kg", "fact", "kind", "note", "agent_code", "agent_name", "raw_text", "confidence")))

        val agentProps = JSONObject()
            .put("code", prop("string"))
            .put("name", prop(nullable("string")))
            .put("phone", prop(nullable("string")))
        val agent = JSONObject()
            .put("type", "object")
            .put("additionalProperties", false)
            .put("properties", agentProps)
            .put("required", JSONArray(listOf("code", "name", "phone")))

        val totalsProps = JSONObject()
            .put("weight_kg", prop(nullable("number")))
            .put("fact", prop(nullable("number")))
            .put("found", prop("boolean"))
        val totals = JSONObject()
            .put("type", "object")
            .put("additionalProperties", false)
            .put("properties", totalsProps)
            .put("required", JSONArray(listOf("weight_kg", "fact", "found")))

        val rootProps = JSONObject()
            .put("document_title", prop("string"))
            .put("pages_received", prop("integer"))
            .put("pages_used_until_total", prop("integer"))
            .put("agents", JSONObject().put("type", "array").put("items", agent))
            .put("rows", JSONObject().put("type", "array").put("items", row))
            .put("totals", totals)
            .put("notes", JSONObject().put("type", "array").put("items", prop("string")))

        return JSONObject()
            .put("type", "object")
            .put("additionalProperties", false)
            .put("properties", rootProps)
            .put("required", JSONArray(listOf("document_title", "pages_received", "pages_used_until_total", "agents", "rows", "totals", "notes")))
    }

    override fun onDestroy() {
        releaseWakeLock()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

}
