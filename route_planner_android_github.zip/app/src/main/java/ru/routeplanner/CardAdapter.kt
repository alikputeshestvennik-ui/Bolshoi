package ru.routeplanner

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

sealed class Item {
    class Header(val text: String) : Item()

    class RowCard(
        val row: SheetRow,
        val problems: List<String>,
        val point: Point?,
        val agent: String?
    ) : Item() {
        var expanded = false
    }

    class PointCard(val group: PointGroup) : Item() {
        var expanded = false
    }
}

class CardAdapter(private val items: List<Item>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private class HeaderHolder(v: View) : RecyclerView.ViewHolder(v) {
        val text: TextView = v as TextView
    }

    private class CardHolder(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.title)
        val sub: TextView = v.findViewById(R.id.sub)
        val meta: TextView = v.findViewById(R.id.meta)
        val detail: TextView = v.findViewById(R.id.detail)
    }

    private val normalColor = Color.parseColor("#1B1B1F")
    private val warnColor = Color.parseColor("#B26A00")

    override fun getItemViewType(position: Int): Int = if (items[position] is Item.Header) 0 else 1

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == 0) {
            HeaderHolder(inflater.inflate(R.layout.item_header, parent, false))
        } else {
            CardHolder(inflater.inflate(R.layout.item_card, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = items[position]
        if (item is Item.Header) {
            (holder as HeaderHolder).text.text = item.text
        } else if (item is Item.RowCard) {
            bindRow(holder as CardHolder, item)
        } else if (item is Item.PointCard) {
            bindPoint(holder as CardHolder, item)
        }
    }

    private fun toggle(h: CardHolder, flip: () -> Unit) {
        h.itemView.setOnClickListener {
            flip()
            val pos = h.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) notifyItemChanged(pos)
        }
    }

    // ---------- строка листа: на карточке только позывной ----------
    private fun bindRow(h: CardHolder, item: Item.RowCard) {
        val r = item.row
        h.title.text = r.callSign ?: "позывной не распознан"
        h.title.setTextColor(if (item.problems.isNotEmpty()) warnColor else normalColor)
        h.sub.visibility = View.GONE
        h.meta.visibility = View.GONE
        h.detail.visibility = if (item.expanded) View.VISIBLE else View.GONE
        if (item.expanded) h.detail.text = rowDetails(item)
        toggle(h) { item.expanded = !item.expanded }
    }

    private fun rowDetails(item: Item.RowCard): String {
        val r = item.row
        val sb = StringBuilder()
        fun line(label: String, value: String?) {
            if (!value.isNullOrBlank()) sb.append(label).append(": ").append(value).append('\n')
        }
        line("Накладная", r.invoice)
        line("Тип", r.kind)
        line("Вес", r.weight?.let { Fmt.num(it) + " кг" })
        line("Факт", r.fact?.let { Fmt.num(it) })
        line("Агент", item.agent)
        line("Клиент по листу", r.client)
        line("Адрес по листу", r.address)
        line("Заметки", r.note)
        val p = item.point
        if (p != null) {
            line("Точка в базе", p.name + (if (p.address.isNotEmpty()) " — " + p.address else ""))
        } else if (r.callSign != null) {
            line("Точка в базе", "не найдена")
        }
        val conf = when (r.confidence) {
            "high" -> "высокая"
            "medium" -> "средняя"
            "low" -> "низкая"
            else -> r.confidence
        }
        sb.append("Строка ${r.rowNumber} · стр. ${r.page} · уверенность: $conf\n")
        line("Как прочитано", r.rawText)
        for (p2 in item.problems) sb.append("⚠ ").append(p2).append('\n')
        return sb.toString().trimEnd()
    }

    // ---------- торговая точка: суммы по строкам ----------
    private fun bindPoint(h: CardHolder, item: Item.PointCard) {
        val g = item.group
        h.title.text = g.label
        h.title.setTextColor(if (g.point == null) warnColor else normalColor)
        val p = g.point
        h.sub.visibility = View.VISIBLE
        h.sub.text = (if (p != null) p.address.ifEmpty { "адрес не указан" } else "нет в базе") +
            " · строк: ${g.rows.size}"
        h.meta.visibility = View.VISIBLE
        h.meta.text = Fmt.num(g.weight) + " кг" + (if (g.hasFact) "\nфакт " + Fmt.num(g.fact) else "")
        h.detail.visibility = if (item.expanded) View.VISIBLE else View.GONE
        if (item.expanded) h.detail.text = pointDetails(g)
        toggle(h) { item.expanded = !item.expanded }
    }

    private fun pointDetails(g: PointGroup): String {
        val sb = StringBuilder()
        for (r in g.rows) {
            val parts = listOfNotNull(
                r.invoice,
                r.callSign,
                r.kind,
                r.weight?.let { Fmt.num(it) + " кг" },
                r.fact?.let { "факт " + Fmt.num(it) },
                r.agentCode?.let { "агент $it" }
            )
            sb.append("• ").append(parts.joinToString(" · ")).append('\n')
        }
        return sb.toString().trimEnd()
    }
}
