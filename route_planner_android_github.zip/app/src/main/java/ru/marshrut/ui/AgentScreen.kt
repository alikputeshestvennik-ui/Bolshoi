package ru.marshrut.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import ru.marshrut.Agent
import ru.marshrut.AppVm

/** Чат с агентом: реплики, предложения «Да/Нет», выполненные действия с откатом. */
@Composable
fun AgentScreen(vm: AppVm) {
    val ag = vm.agent
    var text by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    LaunchedEffect(ag.msgs.size, ag.busy) { if (ag.msgs.isNotEmpty()) list.animateScrollToItem((list.layoutInfo.totalItemsCount - 1).coerceAtLeast(0)) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Агент", { vm.closeAgent() }, subtitle = vm.agentFrom.replaceFirstChar { it.uppercase() }) {
            if (ag.msgs.isNotEmpty()) RoundIconButton(Ic.Trash, { ag.clear() }, size = 42.dp, tint = C.Mute)
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list,
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (ag.msgs.isEmpty()) item(key = "hello") {
                Column(Modifier.fillMaxWidth().background(C.Surface).padding(16.dp)) {
                    Text("Напишите задачу обычными словами", style = T.H3)
                    Spacer(Modifier.height(6.dp))
                    Text("Агент сам посмотрит лист, базу и раскладку. Всё, что меняет данные, он сначала спросит.", style = T.Body)
                    Spacer(Modifier.height(10.dp))
                    listOf("Почему Олива встала к Суботиной?", "Сколько наличных по листу и у кого?", "Проверь новые точки — может, они уже есть в базе")
                        .forEach { ex ->
                            Text("«$ex»", style = T.Body.copy(color = C.Ink), modifier = Modifier.fillMaxWidth()
                                .padding(top = 6.dp).background(C.Field).pressable { text = ex }.padding(10.dp))
                        }
                }
            }
            itemsIndexed(ag.msgs) { _, m -> Bubble(ag, m) }
            ag.busy?.let { b -> item(key = "busy") { Text("$b…", style = T.Small, modifier = Modifier.padding(start = 4.dp, top = 2.dp)) } }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Field(text, { text = it }, "", Modifier.weight(1f), singleLine = false, placeholder = "Задача или вопрос")
            Spacer(Modifier.width(8.dp))
            RoundIconButton(Ic.ArrowRight, { ag.send(text); text = "" }, size = 54.dp, tint = Color.White, bg = if (ag.busy == null && text.isNotBlank()) C.Ink else C.Mute)
        }
    }
}

@Composable
private fun Bubble(ag: Agent, m: Agent.Msg) {
    when (m.role) {
        Agent.Role.USER -> Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
            Text(m.text, style = T.Body.copy(color = Color.White), modifier = Modifier.widthIn(max = 300.dp).background(C.Ink).padding(12.dp))
        }
        Agent.Role.NOTE -> Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(m.text, style = T.Small, modifier = Modifier.weight(1f))
            if (m.undo != null && !ag.isUndone(m)) GhostButton("Откатить", { ag.undo(m) }, tint = C.Danger)
        }
        Agent.Role.ERROR -> Text(m.text, style = T.Body.copy(color = C.Danger), modifier = Modifier.fillMaxWidth().background(C.DangerSoft).padding(12.dp))
        Agent.Role.AGENT -> {
            val p = m.proposal
            Column(Modifier.widthIn(max = 320.dp).background(C.Surface).then(if (p != null) Modifier.border(1.5.dp, C.Ink) else Modifier).padding(12.dp)) {
                Text(m.text, style = T.Body.copy(color = C.Ink))
                if (p != null) {
                    Spacer(Modifier.height(10.dp))
                    when (p.state) {
                        0 -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PrimaryButton("Да", { ag.answer(p, true) }, Modifier.weight(1f), height = 46.dp)
                            SecondaryButton("Нет", { ag.answer(p, false) }, Modifier.weight(1f), height = 46.dp)
                        }
                        1 -> Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Ic.Check, null, tint = C.Pine, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp))
                            Text("Сделано", style = T.Small.copy(color = C.Pine))
                        }
                        else -> Text("Отменено", style = T.Small)
                    }
                }
            }
        }
    }
}
