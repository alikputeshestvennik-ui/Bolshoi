package ru.marshrut.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ru.marshrut.Agent
import ru.marshrut.AppVm
import ru.marshrut.EquipDir
import ru.marshrut.Kind
import ru.marshrut.Point
import ru.marshrut.Row as SheetRow
import ru.marshrut.Screen
import ru.marshrut.dial
import ru.marshrut.fmt
import ru.marshrut.money
import ru.marshrut.toD

// ======================= Настройки =======================

@Composable
fun SettingsScreen(vm: AppVm) {
    val st = vm.st
    var mc by remember { mutableStateOf(st.modelChoice) }
    var gm by remember { mutableStateOf(st.gptModel) }
    var gpi by remember { mutableStateOf(st.gptPriceIn) }
    var gpo by remember { mutableStateOf(st.gptPriceOut) }
    var truck by remember { mutableStateOf(st.truck) }
    var osrm by remember { mutableStateOf(st.osrm) }
    var depot by remember { mutableStateOf(st.depot) }
    var cap by remember { mutableStateOf(st.capacity) }
    var wc by remember { mutableStateOf(st.withClient) }
    var rt by remember { mutableStateOf(st.endAtDepot) }
    var gps by remember { mutableStateOf(st.startFromGps) }
    var ab by remember { mutableStateOf(st.autoBackup) }
    var editorPass by remember { mutableStateOf("") }
    var ownerPass by remember { mutableStateOf("") }
    var showEditor by remember { mutableStateOf(false) }
    var showOwner by remember { mutableStateOf(false) }
    val clip = androidx.compose.ui.platform.LocalClipboardManager.current
    var askRestore by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Настройки", { vm.screen = Screen.HOME })
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(Modifier.fillMaxWidth().appear(0), padding = 20.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBubble(Ic.Sparkle, C.Sea, C.SeaSoft, 38.dp, 19.dp)
                    Spacer(Modifier.width(12.dp)); Text("Распознавание", style = T.H3)
                }
                Spacer(Modifier.height(16.dp))
                Text("Модель", style = T.Small)
                Spacer(Modifier.height(8.dp))
                Choice(listOf("deepseek" to "DeepSeek", "qwen" to "Qwen", "gemini" to "Gemini"), mc) { mc = it }
                Spacer(Modifier.height(8.dp))
                val keysOk = st.apiKey.isNotBlank() && ru.marshrut.BuildConfig.DEEPSEEK_MODEL.isNotBlank() && ru.marshrut.BuildConfig.QWEN_MODEL.isNotBlank()
                Text(if (keysOk) "Ключи Yandex вшиты в сборку ✓" else "В сборке нет ключей Yandex — проверьте секреты на GitHub", style = T.Small,
                    color = if (keysOk) C.Pine else C.Danger)
                if (mc == "gemini") {
                    Spacer(Modifier.height(8.dp))
                    val gptOk = st.gptKey.isNotBlank()
                    Text(if (gptOk) "Ключ gptunnel вшит в сборку ✓ · запасная модель — Qwen" else "В сборке нет ключа gptunnel — добавьте секрет GPTUNNEL_KEY",
                        style = T.Small, color = if (gptOk) C.Pine else C.Danger)
                    Spacer(Modifier.height(10.dp))
                    Field(gm, { gm = it }, "Модель gptunnel", placeholder = "gemini-3.1-flash-lite")
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Field(gpi, { gpi = it }, "₽ за 1000 вход", Modifier.weight(1f), placeholder = "0.05",
                            keyboard = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                        Field(gpo, { gpo = it }, "₽ за 1000 выход", Modifier.weight(1f), placeholder = "0.30",
                            keyboard = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    }
                    Text("Цены — со страницы модели на gptunnel; нужны только для счётчика расхода.", style = T.Small)
                }
                Spacer(Modifier.height(14.dp))
                UsageBlock(vm)
                Spacer(Modifier.height(14.dp))
                ToggleRow("Читать клиента и адрес", "Незнакомый позывной сам станет точкой по адресу из листа. Распознаётся чуть дольше", wc) { wc = it }
            }
            Card(Modifier.fillMaxWidth().appear(1), padding = 20.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBubble(Ic.Route, C.Apricot, C.ApricotSoft, 38.dp, 19.dp)
                    Spacer(Modifier.width(12.dp)); Text("Маршрут", style = T.H3)
                }
                Spacer(Modifier.height(16.dp))
                Field(depot, { depot = it }, "Склад: широта, долгота", placeholder = "44.4952, 34.1663", leading = Ic.Locate)
                Spacer(Modifier.height(12.dp))
                ToggleRow("Старт от моего местоположения", "Маршрут начнётся там, где вы стоите, а не со склада", gps) { gps = it }
                Spacer(Modifier.height(12.dp))
                ToggleRow("Заканчивать на складе", "Последний отрезок — до склада, порядок точек учитывает обратную дорогу", rt) { rt = it }
                Spacer(Modifier.height(12.dp))
                Field(cap, { cap = it }, "Вместимость кузова, кг", keyboard = KeyboardOptions(keyboardType = KeyboardType.Number), leading = Ic.Weight)
                Spacer(Modifier.height(12.dp))
                ToggleRow("Грузовик (категория C)", "Дороги для грузовика: крупные трассы вместо горных второстепенных", truck) { truck = it }
                Spacer(Modifier.height(8.dp))
                Text(if (st.orsKey.isNotBlank()) "Дороги: OpenRouteService ✓, запасной — OSRM" else "Ключа ORS нет в сборке — дороги считаются через OSRM (только легковой профиль)",
                    style = T.Small, color = if (st.orsKey.isNotBlank()) C.Pine else C.Danger)
                Spacer(Modifier.height(12.dp))
                Field(osrm, { osrm = it }, "Запасной сервер дорог (OSRM)")
            }
            Card(Modifier.fillMaxWidth().appear(2), padding = 20.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBubble(Ic.Database, C.Pine, C.PineSoft, 38.dp, 19.dp)
                    Spacer(Modifier.width(12.dp)); Text("Копия на Яндекс Диске", style = T.H3)
                }
                Spacer(Modifier.height(8.dp))
                Text("База точек и история маршрутов сохраняются на вашем Диске в папку «Приложения». Если телефон потеряется или сбросится — всё вернётся одной кнопкой.",
                    style = T.Small)
                Spacer(Modifier.height(16.dp))
                if (vm.cloudConnected) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Яндекс Диск подключён ✓", style = T.BodyStrong, modifier = Modifier.weight(1f))
                        GhostButton("Выйти", { vm.yandexLogout() })
                    }
                } else {
                    PrimaryButton("Войти через Яндекс", { vm.yandexLogin() }, Modifier.fillMaxWidth(), icon = Ic.User, height = 52.dp)
                }
                Spacer(Modifier.height(12.dp))
                ToggleRow("Сохранять автоматически", "После каждого маршрута и при сворачивании приложения, если что-то изменилось", ab) { ab = it; st.autoBackup = it }
                Spacer(Modifier.height(12.dp))
                val err = vm.backupError
                Text(
                    when {
                        err != null -> "Последняя попытка не удалась: $err"
                        vm.lastBackup > 0 -> "Последняя копия: " + java.text.SimpleDateFormat("d MMMM, HH:mm", java.util.Locale("ru")).format(java.util.Date(vm.lastBackup))
                        else -> "Копий ещё не было"
                    },
                    style = T.Small, color = if (err != null) C.Danger else C.Ink2
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecondaryButton("Сохранить", { vm.backup(manual = true) }, Modifier.weight(1f), icon = Ic.Export, enabled = vm.cloudConnected)
                    SecondaryButton("Восстановить", { askRestore = true }, Modifier.weight(1f), icon = Ic.Import, enabled = vm.cloudConnected)
                }
            }
            Card(Modifier.fillMaxWidth().appear(3), padding = 20.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBubble(Ic.Truck, C.Pine, C.PineSoft, 38.dp, 19.dp)
                    Spacer(Modifier.width(12.dp)); Text("Общая база", style = T.H3)
                }
                Spacer(Modifier.height(8.dp))
                val hasShared = st.shared != null || vm.preparedShared != null
                if (!hasShared) {
                    Text("В этой сборке общей базы нет — база точек только своя.", style = T.Small)
                } else {
                    Text(if (vm.isEditor) "Режим: редактор. Ваши правки точек уходят всем водителям."
                        else "Режим: только чтение. База сама обновляется при запуске и раз в час.", style = T.BodyStrong)
                    Spacer(Modifier.height(6.dp))
                    val serr = vm.syncError
                    Text(
                        when {
                            serr != null -> "Последняя попытка не удалась: $serr"
                            vm.lastSync > 0 -> "Проверено: " + java.text.SimpleDateFormat("d MMMM, HH:mm", java.util.Locale("ru")).format(java.util.Date(vm.lastSync))
                            else -> "Ещё не проверялось"
                        },
                        style = T.Small, color = if (serr != null) C.Danger else C.Ink2
                    )
                    Spacer(Modifier.height(12.dp))
                    SecondaryButton(if (vm.isEditor) "Выложить изменения" else "Проверить обновления", { vm.sync(manual = true) },
                        Modifier.fillMaxWidth(), icon = Ic.Route)
                    Spacer(Modifier.height(12.dp))
                    Spacer(Modifier.height(4.dp))
                    if (vm.isEditor) {
                        SecondaryButton("Редактировать базу", { vm.openDbEditor() }, Modifier.fillMaxWidth(), icon = Ic.Edit)
                        Spacer(Modifier.height(4.dp))
                        GhostButton("Выйти из режима редактора", { vm.leaveEditor() })
                    } else if (!showEditor) {
                        GhostButton("Я редактор", { showEditor = true }, icon = Ic.Edit)
                    } else {
                        Spacer(Modifier.height(8.dp))
                        Field(editorPass, { editorPass = it }, "Пароль редактора", password = true,
                            keyboard = KeyboardOptions(keyboardType = KeyboardType.Password))
                        Spacer(Modifier.height(8.dp))
                        SecondaryButton("Войти как редактор", { vm.becomeEditor(editorPass); editorPass = ""; showEditor = false },
                            Modifier.fillMaxWidth(), icon = Ic.Edit)
                    }
                }
                // Владелец (вошёл в Яндекс выше): подготовка общей базы — пока её нет, или по ссылке «Сменить пароль»
                // Чужой аккаунт Яндекса (не тот, где лежит база из сборки) блока владельца не видит
                val ownerUi = vm.cloudConnected && (!hasShared || vm.isOwner)
                if (ownerUi && hasShared && !showOwner) {
                    GhostButton("Сменить пароль редактора", { showOwner = true }, icon = Ic.Sliders)
                }
                if (ownerUi && (!hasShared || showOwner)) {
                    Spacer(Modifier.height(14.dp))
                    Text("ДЛЯ ВЛАДЕЛЬЦА", style = T.Label)
                    Spacer(Modifier.height(6.dp))
                    Text(if (hasShared) "Новый пароль заменит старый после пересборки APK: обновите секрет SHARED_DB новой строкой."
                        else "Придумайте пароль редактора (от 6 символов) и подготовьте общую базу. Получится строка — добавьте её в GitHub секретом SHARED_DB и пересоберите APK.",
                        style = T.Small)
                    Spacer(Modifier.height(10.dp))
                    Field(ownerPass, { ownerPass = it }, "Пароль редактора", password = true,
                        keyboard = KeyboardOptions(keyboardType = KeyboardType.Password))
                    Spacer(Modifier.height(8.dp))
                    SecondaryButton("Подготовить общую базу", { vm.prepareShared(ownerPass); ownerPass = "" }, Modifier.fillMaxWidth(), icon = Ic.Export)
                    vm.preparedShared?.let { line ->
                        Spacer(Modifier.height(10.dp))
                        Text("Строка для секрета SHARED_DB готова. Пароль в ней не хранится.", style = T.Small)
                        Spacer(Modifier.height(6.dp))
                        PrimaryButton("Скопировать строку", { clip.setText(androidx.compose.ui.text.AnnotatedString(line)); vm.info = "Скопировано" },
                            Modifier.fillMaxWidth(), icon = Ic.Check, height = 52.dp)
                    }
                }
            }
        }
        PrimaryButton("Сохранить", {
            st.withClient = wc; st.modelChoice = mc; st.gptModel = gm; st.gptPriceIn = gpi; st.gptPriceOut = gpo; st.truck = truck; st.osrm = osrm; st.depot = depot
            st.capacity = cap; st.endAtDepot = rt; st.startFromGps = gps
            vm.screen = Screen.HOME
        }, Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), icon = Ic.Check)
    }
    if (askRestore) ConfirmDialog(
        title = "Восстановить с Диска?",
        text = "База точек и история маршрутов в телефоне заменятся копией с Яндекс Диска. Текущий маршрут не пострадает.",
        confirm = "Восстановить",
        onConfirm = { askRestore = false; vm.restore() },
        onDismiss = { askRestore = false }
    )
    vm.yaCode?.let { YandexCodeDialog(it.userCode, it.url, onCancel = vm::cancelLogin) }
}

/** Вход в Яндекс по коду: показываем код, открываем страницу ввода, ждём подтверждения. */
@Composable
private fun YandexCodeDialog(code: String, url: String, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    val clip = androidx.compose.ui.platform.LocalClipboardManager.current
    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(Modifier.fillMaxWidth().padding(16.dp).border(1.dp, C.Ink), padding = 22.dp, fullBleed = false) {
            Text("Вход через Яндекс", style = T.H2)
            Spacer(Modifier.height(8.dp))
            Text("Откройте страницу Яндекса, войдите в свой аккаунт и введите этот код. Код уже скопирован — его можно вставить.", style = T.Body)
            Spacer(Modifier.height(18.dp))
            Box(Modifier.fillMaxWidth().background(C.Field).padding(vertical = 18.dp), contentAlignment = Alignment.Center) {
                Text(code, style = T.H1.copy(letterSpacing = 4.sp))
            }
            Spacer(Modifier.height(18.dp))
            PrimaryButton("Открыть страницу Яндекса", {
                clip.setText(androidx.compose.ui.text.AnnotatedString(code))
                ru.marshrut.openUrl(ctx, url)
            }, Modifier.fillMaxWidth(), icon = Ic.ArrowRight)
            Spacer(Modifier.height(10.dp))
            Text("Ждём подтверждения… Когда разрешите доступ, вернитесь в приложение — окно закроется само.", style = T.Small)
            Spacer(Modifier.height(4.dp))
            GhostButton("Отмена", onCancel, Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

/** Переключатель из нескольких вариантов (выбор модели). */
@Composable
private fun Choice(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (id, label) ->
            val on = id == selected
            Box(
                Modifier.weight(1f).height(46.dp).background(if (on) C.Ink else C.Field).pressable { onSelect(id) },
                contentAlignment = Alignment.Center
            ) { Text(label, style = T.BodyStrong, color = if (on) Color.White else C.Ink) }
        }
    }
}

@Composable
private fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.weight(1f)) {
            Text(title, style = T.BodyStrong)
            Text(sub, style = T.Small)
        }
        Spacer(Modifier.width(12.dp))
        Toggle(checked, onChange)
    }
}

// ======================= Проверка листа =======================

private fun kindIcon(k: Kind): ImageVector = when (k) { Kind.GOODS -> Ic.Box; Kind.RETURN -> Ic.Return; Kind.EQUIPMENT -> Ic.Fridge }
private fun kindFg(k: Kind): Color = when (k) { Kind.GOODS -> C.Ink2; else -> Color.White }
private fun kindBg(k: Kind): Color = when (k) { Kind.GOODS -> C.Field; else -> C.Ink }

@OptIn(ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
fun ReviewScreen(vm: AppVm) {
    var open by remember { mutableStateOf<Int?>(null) }
    var agOpen by remember { mutableStateOf(false) }
    var gOpen by remember { mutableStateOf<String?>(null) }
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        TopBar("Проверка листа", { vm.screen = Screen.HOME }, subtitle = vm.header.ifBlank { null }) {
            RoundIconButton(Ic.Sort, { vm.sortByAgent = !vm.sortByAgent }, tint = if (vm.sortByAgent) C.Sea else C.Ink)
        }
        val shown = if (vm.sortByAgent) vm.rows.sortedWith(compareBy({ vm.agentFor(it.agent)?.name ?: "яяя" }, { it.callsign })) else vm.rows.toList()
        val groups = remember(vm.rows.toList(), vm.dbVer, vm.agents.toList()) { vm.reviewGroups() }
        val newCount = groups.count { it.kind == AppVm.RGroup.NEW }
        val pinnedCount = groups.count { it.kind == AppVm.RGroup.NEW && it.key in vm.pins }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(key = "summary") {
                val sum = vm.rows.sumOf { it.weight }
                val tot = listOfNotNull(vm.total, vm.totalNoSg)
                val ok = tot.isEmpty() || tot.any { kotlin.math.abs(it - sum) < 0.5 }
                Card(Modifier.fillMaxWidth().appear(0), radius = 24.dp, padding = 18.dp) {
                    Row {
                        StatBlock(vm.rows.size.toString(), plural(vm.rows.size, "строка", "строки", "строк"), Modifier.weight(1f))
                        StatBlock(fmt(sum), "кг по строкам", Modifier.weight(1.3f))
                        StatBlock(if (tot.isEmpty()) "—" else fmt(tot.first()), "итого в листе", Modifier.weight(1.3f))
                    }
                    if (tot.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        Pill(if (ok) "Вес сходится с итогом" else "Вес не сходится — проверьте строки",
                            if (ok) C.Pine else C.Danger, if (ok) C.PineSoft else C.DangerSoft, if (ok) Ic.Check else Ic.Warning)
                    }
                    if (!vm.sortByAgent) {
                        Spacer(Modifier.height(10.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Pill("Точек: ${groups.count { it.kind != AppVm.RGroup.SKIP }}", C.Ink2, C.Field, Ic.Pin)
                            if (newCount > 0) Pill(if (pinnedCount == newCount) "Новые точки отмечены: $newCount"
                                else "Новых точек: $newCount — уточните на карте", Color.White, if (pinnedCount == newCount) C.Pine else C.Danger, Ic.Warning)
                        }
                    }
                    val ret = vm.rows.count { it.kind == Kind.RETURN }
                    val eq = vm.rows.count { it.kind == Kind.EQUIPMENT }
                    val ro = vm.returnOnlyCount
                    if (ret + eq + ro > 0) {
                        Spacer(Modifier.height(10.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (ret > 0) Pill("Возвратов: $ret", C.Apricot, C.ApricotSoft, Ic.Return)
                            if (eq > 0) Pill("Оборудование: $eq", C.Lavender, C.LavenderSoft, Ic.Fridge)
                            if (ro > 0) Pill("Без товара, не едем: $ro", C.Ink2, C.Field, Ic.Skip)
                        }
                    }
                }
            }
            item(key = "agents") {
                Card(Modifier.fillMaxWidth().appear(1), radius = 20.dp, padding = 16.dp) {
                    Row(Modifier.fillMaxWidth().pressable(scaleTo = 0.985f) { agOpen = !agOpen }, verticalAlignment = Alignment.CenterVertically) {
                        IconBubble(Ic.User, C.Ink2, C.Field, 38.dp, 19.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Агенты", style = T.H3)
                            Text(vm.agents.joinToString(", ") { "${it.num} ${it.name}".trim() }.ifBlank { "Не найдены" }, style = T.Small,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Chevron(agOpen)
                    }
                    Expand(agOpen) {
                        Column(Modifier.padding(top = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            vm.agents.forEachIndexed { i, a -> AgentEditor(a, { vm.agents[i] = it }, { vm.agents.removeAt(i) }) { dial(ctx, a.phone) } }
                            GhostButton("Добавить агента", { vm.agents.add(Agent()) }, icon = Ic.Plus, tint = C.Sea)
                        }
                    }
                }
            }
            if (vm.sortByAgent) items(shown, key = { it.id }) { r ->
                RowCard(vm, r, open == r.id, { open = if (open == r.id) null else r.id }, Modifier.animateItem())
            } else {
                // Накладные сразу разложены по точкам: новые точки выделены и уточняются на карте до маршрута
                items(groups, key = { it.key }) { g ->
                    GroupCard(vm, g, gOpen == g.key, { gOpen = if (gOpen == g.key) null else g.key }, open, { id -> open = if (open == id) null else id },
                        Modifier.animateItem())
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SecondaryButton("Довоз", { vm.addRow() }, Modifier.weight(1f), icon = Ic.Plus, height = 58.dp)
            PrimaryButton("Сопоставить точки", { vm.startMatch() }, Modifier.weight(2f), icon = Ic.ArrowRight, enabled = vm.rows.isNotEmpty() && vm.busy == null)
        }
    }
}

@Composable
private fun Chevron(open: Boolean) {
    val rot by androidx.compose.animation.core.animateFloatAsState(if (open) 180f else 0f, spring(dampingRatio = 0.7f), label = "chev")
    Icon(Ic.ChevronDown, null, tint = C.Mute, modifier = Modifier.size(22.dp).rotate(rot))
}

@Composable
private fun AgentEditor(a: Agent, onChange: (Agent) -> Unit, onDelete: () -> Unit, onCall: () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RectangleShape).background(C.Field).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field(a.num, { onChange(a.copy(num = it)) }, "№", Modifier.width(72.dp))
            Field(a.name, { onChange(a.copy(name = it)) }, "Имя", Modifier.weight(1f))
        }
        Field(a.phone, { onChange(a.copy(phone = it)) }, "Телефон", keyboard = KeyboardOptions(keyboardType = KeyboardType.Phone))
        Row {
            if (a.phone.isNotBlank()) GhostButton("Позвонить", onCall, icon = Ic.Phone, tint = C.Pine)
            Spacer(Modifier.weight(1f))
            GhostButton("Удалить", onDelete, icon = Ic.Trash, tint = C.Danger)
        }
    }
}

/** Остановка: все накладные одной точки. Новая точка — красная рамка и кнопка «Уточнить на карте». */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun GroupCard(vm: AppVm, g: AppVm.RGroup, open: Boolean, onToggle: () -> Unit, rowOpen: Int?, onRow: (Int) -> Unit, modifier: Modifier) {
    val isNew = g.kind == AppVm.RGroup.NEW
    val pinned = vm.pins[g.key]
    var mapAt by remember(g.key) { mutableStateOf<Pair<Double, Double>?>(null) }
    val accent = when {
        isNew && pinned == null -> C.Danger
        isNew -> C.Pine
        g.kind == AppVm.RGroup.MANUAL -> C.Apricot
        else -> Color.Transparent
    }
    Card(modifier.fillMaxWidth(), radius = 20.dp, padding = 0.dp, elevation = if (open) 14.dp else 6.dp) {
        Column(Modifier.border(if (accent == Color.Transparent) 0.dp else 2.dp, accent, RectangleShape)
            .background(if (isNew && pinned == null) C.DangerSoft else Color.Transparent).padding(16.dp)) {
            Row(Modifier.fillMaxWidth().pressable(scaleTo = 0.985f, onClick = onToggle), verticalAlignment = Alignment.CenterVertically) {
                IconBubble(if (isNew) Ic.Plus else if (g.kind == AppVm.RGroup.SKIP) Ic.Skip else Ic.Pin,
                    if (isNew || g.kind == AppVm.RGroup.KNOWN) Color.White else C.Ink2,
                    when { isNew && pinned == null -> C.Danger; isNew -> C.Pine; g.kind == AppVm.RGroup.KNOWN -> C.Ink; else -> C.Field }, 42.dp, 20.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(g.title, style = T.H3, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (g.address.isNotBlank()) Text(g.address, style = T.Small, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Spacer(Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.End) {
                    Text(fmt(g.weight), style = T.Num.copy(fontSize = 18.sp))
                    Text("${g.rows.size} " + plural(g.rows.size, "накл.", "накл.", "накл."), style = T.Small)
                }
            }
            Spacer(Modifier.height(10.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                when (g.kind) {
                    AppVm.RGroup.NEW -> Pill(if (pinned == null) "Новая точка — нет в базе" else "Новая точка · место отмечено", Color.White,
                        if (pinned == null) C.Danger else C.Pine, if (pinned == null) Ic.Warning else Ic.Check)
                    AppVm.RGroup.MANUAL -> Pill("Выбор точки вручную", C.Apricot, C.ApricotSoft, Ic.Pin)
                    AppVm.RGroup.SKIP -> Pill("Только возврат — не едем", C.Ink2, C.Field, Ic.Skip)
                }
                g.callsigns.forEach { Pill(it, C.Ink2, C.Field) }
                val fact = g.rows.sumOf { it.factSum }
                if (fact != 0.0) Pill("Факт ${money(fact)}", C.Pine, C.PineSoft, Ic.Cash)
            }
            if (isNew) {
                Spacer(Modifier.height(12.dp))
                PrimaryButton(if (pinned == null) "Уточнить на карте" else "Переставить метку", {
                    if (pinned != null) mapAt = pinned else vm.mapStart(g.address) { mapAt = it }
                }, Modifier.fillMaxWidth(), icon = Ic.Map, height = 52.dp)
            }
            Expand(open) {
                Column(Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    g.rows.forEach { r -> RowCard(vm, r, rowOpen == r.id, { onRow(r.id) }, Modifier) }
                }
            }
        }
    }
    mapAt?.let { start ->
        MapPickerDialog(g.title, start, onPick = { la, lo -> vm.pinNew(g, la, lo); mapAt = null }, onDismiss = { mapAt = null })
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RowCard(vm: AppVm, r: SheetRow, open: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    val ctx = LocalContext.current
    val k = r.kind
    val border by animateColorAsState(if (open) C.SeaBright else Color.Transparent, tween(200), label = "rb")
    Card(modifier.fillMaxWidth(), radius = 20.dp, padding = 0.dp, elevation = if (open) 14.dp else 6.dp) {
        Column(Modifier.border(1.5.dp, border, RectangleShape).padding(16.dp)) {
            Row(Modifier.fillMaxWidth().pressable(scaleTo = 0.985f, onClick = onToggle), verticalAlignment = Alignment.CenterVertically) {
                IconBubble(kindIcon(k), kindFg(k), kindBg(k), 42.dp, 20.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(r.callsign.ifBlank { "Без позывного" }, style = T.H3, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        if (vm.sortByAgent) (vm.agentFor(r.agent)?.name?.ifBlank { null } ?: "Агент не найден") else r.invoiceLabel,
                        style = T.Small, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.End) {
                    Text(fmt(r.weight), style = T.Num.copy(fontSize = 18.sp))
                    Text("кг", style = T.Small)
                }
            }
            val flags = r.factSum != 0.0 || r.calc.uppercase().contains("ЧЗ") || vm.manual(r)
            if (flags) {
                Spacer(Modifier.height(10.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (r.factSum != 0.0) Pill("Факт ${money(r.factSum)}", C.Pine, C.PineSoft, Ic.Cash)
                    if (r.calc.isNotBlank()) Pill(r.calc, C.Ink2, C.Field)
                    if (vm.manual(r)) Pill("Выбор точки вручную", C.Apricot, C.ApricotSoft, Ic.Pin)
                }
            }
            Expand(open) {
                var w by remember(r.id) { mutableStateOf(fmt(r.weight)) }
                Column(Modifier.padding(top = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Field(r.callsign, { vm.update(r.copy(callsign = it)) }, "Позывной")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Field(w, { w = it; vm.update(r.copy(weight = it.toD() ?: 0.0)) }, "Вес, кг", Modifier.weight(1f),
                            keyboard = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                        Field(r.fact, { vm.update(r.copy(fact = it)) }, "Факт", Modifier.weight(1f),
                            keyboard = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Field(r.calc, { vm.update(r.copy(calc = it)) }, "Расчёт", Modifier.weight(1f))
                        Field(r.agent, { vm.update(r.copy(agent = it)) }, "Агент №", Modifier.weight(1f))
                    }
                    Field(r.invoice, { vm.update(r.copy(invoice = it)) }, "Накладная", singleLine = false)
                    Field(r.notes, { vm.update(r.copy(notes = it)) }, "Заметки", singleLine = false)
                    Field(r.client, { vm.update(r.copy(client = it)) }, "Клиент", singleLine = false)
                    Field(r.address, { vm.update(r.copy(address = it)) }, "Адрес", singleLine = false)
                    if (r.sum.isNotBlank()) Text("Сумма накладной: ${r.sum}", style = T.Small)
                    Row {
                        vm.contactsOf(r).filter { it.phone.isNotBlank() }.forEach { a ->
                            GhostButton(a.name.ifBlank { a.num }, { dial(ctx, a.phone) }, icon = Ic.Phone, tint = C.Pine)
                        }
                        Spacer(Modifier.weight(1f))
                        GhostButton("Удалить", { vm.delRow(r.id) }, icon = Ic.Trash, tint = C.Danger)
                    }
                }
            }
        }
    }
}

// ======================= Сопоставление =======================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MatchScreen(vm: AppVm) {
    @Suppress("UNUSED_VARIABLE") val v = vm.dbVer
    val rowId = vm.queue.getOrNull(vm.qi) ?: return
    val r = vm.rows.firstOrNull { it.id == rowId } ?: return
    val ctx = LocalContext.current
    var creating by remember(rowId) { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Точка для строки", { vm.backMatch() }, subtitle = "${vm.qi + 1} из ${vm.queue.size}")
        SegmentedProgress(vm.queue.size, vm.qi, Modifier.padding(horizontal = 20.dp))
        AnimatedContent(
            targetState = rowId,
            transitionSpec = {
                (androidx.compose.animation.slideInHorizontally(spring(dampingRatio = 0.85f, stiffness = 400f)) { it / 3 } +
                    androidx.compose.animation.fadeIn(tween(220)))
                    .togetherWith(androidx.compose.animation.slideOutHorizontally(tween(220)) { -it / 4 } + androidx.compose.animation.fadeOut(tween(160)))
            },
            modifier = Modifier.weight(1f),
            label = "match"
        ) { id ->
            val row = vm.rows.firstOrNull { it.id == id } ?: return@AnimatedContent
            var q by remember(id) { mutableStateOf(row.client.trim().split(" ").firstOrNull().orEmpty()) }
            val suspicious = vm.manual(row)
            val suggested = if (row.callsign.isBlank()) null else vm.db.pointFor(row.callsign)
            val hits = vm.db.points.filter { q.isBlank() || it.name.contains(q, true) || it.address.contains(q, true) || it.title.contains(q, true) }
                .filter { it.name != suggested?.name }.take(8)
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(top = 16.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Card(Modifier.fillMaxWidth(), radius = 26.dp, padding = 20.dp) {
                    Text(row.callsign.ifBlank { "Без позывного" }, style = T.H1)
                    if (row.client.isNotBlank() || row.address.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(listOf(row.client, row.address).filter { it.isNotBlank() }.joinToString(", "), style = T.Body)
                    }
                    Spacer(Modifier.height(12.dp))
                    val group = vm.groupOf(id)
                    if (group.size > 1) {
                        // Одна точка на всю группу: показываем все накладные
                        Text("${group.size} " + plural(group.size, "накладная", "накладные", "накладных") + " — точка выбирается для всех сразу", style = T.Small)
                        Spacer(Modifier.height(8.dp))
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        group.forEach { g -> Pill(g.invoiceLabel, kindFg(g.kind), kindBg(g.kind), kindIcon(g.kind)) }
                        Pill("${fmt(group.sumOf { it.weight })} кг", C.Ink2, C.Field, Ic.Weight)
                        group.sumOf { it.factSum }.let { f -> if (f != 0.0) Pill("Факт ${money(f)}", C.Pine, C.PineSoft, Ic.Cash) }
                        if (row.calc.isNotBlank()) Pill(row.calc, C.Ink2, C.Field)
                        vm.contactsOf(row).forEach { a -> Pill(a.name.ifBlank { "Агент ${a.num}" }, C.Ink2, C.Field, Ic.User) }
                    }
                    if (row.visibleNotes.isNotBlank()) { Spacer(Modifier.height(10.dp)); Text(row.visibleNotes, style = T.Small) }
                    vm.contactsOf(row).filter { it.phone.isNotBlank() }.forEach { a ->
                        GhostButton("Позвонить: ${a.name.ifBlank { a.num }}", { dial(ctx, a.phone) }, icon = Ic.Phone, tint = C.Pine)
                    }
                }
                Hint(
                    when {
                        suspicious -> "Есть факт или ЧЗ — выбор не сохранится в базу. Выберите точку вручную или подтвердите по позывному."
                        row.address.isNotBlank() -> "Позывного нет в базе, а адрес «${row.address.trim()}» не нашёлся на карте. Выберите точку или создайте новую."
                        else -> "Позывного нет в базе. Выберите точку — связь сохранится для следующих листов."
                    },
                    if (suspicious) C.Apricot else C.Sea, if (suspicious) C.ApricotSoft else C.SeaSoft
                )
                if (suggested != null) {
                    SectionLabel("По позывному")
                    PointRow(suggested, highlighted = !suspicious) { vm.choose(id, suggested.name) }
                }
                Field(q, { q = it }, "Поиск в базе", leading = Ic.Search, placeholder = "Название или адрес")
                hits.forEachIndexed { i, p -> PointRow(p, false, Modifier.appear(i, p.name)) { vm.choose(id, p.name) } }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SecondaryButton("Новая точка", { creating = true }, Modifier.weight(1f), icon = Ic.Plus, tint = C.Sea)
                    SecondaryButton("Не везём", { vm.skip() }, Modifier.weight(1f), icon = Ic.Skip, tint = C.Ink2)
                }
                if (suspicious) {
                    // Документ с фактом/ЧЗ: товар может забрать торговый — тогда в объезд не включаем
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(C.seaGradient)
                            .shimmer(true, 0.12f).pressable { vm.agentTakes(id) }.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconBubble(Ic.User, C.Ink, Color.White, 40.dp, 20.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Заберёт торговый", style = T.H3.copy(color = Color.White))
                            Text(
                                vm.contactsOf(row).firstOrNull()?.name?.ifBlank { null }?.let { "$it — в объезд не включаем" } ?: "В объезд не включаем",
                                style = T.Small.copy(color = Color.White.copy(alpha = 0.65f))
                            )
                        }
                        Icon(Ic.ChevronRight, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
    }
    if (creating) NewPointDialog(vm, r.callsign, r.client, r.address, { creating = false }) { creating = false; vm.createPoint(rowId, it) }
}

/** После построения маршрута: точки, найденные по адресу из листа, — добавить ли их в базу. */
@Composable
fun NewPointsDialog(vm: AppVm) {
    val items = vm.newPoints.toList()
    val chosen = remember(items) { androidx.compose.runtime.mutableStateListOf(*items.map { true }.toTypedArray()) }
    // По одному адресу несколько клиентов: по умолчанию одна общая точка
    val together = remember(items) { androidx.compose.runtime.mutableStateListOf(*items.map { true }.toTypedArray()) }
    Dialog(onDismissRequest = { vm.newPoints.clear() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(Modifier.fillMaxWidth().padding(16.dp).border(1.dp, C.Ink), padding = 22.dp, fullBleed = false) {
            Text("Новые точки", style = T.H2)
            Spacer(Modifier.height(6.dp))
            Text("Этих позывных не было в базе — точки взяты из листа по клиенту и адресу и уже в маршруте. " +
                "Координаты найдены по адресу автоматически: проверьте на карте. Добавить в базу?", style = T.Body)
            Spacer(Modifier.height(14.dp))
            Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items.forEachIndexed { i, np ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(np.point.title, style = T.BodyStrong, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(listOf(np.callsigns.joinToString(", "), np.point.address).filter { it.isNotBlank() }.joinToString(" · "),
                                style = T.Small, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            np.approx?.let { Text("Приблизительно: $it", style = T.Small, color = C.Danger) }
                        }
                        Spacer(Modifier.width(12.dp))
                        Toggle(chosen[i]) { chosen[i] = it }
                    }
                    if (np.members.size > 1 && chosen[i]) {
                        Row(Modifier.fillMaxWidth().background(C.Field).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Один адрес — ${np.members.size} " + plural(np.members.size, "клиент", "клиента", "клиентов"), style = T.BodyStrong)
                                Text(if (together[i]) "Объединить в одну точку: в рейсе это одна остановка"
                                    else "Раздельно: ${np.members.joinToString(", ") { it.client }}", style = T.Small)
                            }
                            Spacer(Modifier.width(12.dp))
                            Toggle(together[i]) { together[i] = it }
                        }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            val n = chosen.count { it }
            PrimaryButton(if (n > 0) "Добавить в базу ($n)" else "Ничего не добавлять", {
                vm.addNewPoints(items.filterIndexed { i, _ -> chosen[i] }, items.filterIndexed { i, _ -> !together[i] }.toSet())
            }, Modifier.fillMaxWidth(), icon = Ic.Plus)
            Spacer(Modifier.height(4.dp))
            GhostButton("Не сейчас", { vm.newPoints.clear() }, Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@Composable
private fun Hint(text: String, fg: Color, bg: Color) {
    Row(Modifier.fillMaxWidth().clip(RectangleShape).background(bg).padding(14.dp), verticalAlignment = Alignment.Top) {
        Icon(Ic.Warning, null, tint = fg, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, style = T.Body.copy(color = C.Ink, fontSize = 14.sp))
    }
}

@Composable
private fun PointRow(p: Point, highlighted: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RectangleShape
    Row(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (highlighted) C.Sea else C.Surface)
            .border(1.dp, if (highlighted) C.Sea else C.Line, shape)
            .pressable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBubble(Ic.Pin, if (highlighted) C.Sea else C.Ink2, if (highlighted) Color.White else C.Field, 38.dp, 19.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.display, style = T.H3.copy(color = if (highlighted) Color.White else C.Ink), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(listOf(p.name, p.address).filter { it.isNotBlank() }.joinToString(", "),
                style = T.Small.copy(color = if (highlighted) Color.White.copy(alpha = 0.8f) else C.Mute), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(if (highlighted) Ic.Check else Ic.ChevronRight, null, tint = if (highlighted) Color.White else C.Mute, modifier = Modifier.size(20.dp))
    }
}

@Composable
fun NewPointDialog(vm: AppVm, callsign: String, initName: String, initAddr: String, onClose: () -> Unit, onOk: (Point) -> Unit) {
    var code by remember { mutableStateOf("") }
    var name by remember { mutableStateOf(initName) }
    var addr by remember { mutableStateOf(initAddr) }
    var lat by remember { mutableStateOf("") }
    var lon by remember { mutableStateOf("") }
    var comment by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(Modifier.fillMaxWidth().padding(16.dp).appear(0).border(1.dp, C.Ink), padding = 20.dp, fullBleed = false) {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Новая точка", style = T.H2)
                if (callsign.isNotBlank()) Text("Позывной $callsign", style = T.Small)
                Field(code, { code = it }, "Код точки", placeholder = "Например, 105я")
                Field(name, { name = it }, "Название")
                Field(addr, { addr = it }, "Адрес", singleLine = false)
                SecondaryButton("Найти координаты по адресу", {
                    msg = "Ищем…"
                    vm.geocode(addr) { c ->
                        if (c == null) msg = "Адрес не найден — проверьте написание или введите координаты вручную"
                        else { lat = c.lat.toString(); lon = c.lon.toString(); msg = c.note?.let { "Найдено приблизительно: $it. Уточните координаты" } ?: "Координаты найдены" }
                    }
                }, Modifier.fillMaxWidth(), icon = Ic.Locate, tint = C.Sea)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Field(lat, { lat = it }, "Широта", Modifier.weight(1f), keyboard = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    Field(lon, { lon = it }, "Долгота", Modifier.weight(1f), keyboard = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                }
                Field(comment, { comment = it }, "Комментарий к выгрузке", singleLine = false, leading = Ic.Note)
                if (msg.isNotEmpty()) Text(msg, style = T.Small.copy(color = C.Sea))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SecondaryButton("Отмена", onClose, Modifier.weight(1f))
                    PrimaryButton("Создать", {
                        val la = lat.toD(); val lo = lon.toD()
                        val id = code.trim().ifBlank { name.trim() }
                        if (id.isBlank() || la == null || lo == null) msg = "Нужны код или название и координаты"
                        else onOk(Point(id, addr.trim(), la, lo, name.trim(), comment.trim()))
                    }, Modifier.weight(1f), height = 54.dp)
                }
            }
        }
    }
}

// ======================= Оборудование =======================

@Composable
fun EquipScreen(vm: AppVm) {
    val list = vm.equipRows
    val left = list.count { it.equip == EquipDir.UNKNOWN }
    Column(Modifier.fillMaxSize()) {
        TopBar("Оборудование", { vm.screen = Screen.REVIEW }, subtitle = "Уточните: забираем или доставляем")
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 6.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            itemsIndexed(list, key = { _, r -> r.id }) { i, r ->
                val p = vm.pointOf(r.id)
                Card(Modifier.fillMaxWidth().appear(i, r.id), radius = 24.dp, padding = 18.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBubble(Ic.Fridge, C.Lavender, C.LavenderSoft)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p?.display ?: r.callsign.ifBlank { "Точка" }, style = T.H3, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(listOf(r.callsign, p?.address.orEmpty()).filter { it.isNotBlank() }.joinToString(", "), style = T.Small, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Column(Modifier.fillMaxWidth().clip(RectangleShape).background(C.LavenderSoft).padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Ic.Note, null, tint = C.Lavender, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Заметка из листа", style = T.Small.copy(color = C.Lavender))
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(r.visibleNotes.ifBlank { "Заметки нет — уточните у агента" }, style = T.BodyStrong)
                        if (r.invoice.isNotBlank()) { Spacer(Modifier.height(4.dp)); Text(r.invoice, style = T.Small) }
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Choice("Забираем", Ic.Import, r.equip == EquipDir.PICKUP, Modifier.weight(1f)) { vm.setEquip(r.id, EquipDir.PICKUP) }
                        Choice("Доставляем", Ic.Export, r.equip == EquipDir.DELIVER, Modifier.weight(1f)) { vm.setEquip(r.id, EquipDir.DELIVER) }
                    }
                }
            }
        }
        PrimaryButton(
            if (left == 0) "Построить маршрут" else "Осталось уточнить: $left", vm::equipDone,
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), icon = Ic.Route, enabled = left == 0 && vm.busy == null
        )
    }
}

@Composable
private fun Choice(text: String, icon: ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) C.Lavender else C.Field, tween(220), label = "cb")
    val fg by animateColorAsState(if (selected) Color.White else C.Ink2, tween(220), label = "cf")
    Row(
        modifier.height(54.dp).clip(RectangleShape).background(bg).pressable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(19.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, style = T.Button.copy(fontSize = 15.sp), color = fg)
    }
}


/** Расход нейросети: последний лист, сегодня, месяц и средняя цена листа — по данным самого Яндекса из ответов. */
@Composable
private fun UsageBlock(vm: AppVm) {
    @Suppress("UNUSED_VARIABLE") val ver = vm.usageVer
    val last = vm.usageLog.last; val day = vm.usageLog.today; val month = vm.usageLog.thisMonth
    fun rub(x: Double) = String.format(java.util.Locale("ru"), "%.2f ₽", x)
    fun k(x: Long) = if (x >= 10_000) "${x / 1000} тыс." else x.toString()
    Column(Modifier.fillMaxWidth().background(C.Field).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("РАСХОД НЕЙРОСЕТИ", style = T.Label)
        if (last.sheets == 0) Text("Появится после первого распознавания", style = T.Small)
        else {
            Text("Последний лист: ${rub(last.rub)}", style = T.BodyStrong)
            Text("${last.requests} " + plural(last.requests, "запрос", "запроса", "запросов") +
                " · вход ${k(last.input)} · выход ${k(last.output)}" +
                (if (last.reasoning > 0) " (из них рассуждение ${k(last.reasoning)})" else "") + " токенов", style = T.Small)
            vm.usageLog.lastLog.forEach { Text("· $it", style = T.Small.copy(color = C.Mute)) }
            Text("Сегодня: ${day.sheets} " + plural(day.sheets, "лист", "листа", "листов") + " · ${rub(day.rub)}", style = T.Small)
            Text("За месяц: ${month.sheets} " + plural(month.sheets, "лист", "листа", "листов") + " · ${rub(month.rub)}" +
                (if (month.sheets > 0) " · в среднем ${rub(month.rub / month.sheets)} за лист" else ""), style = T.Small)
        }
        Text("Цены Qwen 0,20 ₽ вход / 0,30 ₽ выход, DeepSeek 0,30 / 0,50 за 1000 токенов — из детализации Yandex Billing; Gemini — из настроек выше.",
            style = T.Small.copy(color = C.Mute))
    }
}
