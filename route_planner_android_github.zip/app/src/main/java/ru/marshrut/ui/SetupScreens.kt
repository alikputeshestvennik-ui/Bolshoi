package ru.marshrut.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ru.marshrut.Agent
import ru.marshrut.AppVm
import ru.marshrut.EquipDir
import ru.marshrut.Kind
import ru.marshrut.Point
import ru.marshrut.Row as SheetRow
import ru.marshrut.Screen
import ru.marshrut.dial
import ru.marshrut.fmt
import ru.marshrut.money
import ru.marshrut.toD

// ======================= Настройки =======================

@Composable
fun SettingsScreen(vm: AppVm) {
    val st = vm.st
    var key by remember { mutableStateOf(st.apiKey) }
    var folder by remember { mutableStateOf(st.folder) }
    var model by remember { mutableStateOf(st.model) }
    var osrm by remember { mutableStateOf(st.osrm) }
    var depot by remember { mutableStateOf(st.depot) }
    var cap by remember { mutableStateOf(st.capacity) }
    var wc by remember { mutableStateOf(st.withClient) }
    var rt by remember { mutableStateOf(st.endAtDepot) }
    var gps by remember { mutableStateOf(st.startFromGps) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Настройки", { vm.screen = Screen.HOME })
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(Modifier.fillMaxWidth().appear(0), padding = 20.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBubble(Ic.Sparkle, C.Sea, C.SeaSoft, 38.dp, 19.dp)
                    Spacer(Modifier.width(12.dp)); Text("Распознавание", style = T.H3)
                }
                Spacer(Modifier.height(16.dp))
                Field(key, { key = it }, "API-ключ Yandex AI Studio")
                Spacer(Modifier.height(12.dp))
                Field(folder, { folder = it }, "ID каталога")
                Spacer(Modifier.height(12.dp))
                Field(model, { model = it }, "Модель", singleLine = false)
                Spacer(Modifier.height(14.dp))
                ToggleRow("Читать клиента и адрес", "Удобно для новых точек, но распознаётся дольше", wc) { wc = it }
            }
            Card(Modifier.fillMaxWidth().appear(1), padding = 20.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBubble(Ic.Route, C.Apricot, C.ApricotSoft, 38.dp, 19.dp)
                    Spacer(Modifier.width(12.dp)); Text("Маршрут", style = T.H3)
                }
                Spacer(Modifier.height(16.dp))
                Field(depot, { depot = it }, "Склад: широта, долгота", placeholder = "44.4952, 34.1663", leading = Ic.Locate)
                Spacer(Modifier.height(12.dp))
                ToggleRow("Старт от моего местоположения", "Маршрут начнётся там, где вы стоите, а не со склада", gps) { gps = it }
                Spacer(Modifier.height(12.dp))
                ToggleRow("Заканчивать на складе", "Последний отрезок — до склада, порядок точек учитывает обратную дорогу", rt) { rt = it }
                Spacer(Modifier.height(12.dp))
                Field(cap, { cap = it }, "Вместимость кузова, кг", keyboard = KeyboardOptions(keyboardType = KeyboardType.Number), leading = Ic.Weight)
                Spacer(Modifier.height(12.dp))
                Field(osrm, { osrm = it }, "Сервер дорог (OSRM)")
            }
        }
        PrimaryButton("Сохранить", {
            st.withClient = wc; st.apiKey = key; st.folder = folder; st.model = model; st.osrm = osrm; st.depot = depot
            st.capacity = cap; st.endAtDepot = rt; st.startFromGps = gps
            vm.screen = Screen.HOME
        }, Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), icon = Ic.Check)
    }
}

@Composable
private fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.weight(1f)) {
            Text(title, style = T.BodyStrong)
            Text(sub, style = T.Small)
        }
        Spacer(Modifier.width(12.dp))
        Toggle(checked, onChange)
    }
}

// ======================= Проверка листа =======================

private fun kindIcon(k: Kind): ImageVector = when (k) { Kind.GOODS -> Ic.Box; Kind.RETURN -> Ic.Return; Kind.EQUIPMENT -> Ic.Fridge }
private fun kindFg(k: Kind): Color = when (k) { Kind.GOODS -> C.Ink2; else -> Color.White }
private fun kindBg(k: Kind): Color = when (k) { Kind.GOODS -> C.Field; else -> C.Ink }

@OptIn(ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
fun ReviewScreen(vm: AppVm) {
    var open by remember { mutableStateOf<Int?>(null) }
    var agOpen by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        TopBar("Проверка листа", { vm.screen = Screen.HOME }, subtitle = vm.header.ifBlank { null }) {
            RoundIconButton(Ic.Sort, { vm.sortByAgent = !vm.sortByAgent }, tint = if (vm.sortByAgent) C.Sea else C.Ink)
        }
        val shown = if (vm.sortByAgent) vm.rows.sortedWith(compareBy({ vm.agentFor(it.agent)?.name ?: "яяя" }, { it.callsign })) else vm.rows.toList()
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(key = "summary") {
                val sum = vm.rows.sumOf { it.weight }
                val tot = listOfNotNull(vm.total, vm.totalNoSg)
                val ok = tot.isEmpty() || tot.any { kotlin.math.abs(it - sum) < 0.5 }
                Card(Modifier.fillMaxWidth().appear(0), radius = 24.dp, padding = 18.dp) {
                    Row {
                        StatBlock(vm.rows.size.toString(), plural(vm.rows.size, "строка", "строки", "строк"), Modifier.weight(1f))
                        StatBlock(fmt(sum), "кг по строкам", Modifier.weight(1.3f))
                        StatBlock(if (tot.isEmpty()) "—" else fmt(tot.first()), "итого в листе", Modifier.weight(1.3f))
                    }
                    if (tot.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        Pill(if (ok) "Вес сходится с итогом" else "Вес не сходится — проверьте строки",
                            if (ok) C.Pine else C.Danger, if (ok) C.PineSoft else C.DangerSoft, if (ok) Ic.Check else Ic.Warning)
                    }
                    val ret = vm.rows.count { it.kind == Kind.RETURN }
                    val eq = vm.rows.count { it.kind == Kind.EQUIPMENT }
                    val ro = vm.returnOnlyCount
                    if (ret + eq + ro > 0) {
                        Spacer(Modifier.height(10.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (ret > 0) Pill("Возвратов: $ret", C.Apricot, C.ApricotSoft, Ic.Return)
                            if (eq > 0) Pill("Оборудование: $eq", C.Lavender, C.LavenderSoft, Ic.Fridge)
                            if (ro > 0) Pill("Без товара, не едем: $ro", C.Ink2, C.Field, Ic.Skip)
                        }
                    }
                }
            }
            item(key = "agents") {
                Card(Modifier.fillMaxWidth().appear(1), radius = 20.dp, padding = 16.dp) {
                    Row(Modifier.fillMaxWidth().pressable(scaleTo = 0.985f) { agOpen = !agOpen }, verticalAlignment = Alignment.CenterVertically) {
                        IconBubble(Ic.User, C.Ink2, C.Field, 38.dp, 19.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Агенты", style = T.H3)
                            Text(vm.agents.joinToString(", ") { "${it.num} ${it.name}".trim() }.ifBlank { "Не найдены" }, style = T.Small,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Chevron(agOpen)
                    }
                    Expand(agOpen) {
                        Column(Modifier.padding(top = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            vm.agents.forEachIndexed { i, a -> AgentEditor(a, { vm.agents[i] = it }, { vm.agents.removeAt(i) }) { dial(ctx, a.phone) } }
                            GhostButton("Добавить агента", { vm.agents.add(Agent()) }, icon = Ic.Plus, tint = C.Sea)
                        }
                    }
                }
            }
            items(shown, key = { it.id }) { r ->
                RowCard(vm, r, open == r.id, { open = if (open == r.id) null else r.id }, Modifier.animateItem())
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SecondaryButton("Строка", { vm.addRow() }, Modifier.weight(1f), icon = Ic.Plus, height = 58.dp)
            PrimaryButton("Сопоставить точки", { vm.startMatch() }, Modifier.weight(2f), icon = Ic.ArrowRight, enabled = vm.rows.isNotEmpty() && vm.busy == null)
        }
    }
}

@Composable
private fun Chevron(open: Boolean) {
    val rot by androidx.compose.animation.core.animateFloatAsState(if (open) 180f else 0f, spring(dampingRatio = 0.7f), label = "chev")
    Icon(Ic.ChevronDown, null, tint = C.Mute, modifier = Modifier.size(22.dp).rotate(rot))
}

@Composable
private fun AgentEditor(a: Agent, onChange: (Agent) -> Unit, onDelete: () -> Unit, onCall: () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RectangleShape).background(C.Field).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field(a.num, { onChange(a.copy(num = it)) }, "№", Modifier.width(72.dp))
            Field(a.name, { onChange(a.copy(name = it)) }, "Имя", Modifier.weight(1f))
        }
        Field(a.phone, { onChange(a.copy(phone = it)) }, "Телефон", keyboard = KeyboardOptions(keyboardType = KeyboardType.Phone))
        Row {
            if (a.phone.isNotBlank()) GhostButton("Позвонить", onCall, icon = Ic.Phone, tint = C.Pine)
            Spacer(Modifier.weight(1f))
            GhostButton("Удалить", onDelete, icon = Ic.Trash, tint = C.Danger)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RowCard(vm: AppVm, r: SheetRow, open: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    val ctx = LocalContext.current
    val k = r.kind
    val border by animateColorAsState(if (open) C.SeaBright else Color.Transparent, tween(200), label = "rb")
    Card(modifier.fillMaxWidth(), radius = 20.dp, padding = 0.dp, elevation = if (open) 14.dp else 6.dp) {
        Column(Modifier.border(1.5.dp, border, RectangleShape).padding(16.dp)) {
            Row(Modifier.fillMaxWidth().pressable(scaleTo = 0.985f, onClick = onToggle), verticalAlignment = Alignment.CenterVertically) {
                IconBubble(kindIcon(k), kindFg(k), kindBg(k), 42.dp, 20.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(r.callsign.ifBlank { "Без позывного" }, style = T.H3, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        if (vm.sortByAgent) (vm.agentFor(r.agent)?.name?.ifBlank { null } ?: "Агент не найден") else r.invoiceLabel,
                        style = T.Small, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.End) {
                    Text(fmt(r.weight), style = T.Num.copy(fontSize = 18.sp))
                    Text("кг", style = T.Small)
                }
            }
            val flags = r.factSum != 0.0 || r.calc.uppercase().contains("ЧЗ") || vm.manual(r)
            if (flags) {
                Spacer(Modifier.height(10.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (r.factSum != 0.0) Pill("Факт ${money(r.factSum)}", C.Pine, C.PineSoft, Ic.Cash)
                    if (r.calc.isNotBlank()) Pill(r.calc, C.Ink2, C.Field)
                    if (vm.manual(r)) Pill("Выбор точки вручную", C.Apricot, C.ApricotSoft, Ic.Pin)
                }
            }
            Expand(open) {
                var w by remember(r.id) { mutableStateOf(fmt(r.weight)) }
                Column(Modifier.padding(top = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Field(r.callsign, { vm.update(r.copy(callsign = it)) }, "Позывной")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Field(w, { w = it; vm.update(r.copy(weight = it.toD() ?: 0.0)) }, "Вес, кг", Modifier.weight(1f),
                            keyboard = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                        Field(r.fact, { vm.update(r.copy(fact = it)) }, "Факт", Modifier.weight(1f),
                            keyboard = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Field(r.calc, { vm.update(r.copy(calc = it)) }, "Расчёт", Modifier.weight(1f))
                        Field(r.agent, { vm.update(r.copy(agent = it)) }, "Агент №", Modifier.weight(1f))
                    }
                    Field(r.invoice, { vm.update(r.copy(invoice = it)) }, "Накладная", singleLine = false)
                    Field(r.notes, { vm.update(r.copy(notes = it)) }, "Заметки", singleLine = false)
                    Field(r.client, { vm.update(r.copy(client = it)) }, "Клиент", singleLine = false)
                    Field(r.address, { vm.update(r.copy(address = it)) }, "Адрес", singleLine = false)
                    if (r.sum.isNotBlank()) Text("Сумма накладной: ${r.sum}", style = T.Small)
                    Row {
                        vm.contactsOf(r).filter { it.phone.isNotBlank() }.forEach { a ->
                            GhostButton(a.name.ifBlank { a.num }, { dial(ctx, a.phone) }, icon = Ic.Phone, tint = C.Pine)
                        }
                        Spacer(Modifier.weight(1f))
                        GhostButton("Удалить", { vm.delRow(r.id) }, icon = Ic.Trash, tint = C.Danger)
                    }
                }
            }
        }
    }
}

// ======================= Сопоставление =======================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MatchScreen(vm: AppVm) {
    @Suppress("UNUSED_VARIABLE") val v = vm.dbVer
    val rowId = vm.queue.getOrNull(vm.qi) ?: return
    val r = vm.rows.firstOrNull { it.id == rowId } ?: return
    val ctx = LocalContext.current
    var creating by remember(rowId) { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Точка для строки", { vm.backMatch() }, subtitle = "${vm.qi + 1} из ${vm.queue.size}")
        SegmentedProgress(vm.queue.size, vm.qi, Modifier.padding(horizontal = 20.dp))
        AnimatedContent(
            targetState = rowId,
            transitionSpec = {
                (androidx.compose.animation.slideInHorizontally(spring(dampingRatio = 0.85f, stiffness = 400f)) { it / 3 } +
                    androidx.compose.animation.fadeIn(tween(220)))
                    .togetherWith(androidx.compose.animation.slideOutHorizontally(tween(220)) { -it / 4 } + androidx.compose.animation.fadeOut(tween(160)))
            },
            modifier = Modifier.weight(1f),
            label = "match"
        ) { id ->
            val row = vm.rows.firstOrNull { it.id == id } ?: return@AnimatedContent
            var q by remember(id) { mutableStateOf(row.client.trim().split(" ").firstOrNull().orEmpty()) }
            val suspicious = vm.manual(row)
            val suggested = if (row.callsign.isBlank()) null else vm.db.pointFor(row.callsign)
            val hits = vm.db.points.filter { q.isBlank() || it.name.contains(q, true) || it.address.contains(q, true) || it.title.contains(q, true) }
                .filter { it.name != suggested?.name }.take(8)
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(top = 16.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Card(Modifier.fillMaxWidth(), radius = 26.dp, padding = 20.dp) {
                    Text(row.callsign.ifBlank { "Без позывного" }, style = T.H1)
                    if (row.client.isNotBlank() || row.address.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(listOf(row.client, row.address).filter { it.isNotBlank() }.joinToString(", "), style = T.Body)
                    }
                    Spacer(Modifier.height(12.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Pill(row.invoiceLabel, kindFg(row.kind), kindBg(row.kind), kindIcon(row.kind))
                        Pill("${fmt(row.weight)} кг", C.Ink2, C.Field, Ic.Weight)
                        if (row.factSum != 0.0) Pill("Факт ${money(row.factSum)}", C.Pine, C.PineSoft, Ic.Cash)
                        if (row.calc.isNotBlank()) Pill(row.calc, C.Ink2, C.Field)
                        vm.contactsOf(row).forEach { a -> Pill(a.name.ifBlank { "Агент ${a.num}" }, C.Ink2, C.Field, Ic.User) }
                    }
                    if (row.visibleNotes.isNotBlank()) { Spacer(Modifier.height(10.dp)); Text(row.visibleNotes, style = T.Small) }
                    vm.contactsOf(row).filter { it.phone.isNotBlank() }.forEach { a ->
                        GhostButton("Позвонить: ${a.name.ifBlank { a.num }}", { dial(ctx, a.phone) }, icon = Ic.Phone, tint = C.Pine)
                    }
                }
                Hint(
                    if (suspicious) "Есть факт или ЧЗ — выбор не сохранится в базу. Выберите точку вручную или подтвердите по позывному."
                    else "Позывного нет в базе. Выберите точку — связь сохранится для следующих листов.",
                    if (suspicious) C.Apricot else C.Sea, if (suspicious) C.ApricotSoft else C.SeaSoft
                )
                if (suggested != null) {
                    SectionLabel("По позывному")
                    PointRow(suggested, highlighted = !suspicious) { vm.choose(id, suggested.name) }
                }
                Field(q, { q = it }, "Поиск в базе", leading = Ic.Search, placeholder = "Название или адрес")
                hits.forEachIndexed { i, p -> PointRow(p, false, Modifier.appear(i, p.name)) { vm.choose(id, p.name) } }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SecondaryButton("Новая точка", { creating = true }, Modifier.weight(1f), icon = Ic.Plus, tint = C.Sea)
                    SecondaryButton("Не везём", { vm.skip() }, Modifier.weight(1f), icon = Ic.Skip, tint = C.Ink2)
                }
            }
        }
    }
    if (creating) NewPointDialog(vm, r.callsign, r.client, r.address, { creating = false }) { creating = false; vm.createPoint(rowId, it) }
}

@Composable
private fun Hint(text: String, fg: Color, bg: Color) {
    Row(Modifier.fillMaxWidth().clip(RectangleShape).background(bg).padding(14.dp), verticalAlignment = Alignment.Top) {
        Icon(Ic.Warning, null, tint = fg, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, style = T.Body.copy(color = C.Ink, fontSize = 14.sp))
    }
}

@Composable
private fun PointRow(p: Point, highlighted: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RectangleShape
    Row(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (highlighted) C.Sea else C.Surface)
            .border(1.dp, if (highlighted) C.Sea else C.Line, shape)
            .pressable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBubble(Ic.Pin, if (highlighted) C.Sea else C.Ink2, if (highlighted) Color.White else C.Field, 38.dp, 19.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.display, style = T.H3.copy(color = if (highlighted) Color.White else C.Ink), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(listOf(p.name, p.address).filter { it.isNotBlank() }.joinToString(", "),
                style = T.Small.copy(color = if (highlighted) Color.White.copy(alpha = 0.8f) else C.Mute), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(if (highlighted) Ic.Check else Ic.ChevronRight, null, tint = if (highlighted) Color.White else C.Mute, modifier = Modifier.size(20.dp))
    }
}

@Composable
fun NewPointDialog(vm: AppVm, callsign: String, initName: String, initAddr: String, onClose: () -> Unit, onOk: (Point) -> Unit) {
    var code by remember { mutableStateOf("") }
    var name by remember { mutableStateOf(initName) }
    var addr by remember { mutableStateOf(initAddr) }
    var lat by remember { mutableStateOf("") }
    var lon by remember { mutableStateOf("") }
    var comment by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(Modifier.fillMaxWidth().padding(16.dp).appear(0).border(1.dp, C.Ink), padding = 20.dp, fullBleed = false) {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Новая точка", style = T.H2)
                if (callsign.isNotBlank()) Text("Позывной $callsign", style = T.Small)
                Field(code, { code = it }, "Код точки", placeholder = "Например, 105я")
                Field(name, { name = it }, "Название")
                Field(addr, { addr = it }, "Адрес", singleLine = false)
                SecondaryButton("Найти координаты по адресу", {
                    msg = "Ищем…"
                    vm.geocode(addr) { c -> if (c == null) msg = "Адрес не найден" else { lat = c.first.toString(); lon = c.second.toString(); msg = "Координаты найдены" } }
                }, Modifier.fillMaxWidth(), icon = Ic.Locate, tint = C.Sea)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Field(lat, { lat = it }, "Широта", Modifier.weight(1f), keyboard = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    Field(lon, { lon = it }, "Долгота", Modifier.weight(1f), keyboard = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                }
                Field(comment, { comment = it }, "Комментарий к выгрузке", singleLine = false, leading = Ic.Note)
                if (msg.isNotEmpty()) Text(msg, style = T.Small.copy(color = C.Sea))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SecondaryButton("Отмена", onClose, Modifier.weight(1f))
                    PrimaryButton("Создать", {
                        val la = lat.toD(); val lo = lon.toD()
                        val id = code.trim().ifBlank { name.trim() }
                        if (id.isBlank() || la == null || lo == null) msg = "Нужны код или название и координаты"
                        else onOk(Point(id, addr.trim(), la, lo, name.trim(), comment.trim()))
                    }, Modifier.weight(1f), height = 54.dp)
                }
            }
        }
    }
}

// ======================= Оборудование =======================

@Composable
fun EquipScreen(vm: AppVm) {
    val list = vm.equipRows
    val left = list.count { it.equip == EquipDir.UNKNOWN }
    Column(Modifier.fillMaxSize()) {
        TopBar("Оборудование", { vm.screen = Screen.REVIEW }, subtitle = "Уточните: забираем или доставляем")
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 6.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            itemsIndexed(list, key = { _, r -> r.id }) { i, r ->
                val p = vm.pointOf(r.id)
                Card(Modifier.fillMaxWidth().appear(i, r.id), radius = 24.dp, padding = 18.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBubble(Ic.Fridge, C.Lavender, C.LavenderSoft)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p?.display ?: r.callsign.ifBlank { "Точка" }, style = T.H3, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(listOf(r.callsign, p?.address.orEmpty()).filter { it.isNotBlank() }.joinToString(", "), style = T.Small, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Column(Modifier.fillMaxWidth().clip(RectangleShape).background(C.LavenderSoft).padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Ic.Note, null, tint = C.Lavender, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Заметка из листа", style = T.Small.copy(color = C.Lavender))
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(r.visibleNotes.ifBlank { "Заметки нет — уточните у агента" }, style = T.BodyStrong)
                        if (r.invoice.isNotBlank()) { Spacer(Modifier.height(4.dp)); Text(r.invoice, style = T.Small) }
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Choice("Забираем", Ic.Import, r.equip == EquipDir.PICKUP, Modifier.weight(1f)) { vm.setEquip(r.id, EquipDir.PICKUP) }
                        Choice("Доставляем", Ic.Export, r.equip == EquipDir.DELIVER, Modifier.weight(1f)) { vm.setEquip(r.id, EquipDir.DELIVER) }
                    }
                }
            }
        }
        PrimaryButton(
            if (left == 0) "Построить маршрут" else "Осталось уточнить: $left", vm::equipDone,
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), icon = Ic.Route, enabled = left == 0 && vm.busy == null
        )
    }
}

@Composable
private fun Choice(text: String, icon: ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) C.Lavender else C.Field, tween(220), label = "cb")
    val fg by animateColorAsState(if (selected) Color.White else C.Ink2, tween(220), label = "cf")
    Row(
        modifier.height(54.dp).clip(RectangleShape).background(bg).pressable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(19.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, style = T.Button.copy(fontSize = 15.sp), color = fg)
    }
}
