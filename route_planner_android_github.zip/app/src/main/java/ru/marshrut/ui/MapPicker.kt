package ru.marshrut.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import java.io.File
import java.util.Locale

/** Спутниковые снимки Esri: видно крыши, ворота и заезды — точку удобно ставить прямо на вход. */
private val SATELLITE = object : OnlineTileSourceBase(
    "EsriWorldImagery", 0, 19, 256, "",
    arrayOf("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/")
) {
    override fun getTileURLString(index: Long): String =
        baseUrl + MapTileIndex.getZoom(index) + "/" + MapTileIndex.getY(index) + "/" + MapTileIndex.getX(index)
}

/**
 * Карта для выбора места точки: двигаете карту, пока метка в центре не встанет на нужное место, и жмёте «Поставить».
 * OpenStreetMap и снимки Esri — без ключей и SDK.
 */
@Composable
fun MapPickerDialog(title: String, start: Pair<Double, Double>, onPick: (Double, Double) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var sat by remember { mutableStateOf(true) }
    val map = remember {
        Configuration.getInstance().apply {
            userAgentValue = ctx.packageName
            osmdroidBasePath = File(ctx.cacheDir, "osm")
            osmdroidTileCache = File(ctx.cacheDir, "osm/tiles")
        }
        MapView(ctx).apply {
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            isTilesScaledToDpi = true
            minZoomLevel = 5.0; maxZoomLevel = 19.0
            controller.setZoom(17.5)
            controller.setCenter(GeoPoint(start.first, start.second))
        }
    }
    LaunchedEffect(sat) { map.setTileSource(if (sat) SATELLITE else TileSourceFactory.MAPNIK) }
    DisposableEffect(Unit) { map.onResume(); onDispose { map.onPause(); map.onDetach() } }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(Modifier.fillMaxSize().background(C.Bg)) {
            AndroidView({ map }, Modifier.fillMaxSize())
            // Метка: остриё ровно в центре карты
            Icon(Ic.Pin, null, tint = C.Danger, modifier = Modifier.align(Alignment.Center).offset(y = (-17).dp).size(36.dp))
            Box(Modifier.align(Alignment.Center).size(7.dp).background(C.Ink, CircleShape).border(1.5.dp, Color.White, CircleShape))

            Row(
                Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(12.dp)
                    .background(C.Surface).border(1.dp, C.Line).padding(start = 14.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(title, style = T.BodyStrong, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("Двигайте карту, чтобы метка встала на место выгрузки", style = T.Small)
                }
                RoundIconButton(Ic.Close, onDismiss, size = 42.dp)
            }

            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(12.dp)
                    .background(C.Surface).border(1.dp, C.Line).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Спутник" to true, "Схема" to false).forEach { (label, v) ->
                        val on = sat == v
                        Box(Modifier.weight(1f).height(40.dp).background(if (on) C.Ink else C.Field).pressable { sat = v },
                            contentAlignment = Alignment.Center) { Text(label, style = T.BodyStrong, color = if (on) Color.White else C.Ink) }
                    }
                }
                PrimaryButton("Поставить точку здесь", {
                    val c = map.mapCenter
                    onPick(c.latitude, c.longitude)
                }, Modifier.fillMaxWidth(), icon = Ic.Check)
                Text(if (sat) "Снимки © Esri World Imagery" else "© участники OpenStreetMap",
                    style = T.Small.copy(fontSize = 10.sp), modifier = Modifier.align(Alignment.End))
            }
        }
    }
}

/** Координаты так же, как их копирует Яндекс Карты: «44.581956, 34.343381». */
fun coordsText(lat: Double, lon: Double) = String.format(Locale.US, "%.6f, %.6f", lat, lon)
