package ru.marshrut.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Нажатие с мягким «проседанием» вместо ряби. */
@Composable
fun Modifier.pressable(enabled: Boolean = true, scaleTo: Float = 0.965f, onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed && enabled) scaleTo else 1f, spring(dampingRatio = 0.55f, stiffness = 700f), label = "press")
    return this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
}

/** Появление элемента списка с небольшой задержкой по индексу. */
@Composable
fun Modifier.appear(index: Int = 0, key: Any = Unit): Modifier {
    val a = remember(key) { Animatable(0f) }
    LaunchedEffect(key) {
        kotlinx.coroutines.delay((index.coerceAtMost(10) * 45).toLong())
        a.animateTo(1f, tween(480, easing = FastOutSlowInEasing))
    }
    return this.graphicsLayer {
        alpha = a.value
        translationY = (1f - a.value) * 28.dp.toPx()
    }
}

@Composable
fun Card(
    modifier: Modifier = Modifier,
    radius: Dp = 22.dp,
    color: Color = C.Surface,
    elevation: Dp = 10.dp,
    padding: Dp = 18.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(radius)
    Column(
        modifier
            .shadow(elevation, shape, clip = false, ambientColor = Color(0x22103040), spotColor = Color(0x33103040))
            .clip(shape)
            .background(color)
            .padding(padding),
        content = content
    )
}

@Composable
fun IconBubble(icon: ImageVector, tint: Color, bg: Color, size: Dp = 44.dp, iconSize: Dp = 22.dp, shape: Shape = RoundedCornerShape(14.dp)) {
    Box(Modifier.size(size).clip(shape).background(bg), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(iconSize))
    }
}

@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    height: Dp = 58.dp,
    brush: Brush = C.seaGradient
) {
    val a by animateFloatAsState(if (enabled) 1f else 0.38f, tween(250), label = "en")
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier
            .height(height)
            .graphicsLayer { alpha = a }
            .shadow(if (enabled) 14.dp else 0.dp, shape, clip = false, ambientColor = C.Sea.copy(alpha = 0.35f), spotColor = C.Sea.copy(alpha = 0.45f))
            .clip(shape)
            .background(brush)
            .shimmer(enabled)
            .pressable(enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(10.dp)) }
            Text(text, style = T.Button, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun SecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    tint: Color = C.Ink,
    height: Dp = 54.dp
) {
    val a by animateFloatAsState(if (enabled) 1f else 0.4f, tween(250), label = "en2")
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier
            .height(height)
            .graphicsLayer { alpha = a }
            .clip(shape)
            .background(C.Surface)
            .border(1.dp, C.Line, shape)
            .pressable(enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 14.dp)) {
            if (icon != null) { Icon(icon, null, tint = tint, modifier = Modifier.size(19.dp)); Spacer(Modifier.width(8.dp)) }
            Text(text, style = T.Button.copy(fontSize = 15.sp), color = tint, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun GhostButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null, tint: Color = C.Ink2) {
    Row(
        modifier.clip(RoundedCornerShape(12.dp)).pressable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) { Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(7.dp)) }
        Text(text, style = T.Button.copy(fontSize = 14.sp), color = tint)
    }
}

@Composable
fun RoundIconButton(icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = C.Ink, bg: Color = C.Surface, size: Dp = 46.dp) {
    Box(
        modifier
            .size(size)
            .shadow(6.dp, CircleShape, clip = false, ambientColor = Color(0x18103040), spotColor = Color(0x22103040))
            .clip(CircleShape)
            .background(bg)
            .pressable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = tint, modifier = Modifier.size(21.dp)) }
}

@Composable
fun Pill(text: String, fg: Color, bg: Color, icon: ImageVector? = null, modifier: Modifier = Modifier) {
    Row(
        modifier.clip(RoundedCornerShape(10.dp)).background(bg).padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) { Icon(icon, null, tint = fg, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(5.dp)) }
        Text(text, style = T.Small.copy(fontSize = 12.5.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold), color = fg, maxLines = 1)
    }
}

@Composable
fun Field(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    leading: ImageVector? = null,
    keyboard: KeyboardOptions = KeyboardOptions.Default,
    placeholder: String = ""
) {
    var focused by remember { mutableStateOf(false) }
    val border by animateColorAsState(if (focused) C.SeaBright else Color.Transparent, tween(220), label = "fb")
    val bg by animateColorAsState(if (focused) C.Surface else C.Field, tween(220), label = "fbg")
    Column(modifier) {
        if (label.isNotEmpty()) Text(label, style = T.Small, modifier = Modifier.padding(start = 4.dp, bottom = 6.dp))
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = singleLine,
            keyboardOptions = keyboard,
            textStyle = T.BodyStrong.copy(fontSize = 16.sp),
            cursorBrush = SolidColor(C.Sea),
            modifier = Modifier
                .fillMaxWidth()
                .onFocusChanged { focused = it.isFocused },
            decorationBox = { inner ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(bg)
                        .border(1.5.dp, border, RoundedCornerShape(14.dp))
                        .padding(horizontal = 14.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (leading != null) { Icon(leading, null, tint = C.Mute, modifier = Modifier.size(19.dp)); Spacer(Modifier.width(10.dp)) }
                    Box(Modifier.weight(1f)) {
                        if (value.isEmpty() && placeholder.isNotEmpty()) Text(placeholder, style = T.Body.copy(color = C.Mute, fontSize = 16.sp))
                        inner()
                    }
                }
            }
        )
    }
}

@Composable
fun Toggle(checked: Boolean, onChange: (Boolean) -> Unit) {
    val x by animateFloatAsState(if (checked) 1f else 0f, spring(dampingRatio = 0.65f, stiffness = 500f), label = "tg")
    val track by animateColorAsState(if (checked) C.Sea else C.Line, tween(220), label = "tt")
    Box(
        Modifier.size(52.dp, 32.dp).clip(CircleShape).background(track).pressable(scaleTo = 0.93f) { onChange(!checked) }.padding(4.dp)
    ) {
        Box(
            Modifier
                .offset(x = 20.dp * x)
                .size(24.dp)
                .shadow(3.dp, CircleShape)
                .clip(CircleShape)
                .background(Color.White)
        )
    }
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)?, subtitle: String? = null, actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) { RoundIconButton(Ic.ChevronLeft, onBack); Spacer(Modifier.width(14.dp)) }
        Column(Modifier.weight(1f)) {
            Text(title, style = T.H2, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (!subtitle.isNullOrBlank()) Text(subtitle, style = T.Small, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        actions()
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(text, style = T.H3.copy(fontSize = 15.sp, color = C.Ink2), modifier = modifier.padding(start = 4.dp, top = 6.dp, bottom = 8.dp))
}

/** Фирменный знак: волна маршрута между двумя точками. */
@Composable
fun BrandMark(size: Dp = 52.dp) {
    Box(Modifier.size(size).shadow(12.dp, RoundedCornerShape(16.dp), ambientColor = C.Sea, spotColor = C.Sea).clip(RoundedCornerShape(16.dp)).background(C.seaGradient)) {
        Canvas(Modifier.fillMaxSize().padding(size * 0.2f)) {
            val w = this.size.width; val h = this.size.height
            val p = Path().apply {
                moveTo(w * 0.12f, h * 0.85f)
                cubicTo(w * 0.1f, h * 0.35f, w * 0.9f, h * 0.65f, w * 0.88f, h * 0.15f)
            }
            drawPath(p, Color.White, style = Stroke(width = w * 0.11f, cap = StrokeCap.Round))
            drawCircle(Color.White, w * 0.12f, Offset(w * 0.12f, h * 0.85f))
            drawCircle(C.Sea, w * 0.055f, Offset(w * 0.12f, h * 0.85f))
            drawCircle(Color.White, w * 0.14f, Offset(w * 0.88f, h * 0.15f))
        }
    }
}

/** Индикатор занятости: две орбиты вокруг точки. */
@Composable
fun Orbit(size: Dp = 72.dp) {
    val t = rememberInfiniteTransition(label = "orbit")
    val r1 by t.animateFloat(0f, 360f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "r1")
    val r2 by t.animateFloat(360f, 0f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "r2")
    val pulse by t.animateFloat(0.75f, 1f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension
        val st = s * 0.07f
        rotate(r1) {
            drawArc(Brush.sweepGradient(listOf(Color.Transparent, C.SeaBright.copy(alpha = 0.4f), C.SeaBright), center), 0f, 300f, false,
                topLeft = Offset(st, st), size = Size(s - 2 * st, s - 2 * st), style = Stroke(st, cap = StrokeCap.Round))
        }
        val inset = s * 0.22f
        drawArc(C.Sea.copy(alpha = 0.55f), r2, 160f, false, topLeft = Offset(inset, inset), size = Size(s - 2 * inset, s - 2 * inset), style = Stroke(st * 0.8f, cap = StrokeCap.Round))
        drawCircle(C.Sea, s * 0.08f * pulse, center)
    }
}

@Composable
fun BusyOverlay(text: String?) {
    AnimatedVisibility(text != null, enter = fadeIn(tween(250)), exit = fadeOut(tween(300))) {
        val holder = remember { arrayOf("") }
        if (text != null) holder[0] = text
        val last = holder[0]
        Box(
            Modifier.fillMaxSize().background(C.Bg.copy(alpha = 0.86f)).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
            contentAlignment = Alignment.Center
        ) {
            Card(radius = 28.dp, padding = 28.dp, modifier = Modifier.padding(32.dp)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(220.dp)) {
                    Orbit()
                    Spacer(Modifier.height(18.dp))
                    androidx.compose.animation.AnimatedContent(last, label = "busy") { s ->
                        Text(s, style = T.H3, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            }
        }
    }
}

@Composable
fun ErrorBanner(text: String?, onClose: () -> Unit, modifier: Modifier = Modifier) {
    val holder = remember { arrayOf("") }
    if (text != null) holder[0] = text
    val last = holder[0]
    AnimatedVisibility(
        text != null, modifier = modifier,
        enter = slideInVertically(spring(dampingRatio = 0.75f)) { -it } + fadeIn(),
        exit = slideOutVertically(tween(250)) { -it } + fadeOut()
    ) {
        Card(radius = 18.dp, padding = 14.dp, color = C.Surface, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBubble(Ic.Warning, C.Danger, C.DangerSoft, 38.dp, 19.dp, RoundedCornerShape(12.dp))
                Spacer(Modifier.width(12.dp))
                Text(last, style = T.Body.copy(color = C.Ink, fontSize = 14.sp), modifier = Modifier.weight(1f))
                Box(Modifier.size(34.dp).clip(CircleShape).pressable(onClick = onClose), contentAlignment = Alignment.Center) {
                    Icon(Ic.Close, null, tint = C.Mute, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
fun Expand(visible: Boolean, content: @Composable () -> Unit) {
    AnimatedVisibility(
        visible,
        enter = expandVertically(spring(dampingRatio = 0.85f, stiffness = 400f)) + fadeIn(tween(220)),
        exit = shrinkVertically(tween(240)) + fadeOut(tween(160))
    ) { content() }
}

@Composable
fun StatBlock(value: String, label: String, modifier: Modifier = Modifier, valueStyle: TextStyle = T.Num) {
    Column(modifier) {
        Text(value, style = valueStyle, maxLines = 1)
        Text(label, style = T.Small, maxLines = 1)
    }
}

/** Прогресс маршрута: сегмент на каждую точку, пройденные заливаются бирюзой. */
@Composable
fun SegmentedProgress(total: Int, current: Int, modifier: Modifier = Modifier) {
    val anim by animateFloatAsState(current.toFloat(), spring(dampingRatio = 0.8f, stiffness = 200f), label = "seg")
    Canvas(modifier.fillMaxWidth().height(6.dp)) {
        if (total <= 0) return@Canvas
        val gap = if (total > 30) 2.dp.toPx() else 4.dp.toPx()
        val w = (size.width - gap * (total - 1)) / total
        for (i in 0 until total) {
            val x = i * (w + gap)
            val fill = (anim + 1 - i).coerceIn(0f, 1f)
            drawRoundRect(C.Line, Offset(x, 0f), Size(w, size.height), androidx.compose.ui.geometry.CornerRadius(size.height / 2))
            if (fill > 0f) drawRoundRect(if (i < current) C.Sea else C.SeaBright, Offset(x, 0f), Size(w * fill, size.height),
                androidx.compose.ui.geometry.CornerRadius(size.height / 2))
        }
    }
}
