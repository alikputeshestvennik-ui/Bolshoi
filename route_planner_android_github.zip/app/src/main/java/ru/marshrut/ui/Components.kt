package ru.marshrut.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.animation.togetherWith
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.layout.layout
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Нажатие с мягким «проседанием» вместо ряби. */
@Composable
fun Modifier.pressable(enabled: Boolean = true, scaleTo: Float = 0.965f, onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed && enabled) scaleTo else 1f, spring(dampingRatio = 0.55f, stiffness = 700f), label = "press")
    return this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
}

/** Появление элемента списка с небольшой задержкой по индексу. */
@Composable
fun Modifier.appear(index: Int = 0, key: Any = Unit): Modifier {
    val a = remember(key) { Animatable(0f) }
    LaunchedEffect(key) {
        kotlinx.coroutines.delay((index.coerceAtMost(10) * 45).toLong())
        a.animateTo(1f, tween(480, easing = FastOutSlowInEasing))
    }
    return this.graphicsLayer {
        alpha = a.value
        translationY = (1f - a.value) * 28.dp.toPx()
    }
}

/** Выход карточки за поля экрана: карточки идут во всю ширину, текст остаётся на сетке 20dp. */
fun Modifier.bleed(h: Dp = 20.dp): Modifier = this.layout { m, c ->
    if (!c.hasBoundedWidth) { val p = m.measure(c); return@layout layout(p.width, p.height) { p.place(0, 0) } }
    val extra = h.roundToPx() * 2
    val p = m.measure(c.copy(minWidth = c.minWidth + extra, maxWidth = c.maxWidth + extra))
    layout(p.width - extra, p.height) { p.place(-extra / 2, 0) }
}

/**
 * Карточка в редакционном стиле: прямые углы, без теней, во всю ширину экрана,
 * тонкие линии сверху и снизу. radius/elevation оставлены для совместимости и не используются.
 */
@Composable
fun Card(
    modifier: Modifier = Modifier,
    @Suppress("UNUSED_PARAMETER") radius: Dp = 0.dp,
    color: Color = C.Surface,
    @Suppress("UNUSED_PARAMETER") elevation: Dp = 0.dp,
    padding: Dp = 18.dp,
    fullBleed: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier
            .then(if (fullBleed) Modifier.bleed() else Modifier)
            .background(color)
            .drawBehind {
                val t = 1.dp.toPx()
                drawRect(C.Line, Offset.Zero, Size(size.width, t))
                drawRect(C.Line, Offset(0f, size.height - t), Size(size.width, t))
            }
            .padding(horizontal = if (fullBleed && padding > 0.dp) maxOf(padding, 20.dp) else padding, vertical = padding),
        content = content
    )
}

@Composable
fun IconBubble(icon: ImageVector, tint: Color, bg: Color, size: Dp = 44.dp, iconSize: Dp = 22.dp, shape: Shape = RectangleShape) {
    Box(Modifier.size(size).clip(shape).background(bg), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(iconSize))
    }
}

@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    height: Dp = 58.dp,
    brush: Brush = C.seaGradient
) {
    val a by animateFloatAsState(if (enabled) 1f else 0.38f, tween(250), label = "en")
    val shape = RectangleShape
    Box(
        modifier
            .height(height)
            .graphicsLayer { alpha = a }
            .clip(shape)
            .background(brush)
            .shimmer(enabled)
            .pressable(enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(text.uppercase(), style = T.Button, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            if (icon != null) { Spacer(Modifier.width(12.dp)); Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
        }
    }
}

@Composable
fun SecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    tint: Color = C.Ink,
    height: Dp = 54.dp
) {
    val a by animateFloatAsState(if (enabled) 1f else 0.4f, tween(250), label = "en2")
    val shape = RectangleShape
    Box(
        modifier
            .height(height)
            .graphicsLayer { alpha = a }
            .clip(shape)
            .background(C.Surface)
            .border(1.dp, C.Ink.copy(alpha = 0.85f), shape)
            .pressable(enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 14.dp)) {
            if (icon != null) { Icon(icon, null, tint = tint, modifier = Modifier.size(19.dp)); Spacer(Modifier.width(8.dp)) }
            Text(text.uppercase(), style = T.Button, color = tint, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun GhostButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null, tint: Color = C.Ink2) {
    Row(
        modifier.clip(RectangleShape).pressable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) { Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(7.dp)) }
        Text(text.uppercase(), style = T.Button.copy(fontSize = 12.5.sp), color = tint)
    }
}

@Composable
fun RoundIconButton(icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = C.Ink, bg: Color = C.Surface, size: Dp = 46.dp) {
    Box(
        modifier
            .size(size)
            .background(bg)
            .border(1.dp, if (bg == C.Surface) C.Line else bg)
            .pressable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = tint, modifier = Modifier.size(21.dp)) }
}

@Composable
fun Pill(text: String, fg: Color, bg: Color, icon: ImageVector? = null, modifier: Modifier = Modifier) {
    Row(
        modifier.clip(RectangleShape).background(bg).padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) { Icon(icon, null, tint = fg, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(5.dp)) }
        Text(text.uppercase(), style = T.Label.copy(fontSize = 11.sp, color = fg), maxLines = 1)
    }
}

@Composable
fun Field(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    leading: ImageVector? = null,
    keyboard: KeyboardOptions = KeyboardOptions.Default,
    placeholder: String = "",
    password: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    val border by animateColorAsState(if (focused) C.SeaBright else Color.Transparent, tween(220), label = "fb")
    val bg by animateColorAsState(if (focused) C.Surface else C.Field, tween(220), label = "fbg")
    Column(modifier) {
        if (label.isNotEmpty()) Text(label.uppercase(), style = T.Label, modifier = Modifier.padding(bottom = 6.dp))
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = singleLine,
            keyboardOptions = keyboard,
            visualTransformation = if (password) androidx.compose.ui.text.input.PasswordVisualTransformation()
                else androidx.compose.ui.text.input.VisualTransformation.None,
            textStyle = T.BodyStrong.copy(fontSize = 16.sp),
            cursorBrush = SolidColor(C.Sea),
            modifier = Modifier
                .fillMaxWidth()
                .onFocusChanged { focused = it.isFocused },
            decorationBox = { inner ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RectangleShape)
                        .background(bg)
                        .border(1.5.dp, border, RectangleShape)
                        .padding(horizontal = 14.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (leading != null) { Icon(leading, null, tint = C.Mute, modifier = Modifier.size(19.dp)); Spacer(Modifier.width(10.dp)) }
                    Box(Modifier.weight(1f)) {
                        if (value.isEmpty() && placeholder.isNotEmpty()) Text(placeholder, style = T.Body.copy(color = C.Mute, fontSize = 16.sp))
                        inner()
                    }
                }
            }
        )
    }
}

@Composable
fun Toggle(checked: Boolean, onChange: (Boolean) -> Unit) {
    val x by animateFloatAsState(if (checked) 1f else 0f, spring(dampingRatio = 0.65f, stiffness = 500f), label = "tg")
    val track by animateColorAsState(if (checked) C.Sea else C.Line, tween(220), label = "tt")
    Box(
        Modifier.size(52.dp, 32.dp).clip(RectangleShape).background(track).pressable(scaleTo = 0.93f) { onChange(!checked) }.padding(4.dp)
    ) {
        Box(
            Modifier
                .offset(x = 20.dp * x)
                .size(24.dp)
                .clip(RectangleShape)
                .background(Color.White)
        )
    }
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)?, subtitle: String? = null, actions: @Composable RowScope.() -> Unit = {}) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(top = 8.dp, bottom = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) RoundIconButton(Ic.ChevronLeft, onBack, size = 42.dp)
            Spacer(Modifier.weight(1f))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), content = actions)
        }
        Spacer(Modifier.height(14.dp))
        if (!subtitle.isNullOrBlank()) Text(subtitle.uppercase(), style = T.Label, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(title, style = T.H1, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.appear(0, title))
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(text.uppercase(), style = T.Label, modifier = modifier.padding(top = 10.dp, bottom = 4.dp))
}

/** Фирменный знак — сама иконка приложения в сквиркле с мягкой тенью и бликом. */
@Composable
fun BrandMark(size: Dp = 52.dp) {
    val shape = RectangleShape
    Box(
        Modifier.size(size)
            .clip(shape)
            .shimmer(true, 0.25f)
    ) {
        androidx.compose.foundation.Image(
            painter = androidx.compose.ui.res.painterResource(ru.marshrut.R.drawable.brand),
            contentDescription = null,
            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}

/** Индикатор занятости: две орбиты вокруг точки. */
@Composable
fun Orbit(size: Dp = 72.dp) {
    val t = rememberInfiniteTransition(label = "orbit")
    val r1 by t.animateFloat(0f, 360f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "r1")
    val r2 by t.animateFloat(360f, 0f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "r2")
    val pulse by t.animateFloat(0.75f, 1f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension
        val st = s * 0.07f
        rotate(r1) {
            drawArc(Brush.sweepGradient(listOf(Color.Transparent, C.SeaBright.copy(alpha = 0.4f), C.SeaBright), center), 0f, 300f, false,
                topLeft = Offset(st, st), size = Size(s - 2 * st, s - 2 * st), style = Stroke(st, cap = StrokeCap.Round))
        }
        val inset = s * 0.22f
        drawArc(C.Sea.copy(alpha = 0.55f), r2, 160f, false, topLeft = Offset(inset, inset), size = Size(s - 2 * inset, s - 2 * inset), style = Stroke(st * 0.8f, cap = StrokeCap.Round))
        drawCircle(C.Sea, s * 0.08f * pulse, center)
    }
}

/**
 * Идёт работа (распознавание, уточнение агентов, перечитывание, поиск адресов): без окна посреди экрана.
 * Снизу выезжает тёмная полоса — по ней бежит индикатор, текст этапа сменяется плавно, а счётчик секунд
 * тикает, чтобы было видно: приложение живо. Этап «N из M» заполняет полосу по шагам.
 * Экран под полосой остаётся виден, но нажатия не принимает.
 */
@Composable
fun BusyOverlay(text: String?) {
    val holder = remember { arrayOf("") }
    if (text != null) holder[0] = text
    val last = holder[0]
    // Секунды с начала работы — сбрасываются, когда работа закончилась
    var started by remember { mutableStateOf(0L) }
    var secs by remember { mutableStateOf(0) }
    LaunchedEffect(text != null) {
        if (text == null) return@LaunchedEffect
        started = System.currentTimeMillis(); secs = 0
        while (true) { kotlinx.coroutines.delay(250); secs = ((System.currentTimeMillis() - started) / 1000).toInt() }
    }
    // Лёгкая вуаль снизу и перехват нажатий
    AnimatedVisibility(text != null, enter = fadeIn(tween(250)), exit = fadeOut(tween(350))) {
        Box(Modifier.fillMaxSize()
            .background(androidx.compose.ui.graphics.Brush.verticalGradient(0.55f to Color.Transparent, 1f to C.Ink.copy(alpha = 0.18f)))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {})
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
        AnimatedVisibility(
            text != null,
            enter = slideInVertically(spring(dampingRatio = 0.72f, stiffness = 320f)) { it } + fadeIn(tween(200)),
            exit = slideOutVertically(tween(320)) { it } + fadeOut(tween(250))
        ) {
            val step = Regex("(\\d+)\\s+из\\s+(\\d+)").find(last)?.let { m ->
                val n = m.groupValues[1].toFloat(); val t = m.groupValues[2].toFloat()
                if (t > 0) ((n - 0.5f) / t).coerceIn(0f, 1f) else null
            }
            val shown by animateFloatAsState(step ?: 0f, tween(600, easing = FastOutSlowInEasing), label = "busyStep")
            val inf = rememberInfiniteTransition(label = "busyRun")
            val run by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "run")
            val pulse by inf.animateFloat(0.55f, 1f, infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
            Column(Modifier.fillMaxWidth().background(C.Ink)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}) {
                // Индикатор: бегущий отрезок, а для этапов «N из M» — ещё и заполненная часть
                Canvas(Modifier.fillMaxWidth().height(3.dp)) {
                    drawRect(Color.White.copy(alpha = 0.12f))
                    if (step != null) drawRect(Color.White.copy(alpha = 0.55f), size = Size(size.width * shown, size.height))
                    val w = size.width * 0.28f
                    val x = -w + (size.width + w) * run
                    drawRect(androidx.compose.ui.graphics.Brush.horizontalGradient(
                        listOf(Color.Transparent, Color.White, Color.Transparent), startX = x, endX = x + w),
                        topLeft = Offset(x, 0f), size = Size(w, size.height))
                }
                Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).graphicsLayer { scaleX = pulse; scaleY = pulse; alpha = pulse }.background(Color.White, androidx.compose.foundation.shape.CircleShape))
                    Spacer(Modifier.width(14.dp))
                    androidx.compose.animation.AnimatedContent(last, Modifier.weight(1f), transitionSpec = {
                        (slideInVertically(tween(280)) { it / 2 } + fadeIn(tween(280))) togetherWith
                            (slideOutVertically(tween(220)) { -it / 2 } + fadeOut(tween(200)))
                    }, label = "busyText") { s ->
                        Text(s, style = T.BodyStrong, color = Color.White, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text("$secs с", style = T.Small, color = Color.White.copy(alpha = 0.6f))
                }
            }
        }
    }
}

@Composable
fun ErrorBanner(text: String?, onClose: () -> Unit, modifier: Modifier = Modifier) {
    val holder = remember { arrayOf("") }
    if (text != null) holder[0] = text
    val last = holder[0]
    AnimatedVisibility(
        text != null, modifier = modifier,
        enter = slideInVertically(spring(dampingRatio = 0.75f)) { -it } + fadeIn(),
        exit = slideOutVertically(tween(250)) { -it } + fadeOut()
    ) {
        Card(padding = 16.dp, color = C.Surface, fullBleed = false, modifier = Modifier.fillMaxWidth().border(1.dp, C.Danger)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBubble(Ic.Warning, C.Danger, C.DangerSoft, 38.dp, 19.dp, RectangleShape)
                Spacer(Modifier.width(12.dp))
                Text(last, style = T.Body.copy(color = C.Ink, fontSize = 14.sp), modifier = Modifier.weight(1f))
                Box(Modifier.size(34.dp).clip(RectangleShape).pressable(onClick = onClose), contentAlignment = Alignment.Center) {
                    Icon(Ic.Close, null, tint = C.Mute, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
fun Expand(visible: Boolean, content: @Composable () -> Unit) {
    AnimatedVisibility(
        visible,
        enter = expandVertically(spring(dampingRatio = 0.85f, stiffness = 400f)) + fadeIn(tween(220)),
        exit = shrinkVertically(tween(240)) + fadeOut(tween(160))
    ) { content() }
}

@Composable
fun StatBlock(value: String, label: String, modifier: Modifier = Modifier, valueStyle: TextStyle = T.Num) {
    Column(modifier) {
        Text(value, style = valueStyle, maxLines = 1)
        Text(label, style = T.Small, maxLines = 1)
    }
}

/** Прогресс маршрута: сегмент на каждую точку, пройденные заливаются бирюзой. */
@Composable
fun SegmentedProgress(total: Int, current: Int, modifier: Modifier = Modifier) {
    val anim by animateFloatAsState(current.toFloat(), spring(dampingRatio = 0.8f, stiffness = 200f), label = "seg")
    Canvas(modifier.fillMaxWidth().height(3.dp)) {
        if (total <= 0) return@Canvas
        val gap = if (total > 30) 2.dp.toPx() else 4.dp.toPx()
        val w = (size.width - gap * (total - 1)) / total
        for (i in 0 until total) {
            val x = i * (w + gap)
            val fill = (anim + 1 - i).coerceIn(0f, 1f)
            drawRoundRect(C.Line, Offset(x, 0f), Size(w, size.height), androidx.compose.ui.geometry.CornerRadius.Zero)
            if (fill > 0f) drawRoundRect(if (i < current) C.Sea else C.SeaBright, Offset(x, 0f), Size(w * fill, size.height),
                androidx.compose.ui.geometry.CornerRadius.Zero)
        }
    }
}

/** Подтверждение важного действия: появляется с пружиной, фон затемняется. */
@Composable
fun ConfirmDialog(
    title: String,
    text: String,
    confirm: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    secondary: String? = null,
    onSecondary: () -> Unit = {}
) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        val sc = remember { Animatable(0.85f) }
        LaunchedEffect(Unit) { sc.animateTo(1f, spring(dampingRatio = 0.6f, stiffness = 420f)) }
        Card(Modifier.fillMaxWidth().padding(16.dp).graphicsLayer { scaleX = sc.value; scaleY = sc.value }.border(1.dp, C.Ink), padding = 22.dp, fullBleed = false) {
            IconBubble(Ic.Warning, Color.White, C.Danger, 48.dp, 24.dp, RectangleShape)
            Spacer(Modifier.height(16.dp))
            Text(title, style = T.H2)
            Spacer(Modifier.height(6.dp))
            Text(text, style = T.Body)
            Spacer(Modifier.height(20.dp))
            PrimaryButton(confirm, onConfirm, Modifier.fillMaxWidth(), icon = Ic.Flag,
                brush = Brush.linearGradient(listOf(Color(0xFFD9475B), Color(0xFFA9263A))))
            if (secondary != null) {
                Spacer(Modifier.height(10.dp))
                SecondaryButton(secondary, onSecondary, Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(4.dp))
            GhostButton("Отмена", onDismiss, Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

/** Сообщение об успехе: графитовая полоса сверху, сама исчезает через несколько секунд. */
@Composable
fun InfoBanner(text: String?, onClose: () -> Unit, modifier: Modifier = Modifier) {
    val holder = remember { arrayOf("") }
    if (text != null) holder[0] = text
    LaunchedEffect(text) { if (text != null) { kotlinx.coroutines.delay(4500); onClose() } }
    AnimatedVisibility(
        text != null, modifier = modifier,
        enter = slideInVertically(spring(dampingRatio = 0.75f)) { -it } + fadeIn(),
        exit = slideOutVertically(tween(250)) { -it } + fadeOut()
    ) {
        Row(
            Modifier.fillMaxWidth().background(C.Ink).pressable(scaleTo = 0.99f, onClick = onClose).padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Ic.Check, null, tint = Color.White, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(12.dp))
            Text(holder[0], style = T.BodyStrong.copy(color = Color.White), modifier = Modifier.weight(1f))
        }
    }
}
