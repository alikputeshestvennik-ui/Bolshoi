package ru.marshrut.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ru.marshrut.AppVm

/** Своё правило прямо на экране маршрута: нейросеть перестраивает текущий маршрут с ним. */
@Composable
fun RuleDialog(vm: AppVm, onClose: () -> Unit) {
    var text by remember { mutableStateOf("") }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(Modifier.fillMaxWidth().padding(16.dp).border(1.dp, C.Ink), padding = 22.dp, fullBleed = false) {
            Text("Своё правило", style = T.H2)
            Spacer(Modifier.height(6.dp))
            Text("Напишите, что поменять, — нейросеть перестроит этот маршрут. Например: «Мисхорскую — сразу после ЮБШ 32А, не возвращаться»", style = T.Small)
            Spacer(Modifier.height(12.dp))
            Field(text, { text = it }, "Правило", singleLine = false)
            Spacer(Modifier.height(16.dp))
            PrimaryButton("Перестроить", { vm.askLlmWithRule(text, false); onClose() }, Modifier.fillMaxWidth(), icon = Ic.Sparkle)
            Spacer(Modifier.height(8.dp))
            SecondaryButton("Перестроить и запомнить", { vm.askLlmWithRule(text, true); onClose() }, Modifier.fillMaxWidth(), icon = Ic.Check, height = 50.dp)
            Text("«Запомнить» — правило добавится в «Правила для нейросети» в настройках и будет действовать всегда", style = T.Small,
                modifier = Modifier.padding(top = 6.dp))
            GhostButton("Отмена", onClose, Modifier.align(Alignment.CenterHorizontally))
        }
    }
}
