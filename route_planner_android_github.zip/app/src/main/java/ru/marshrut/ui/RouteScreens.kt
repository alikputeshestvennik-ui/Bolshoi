package ru.marshrut.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import kotlinx.coroutines.launch
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.marshrut.AppVm
import ru.marshrut.EquipDir
import ru.marshrut.Excluded
import ru.marshrut.Plan
import ru.marshrut.PlanStop
import ru.marshrut.Screen
import ru.marshrut.dial
import ru.marshrut.fmt
import ru.marshrut.km
import ru.marshrut.minutes
import ru.marshrut.money
import ru.marshrut.openNavigator
import ru.marshrut.openUrl
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min

// ======================= Схема маршрута =======================

/** Схема без картографической подложки: дорога рисуется по геометрии OSRM, точки появляются по ходу «прорисовки». */
@Composable
fun RouteMap(plan: Plan, modifier: Modifier = Modifier, current: Int = -1) {
    val tm = rememberTextMeasurer()
    val prog = remember(plan) { Animatable(0f) }
    LaunchedEffect(plan) { prog.animateTo(1f, tween(1900, easing = FastOutSlowInEasing)) }
    val inf = rememberInfiniteTransition(label = "map")
    val pulse by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1500), RepeatMode.Restart), label = "pulse")
    val travel by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(11000, easing = androidx.compose.animation.core.LinearEasing)), label = "travel")
    val phase by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(900, easing = androidx.compose.animation.core.LinearEasing)), label = "phase")
    val numStyle = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = C.Sea)
    val numStyleOn = numStyle.copy(color = Color.White)
    val nameStyle = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = C.Ink)

    // Масштаб схемы: экран = база × zoom + off. Метки и линии остаются одной толщины — увеличивается только «карта».
    var zoom by remember(plan) { mutableFloatStateOf(1f) }
    var off by remember(plan) { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(androidx.compose.ui.unit.IntSize.Zero) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    fun clampOff(z: Float, o: Offset) = Offset(o.x.coerceIn(box.width * (1 - z), 0f), o.y.coerceIn(box.height * (1 - z), 0f))
    fun zoomTo(z2: Float, c: Offset) {
        scope.launch {
            val z0 = zoom; val o0 = off
            val zt = z2.coerceIn(1f, 8f)
            val target = clampOff(zt, c - (c - o0) * (zt / z0))
            androidx.compose.animation.core.animate(0f, 1f, animationSpec = spring(dampingRatio = 0.85f, stiffness = 260f)) { t, _ ->
                zoom = z0 + (zt - z0) * t; off = o0 + (target - o0) * t
            }
        }
    }

    Box(modifier.onSizeChanged { box = it }) {
    Canvas(
        Modifier.matchParentSize()
            .clipToBounds()
            .pointerInput(plan) {
                // Два пальца — масштаб и сдвиг; один палец двигает схему только когда она увеличена,
                // иначе жест уходит списку и экран обычно прокручивается.
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        val fingers = ev.changes.count { it.pressed }
                        if (fingers >= 2 || (fingers == 1 && zoom > 1.01f)) {
                            val z = if (fingers >= 2) ev.calculateZoom() else 1f
                            val c = ev.calculateCentroid(useCurrent = true)
                            val nz = (zoom * z).coerceIn(1f, 8f)
                            val no = if (c == Offset.Unspecified) off else c - (c - off) * (nz / zoom)
                            zoom = nz
                            off = clampOff(nz, no + ev.calculatePan())
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            }
            .pointerInput(plan) {
                detectTapGestures(onDoubleTap = { c -> if (zoom > 1.05f) zoomTo(1f, c) else zoomTo(2.6f, c) })
            }
    ) {
        val pts = plan.stops.map { it.point.lat to it.point.lon }
        if (pts.isEmpty()) return@Canvas
        val dep = plan.depot?.let { it.lat to it.lon }
        val route = if (plan.path.size >= 2) plan.path
        else listOfNotNull(dep) + pts + listOfNotNull(plan.end?.let { it.lat to it.lon })
        val fin = plan.end?.let { it.lat to it.lon }
        val all = route + pts + listOfNotNull(dep, fin)
        val minLat = all.minOf { it.first }; val maxLat = all.maxOf { it.first }
        val minLon = all.minOf { it.second }; val maxLon = all.maxOf { it.second }
        val k = cos(Math.toRadians((minLat + maxLat) / 2))
        val spanX = max((maxLon - minLon) * k, 1e-5); val spanY = max(maxLat - minLat, 1e-5)
        val pad = 30.dp.toPx()
        val sc = min((size.width - 2 * pad) / spanX, (size.height - 2 * pad) / spanY)
        val ox = (size.width - spanX * sc) / 2; val oy = (size.height - spanY * sc) / 2
        fun at(p: Pair<Double, Double>) = Offset(
            (ox + (p.second - minLon) * k * sc).toFloat() * zoom + off.x,
            (oy + (maxLat - p.first) * sc).toFloat() * zoom + off.y
        )

        // точечная сетка — плывёт и растягивается вместе со схемой
        val base = 22.dp.toPx()
        var step = base * zoom
        while (step > base * 1.9f) step /= 2f
        var gx = ((off.x % step) + step) % step
        while (gx < size.width) {
            var gy = ((off.y % step) + step) % step
            while (gy < size.height) { drawCircle(C.Line, 1.2.dp.toPx(), Offset(gx, gy)); gy += step }
            gx += step
        }

        val path = Path()
        route.forEachIndexed { i, p -> val o = at(p); if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
        val sw = 5.dp.toPx()
        drawPath(path, C.Sea.copy(alpha = 0.10f), style = Stroke(sw * 2.6f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(path, C.Line, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
        val pm = PathMeasure(); pm.setPath(path, false)
        val seg = Path(); pm.getSegment(0f, pm.length * prog.value, seg, true)
        drawPath(seg, C.Sea, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
        if (prog.value >= 1f && pm.length > 0f) {
            val dash = 7.dp.toPx(); val gap = 13.dp.toPx()
            drawPath(path, Color.White.copy(alpha = 0.8f), style = Stroke(sw * 0.34f, cap = StrokeCap.Round,
                pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(dash, gap), -phase * (dash + gap))))
            val car = pm.getPosition(pm.length * travel)
            drawCircle(C.SeaBright.copy(alpha = 0.25f), sw * 3.2f, car)
            drawCircle(Color.White, sw * 1.6f, car)
            drawCircle(C.Sea, sw * 1.0f, car)
        }
        if (prog.value < 1f && pm.length > 0f) {
            val head = pm.getPosition(pm.length * prog.value)
            drawCircle(C.SeaBright, sw * 1.3f, head)
        }

        // старт — графитовый круг, склад-финиш — графитовый квадрат
        dep?.let {
            val o = at(it)
            drawCircle(C.Ink, 9.dp.toPx(), o)
            drawCircle(Color.White, 3.5.dp.toPx(), o)
        }
        fin?.let {
            val o = at(it)
            drawRoundRect(C.Ink, Offset(o.x - 10.dp.toPx(), o.y - 10.dp.toPx()), Size(20.dp.toPx(), 20.dp.toPx()),
                androidx.compose.ui.geometry.CornerRadius.Zero)
            drawRoundRect(Color.White, Offset(o.x - 4.dp.toPx(), o.y - 4.dp.toPx()), Size(8.dp.toPx(), 8.dp.toPx()),
                androidx.compose.ui.geometry.CornerRadius.Zero)
        }

        val n = pts.size
        val r = 11.5.dp.toPx()
        pts.forEachIndexed { i, p ->
            val a = ((prog.value * (n + 1)) - i).coerceIn(0f, 1f)
            if (a <= 0f) return@forEachIndexed
            val o = at(p)
            val on = i == current
            val done = current >= 0 && i < current
            if (on) drawCircle(C.SeaBright.copy(alpha = (1f - pulse) * 0.45f), r * (1.2f + pulse * 1.3f), o)
            // квадратные метки — в тон прямоугольной сетке интерфейса
            val half = r * a
            drawRect(if (on || done) C.Sea else Color.White, Offset(o.x - half, o.y - half), Size(half * 2, half * 2))
            drawRect(C.Sea, Offset(o.x - half, o.y - half), Size(half * 2, half * 2), style = Stroke(2.dp.toPx()))
            if (a > 0.6f) {
                val t = tm.measure((i + 1).toString(), if (on || done) numStyleOn else numStyle)
                drawText(t, topLeft = Offset(o.x - t.size.width / 2f, o.y - t.size.height / 2f), alpha = a)
            }
            // при приближении — подписи точек
            val labelA = ((zoom - 1.8f) / 0.6f).coerceIn(0f, 1f) * a
            if (labelA > 0f && o.x > -200f && o.x < size.width + 20f && o.y > -20f && o.y < size.height + 20f) {
                val name = plan.stops[i].point.display.let { if (it.length > 22) it.take(21) + "…" else it }
                val t = tm.measure(name, nameStyle)
                val px = 5.dp.toPx(); val py = 2.5.dp.toPx()
                val tl = Offset(o.x + half + 6.dp.toPx(), o.y - t.size.height / 2f - py)
                drawRect(Color.White.copy(alpha = 0.92f * labelA), tl, Size(t.size.width + px * 2, t.size.height + py * 2))
                drawRect(C.Line.copy(alpha = labelA), tl, Size(t.size.width + px * 2, t.size.height + py * 2), style = Stroke(1.dp.toPx()))
                drawText(t, topLeft = tl + Offset(px, py), alpha = labelA)
            }
        }
    }

    // Кнопки масштаба
    Column(
        Modifier.align(Alignment.BottomEnd).padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        androidx.compose.animation.AnimatedVisibility(zoom > 1.05f, enter = fadeIn() + scaleIn(), exit = fadeOut() + scaleOut()) {
            RoundIconButton(Ic.Locate, { zoomTo(1f, Offset(box.width / 2f, box.height / 2f)) }, size = 38.dp)
        }
        RoundIconButton(Ic.Plus, { zoomTo(zoom * 1.8f, Offset(box.width / 2f, box.height / 2f)) }, size = 38.dp)
        RoundIconButton(Ic.Minus, { zoomTo(zoom / 1.8f, Offset(box.width / 2f, box.height / 2f)) }, size = 38.dp)
    }
    androidx.compose.animation.AnimatedVisibility(
        zoom <= 1.05f, modifier = Modifier.align(Alignment.BottomStart).padding(12.dp), enter = fadeIn(), exit = fadeOut()
    ) {
        Pill("Двумя пальцами — масштаб", C.Ink2, Color.White.copy(alpha = 0.9f))
    }
    }
}

// ======================= Обзор маршрута =======================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OverviewScreen(vm: AppVm) {
    val plan = vm.plan ?: run { vm.screen = Screen.HOME; return }
    val ctx = LocalContext.current
    var fullMap by remember { mutableStateOf(false) }
    if (fullMap) FullMapDialog(plan, if (vm.started) vm.stopIndex else -1) { fullMap = false }
    Column(Modifier.fillMaxSize()) {
        TopBar("Маршрут готов", { vm.screen = Screen.HOME }, subtitle = plan.header.ifBlank { null }) {
            if (vm.scans.isNotEmpty()) RoundIconButton(Ic.Doc, { vm.showScans = true })
            // Назад к точкам и накладным листа — пока рейс не начат
            if (!vm.started && vm.rows.isNotEmpty()) RoundIconButton(Ic.Edit, { vm.backToReview() })
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "map") {
                Card(Modifier.fillMaxWidth().appear(0), radius = 28.dp, padding = 0.dp) {
                    Box {
                        RouteMap(plan, Modifier.fillMaxWidth().height(440.dp), if (vm.started) vm.stopIndex else -1)
                        RoundIconButton(Ic.Map, { fullMap = true }, Modifier.align(Alignment.TopEnd).padding(10.dp), size = 40.dp)
                    }
                }
            }
            if (vm.variants.size > 1 && !vm.started) item(key = "variants") {
                Box(Modifier.appear(1)) { VariantPicker(vm, plan) }
            }
            if (plan.agentHandoff.isNotEmpty()) item(key = "agent") {
                AgentPlaque(vm, plan, Modifier.appear(1))
            }
            item(key = "stats") {
                Card(Modifier.fillMaxWidth().appear(1), radius = 22.dp, padding = 18.dp) {
                    Row {
                        StatBlock(plan.stops.size.toString(), plural(plan.stops.size, "точка", "точки", "точек"), Modifier.weight(1f))
                        StatBlock(km(plan.distanceKm), "км", Modifier.weight(1f))
                        StatBlock(minutes(plan.durationMin), "в пути", Modifier.weight(1.4f))
                        StatBlock(fmt(plan.stops.sumOf { it.weight }), "кг", Modifier.weight(1.1f))
                    }
                    val cash = plan.stops.sumOf { it.fact }
                    val ret = plan.stops.sumOf { it.returns.size }
                    val eq = plan.stops.sumOf { it.equipment.size }
                    if (plan.depot != null || plan.end != null) {
                        Spacer(Modifier.height(12.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            plan.depot?.let { Pill("Старт: ${it.title}", C.Ink2, C.Field, Ic.Locate) }
                            plan.end?.let { Pill("Финиш: склад", C.Ink2, C.Field, Ic.Flag) }
                        }
                    }
                    if (cash > 0 || ret > 0 || eq > 0) {
                        Spacer(Modifier.height(12.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (cash > 0) Pill("Наличные ${money(cash)}", C.Pine, C.PineSoft, Ic.Cash)
                            if (ret > 0) Pill("Возвратов: $ret", C.Apricot, C.ApricotSoft, Ic.Return)
                            if (eq > 0) Pill("Оборудование: $eq", C.Lavender, C.LavenderSoft, Ic.Fridge)
                        }
                    }
                }
            }
            item(key = "summary") { RouteSummaryCard(plan, Modifier.appear(1)) }
            plan.excluded.groupBy { it.reason }.forEach { (reason, list) ->
                item(key = "excluded_$reason") {
                    val agent = reason == Excluded.REASON_AGENT
                    Card(Modifier.fillMaxWidth().appear(2), radius = 22.dp, padding = 16.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconBubble(if (agent) Ic.User else Ic.Skip, if (agent) Color.White else C.Ink2, if (agent) C.Ink else C.Field, 38.dp, 19.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(if (agent) "Заберёт торговый" else "Не заезжаем", style = T.H3)
                                Text(if (agent) "В объезд не включены" else reason, style = T.Small)
                            }
                            Text(list.size.toString(), style = T.Num.copy(fontSize = 18.sp, color = C.Mute))
                        }
                        Spacer(Modifier.height(10.dp))
                        list.forEach { e ->
                            Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(e.title, style = T.BodyStrong, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.width(8.dp))
                                Pill(e.label, C.Ink2, C.Field)
                            }
                        }
                    }
                }
            }
            itemsIndexed(plan.stops, key = { i, s -> "s$i" + s.point.name }) { i, s ->
                TimelineItem(i, s, i == plan.stops.lastIndex, vm.started && i == vm.stopIndex, vm.started && i < vm.stopIndex,
                    Modifier.appear(i + 3, s.point.name)) { vm.jumpTo(i) }
            }
            item(key = "links") {
                Column {
                    plan.links.forEachIndexed { i, url ->
                        GhostButton(if (plan.links.size == 1) "Весь маршрут в Яндекс Картах" else "Участок ${i + 1} в Яндекс Картах",
                            { openUrl(ctx, url) }, icon = Ic.Map, tint = C.Ink2)
                    }
                }
            }
        }
        GoButton(if (vm.started) "Продолжить: точка ${vm.stopIndex + 1}" else "Загрузка и в путь", Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
            if (vm.started) vm.screen = Screen.DRIVE else vm.toLoading()
        }
    }
}

@Composable
private fun GoButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "go")
    val glow by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glow")
    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(
            Modifier.fillMaxWidth().height(64.dp)
                .graphicsLayer { scaleX = 1f + glow * 0.02f; scaleY = 1f + glow * 0.08f; alpha = 0.25f + glow * 0.25f }
                .clip(RectangleShape).background(C.SeaBright)
        )
        PrimaryButton(text, onClick, Modifier.fillMaxWidth(), icon = Ic.Play, height = 64.dp)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun TimelineItem(i: Int, s: PlanStop, last: Boolean, current: Boolean, done: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Row(modifier.fillMaxWidth().clip(RectangleShape).background(if (current) C.Surface else Color.Transparent).pressable(scaleTo = 0.985f, onClick = onClick).padding(10.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(40.dp)) {
            Box(
                Modifier.size(36.dp).clip(RectangleShape).background(if (done || current) C.Sea else C.Surface),
                contentAlignment = Alignment.Center
            ) {
                if (done) Icon(Ic.Check, null, tint = Color.White, modifier = Modifier.size(18.dp))
                else Text("${i + 1}", style = T.Num.copy(fontSize = 15.sp, color = if (current) Color.White else C.Sea))
            }
            if (!last) Box(Modifier.padding(top = 6.dp).width(2.dp).height(36.dp).clip(RectangleShape).background(C.Line))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f).padding(top = 2.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(s.point.display, style = T.H3, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (s.legKm > 0) Text("${km(s.legKm)} км", style = T.Small)
            }
            if (s.point.address.isNotBlank()) Text(s.point.address, style = T.Small, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Pill("${fmt(s.weight)} кг", C.Ink2, C.Field)
                if (s.fact > 0) Pill(money(s.fact), C.Pine, C.PineSoft, Ic.Cash)
                if (s.returns.isNotEmpty()) Pill("Возврат", Color.White, C.Ink, Ic.Return)
                if (s.equipment.isNotEmpty()) Pill("Оборудование", Color.White, C.Ink, Ic.Fridge)
                s.point.saturdayBadge?.let { Pill(it, Color.White, C.Danger, Ic.Clock) }
                if (s.point.commentText.isNotBlank()) Pill("Комментарий", C.Sea, C.SeaSoft, Ic.Note)
            }
        }
    }
}

// ======================= Ведение по точкам =======================

@Composable
fun DriveScreen(vm: AppVm) {
    val plan = vm.plan ?: run { vm.screen = Screen.HOME; return }
    if (plan.stops.isEmpty()) { vm.screen = Screen.HOME; return }
    val ctx = LocalContext.current
    val density = androidx.compose.ui.platform.LocalDensity.current
    val idx = vm.stopIndex.coerceIn(0, plan.stops.lastIndex)
    val leftKm = plan.stops.drop(idx + 1).sumOf { it.legKm } + plan.endKm
    var askAbort by remember { mutableStateOf(false) }
    var rootTop by remember { mutableFloatStateOf(0f) }
    val fold = vm.fold
    val last = idx == plan.stops.lastIndex

    val header: @Composable () -> Unit = {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIconButton(Ic.Map, { vm.screen = Screen.OVERVIEW })
            if (vm.scans.isNotEmpty()) { Spacer(Modifier.width(8.dp)); RoundIconButton(Ic.Doc, { vm.showScans = true }) }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                AnimatedContent(idx, label = "cnt") { Text("Точка ${it + 1} из ${plan.stops.size}", style = T.H3) }
                Text(if (leftKm > 0) "дальше ещё ${km(leftKm)} км" else "последняя точка", style = T.Small)
            }
            RoundIconButton(Ic.Close, { askAbort = true })
        }
        SegmentedProgress(plan.stops.size, idx, Modifier.padding(horizontal = 20.dp))
    }
    val pager: @Composable (Modifier) -> Unit = { m ->
        AnimatedContent(
            targetState = idx,
            transitionSpec = {
                val d = if (targetState >= initialState) 1 else -1
                (slideInHorizontally(spring(dampingRatio = 0.82f, stiffness = 320f)) { it * d } + fadeIn(tween(250)) +
                    scaleIn(tween(380), initialScale = 0.94f))
                    .togetherWith(slideOutHorizontally(tween(300)) { -it * d / 2 } + fadeOut(tween(200)) + scaleOut(tween(300), targetScale = 0.92f))
            },
            modifier = m,
            label = "stop"
        ) { i -> StopCard(vm, plan, i) }
    }
    val slider: @Composable () -> Unit = {
        SwipeToConfirm(if (last) "Проведите, чтобы завершить" else "Проведите — следующая точка", { vm.nextStop() },
            icon = if (last) Ic.Flag else Ic.ArrowRight)
    }

    Column(Modifier.fillMaxSize().onGloballyPositioned { rootTop = it.positionInWindow().y }) {
        if (fold != null) {
            // Galaxy Flip в режиме «ноутбук»: карточка — на верхней половине, управление — на нижней
            val topH = with(density) { (fold.first - rootTop).coerceAtLeast(160f).toDp() }
            val gap = with(density) { (fold.second - fold.first).coerceAtLeast(0).toFloat().toDp() }
            Column(Modifier.fillMaxWidth().height(topH)) {
                header()
                pager(Modifier.weight(1f))
            }
            Spacer(Modifier.height(gap))
            FlexControls(vm, plan, idx, Modifier.weight(1f), slider)
        } else {
            header()
            if (plan.agentHandoff.isNotEmpty()) AgentPlaque(vm, plan, Modifier.padding(top = 10.dp))
            pager(Modifier.weight(1f))
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (idx > 0) RoundIconButton(Ic.ChevronLeft, { vm.prevStop() }, size = 54.dp)
                    SecondaryButton("Навигатор", { openNavigator(ctx, plan.stops[idx].point) }, Modifier.weight(1f), icon = Ic.Navigate, tint = C.Sea)
                }
            }
            Box(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, bottom = 8.dp)) { slider() }
        }
    }

    if (vm.askPaid) PaidDialog(plan.stops[idx], { vm.answerPaid(true) }, { vm.answerPaid(false) }) { vm.askPaid = false }

    if (askAbort) ConfirmDialog(
        title = "Прервать маршрут?",
        text = "Осталось ${plan.stops.size - idx} ${plural(plan.stops.size - idx, "точка", "точки", "точек")}. Их не будет в ведении, уведомление закроется.",
        confirm = "Прервать маршрут",
        onConfirm = { askAbort = false; vm.abortRoute() },
        secondary = "Свернуть и вернуться позже",
        onSecondary = { askAbort = false; vm.screen = Screen.HOME },
        onDismiss = { askAbort = false }
    )
}

/** Нижняя половина Flip: крупный звонок агенту, навигатор и слайдер — всё под большим пальцем. */
@Composable
private fun FlexControls(vm: AppVm, plan: Plan, idx: Int, modifier: Modifier, slider: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val s = plan.stops[idx]
    val phones = s.contacts.filter { it.phone.isNotBlank() }
    Column(
        modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        AnimatedContent(phones, label = "call") { list ->
            if (list.isEmpty()) {
                SecondaryButton("Телефон агента не указан", {}, Modifier.fillMaxWidth(), icon = Ic.Phone, enabled = false, height = 64.dp)
            } else Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                list.take(2).forEach { a ->
                    PrimaryButton(if (list.size == 1) "Позвонить: ${a.name.ifBlank { a.num }}" else a.name.ifBlank { a.num },
                        { dial(ctx, a.phone) }, Modifier.weight(1f), icon = Ic.Phone, height = 64.dp)
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (idx > 0) RoundIconButton(Ic.ChevronLeft, { vm.prevStop() }, size = 54.dp)
            SecondaryButton("Навигатор", { openNavigator(ctx, s.point) }, Modifier.weight(1f), icon = Ic.Navigate, tint = C.Sea)
        }
        Box(Modifier.fillMaxWidth().padding(horizontal = 0.dp)) { slider() }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StopCard(vm: AppVm, plan: Plan, i: Int) {
    val s = plan.stops[i]
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(top = 16.dp, bottom = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Главная карточка
        Card(Modifier.fillMaxWidth(), radius = 32.dp, padding = 24.dp, elevation = 18.dp) {
            Row(verticalAlignment = Alignment.Top) {
                Text(String.format("%02d", i + 1), style = T.Display.copy(fontSize = 68.sp, lineHeight = 68.sp, letterSpacing = (-3).sp),
                    modifier = Modifier.liquidGradient(listOf(C.Ink, Color(0xFF9A9DA3), C.Ink, Color(0xFF5A5E66))))
                Spacer(Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (s.legKm > 0) Pill("${km(s.legKm)} км", C.Sea, C.SeaSoft, Ic.Route)
                    if (s.legMin > 0) Pill(minutes(s.legMin), C.Ink2, C.Field, Ic.Clock)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(s.point.display, style = T.H1)
            if (s.point.address.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Ic.Pin, null, tint = C.Mute, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(s.point.address, style = T.Body.copy(fontSize = 16.sp))
                }
            }
            if (s.callsigns.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    s.callsigns.forEach { Pill(it, C.Ink2, C.Field) }
                }
            }
            Spacer(Modifier.height(18.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(C.Line))
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Column(Modifier.weight(1f)) {
                    Text("Выгрузить", style = T.Small)
                    CountUpText(s.weight, T.Num.copy(fontSize = 30.sp), suffix = " кг")
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("останется в кузове", style = T.Small)
                    Text("${fmt(s.remaining)} кг", style = T.Num.copy(fontSize = 18.sp, color = C.Ink2))
                }
            }
        }

        // Суббота: приём до …
        SaturdayNotice(s.point)

        // Фрагмент схемы от предыдущей точки
        Card(Modifier.fillMaxWidth(), padding = 0.dp) {
            LegMap(plan, i, Modifier.fillMaxWidth().height(200.dp))
        }

        // Стоим у точки — записать её координаты с GPS
        var askFix by remember(i) { mutableStateOf(false) }
        val locPerm = androidx.activity.compose.rememberLauncherForActivityResult(
            androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
        ) { granted -> if (granted.values.any { it }) vm.fixCoordsHere(i) else vm.error = "Без доступа к геолокации координаты не уточнить" }
        GhostButton("Уточнить координаты здесь", { askFix = true }, icon = Ic.Locate)
        if (askFix) ConfirmDialog(
            title = "Уточнить координаты?",
            text = "Точка «${s.point.display}» встанет туда, где вы сейчас. Нажимайте, стоя у входа или места разгрузки.",
            confirm = "Записать место",
            onConfirm = {
                askFix = false
                locPerm.launch(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION))
            },
            onDismiss = { askFix = false }
        )

        // Комментарий к выгрузке
        if (s.point.commentText.isNotBlank()) {
            Notice(Ic.Note, "Комментарий к выгрузке") {
                Text(s.point.commentText, style = T.BodyStrong.copy(fontSize = 17.sp, lineHeight = 24.sp))
            }
        }

        // Наличные
        if (s.fact > 0) {
            Notice(Ic.Cash, "Получить наличные") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CountUpText(s.fact, T.Num.copy(fontSize = 32.sp), Modifier.weight(1f), formatter = { money(it) })
                    when (vm.paid[i]) {
                        true -> Pill("Оплачено", Color.White, C.Ink, Ic.Check)
                        false -> Pill("Не оплачено", Color.White, C.Danger, Ic.Close)
                        null -> {}
                    }
                }
            }
        }

        // Возвраты
        if (s.returns.isNotEmpty()) {
            Notice(Ic.Return, "Забрать возврат", strong = true) {
                s.returns.forEach { r ->
                    Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(r.invoiceLabel, style = T.BodyStrong.copy(color = Color.White, fontSize = 17.sp), modifier = Modifier.weight(1f))
                        if (r.weight != 0.0) Text("${fmt(r.weight)} кг", style = T.Small.copy(color = Color.White.copy(alpha = 0.6f)))
                    }
                }
            }
        }

        // Оборудование
        s.equipment.forEach { r ->
            val title = when (r.equip) {
                EquipDir.PICKUP -> "Забрать оборудование"
                EquipDir.DELIVER -> "Доставить оборудование"
                EquipDir.UNKNOWN -> "Оборудование: уточните направление"
            }
            Notice(if (r.equip == EquipDir.PICKUP) Ic.Import else Ic.Fridge, title, strong = true) {
                Text(r.visibleNotes.ifBlank { "Заметки нет" }, style = T.BodyStrong.copy(color = Color.White, fontSize = 17.sp))
                if (r.weight != 0.0) Text("${fmt(r.weight)} кг", style = T.Small.copy(color = Color.White.copy(alpha = 0.6f)))
            }
        }

        // Накладные
        if (s.goods.isNotEmpty()) {
            Card(Modifier.fillMaxWidth(), radius = 24.dp, padding = 18.dp, elevation = 6.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBubble(Ic.Box, C.Sea, C.SeaSoft, 36.dp, 18.dp, RectangleShape)
                    Spacer(Modifier.width(12.dp))
                    Text("Накладные", style = T.H3)
                }
                Spacer(Modifier.height(10.dp))
                // Несколько клиентов в одной остановке — подписываем, чья накладная
                val manyClients = s.rows.map { it.client.trim() }.filter { it.isNotBlank() }.distinct().size > 1
                s.goods.forEach { r ->
                    Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.invoiceLabel, style = T.BodyStrong, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (manyClients && r.client.isNotBlank()) Text(r.client, style = T.Small, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (r.visibleNotes.isNotBlank()) Text(r.visibleNotes, style = T.Small)
                        }
                        Text("${fmt(r.weight)} кг", style = T.Num.copy(fontSize = 15.sp))
                    }
                }
            }
        }

        // Агенты
        s.contacts.forEach { a ->
            Card(Modifier.fillMaxWidth(), radius = 22.dp, padding = 14.dp, elevation = 6.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBubble(Ic.User, C.Ink2, C.Field, 42.dp, 20.dp, RectangleShape)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(a.name.ifBlank { "Агент ${a.num}" }, style = T.H3)
                        if (a.phone.isNotBlank()) Text(a.phone, style = T.Small)
                    }
                    if (a.phone.isNotBlank()) RoundIconButton(Ic.Phone, { dial(ctx, a.phone) }, tint = Color.White, bg = C.Pine)
                }
            }
        }

        // Следующая точка
        plan.stops.getOrNull(i + 1)?.let { n ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Дальше", style = T.Small)
                Spacer(Modifier.width(8.dp))
                Text(n.point.display, style = T.BodyStrong, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (n.legKm > 0) Text("${km(n.legKm)} км", style = T.Small)
            }
        }
    }
}

@Composable
private fun Notice(icon: ImageVector, title: String, strong: Boolean = false, content: @Composable () -> Unit) {
    // strong — инвертированная графитовая карточка для того, что нельзя пропустить (возврат, оборудование)
    val shape = RectangleShape
    Column(
        Modifier.fillMaxWidth()
            .bleed()
            .background(if (strong) C.seaGradient else androidx.compose.ui.graphics.SolidColor(C.Surface))
            .then(if (strong) Modifier.shimmer(true, 0.10f) else Modifier.border(1.dp, C.Line, shape))
            .padding(horizontal = 20.dp, vertical = 18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBubble(icon, if (strong) C.Ink else Color.White, if (strong) Color.White else C.Ink, 36.dp, 18.dp, RectangleShape)
            Spacer(Modifier.width(12.dp))
            Text(title, style = T.H3.copy(color = if (strong) Color.White else C.Ink))
        }
        Spacer(Modifier.height(10.dp))
        content()
    }
}

// ======================= Финиш =======================

@Composable
fun FinishScreen(vm: AppVm) {
    val plan = vm.plan
    val ctx = LocalContext.current
    val aborted = vm.aborted
    val sc = remember { Animatable(0f) }
    val ring = remember { Animatable(0f) }
    LaunchedEffect(Unit) { ring.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(250); sc.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 300f)) }
    val done = if (plan == null) 0 else if (aborted) vm.stopIndex else plan.stops.size
    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(Modifier.size(160.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val st = 8.dp.toPx()
                    drawCircle(C.SeaSoft, size.minDimension / 2 - st)
                    drawArc(if (aborted) C.Mute else C.Sea, -90f, 360f * ring.value * (if (aborted && plan != null && plan.stops.isNotEmpty()) done.toFloat() / plan.stops.size else 1f),
                        false, topLeft = Offset(st / 2, st / 2), size = Size(size.width - st, size.height - st), style = Stroke(st, cap = StrokeCap.Round))
                }
                Icon(if (aborted) Ic.Flag else Ic.Check, null, tint = C.Sea, modifier = Modifier.size(68.dp).graphicsLayer { scaleX = sc.value; scaleY = sc.value })
            }
            Spacer(Modifier.height(28.dp))
            Text(if (aborted) "Маршрут прерван" else "Все точки пройдены", style = T.H1, modifier = Modifier.appear(1), textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            if (plan != null) {
                Text(
                    if (aborted) "Пройдено $done из ${plan.stops.size}" else "${plan.stops.size} ${plural(plan.stops.size, "точка", "точки", "точек")}, ${km(plan.distanceKm)} км",
                    style = T.Body, modifier = Modifier.appear(2)
                )
                CashSummary(vm, plan, Modifier.appear(3))
                plan.end?.let { e ->
                    Spacer(Modifier.height(28.dp))
                    Card(Modifier.fillMaxWidth().appear(4), radius = 26.dp, padding = 20.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconBubble(Ic.Flag, Color.White, C.Ink)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Возвращаемся на склад", style = T.H3)
                                Text(if (!aborted && plan.endKm > 0) "${km(plan.endKm)} км, ${minutes(plan.endMin)}" else "Финиш маршрута", style = T.Small)
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        SecondaryButton("Навигатор до склада", { openNavigator(ctx, e) }, Modifier.fillMaxWidth(), icon = Ic.Navigate, tint = C.Sea)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            PrimaryButton(if (plan?.end != null) "На складе — закрыть маршрут" else "Новый маршрутный лист", { vm.finishRoute() },
                Modifier.fillMaxWidth().appear(5), icon = Ic.Check)
        }
        if (!aborted) Confetti()
    }
}


/** Вопрос после точки с наличными. Ответ идёт в итоговую сумму к сдаче. */
@Composable
private fun PaidDialog(s: PlanStop, onPaid: () -> Unit, onNotPaid: () -> Unit, onDismiss: () -> Unit) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        val sc = remember { Animatable(0.8f) }
        LaunchedEffect(Unit) { sc.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 380f)) }
        Card(Modifier.fillMaxWidth().padding(20.dp).graphicsLayer { scaleX = sc.value; scaleY = sc.value }, radius = 32.dp, padding = 24.dp) {
            IconBubble(Ic.Cash, Color.White, C.Ink, 52.dp, 26.dp, RoundedCornerShape(17.dp))
            Spacer(Modifier.height(16.dp))
            Text("Оплатили?", style = T.H1)
            Spacer(Modifier.height(4.dp))
            Text(s.point.display, style = T.Body, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(14.dp))
            CountUpText(s.fact, T.Display.copy(fontSize = 44.sp, lineHeight = 48.sp), formatter = { money(it) },
                modifier = Modifier.liquidGradient(listOf(C.Ink, Color(0xFF9A9DA3), C.Ink, Color(0xFF5A5E66))))
            Spacer(Modifier.height(22.dp))
            PrimaryButton("Оплатили", onPaid, Modifier.fillMaxWidth(), icon = Ic.Check, height = 62.dp)
            Spacer(Modifier.height(10.dp))
            SecondaryButton("Не оплатили", onNotPaid, Modifier.fillMaxWidth(), icon = Ic.Close, tint = C.Danger, height = 58.dp)
            GhostButton("Вернуться к точке", onDismiss, Modifier.align(Alignment.CenterHorizontally).padding(top = 4.dp))
        }
    }
}

/** Итог по наличным: что получено и к сдаче, и где не оплатили. */
@Composable
private fun CashSummary(vm: AppVm, plan: Plan, modifier: Modifier = Modifier) {
    val agentItems = plan.excluded.withIndex().filter { it.value.reason == ru.marshrut.Excluded.REASON_AGENT }
    if (agentItems.any { it.index !in vm.handed }) {
        Spacer(Modifier.height(24.dp))
        Column(modifier.fillMaxWidth()) {
            Text("ПЕРЕДАТЬ ТОРГОВОМУ — ОТМЕТЬТЕ ОПЛАТУ", style = T.Label)
            Spacer(Modifier.height(8.dp))
            AgentHandoffList(vm, plan)
        }
    }
    val withCash = plan.stops.withIndex().filter { it.value.fact > 0 && vm.paid[it.index] != null }
    val agentAnswered = agentItems.filter { it.value.cash > 0 && vm.agentPaid[it.index] != null }
    if (withCash.isEmpty() && agentAnswered.isEmpty()) return
    val got = withCash.filter { vm.paid[it.index] == true }.sumOf { it.value.fact } +
        agentAnswered.filter { vm.agentPaid[it.index] == true }.sumOf { it.value.cash }
    val unpaid = withCash.filter { vm.paid[it.index] == false }
    val agentUnpaid = agentAnswered.filter { vm.agentPaid[it.index] == false }
    Spacer(Modifier.height(24.dp))
    Card(modifier.fillMaxWidth(), radius = 26.dp, padding = 20.dp) {
        Text("К сдаче наличными", style = T.Small)
        CountUpText(got, T.Display.copy(fontSize = 40.sp, lineHeight = 44.sp), formatter = { money(it) })
        val totalN = withCash.size + agentAnswered.size
        val paidN = totalN - unpaid.size - agentUnpaid.size
        Text("$paidN из $totalN оплатили" + if (agentAnswered.isNotEmpty()) ", включая документы торгового" else "", style = T.Small)
        if (unpaid.isNotEmpty() || agentUnpaid.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(C.Line))
            Spacer(Modifier.height(12.dp))
            Text("Не оплатили — ${money(unpaid.sumOf { it.value.fact } + agentUnpaid.sumOf { it.value.cash })}", style = T.H3.copy(color = C.Danger))
            Spacer(Modifier.height(6.dp))
            unpaid.forEach { (i, st) ->
                Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${i + 1}. ${st.point.display}", style = T.BodyStrong, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(money(st.fact), style = T.Num.copy(fontSize = 15.sp))
                }
            }
            agentUnpaid.forEach { (_, e) ->
                Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Торговый: ${e.title}", style = T.BodyStrong, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(money(e.cash), style = T.Num.copy(fontSize = 15.sp))
                }
            }
        }
    }
}


/**
 * Сводка маршрута лентой: склад → посёлки по порядку объезда → склад. У каждого посёлка — номера точек, вес,
 * дорога до него и значки: деньги, возврат, самая тяжёлая выгрузка. Кнопка отправляет то же текстом в мессенджер.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RouteSummaryCard(plan: Plan, modifier: Modifier) {
    val ctx = LocalContext.current
    val legs = remember(plan) { ru.marshrut.routeLegs(plan) }
    val heavy = remember(plan) { plan.stops.indices.maxByOrNull { plan.stops[it].weight } }
    Card(modifier.fillMaxWidth(), radius = 22.dp, padding = 18.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Сводка маршрута", style = T.H3)
                Text("${legs.size} " + plural(legs.size, "посёлок", "посёлка", "посёлков") + " · ${plan.stops.size} " +
                    plural(plan.stops.size, "точка", "точки", "точек"), style = T.Small)
            }
            RoundIconButton(Ic.Export, {
                val send = android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(android.content.Intent.EXTRA_TEXT, ru.marshrut.routeSummary(plan))
                ctx.startActivity(android.content.Intent.createChooser(send, "Отправить сводку"))
            }, size = 42.dp)
        }
        Spacer(Modifier.height(14.dp))
        val stations = buildList {
            plan.depot?.let { add(null) }
            legs.forEach { add(it) }
            if (plan.end != null) add(null)
        }
        stations.forEachIndexed { k, leg ->
            val first = k == 0; val last = k == stations.lastIndex
            Row(Modifier.fillMaxWidth().height(androidx.compose.foundation.layout.IntrinsicSize.Min)) {
                // Лента: линия сверху и снизу точки, сама точка — квадрат с числом точек посёлка
                Box(Modifier.width(36.dp).fillMaxHeight(), contentAlignment = Alignment.TopCenter) {
                    Column(Modifier.fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.width(2.dp).height(8.dp).background(if (first) Color.Transparent else C.Line))
                        if (leg == null) Box(Modifier.size(14.dp).background(C.Ink))
                        else Box(Modifier.size(28.dp).background(if (leg.cash > 0) C.Pine else C.Ink), contentAlignment = Alignment.Center) {
                            Text("${leg.to - leg.from + 1}", style = T.Label.copy(color = Color.White, fontSize = 12.sp))
                        }
                        Box(Modifier.width(2.dp).weight(1f).background(if (last) Color.Transparent else C.Line))
                    }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f).padding(bottom = if (last) 0.dp else 14.dp)) {
                    if (leg == null) {
                        Text(if (first) "Склад — старт" else "Склад — финиш", style = T.BodyStrong, color = C.Ink2,
                            modifier = Modifier.padding(top = 4.dp))
                        if (last && plan.endKm > 0) Text("${km(plan.endKm)} км · ${minutes(plan.endMin)}", style = T.Small)
                    } else {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(leg.place, style = T.BodyStrong, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${fmt(leg.weight)} кг", style = T.BodyStrong.copy(color = C.Ink2))
                        }
                        Text((if (leg.from == leg.to) "точка ${leg.from + 1}" else "точки ${leg.from + 1}–${leg.to + 1}") +
                            " · ${km(leg.km)} км · ${minutes(leg.min)}", style = T.Small)
                        val heavyHere = heavy != null && heavy in leg.from..leg.to
                        if (leg.cash > 0 || leg.returns > 0 || heavyHere) {
                            Spacer(Modifier.height(6.dp))
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (leg.cash > 0) Pill("Деньги ${money(leg.cash)}", C.Pine, C.PineSoft, Ic.Cash)
                                if (leg.returns > 0) Pill("Возврат: ${leg.returns}", C.Apricot, C.ApricotSoft, Ic.Return)
                                if (heavyHere) Pill("Самое тяжёлое: ${fmt(plan.stops[heavy!!].weight)} кг", C.Ink2, C.Field, Ic.Weight)
                            }
                        }
                    }
                }
            }
        }
    }
}
