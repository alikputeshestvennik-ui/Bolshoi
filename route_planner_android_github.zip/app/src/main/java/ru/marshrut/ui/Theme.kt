package ru.marshrut.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Палитра «Набережная»: меловой фон, морская бирюза, тёплые сигнальные акценты. */
object C {
    val Bg = Color(0xFFF4F6F5)
    val Bg2 = Color(0xFFE9F1EF)
    val Surface = Color(0xFFFFFFFF)
    val Ink = Color(0xFF10202B)
    val Ink2 = Color(0xFF475764)
    val Mute = Color(0xFF8A97A0)
    val Line = Color(0xFFE2E8E6)
    val Field = Color(0xFFF1F4F3)

    val Sea = Color(0xFF0B7A75)
    val SeaBright = Color(0xFF19B3A3)
    val SeaSoft = Color(0xFFDDF3EF)

    val Apricot = Color(0xFFDB7A22)
    val ApricotSoft = Color(0xFFFDEEDC)
    val Lavender = Color(0xFF6E56CF)
    val LavenderSoft = Color(0xFFEEEAFB)
    val Pine = Color(0xFF2E9A5E)
    val PineSoft = Color(0xFFE2F4E9)
    val Danger = Color(0xFFD6455D)
    val DangerSoft = Color(0xFFFBE5E9)

    val seaGradient get() = Brush.linearGradient(listOf(Color(0xFF0A6E6A), Color(0xFF17A99B)))
    val bgGradient get() = Brush.verticalGradient(listOf(Bg2, Bg, Bg))
}

object T {
    private val f = FontFamily.Default
    val Display = TextStyle(fontFamily = f, fontWeight = FontWeight.Black, fontSize = 40.sp, lineHeight = 42.sp, letterSpacing = (-1.2).sp, color = C.Ink)
    val H1 = TextStyle(fontFamily = f, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp, lineHeight = 34.sp, letterSpacing = (-0.8).sp, color = C.Ink)
    val H2 = TextStyle(fontFamily = f, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 27.sp, letterSpacing = (-0.4).sp, color = C.Ink)
    val H3 = TextStyle(fontFamily = f, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 22.sp, letterSpacing = (-0.2).sp, color = C.Ink)
    val Body = TextStyle(fontFamily = f, fontWeight = FontWeight.Normal, fontSize = 15.sp, lineHeight = 21.sp, color = C.Ink2)
    val BodyStrong = TextStyle(fontFamily = f, fontWeight = FontWeight.Medium, fontSize = 15.sp, lineHeight = 21.sp, color = C.Ink)
    val Small = TextStyle(fontFamily = f, fontWeight = FontWeight.Medium, fontSize = 13.sp, lineHeight = 17.sp, color = C.Mute)
    val Button = TextStyle(fontFamily = f, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, letterSpacing = 0.1.sp)
    val Num = TextStyle(fontFamily = f, fontWeight = FontWeight.Bold, fontSize = 22.sp, fontFeatureSettings = "tnum", letterSpacing = (-0.5).sp, color = C.Ink)
}

@Composable
fun MarshrutTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = C.Sea, onPrimary = Color.White, background = C.Bg, surface = C.Surface,
            onSurface = C.Ink, onBackground = C.Ink, error = C.Danger, outline = C.Line
        ),
        content = content
    )
}
