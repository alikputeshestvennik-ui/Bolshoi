package ru.marshrut.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Палитра «Графит»: монохром. Белая бумага, графит и серебро; цвет — только у ошибок.
 * Имена Sea/Apricot/… сохранены как семантические роли, но все они теперь оттенки графита.
 */
object C {
    val Bg = Color(0xFFF3F3F1)
    val Bg2 = Color(0xFFE9E9E6)
    val Surface = Color(0xFFFFFFFF)
    val Ink = Color(0xFF17181B)
    val Ink2 = Color(0xFF4A4D54)
    val Mute = Color(0xFF8E9096)
    val Line = Color(0xFFE3E3E0)
    val Field = Color(0xFFF1F1EF)

    val Sea = Color(0xFF1C1E22)        // главный акцент — графит
    val SeaBright = Color(0xFF6A6D74)  // вторичный — сталь
    val SeaSoft = Color(0xFFEDEDEB)

    val Apricot = Color(0xFF1C1E22)
    val ApricotSoft = Color(0xFFEAEAE7)
    val Lavender = Color(0xFF1C1E22)
    val LavenderSoft = Color(0xFFEAEAE7)
    val Pine = Color(0xFF1C1E22)
    val PineSoft = Color(0xFFEDEDEB)
    val Danger = Color(0xFFC8364A)
    val DangerSoft = Color(0xFFF8E3E6)

    val seaGradient get() = Brush.linearGradient(listOf(Color(0xFF34373E), Color(0xFF0F1012)))
    val bgGradient get() = Brush.verticalGradient(listOf(Bg2, Bg, Bg))
}

object T {
    private val f = FontFamily.Default
    val Display = TextStyle(fontFamily = f, fontWeight = FontWeight.Black, fontSize = 52.sp, lineHeight = 50.sp, letterSpacing = (-2.2).sp, color = C.Ink)
    val H1 = TextStyle(fontFamily = f, fontWeight = FontWeight.Black, fontSize = 34.sp, lineHeight = 36.sp, letterSpacing = (-1.2).sp, color = C.Ink)
    /** Подписи-капсы с разрядкой — «журнальная» навигация по экрану. */
    val Label = TextStyle(fontFamily = f, fontWeight = FontWeight.SemiBold, fontSize = 11.5.sp, lineHeight = 15.sp, letterSpacing = 1.4.sp, color = C.Mute)
    val H2 = TextStyle(fontFamily = f, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 27.sp, letterSpacing = (-0.4).sp, color = C.Ink)
    val H3 = TextStyle(fontFamily = f, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 22.sp, letterSpacing = (-0.2).sp, color = C.Ink)
    val Body = TextStyle(fontFamily = f, fontWeight = FontWeight.Normal, fontSize = 15.sp, lineHeight = 21.sp, color = C.Ink2)
    val BodyStrong = TextStyle(fontFamily = f, fontWeight = FontWeight.Medium, fontSize = 15.sp, lineHeight = 21.sp, color = C.Ink)
    val Small = TextStyle(fontFamily = f, fontWeight = FontWeight.Medium, fontSize = 13.sp, lineHeight = 17.sp, color = C.Mute)
    val Button = TextStyle(fontFamily = f, fontWeight = FontWeight.Bold, fontSize = 13.5.sp, letterSpacing = 1.3.sp)
    val Num = TextStyle(fontFamily = f, fontWeight = FontWeight.Bold, fontSize = 22.sp, fontFeatureSettings = "tnum", letterSpacing = (-0.5).sp, color = C.Ink)
}

@Composable
fun MarshrutTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = C.Sea, onPrimary = Color.White, background = C.Bg, surface = C.Surface,
            onSurface = C.Ink, onBackground = C.Ink, error = C.Danger, outline = C.Line
        ),
        content = content
    )
}
