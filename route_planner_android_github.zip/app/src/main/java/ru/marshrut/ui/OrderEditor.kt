package ru.marshrut.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.zIndex
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import ru.marshrut.Plan
import java.io.File
import kotlin.math.roundToInt

/**
 * Свой порядок точек списком: держите точку и тяните вверх или вниз (или стрелками — удобно в перчатках).
 * onDone — номера точек плана в новом порядке.
 */
@Composable
fun ReorderDialog(plan: Plan, onDone: (List<Int>) -> Unit, onDismiss: () -> Unit) {
    val order = remember { mutableStateListOf<Int>().apply { addAll(plan.stops.indices) } }
    var dragging by remember { mutableStateOf<Int?>(null) }
    var dragY by remember { mutableFloatStateOf(0f) }
    val rowH = 64.dp
    val rowPx = with(LocalDensity.current) { rowH.toPx() }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Column(Modifier.fillMaxSize().background(C.Bg)) {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Свой порядок", style = T.H2)
                    Text("Держите точку и тяните выше или ниже", style = T.Small)
                }
                RoundIconButton(Ic.Close, onDismiss, size = 44.dp)
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState(), enabled = dragging == null).padding(horizontal = 16.dp)) {
                order.forEachIndexed { pos, idx ->
                    key(idx) {
                        val s = plan.stops[idx]
                        val isDrag = dragging == idx
                        Row(
                            Modifier.fillMaxWidth().height(rowH).zIndex(if (isDrag) 1f else 0f)
                                .offset { IntOffset(0, if (isDrag) dragY.roundToInt() else 0) }
                                .then(if (isDrag) Modifier.shadow(10.dp, RectangleShape) else Modifier)
                                .background(if (isDrag) C.Surface else C.Bg)
                                .pointerInput(idx) {
                                    detectDragGesturesAfterLongPress(
                                        onDragStart = { dragging = idx; dragY = 0f },
                                        onDragEnd = { dragging = null; dragY = 0f },
                                        onDragCancel = { dragging = null; dragY = 0f },
                                        onDrag = { change, amount ->
                                            change.consume()
                                            dragY += amount.y
                                            val cur = order.indexOf(idx)
                                            if (dragY > rowPx / 2 && cur < order.lastIndex) {
                                                order.removeAt(cur); order.add(cur + 1, idx); dragY -= rowPx
                                            } else if (dragY < -rowPx / 2 && cur > 0) {
                                                order.removeAt(cur); order.add(cur - 1, idx); dragY += rowPx
                                            }
                                        }
                                    )
                                }
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(34.dp).background(if (pos == idx) C.Field else C.Ink), contentAlignment = Alignment.Center) {
                                Text("${pos + 1}", style = T.BodyStrong, color = if (pos == idx) C.Ink else Color.White)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(s.point.display, style = T.BodyStrong, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(s.point.address.ifBlank { s.callsigns.joinToString() }, style = T.Small, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            RoundIconButton(Ic.ChevronDown, {
                                val cur = order.indexOf(idx); if (cur > 0) { order.removeAt(cur); order.add(cur - 1, idx) }
                            }, Modifier.rotate(180f), size = 36.dp)
                            Spacer(Modifier.width(6.dp))
                            RoundIconButton(Ic.ChevronDown, {
                                val cur = order.indexOf(idx); if (cur < order.lastIndex) { order.removeAt(cur); order.add(cur + 1, idx) }
                            }, size = 36.dp)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
            Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SecondaryButton("Отмена", onDismiss, Modifier.weight(1f))
                PrimaryButton("Ехать так", { onDone(order.toList()) }, Modifier.weight(1.4f), icon = Ic.Check)
            }
        }
    }
}

/** Кружок с номером (или пустой, если точку ещё не отметили) — значок на карте. */
private fun badge(ctx: android.content.Context, n: Int?): BitmapDrawable {
    val d = ctx.resources.displayMetrics.density
    val sz = (34 * d).toInt()
    val bm = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
    val c = Canvas(bm)
    val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (n == null) android.graphics.Color.WHITE else android.graphics.Color.rgb(28, 30, 34) }
    val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(28, 30, 34); style = Paint.Style.STROKE; strokeWidth = 3 * d }
    c.drawCircle(sz / 2f, sz / 2f, sz / 2f - 2 * d, fill)
    c.drawCircle(sz / 2f, sz / 2f, sz / 2f - 2 * d, ring)
    if (n != null) {
        val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE; textSize = 15 * d; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
        c.drawText(n.toString(), sz / 2f, sz / 2f + 5.5f * d, t)
    }
    return BitmapDrawable(ctx.resources, bm)
}

/**
 * «Нарисовать» маршрут на карте: нажимайте точки по очереди — номера появляются по мере нажатий, линия тянется следом.
 * Не отмеченные точки приложение вставит само. onDone — номера точек плана в порядке нажатий.
 */
@Composable
fun DrawOrderDialog(plan: Plan, onDone: (List<Int>) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val picked = remember { mutableStateListOf<Int>() }
    val map = remember {
        Configuration.getInstance().apply {
            userAgentValue = ctx.packageName
            osmdroidBasePath = File(ctx.cacheDir, "osm")
            osmdroidTileCache = File(ctx.cacheDir, "osm/tiles")
        }
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            isTilesScaledToDpi = true
            minZoomLevel = 6.0; maxZoomLevel = 19.0
        }
    }
    val line = remember { Polyline(map).apply { outlinePaint.color = android.graphics.Color.rgb(28, 30, 34); outlinePaint.strokeWidth = 6f * ctx.resources.displayMetrics.density } }
    val markers = remember {
        plan.stops.mapIndexed { i, s ->
            Marker(map).apply {
                position = GeoPoint(s.point.lat, s.point.lon)
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                title = s.point.display
                icon = badge(ctx, null)
                setOnMarkerClickListener { _, _ -> if (i !in picked) picked.add(i); true }
            }
        }
    }
    LaunchedEffect(Unit) {
        map.overlays.add(line)
        markers.forEach { map.overlays.add(it) }
        plan.depot?.let { d -> map.overlays.add(Marker(map).apply { position = GeoPoint(d.lat, d.lon); title = "Склад"; setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM) }) }
        val pts = plan.stops.map { GeoPoint(it.point.lat, it.point.lon) }
        if (pts.size > 1) map.post { runCatching { map.zoomToBoundingBox(BoundingBox.fromGeoPoints(pts).increaseByScale(1.25f), false) } }
        else pts.firstOrNull()?.let { map.controller.setZoom(15.0); map.controller.setCenter(it) }
    }
    // Номера и линия — по мере нажатий
    LaunchedEffect(picked.toList()) {
        markers.forEachIndexed { i, m -> m.icon = badge(ctx, picked.indexOf(i).takeIf { it >= 0 }?.plus(1)) }
        line.setPoints(listOfNotNull(plan.depot?.let { GeoPoint(it.lat, it.lon) }) + picked.map { GeoPoint(plan.stops[it].point.lat, plan.stops[it].point.lon) })
        map.invalidate()
    }
    DisposableEffect(Unit) { map.onResume(); onDispose { map.onPause(); map.onDetach() } }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(Modifier.fillMaxSize().background(C.Bg)) {
            AndroidView({ map }, Modifier.fillMaxSize())
            Row(
                Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(12.dp)
                    .background(C.Surface).border(1.dp, C.Line).padding(start = 14.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Нарисуйте маршрут", style = T.BodyStrong)
                    Text("Нажимайте точки по порядку: отмечено ${picked.size} из ${plan.stops.size}", style = T.Small)
                }
                RoundIconButton(Ic.Close, onDismiss, size = 42.dp)
            }
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(12.dp)
                    .background(C.Surface).border(1.dp, C.Line).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecondaryButton("Отменить", { if (picked.isNotEmpty()) picked.removeAt(picked.lastIndex) }, Modifier.weight(1f), icon = Ic.Return, enabled = picked.isNotEmpty())
                    SecondaryButton("Сначала", { picked.clear() }, Modifier.weight(1f), icon = Ic.Close, enabled = picked.isNotEmpty())
                }
                PrimaryButton(if (picked.size < plan.stops.size && picked.isNotEmpty()) "Готово — остальные вставлю сам" else "Готово",
                    { onDone(picked.toList()) }, Modifier.fillMaxWidth(), icon = Ic.Check, enabled = picked.isNotEmpty())
            }
        }
    }
}
