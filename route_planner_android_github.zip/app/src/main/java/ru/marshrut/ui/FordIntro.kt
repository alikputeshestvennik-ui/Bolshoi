package ru.marshrut.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import kotlin.math.cos
import kotlin.math.sin

/** Транспорт листа — Форд: на экране проверки заезжает красный Форд Транзит. */
fun isFord(header: String) = header.contains("форд", true) || header.contains("ford", true) || header.contains("транзит", true)

/** Пропорции рисунка: 300 × 120 условных единиц, морда смотрит влево. */
const val FORD_ASPECT = 300f / 120f

private val Red = Color(0xFFD32F2F)
private val RedLight = Color(0xFFEF5350)
private val RedDark = Color(0xFF9E1B1B)
private val Glass = Color(0xFF26313D)
private val GlassHi = Color(0xFF51606F)
private val Tire = Color(0xFF1B1B1B)
private val Rim = Color(0xFFC9CDD2)
private val Plastic = Color(0xFF2B2B2B)
private val FordBlue = Color(0xFF1F3A93)

/**
 * Красный Форд Транзит сбоку.
 * @param wheel угол поворота колёс, рад (крутятся при движении)
 * @param nose  наклон кузова при торможении, градусы (нос вниз — положительный)
 */
@Composable
fun FordTransit(wheel: Float, nose: Float, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val k = size.width / 300f
        scale(k, k, pivot = Offset.Zero) { drawVan(wheel, nose) }
    }
}

private fun DrawScope.drawVan(wheel: Float, nose: Float) {
    // Тень на асфальте
    drawOval(Color.Black.copy(alpha = 0.18f), topLeft = Offset(8f, 106f), size = Size(290f, 10f))

    rotate(-nose, pivot = Offset(240f, 100f)) {
        // Кузов
        val body = Path().apply {
            moveTo(8f, 98f)
            lineTo(5f, 80f)
            quadraticBezierTo(6f, 68f, 14f, 64f)
            lineTo(50f, 55f)
            lineTo(80f, 20f)
            quadraticBezierTo(86f, 12f, 98f, 12f)
            lineTo(286f, 12f)
            quadraticBezierTo(296f, 12f, 296f, 22f)
            lineTo(296f, 96f)
            quadraticBezierTo(296f, 100f, 290f, 100f)
            lineTo(264f, 100f)
            arcTo(Rect(Offset(240f, 100f), 24f), 0f, -180f, false)
            lineTo(86f, 100f)
            arcTo(Rect(Offset(62f, 100f), 24f), 0f, -180f, false)
            lineTo(12f, 100f)
            close()
        }
        drawPath(body, Brush.verticalGradient(listOf(RedLight, Red, RedDark), startY = 12f, endY = 100f))
        // Блик по крыше и тёмный низ
        drawLine(Color.White.copy(alpha = 0.35f), Offset(100f, 16f), Offset(284f, 16f), 2f, StrokeCap.Round)
        drawRect(Color.Black.copy(alpha = 0.12f), Offset(86f, 88f), Size(130f, 12f))

        // Лобовое и боковое стекло
        val wind = Path().apply { moveTo(54f, 55f); lineTo(82f, 22f); lineTo(116f, 22f); lineTo(116f, 55f); close() }
        drawPath(wind, Brush.linearGradient(listOf(GlassHi, Glass), Offset(60f, 25f), Offset(110f, 55f)))
        drawRoundRect(Brush.linearGradient(listOf(GlassHi, Glass), Offset(124f, 22f), Offset(170f, 52f)),
            Offset(124f, 22f), Size(46f, 31f), CornerRadius(4f))
        drawLine(Color.White.copy(alpha = 0.25f), Offset(88f, 26f), Offset(70f, 48f), 3f, StrokeCap.Round)

        // Линии дверей: водительская, сдвижная, задняя
        val seam = Color.Black.copy(alpha = 0.35f)
        drawLine(seam, Offset(120f, 18f), Offset(120f, 96f), 1.4f)
        drawLine(seam, Offset(176f, 18f), Offset(176f, 96f), 1.4f)
        drawLine(seam, Offset(176f, 56f), Offset(282f, 56f), 1.2f)
        drawLine(seam, Offset(286f, 18f), Offset(286f, 96f), 1.4f)
        drawRoundRect(Plastic, Offset(106f, 60f), Size(9f, 3f), CornerRadius(1.5f))
        drawRoundRect(Plastic, Offset(181f, 60f), Size(9f, 3f), CornerRadius(1.5f))

        // Зеркало, фара, решётка, бампер, значок Ford
        drawRoundRect(Plastic, Offset(76f, 44f), Size(9f, 10f), CornerRadius(2f))
        drawRoundRect(Color(0xFFFFF4C2), Offset(9f, 64f), Size(14f, 7f), CornerRadius(3f))
        drawRoundRect(Plastic, Offset(6f, 73f), Size(26f, 12f), CornerRadius(3f))
        drawRoundRect(Plastic, Offset(4f, 88f), Size(36f, 10f), CornerRadius(3f))
        drawRoundRect(Plastic, Offset(268f, 88f), Size(28f, 10f), CornerRadius(3f))
        drawOval(Color.White, Offset(10f, 75.5f), Size(13f, 7f))
        drawOval(FordBlue, Offset(11f, 76.3f), Size(11f, 5.4f))
        drawRoundRect(Color(0xFFB71C1C), Offset(291f, 24f), Size(5f, 12f), CornerRadius(2f))
    }

    wheelAt(62f, wheel); wheelAt(240f, wheel)
}

private fun DrawScope.wheelAt(cx: Float, angle: Float) {
    val c = Offset(cx, 100f)
    drawCircle(Tire, 17f, c)
    drawCircle(Rim, 9.5f, c)
    drawCircle(Color(0xFF8E949A), 3f, c)
    for (i in 0 until 5) {
        val a = angle + i * (2 * Math.PI / 5).toFloat()
        drawLine(Color(0xFF8E949A), c, Offset(cx + 8.5f * cos(a), 100f + 8.5f * sin(a)), 1.8f, StrokeCap.Round)
    }
    drawCircle(Color.Black.copy(alpha = 0.25f), 17f, c, style = Stroke(1.5f))
}
