package ru.marshrut.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.PathParser
import kotlin.math.cos
import kotlin.math.sin

/** Транспорт листа — Форд: на экране проверки заезжает красный Форд Транзит. */
fun isFord(header: String) = header.contains("форд", true) || header.contains("ford", true) || header.contains("транзит", true)

/** Пропорции рисунка: 400 × 204 условных единиц, морда смотрит влево (Транзит Mk7, средняя крыша). */
const val FORD_ASPECT = 400f / 204f
/** Радиус колеса в долях ширины рисунка — чтобы колёса крутились без проскальзывания. */
const val FORD_WHEEL = 24f / 400f

private fun svg(d: String): Path = PathParser().parsePathString(d).toPath()

private val BODY = svg("M12 172 L9 146 Q8 128 14 116 Q30 104 62 96 L104 34 Q110 24 126 22 L380 20 Q391 20 391 32 L391 166 Q391 172 385 172 L350 172 A32 32 0 0 0 286 172 L110 172 A32 32 0 0 0 46 172 Z")
private val SILL = svg("M110 172 L286 172 L286 152 L110 154 Z")
private val SILL_REAR = svg("M350 172 L385 172 Q391 172 391 166 L391 150 L350 151 Z")
private val ARCH_F = svg("M48 172 A30 30 0 0 1 108 172")
private val ARCH_R = svg("M288 172 A30 30 0 0 1 348 172")
private val BUMPER = svg("M8 140 L42 138 Q48 150 47 172 L12 172 Q8 160 8 146 Z")
private val GRILLE = svg("M9 127 L24 125 L28 139 L9 141 Z")
private val LAMP = svg("M15 117 Q30 106 58 99 L62 104 Q44 116 24 126 L15 126 Z")
private val LAMP_AMBER = svg("M17 121 L24 118 L24 124 L17 125 Z")
private val WIND = svg("M66 94 L105 36 Q109 30 116 29 L104 94 Z")
private val PILLAR = svg("M104 94 L116 29 L122 28 L110 94 Z")
private val DOOR_GLASS = svg("M118 32 L174 30 L174 90 L112 90 Z")
private val SAIL = svg("M111 90 L117 60 L130 90 Z")

private val RedTop = Color(0xFFE8473F)
private val RedMid = Color(0xFFC92A2A)
private val RedLow = Color(0xFF8F1D1D)
private val GlassHi = Color(0xFF5B6A78)
private val Glass = Color(0xFF1F2830)
private val Black = Color(0xFF1C1E21)
private val Plastic = Color(0xFF2E3034)
private val Cladding = Color(0xFF4A4D52)
private val Tire = Color(0xFF1B1B1B)
private val Steel = Color(0xFFB9BEC4)

/**
 * Красный Форд Транзит сбоку.
 * @param wheel угол поворота колёс, рад (крутятся при движении)
 * @param nose  наклон кузова при торможении, градусы (нос вниз — положительный)
 */
@Composable
fun FordTransit(wheel: Float, nose: Float, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val k = size.width / 400f
        scale(k, k, pivot = Offset.Zero) { drawVan(wheel, nose) }
    }
}

private fun DrawScope.drawVan(wheel: Float, nose: Float) {
    drawOval(Color.Black.copy(alpha = 0.22f), topLeft = Offset(6f, 192f), size = Size(388f, 10f))
    // Колёсные ниши
    drawCircle(Color(0xFF141414), 30f, Offset(78f, 172f))
    drawCircle(Color(0xFF141414), 30f, Offset(318f, 172f))

    rotate(-nose, pivot = Offset(318f, 172f)) {
        drawPath(BODY, Brush.verticalGradient(0f to RedTop, 0.55f to RedMid, 1f to RedLow, startY = 20f, endY = 172f))
        drawLine(Color.White.copy(alpha = 0.35f), Offset(130f, 25f), Offset(378f, 23f), 2.5f, StrokeCap.Round)
        drawPath(SILL, Cladding); drawPath(SILL_REAR, Cladding)
        drawPath(ARCH_F, Color(0xFF3A3C40), style = Stroke(6f)); drawPath(ARCH_R, Color(0xFF3A3C40), style = Stroke(6f))
        drawPath(BUMPER, Plastic)
        drawLine(Color(0xFF202225), Offset(10f, 158f), Offset(44f, 157f), 2f)
        drawPath(GRILLE, Color(0xFF1E2023))
        drawOval(Color(0xFFCFD6DE), Offset(8.4f, 128.6f), Size(5.2f, 8.8f))
        drawOval(Color(0xFF1F4BA5), Offset(8.8f, 129f), Size(4.4f, 8f))
        drawPath(LAMP, Color(0xFFE9EEF2)); drawPath(LAMP, Color(0xFF9AA3AB), style = Stroke(0.8f))
        drawPath(LAMP_AMBER, Color(0xFFF6C343))
        val glass = Brush.linearGradient(listOf(GlassHi, Glass), Offset(70f, 30f), Offset(170f, 92f))
        drawPath(WIND, glass); drawPath(PILLAR, Color(0xFF222222))
        drawPath(DOOR_GLASS, glass); drawPath(SAIL, Color(0xFF1A1C1F))
        // Зеркало
        drawRoundRect(Black, Offset(96f, 62f), Size(13f, 30f), CornerRadius(3f))
        drawLine(Black, Offset(108f, 80f), Offset(116f, 80f), 3f)
        // Швы дверей: передняя, водительская, сдвижная, задняя
        val seam = Color.Black.copy(alpha = 0.38f)
        drawLine(seam, Offset(110f, 94f), Offset(106f, 152f), 1.4f)
        drawLine(seam, Offset(178f, 26f), Offset(178f, 152f), 1.4f)
        drawLine(seam, Offset(240f, 24f), Offset(240f, 152f), 1.4f)
        drawLine(seam, Offset(384f, 22f), Offset(384f, 168f), 1.4f)
        // Молдинг сдвижной двери, ручки, повторитель, фонарь
        drawLine(Color(0xFF24262A), Offset(240f, 118f), Offset(383f, 117f), 3.5f, StrokeCap.Round)
        drawRoundRect(Color(0xFF24262A), Offset(164f, 110f), Size(9f, 12f), CornerRadius(2f))
        drawRoundRect(Color(0xFF24262A), Offset(244f, 110f), Size(9f, 12f), CornerRadius(2f))
        drawRoundRect(Color(0xFFF2A33A), Offset(96f, 118f), Size(7f, 3f), CornerRadius(1.5f))
        drawRoundRect(Color(0xFFD81B1B), Offset(387f, 104f), Size(4f, 40f), CornerRadius(1.5f))
        // Шильдик TRANSIT
        drawContext.canvas.nativeCanvas.drawText("TRANSIT", 128f, 100f, android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.rgb(201, 205, 210); textSize = 7f; isFakeBoldText = true; letterSpacing = 0.08f
        })
    }

    wheelAt(78f, wheel); wheelAt(318f, wheel)
}

/** Стальной диск с пятью отверстиями — поворачивается вместе с колесом. */
private fun DrawScope.wheelAt(cx: Float, angle: Float) {
    val c = Offset(cx, 172f)
    drawCircle(Tire, 24f, c)
    drawCircle(Color(0xFF2C2C2C), 21f, c, style = Stroke(1.5f))
    drawCircle(Steel, 14.5f, c)
    drawCircle(Color(0xFF9AA0A6), 12f, c, style = Stroke(1f))
    drawCircle(Color(0xFF8A9096), 5.5f, c)
    for (i in 0 until 5) {
        val a = angle + i * (2 * Math.PI / 5).toFloat()
        drawCircle(Color(0xFF6E747A), 1.4f, Offset(cx + 7.5f * cos(a), 172f + 7.5f * sin(a)))
    }
}
