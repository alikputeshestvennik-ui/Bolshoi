package ru.marshrut.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.unit.dp

/** Собственный набор линейных иконок 24×24: тонкий штрих, скруглённые концы. */
object Ic {
    private fun icon(name: String, strokes: List<String>, fills: List<String> = emptyList(), width: Float = 1.8f): ImageVector {
        val b = ImageVector.Builder(name = name, defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f)
        strokes.forEach {
            b.addPath(
                pathData = addPathNodes(it), fill = null, stroke = SolidColor(Color.Black), strokeLineWidth = width,
                strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round
            )
        }
        fills.forEach { b.addPath(pathData = addPathNodes(it), fill = SolidColor(Color.Black)) }
        return b.build()
    }

    val Scan by lazy {
        icon("scan", listOf(
            "M4 8V6a2 2 0 0 1 2-2h2", "M16 4h2a2 2 0 0 1 2 2v2", "M20 16v2a2 2 0 0 1-2 2h-2", "M8 20H6a2 2 0 0 1-2-2v-2",
            "M4 12h16", "M8.5 8h7", "M8.5 16h4"
        ))
    }
    val Camera by lazy {
        icon("camera", listOf("M4 8.5a2 2 0 0 1 2-2h2.2l1.6-2.2h4.4l1.6 2.2H18a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z",
            "M15.5 13a3.5 3.5 0 1 1-7 0a3.5 3.5 0 1 1 7 0z"))
    }
    val Sparkle by lazy {
        icon("sparkle", listOf(
            "M11 3.5l1.7 4.6 4.8 1.6-4.8 1.7L11 16l-1.7-4.6-4.8-1.7 4.8-1.6z",
            "M18.5 14.5l0.7 1.8 1.8 0.7-1.8 0.7-0.7 1.8-0.7-1.8-1.8-0.7 1.8-0.7z"
        ))
    }
    val Sliders by lazy {
        icon("sliders", listOf(
            "M4 7h9", "M17 7h3", "M4 17h3", "M11 17h9",
            "M17 7a2 2 0 1 1-4 0a2 2 0 1 1 4 0z", "M11 17a2 2 0 1 1-4 0a2 2 0 1 1 4 0z"
        ))
    }
    val Database by lazy {
        icon("db", listOf(
            "M4 6c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3z",
            "M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6", "M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"
        ))
    }
    val Import by lazy { icon("import", listOf("M12 4v11", "M7.5 10.5L12 15l4.5-4.5", "M4 16v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2")) }
    val Export by lazy { icon("export", listOf("M12 15V4", "M7.5 8.5L12 4l4.5 4.5", "M4 16v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2")) }
    val Pin by lazy {
        icon("pin", listOf("M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z", "M14.5 9.5a2.5 2.5 0 1 1-5 0a2.5 2.5 0 1 1 5 0z"))
    }
    val Navigate by lazy { icon("nav", listOf("M4 11.2L20 4l-7.2 16-1.9-6.9z")) }
    val Route by lazy {
        icon("route", listOf(
            "M8 18h8a3 3 0 0 0 0-6H8a3 3 0 0 1 0-6h8",
            "M8 18a2 2 0 1 1-4 0a2 2 0 1 1 4 0z", "M20 6a2 2 0 1 1-4 0a2 2 0 1 1 4 0z"
        ))
    }
    val Phone by lazy {
        icon("phone", listOf("M5.2 4h3.3l1.6 4-2.1 1.4a11 11 0 0 0 6.6 6.6l1.4-2.1 4 1.6v3.3a1.6 1.6 0 0 1-1.7 1.6A16 16 0 0 1 3.6 5.7 1.6 1.6 0 0 1 5.2 4z"))
    }
    val Cash by lazy {
        icon("cash", listOf(
            "M5 6h14a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z",
            "M14.5 12a2.5 2.5 0 1 1-5 0a2.5 2.5 0 1 1 5 0z", "M6.5 10v4", "M17.5 10v4"
        ))
    }
    val Return by lazy { icon("return", listOf("M9 14L4 9l5-5", "M4 9h10.5a5.5 5.5 0 0 1 0 11H11")) }
    val Box by lazy { icon("box", listOf("M12 3l8 4.5v9L12 21l-8-4.5v-9z", "M4 7.5l8 4.5 8-4.5", "M12 12v9")) }
    val Fridge by lazy {
        icon("equipment", listOf(
            "M7 3h10a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z", "M6 10h12", "M9 6v1.5", "M9 13v3"
        ))
    }
    val Warning by lazy {
        icon("warn", listOf("M10.3 4.9a2 2 0 0 1 3.4 0l7 12.2a2 2 0 0 1-1.7 3H5a2 2 0 0 1-1.7-3z", "M12 9.5v4"),
            listOf("M12 15.8a1 1 0 1 1 0 2a1 1 0 1 1 0-2z"))
    }
    val Check by lazy { icon("check", listOf("M5 12.5l4.5 4.5L19 7.5"), width = 2.2f) }
    val ChevronRight by lazy { icon("cr", listOf("M9.5 5.5L16 12l-6.5 6.5")) }
    val ChevronLeft by lazy { icon("cl", listOf("M14.5 5.5L8 12l6.5 6.5")) }
    val ChevronDown by lazy { icon("cd", listOf("M5.5 9.5L12 16l6.5-6.5")) }
    val ArrowRight by lazy { icon("ar", listOf("M5 12h14", "M13.5 6.5L19 12l-5.5 5.5"), width = 2f) }
    val Close by lazy { icon("close", listOf("M6.5 6.5l11 11", "M17.5 6.5l-11 11")) }
    val Plus by lazy { icon("plus", listOf("M12 5v14", "M5 12h14")) }
    val Minus by lazy { icon("minus", listOf("M5 12h14")) }
    val Trash by lazy {
        icon("trash", listOf("M4 7h16", "M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2", "M6.5 7l1 12a2 2 0 0 0 2 1.8h5a2 2 0 0 0 2-1.8l1-12", "M10 11v6", "M14 11v6"))
    }
    val Search by lazy { icon("search", listOf("M17 11a6 6 0 1 1-12 0a6 6 0 1 1 12 0z", "M15.5 15.5L20 20")) }
    val Flag by lazy { icon("flag", listOf("M5 21V4", "M5 4h12l-2.5 4 2.5 4H5")) }
    val Play by lazy { icon("play", emptyList(), listOf("M8 5.2c0-0.8 0.9-1.3 1.5-0.9l9.6 6.3c0.6 0.4 0.6 1.4 0 1.8l-9.6 6.3c-0.6 0.4-1.5-0.1-1.5-0.9z")) }
    val Weight by lazy { icon("weight", listOf("M9 8.5a3 3 0 1 1 6 0", "M6.6 10h10.8l1.6 9.5H5z")) }
    val Clock by lazy { icon("clock", listOf("M21 12a9 9 0 1 1-18 0a9 9 0 1 1 18 0z", "M12 7v5l3.2 2")) }
    val Note by lazy {
        icon("note", listOf(
            "M4 4.5h16a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1h-8.5L7 20.5v-4H4a1 1 0 0 1-1-1v-10a1 1 0 0 1 1-1z", "M7.5 9h9", "M7.5 12h6"
        ))
    }
    val Edit by lazy { icon("edit", listOf("M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z", "M13.5 6.5l4 4")) }
    val User by lazy { icon("user", listOf("M16 8a4 4 0 1 1-8 0a4 4 0 1 1 8 0z", "M4.5 20a7.5 7.5 0 0 1 15 0")) }
    val Map by lazy { icon("map", listOf("M9 4L3.5 6.3v13.5L9 17.5l6 2.5 5.5-2.3V4.2L15 6.5z", "M9 4v13.5", "M15 6.5V20")) }
    val Sort by lazy { icon("sort", listOf("M7 4v16", "M3.5 16.5L7 20l3.5-3.5", "M17 20V4", "M13.5 7.5L17 4l3.5 3.5")) }
    val Skip by lazy { icon("skip", listOf("M5 12h11", "M12 7.5l4.5 4.5-4.5 4.5", "M20 6v12")) }
    val Locate by lazy { icon("locate", listOf("M18 12a6 6 0 1 1-12 0a6 6 0 1 1 12 0z", "M12 2.5v3", "M12 18.5v3", "M2.5 12h3", "M18.5 12h3")) }
    val Doc by lazy { icon("doc", listOf("M6 3h8l4 4v13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z", "M14 3v4h4", "M8.5 12h7", "M8.5 16h5")) }
    val Truck by lazy {
        icon("truck", listOf(
            "M3 6h11v10H3z", "M14 9h4l3 3.5V16h-7", "M9 18a2 2 0 1 1-4 0a2 2 0 1 1 4 0z", "M19 18a2 2 0 1 1-4 0a2 2 0 1 1 4 0z"
        ))
    }
}
