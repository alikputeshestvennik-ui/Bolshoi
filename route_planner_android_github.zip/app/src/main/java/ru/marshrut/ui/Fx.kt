package ru.marshrut.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import ru.marshrut.fmt
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/** Живой фон: три мягких световых пятна медленно дрейфуют по фигурам Лиссажу. Перерисовка только в фазе рисования. */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "aurora")
    val p by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(24000, easing = LinearEasing)), label = "ap")
    Canvas(modifier.fillMaxSize()) {
        drawRect(C.bgGradient)
        val w = size.width; val h = size.height
        fun blob(color: Color, cx: Float, cy: Float, r: Float) {
            drawCircle(Brush.radialGradient(listOf(color, color.copy(alpha = 0f)), center = Offset(cx, cy), radius = r), r, Offset(cx, cy))
        }
        // монохром: светлые «софиты» и мягкие графитовые тени
        blob(Color.White.copy(alpha = 0.95f), w * (0.18f + 0.16f * cos(p)), h * (0.10f + 0.06f * sin(2 * p)), w * 0.9f)
        blob(C.Ink.copy(alpha = 0.045f), w * (0.92f + 0.10f * sin(p)), h * (0.40f + 0.10f * cos(p)), w * 0.8f)
        blob(Color.White.copy(alpha = 0.8f), w * (0.30f + 0.20f * sin(p + 1.5f)), h * (0.88f + 0.05f * cos(2 * p)), w * 0.85f)
        blob(C.Ink.copy(alpha = 0.035f), w * (0.05f + 0.08f * cos(p + 2f)), h * (0.62f + 0.08f * sin(p)), w * 0.6f)
    }
}

/** Блик, пробегающий по кнопке. */
@Composable
fun Modifier.shimmer(active: Boolean = true, alpha: Float = 0.30f): Modifier {
    val t = rememberInfiniteTransition(label = "sh")
    val x by t.animateFloat(-0.6f, 1.6f, infiniteRepeatable(tween(2400, delayMillis = 1400, easing = FastOutSlowInEasing)), label = "shx")
    return this.drawWithContent {
        drawContent()
        if (active) {
            val w = size.width; val cx = w * x
            drawRect(
                Brush.linearGradient(
                    listOf(Color.Transparent, Color.White.copy(alpha = alpha), Color.Transparent),
                    start = Offset(cx - w * 0.22f, 0f), end = Offset(cx + w * 0.22f, size.height)
                )
            )
        }
    }
}

/** Переливающийся градиент поверх содержимого (текст, иконки). */
@Composable
fun Modifier.liquidGradient(colors: List<Color>, periodMs: Int = 3200): Modifier {
    val t = rememberInfiniteTransition(label = "lg")
    val s by t.animateFloat(0f, 1f, infiniteRepeatable(tween(periodMs, easing = LinearEasing), RepeatMode.Reverse), label = "lgs")
    return this
        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithContent {
            drawContent()
            val w = size.width
            drawRect(
                Brush.linearGradient(colors, start = Offset(-w + 2 * w * s, 0f), end = Offset(2 * w * s, size.height)),
                blendMode = BlendMode.SrcIn
            )
        }
}

/** Число, которое «набегает» от нуля. */
@Composable
fun CountUpText(value: Double, style: TextStyle, modifier: Modifier = Modifier, suffix: String = "", formatter: (Double) -> String = { fmt(it) }) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(value) { a.animateTo(value.toFloat(), tween(1100, easing = FastOutSlowInEasing)) }
    val shown = if (a.isRunning) formatter(Math.round(a.value.toDouble()).toDouble()) else formatter(value)
    Text(shown + suffix, style = style, modifier = modifier)
}

/** Слайдер подтверждения: тянем кружок вправо — точка закрыта. Защищает от случайного нажатия в кармане. */
@Composable
fun SwipeToConfirm(text: String, onConfirm: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector = Ic.ArrowRight) {
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    var width by remember { mutableFloatStateOf(0f) }
    var drag by remember { mutableFloatStateOf(0f) }
    val thumb = 56.dp
    val thumbPx = with(density) { thumb.toPx() }
    val padPx = with(density) { 4.dp.toPx() }
    val max = (width - thumbPx - 2 * padPx).coerceAtLeast(1f)
    val frac = (drag / max).coerceIn(0f, 1f)
    val shape = RectangleShape
    val inf = rememberInfiniteTransition(label = "sw")
    val nudge by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "nd")
    val dragState = rememberDraggableState { d -> drag = (drag + d).coerceIn(0f, max) }
    Box(
        modifier
            .fillMaxWidth()
            .height(64.dp)
            .onSizeChanged { width = it.width.toFloat() }
            .clip(shape)
            .background(C.seaGradient)
            .shimmer(drag == 0f, 0.22f)
            .draggable(
                state = dragState,
                orientation = Orientation.Horizontal,
                onDragStopped = { _ ->
                    if (drag > max * 0.8f) {
                        animate(drag, max, animationSpec = tween(110)) { v, _ -> drag = v }
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onConfirm()
                        drag = 0f
                    } else {
                        animate(drag, 0f, animationSpec = spring(dampingRatio = 0.5f, stiffness = 420f)) { v, _ -> drag = v }
                    }
                }
            )
    ) {
        // заливка за кружком
        Box(
            Modifier.fillMaxHeight().width(with(density) { (drag + thumbPx + 2 * padPx).toDp() })
                .background(Color.White.copy(alpha = 0.18f))
        )
        Text(
            text, style = T.Button, color = Color.White,
            modifier = Modifier.align(Alignment.Center).padding(start = thumb)
                .graphicsLayer { alpha = (1f - frac * 1.6f).coerceIn(0f, 1f) }
                .liquidGradient(listOf(Color.White.copy(alpha = 0.55f), Color.White, Color.White.copy(alpha = 0.55f)), 1600)
        )
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .offset { IntOffset((drag + padPx + if (drag == 0f) nudge * 6.dp.toPx() else 0f).roundToInt(), 0) }
                .size(thumb)
                .clip(RectangleShape)
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = C.Sea, modifier = Modifier.size(24.dp).graphicsLayer { translationX = frac * 3.dp.toPx() })
        }
    }
}

private class Particle(
    var x: Float, var y: Float, var vx: Float, var vy: Float,
    var rot: Float, val vr: Float, val color: Color, val w: Float, val h: Float, val wobble: Float
)

/** Салют из конфетти с физикой: гравитация, сопротивление воздуха, вращение. */
@Composable
fun Confetti(modifier: Modifier = Modifier, count: Int = 140) {
    val colors = listOf(C.Ink, C.Ink2, C.Mute, Color(0xFFBFC1C5), Color(0xFF2A2C31), Color(0xFFD9DADC))
    val parts = remember {
        val r = Random(7)
        List(count) {
            val ang = (-PI / 2 + (r.nextFloat() - 0.5f) * 2.2f).toFloat()
            val sp = 0.7f + r.nextFloat() * 1.1f
            Particle(0.5f, 0.32f, cos(ang) * sp * 0.75f, sin(ang) * sp, r.nextFloat() * 360f, (r.nextFloat() - 0.5f) * 720f,
                colors[r.nextInt(colors.size)], 6f + r.nextFloat() * 6f, 10f + r.nextFloat() * 10f, r.nextFloat() * 6f)
        }
    }
    var frame by remember { mutableLongStateOf(0L) }
    var life by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = withFrameNanos { it }
        while (life < 6f) {
            val now = withFrameNanos { it }
            val dt = ((now - last) / 1e9f).coerceAtMost(0.05f); last = now
            life += dt
            parts.forEach { p ->
                p.vy += 1.25f * dt
                p.vx *= (1f - 0.9f * dt); p.vy *= (1f - 0.35f * dt)
                p.x += (p.vx + sin(life * 4f + p.wobble) * 0.04f) * dt
                p.y += p.vy * dt
                p.rot += p.vr * dt
            }
            frame = now
        }
    }
    Canvas(modifier.fillMaxSize()) {
        @Suppress("UNUSED_VARIABLE") val f = frame
        val fade = (1f - ((life - 4.5f) / 1.5f)).coerceIn(0f, 1f)
        parts.forEach { p ->
            val o = Offset(p.x * size.width, p.y * size.height)
            if (o.y > size.height + 40f) return@forEach
            val flip = kotlin.math.abs(cos(Math.toRadians(p.rot.toDouble() * 1.7).toFloat()))
            rotate(p.rot, o) {
                val pw = p.w * density * 0.6f; val ph = p.h * flip * density * 0.6f
                drawRect(p.color.copy(alpha = fade), Offset(o.x - pw / 2, o.y - ph / 2), Size(pw, ph))
            }
        }
    }
}
