package ru.marshrut.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Заставка при запуске приложения и старте доставки: знак с иконки (строчная «м»),
 * подчёркивание под ней прорисовывается слева направо, затем всё плавно гаснет.
 */
@Composable
fun DeliveryIntro(caption: String = "", onDone: () -> Unit) {
    val alpha = remember { Animatable(0f) }
    val line = remember { Animatable(0f) }
    val text = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        alpha.animateTo(1f, tween(220))
        line.animateTo(1f, tween(750, easing = FastOutSlowInEasing))
        launch { text.animateTo(1f, tween(300)) }
        delay(650)
        alpha.animateTo(0f, tween(320))
        onDone()
    }
    val ink = Color(0xFF17181B)
    Box(
        Modifier.fillMaxSize().graphicsLayer { this.alpha = alpha.value }.background(Color(0xFFF3F3F1)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Canvas(Modifier.size(180.dp)) {
                val k = size.width / 108f
                fun o(x: Float, y: Float) = Offset(x * k, (y - 3f) * k)
                // «м» — те же координаты, что в ic_launcher_foreground.xml
                val m = Path().apply {
                    val pts = listOf(34f to 66f, 34f to 38f, 44.5f to 38f, 54f to 51f, 63.5f to 38f, 74f to 38f, 74f to 66f,
                        65f to 66f, 65f to 53f, 54f to 66f, 43f to 53f, 43f to 66f)
                    pts.forEachIndexed { i, (x, y) -> val p = o(x, y); if (i == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y) }
                    close()
                }
                drawPath(m, ink)
                // Подчёркивание: от 34 до 58 по ширине, 72–76 по высоте
                val w = 24f * line.value
                if (w > 0f) drawRect(ink, topLeft = o(34f, 72f), size = Size(w * k, 4f * k))
            }
            if (caption.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(caption, style = T.H2, modifier = Modifier.graphicsLayer { this.alpha = text.value })
            }
        }
    }
}
