package ru.marshrut.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.togetherWith
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ru.marshrut.AppVm
import ru.marshrut.EquipDir
import ru.marshrut.Excluded
import ru.marshrut.Plan
import ru.marshrut.PlanStop
import ru.marshrut.Point
import ru.marshrut.Screen
import ru.marshrut.dial
import ru.marshrut.fmt
import ru.marshrut.km
import ru.marshrut.minutes
import ru.marshrut.money
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min

// =====================================================================
// Фрагмент схемы: от предыдущей точки до текущей
// =====================================================================

/** Индексы вершин геометрии, ближайшие к каждой точке маршрута по порядку объезда. */
private fun legAnchors(plan: Plan): List<Int> {
    val path = plan.path
    if (path.size < 2) return emptyList()
    val res = ArrayList<Int>()
    var cursor = 0
    for (s in plan.stops) {
        var best = cursor; var bd = Double.MAX_VALUE
        for (k in cursor until path.size) {
            val d = (path[k].first - s.point.lat).let { it * it } + (path[k].second - s.point.lon).let { it * it }
            if (d < bd) { bd = d; best = k }
        }
        res.add(best); cursor = best
    }
    return res
}

@Composable
fun LegMap(plan: Plan, i: Int, modifier: Modifier = Modifier) {
    val s = plan.stops[i]
    val from: Point? = if (i == 0) plan.depot else plan.stops[i - 1].point
    val anchors = remember(plan) { legAnchors(plan) }
    val seg: List<Pair<Double, Double>> = remember(plan, i) {
        if (anchors.size == plan.stops.size) {
            val a = if (i == 0) 0 else anchors[i - 1]
            val b = anchors[i]
            if (b > a) plan.path.subList(a, b + 1) else listOfNotNull(from?.let { it.lat to it.lon }, s.point.lat to s.point.lon)
        } else listOfNotNull(from?.let { it.lat to it.lon }, s.point.lat to s.point.lon)
    }
    val prog = remember(plan, i) { Animatable(0f) }
    LaunchedEffect(plan, i) { prog.animateTo(1f, tween(1300, delayMillis = 250, easing = FastOutSlowInEasing)) }
    val inf = rememberInfiniteTransition(label = "leg")
    val travel by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(4200, easing = LinearEasing)), label = "lt")
    val phase by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "lp")
    val tm = rememberTextMeasurer()
    val numStyle = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)

    Box(modifier) {
        Canvas(Modifier.fillMaxSize().clipToBounds()) {
            if (seg.isEmpty()) return@Canvas
            val minLat = seg.minOf { it.first }; val maxLat = seg.maxOf { it.first }
            val minLon = seg.minOf { it.second }; val maxLon = seg.maxOf { it.second }
            val k = cos(Math.toRadians((minLat + maxLat) / 2))
            val spanX = max((maxLon - minLon) * k, 2e-4); val spanY = max(maxLat - minLat, 2e-4)
            val pad = 34.dp.toPx()
            val sc = min((size.width - 2 * pad) / spanX, (size.height - 2 * pad) / spanY)
            val ox = (size.width - spanX * sc) / 2; val oy = (size.height - spanY * sc) / 2
            val cLon = (minLon + maxLon) / 2; val cLat = (minLat + maxLat) / 2
            fun at(p: Pair<Double, Double>) = Offset(
                (ox + ((p.second - cLon) * k + spanX / 2) * sc).toFloat(),
                (oy + (spanY / 2 - (p.first - cLat)) * sc).toFloat()
            )
            // сетка
            val step = 18.dp.toPx()
            var gx = step / 2
            while (gx < size.width) { var gy = step / 2; while (gy < size.height) { drawCircle(C.Line, 1.dp.toPx(), Offset(gx, gy)); gy += step }; gx += step }

            val path = Path()
            seg.forEachIndexed { n, p -> val o = at(p); if (n == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
            val sw = 4.5.dp.toPx()
            drawPath(path, C.Line, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
            val pm = PathMeasure(); pm.setPath(path, false)
            val part = Path(); pm.getSegment(0f, pm.length * prog.value, part, true)
            drawPath(part, C.Ink, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
            if (prog.value >= 1f && pm.length > 0f) {
                val dash = 6.dp.toPx(); val gap = 11.dp.toPx()
                drawPath(path, Color.White.copy(alpha = 0.85f), style = Stroke(sw * 0.34f, cap = StrokeCap.Round,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(dash, gap), -phase * (dash + gap))))
                val car = pm.getPosition(pm.length * travel)
                drawCircle(C.Ink.copy(alpha = 0.12f), sw * 3f, car)
                drawCircle(Color.White, sw * 1.5f, car)
                drawCircle(C.Ink, sw * 0.95f, car)
            }
            // откуда
            val a = at(seg.first())
            drawCircle(Color.White, 9.dp.toPx(), a)
            drawCircle(C.Ink, 9.dp.toPx(), a, style = Stroke(2.dp.toPx()))
            drawCircle(C.Ink, 3.dp.toPx(), a)
            // куда — квадратная метка с номером
            val b = at(seg.last())
            val h = 12.dp.toPx() * (0.4f + 0.6f * prog.value)
            drawRect(C.Ink, Offset(b.x - h, b.y - h), Size(h * 2, h * 2))
            val t = tm.measure((i + 1).toString(), numStyle)
            drawText(t, topLeft = Offset(b.x - t.size.width / 2f, b.y - t.size.height / 2f), alpha = prog.value)
        }
        Row(Modifier.align(Alignment.TopStart).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pill(if (i == 0) "От старта" else "От точки $i", C.Ink2, Color.White.copy(alpha = 0.92f))
            if (s.legKm > 0) Pill("${km(s.legKm)} км", Color.White, C.Ink)
            if (s.legMin > 0) Pill(minutes(s.legMin), C.Ink2, Color.White.copy(alpha = 0.92f))
        }
    }
}

// =====================================================================
// Полноэкранная схема
// =====================================================================

@Composable
fun FullMapDialog(plan: Plan, current: Int, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(Modifier.fillMaxSize().background(C.Bg)) {
            RouteMap(plan, Modifier.fillMaxSize(), current)
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 40.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("СХЕМА МАРШРУТА", style = T.Label)
                    Text("${plan.stops.size} точек, ${km(plan.distanceKm)} км", style = T.H3)
                }
                RoundIconButton(Ic.Close, onClose)
            }
        }
    }
}

// =====================================================================
// Варианты маршрута
// =====================================================================

@Composable
fun VariantPicker(vm: AppVm, plan: Plan) {
    if (vm.variants.size < 2 || vm.started) return
    val best = vm.variants.minOf { it.durationMin }
    Column {
        Text("ВАРИАНТЫ МАРШРУТА", style = T.Label, modifier = Modifier.padding(start = 0.dp, bottom = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            vm.variants.forEach { v ->
                val sel = v.variant == plan.variant
                val bg by animateColorAsState(if (sel) C.Ink else C.Surface, tween(260), label = "vb")
                val fg by animateColorAsState(if (sel) Color.White else C.Ink, tween(260), label = "vf")
                Column(
                    Modifier.weight(1f).background(bg).border(1.dp, if (sel) C.Ink else C.Line)
                        .pressable(scaleTo = 0.96f) { vm.chooseVariant(v) }.padding(12.dp)
                ) {
                    Text(v.variant, style = T.Small.copy(color = fg.copy(alpha = 0.75f), fontSize = 12.sp), maxLines = 2, minLines = 2)
                    Spacer(Modifier.height(8.dp))
                    Text("${km(v.distanceKm)} км", style = T.Num.copy(fontSize = 18.sp, color = fg))
                    Text(minutes(v.durationMin), style = T.Small.copy(color = fg.copy(alpha = 0.75f)))
                    if (v.durationMin - best > 0.5) Text("+${minutes(v.durationMin - best)}", style = T.Label.copy(color = fg.copy(alpha = 0.6f)))
                }
            }
        }
    }
}

// =====================================================================
// «Нужно передать торговому»
// =====================================================================

@Composable
fun AgentPlaque(vm: AppVm, plan: Plan, modifier: Modifier = Modifier) {
    val left = plan.excluded.withIndex().filter { it.value.reason == Excluded.REASON_AGENT && it.index !in vm.handed }
    var open by remember { mutableStateOf(false) }
    // плашка сама исчезает, когда всё передано
    androidx.compose.animation.AnimatedVisibility(
        left.isNotEmpty(), modifier = modifier,
        enter = androidx.compose.animation.expandVertically() + androidx.compose.animation.fadeIn(),
        exit = androidx.compose.animation.shrinkVertically(tween(320)) + androidx.compose.animation.fadeOut(tween(200))
    ) {
        val cash = left.sumOf { it.value.cash }
        Row(
            Modifier.fillMaxWidth().background(C.seaGradient).shimmer(true, 0.10f).pressable(scaleTo = 0.985f) { open = true }
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBubble(Ic.User, C.Ink, Color.White, 38.dp, 19.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Нужно передать торговому", style = T.H3.copy(color = Color.White))
                AnimatedContent(left.size, label = "al") { n ->
                    Text(
                        listOfNotNull("$n ${plural(n, "документ", "документа", "документов")}", if (cash > 0) money(cash) else null).joinToString(", "),
                        style = T.Small.copy(color = Color.White.copy(alpha = 0.65f)), maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Icon(Ic.ChevronRight, null, tint = Color.White, modifier = Modifier.size(20.dp))
        }
    }
    if (open && left.isEmpty()) open = false
    if (open) Dialog(onDismissRequest = { open = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val sc = remember { Animatable(0.9f) }
        LaunchedEffect(Unit) { sc.animateTo(1f, spring(dampingRatio = 0.65f, stiffness = 420f)) }
        Card(Modifier.fillMaxWidth().padding(16.dp).graphicsLayer { scaleX = sc.value; scaleY = sc.value }, padding = 20.dp, fullBleed = false) {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("ПЕРЕДАТЬ ТОРГОВОМУ", style = T.Label)
                Text("Отметьте накладные и подтвердите", style = T.H2)
                Spacer(Modifier.height(14.dp))
                AgentHandoffList(vm, plan)
                Spacer(Modifier.height(12.dp))
                GhostButton("Закрыть", { open = false }, Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

/**
 * Документы для торгового, сгруппированные по агенту:
 * шапка — торговый, номер и сумма; ниже накладные столбиком (тап — отметить),
 * под ними ползунок «Оплачено» и кнопка «Подтвердить». Подтверждённые накладные уходят из списка.
 */
@Composable
fun AgentHandoffList(vm: AppVm, plan: Plan) {
    val ctx = LocalContext.current
    val all = plan.excluded.withIndex().filter { it.value.reason == Excluded.REASON_AGENT }
    val groups = all.groupBy { it.value.agent.ifBlank { "Торговый" } to it.value.phone }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        groups.forEach { (key, items) ->
            val (agent, phone) = key
            val left = items.filter { it.index !in vm.handed }
            androidx.compose.animation.AnimatedVisibility(
                left.isNotEmpty(),
                exit = androidx.compose.animation.shrinkVertically(tween(320)) + androidx.compose.animation.fadeOut(tween(200))
            ) {
                val selected = remember(key) { androidx.compose.runtime.mutableStateListOf<Int>() }
                var paidOn by remember(key) { mutableStateOf(false) }
                val selCash = left.filter { it.index in selected }.sumOf { it.value.cash }
                Column(Modifier.fillMaxWidth().border(1.dp, C.Line).background(C.Surface)) {
                    // Шапка: торговый + номер + сумма
                    Row(Modifier.fillMaxWidth().background(C.Ink).padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(agent, style = T.H3.copy(color = Color.White), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (phone.isNotBlank()) Text(phone, style = T.Small.copy(color = Color.White.copy(alpha = 0.65f)))
                        }
                        Text(money(left.sumOf { it.value.cash }), style = T.Num.copy(fontSize = 18.sp, color = Color.White))
                        if (phone.isNotBlank()) {
                            Spacer(Modifier.width(10.dp))
                            RoundIconButton(Ic.Phone, { dial(ctx, phone) }, size = 38.dp, tint = C.Ink, bg = Color.White)
                        }
                    }
                    // Накладные столбиком: тап — отметить
                    items.forEach { (idx, e) ->
                        androidx.compose.animation.AnimatedVisibility(
                            idx !in vm.handed,
                            exit = androidx.compose.animation.slideOutHorizontally(tween(260)) { it } +
                                androidx.compose.animation.shrinkVertically(tween(300, delayMillis = 140)) + androidx.compose.animation.fadeOut(tween(200))
                        ) {
                            val on = idx in selected
                            val bg by animateColorAsState(if (on) C.Field else C.Surface, tween(180), label = "ib")
                            val box by animateColorAsState(if (on) C.Ink else C.Surface, tween(180), label = "bx")
                            Row(
                                Modifier.fillMaxWidth().background(bg)
                                    .pressable(scaleTo = 0.98f) { if (on) selected.remove(idx) else selected.add(idx) }
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(24.dp).background(box).border(1.5.dp, C.Ink), contentAlignment = Alignment.Center) {
                                    if (on) Icon(Ic.Check, null, tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(e.label, style = T.BodyStrong, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(listOfNotNull(e.title, e.callsign.ifBlank { null }).joinToString(", "), style = T.Small,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Text(if (e.cash > 0) money(e.cash) else "—", style = T.Num.copy(fontSize = 15.sp))
                            }
                        }
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(C.Line))
                    // Ползунок «Оплачено»
                    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Оплачено", style = T.H3)
                            Text(
                                if (selected.isEmpty()) "Отметьте накладные выше"
                                else "Отмечено: ${selected.size}" + if (selCash > 0) ", ${money(selCash)}" else "",
                                style = T.Small
                            )
                        }
                        Toggle(paidOn) { paidOn = it }
                    }
                    // Подтвердить
                    PrimaryButton(
                        if (selected.isEmpty()) "Подтвердить" else "Подтвердить (${selected.size})",
                        {
                            val pick = selected.toList()
                            pick.forEach { i ->
                                val cash = plan.excluded.getOrNull(i)?.cash ?: 0.0
                                vm.handOver(i, if (cash > 0) paidOn else null)
                            }
                            selected.clear(); paidOn = false
                        },
                        Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 14.dp),
                        icon = Ic.Check, enabled = selected.isNotEmpty(), height = 54.dp
                    )
                }
            }
        }
    }
}

// =====================================================================
// Загрузка авто
// =====================================================================

/** Подпись на коробке: цифры позывного без букв (228юс → 228). */
private fun boxLabel(s: PlanStop, i: Int): String {
    val cs = s.callsigns.firstOrNull().orEmpty()
    return Regex("\\d+").find(cs)?.value ?: cs.take(4).ifBlank { "${i + 1}" }
}

private class Zone(val title: String, val hint: String, val stops: List<Pair<Int, PlanStop>>) {
    val weight get() = stops.sumOf { it.second.weight }
}

/** Делим очередь выгрузки на зоны кузова: последние точки — к кабине, первые — к дверям. */
private fun zonesOf(plan: Plan): List<Zone> {
    val n = plan.stops.size
    if (n == 0) return emptyList()
    val z = when { n <= 2 -> n; n <= 5 -> 3; else -> 4 }
    val rev = plan.stops.withIndex().map { it.index to it.value }.reversed() // порядок загрузки
    val total = rev.sumOf { it.second.weight }.coerceAtLeast(1.0)
    val groups = ArrayList<MutableList<Pair<Int, PlanStop>>>()
    var cur = ArrayList<Pair<Int, PlanStop>>(); var acc = 0.0
    rev.forEachIndexed { k, p ->
        cur.add(p); acc += p.second.weight
        val left = rev.size - k - 1
        val zonesLeft = z - groups.size - 1
        val target = total * (groups.size + 1) / z
        if (zonesLeft > 0 && (acc >= target || left == zonesLeft)) { groups.add(cur); cur = ArrayList() }
    }
    if (cur.isNotEmpty()) groups.add(cur)
    val names = when (groups.size) {
        1 -> listOf("Весь кузов")
        2 -> listOf("У кабины", "У дверей")
        3 -> listOf("У кабины", "Середина", "У дверей")
        else -> listOf("У кабины", "Ближе к кабине", "Ближе к дверям", "У дверей")
    }
    return groups.mapIndexed { i, g ->
        Zone(names.getOrElse(i) { "Зона ${i + 1}" }, if (i == 0) "грузить первой" else if (i == groups.lastIndex) "грузить последней" else "",
            g.sortedByDescending { it.second.weight })
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LoadScreen(vm: AppVm) {
    val plan = vm.plan ?: run { vm.screen = Screen.HOME; return }
    val zones = remember(plan) { zonesOf(plan) }
    val total = plan.stops.sumOf { it.weight }
    val cap = vm.st.capacity.toDoubleOrNull() ?: 0.0
    val fill = if (cap > 0) (total / cap).toFloat() else 0f
    // центр тяжести по длине кузова: 0 — кабина, 1 — двери
    val com = if (total > 0 && zones.size > 1) zones.withIndex().sumOf { (i, z) -> z.weight * i / (zones.size - 1).toDouble() } / total else 0.5
    val pickups = plan.stops.sumOf { s -> s.returns.size + s.equipment.count { it.equip == EquipDir.PICKUP } }
    val deliverEquip = plan.stops.withIndex().filter { (_, s) -> s.equipment.any { it.equip == EquipDir.DELIVER } }

    Column(Modifier.fillMaxSize()) {
        TopBar("Загрузка авто", { vm.screen = Screen.OVERVIEW }, subtitle = "По очереди выгрузки: последняя точка — у кабины")
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)) {

            Card(Modifier.fillMaxWidth().appear(0), padding = 0.dp) {
                VanScheme(zones, plan.stops.size, Modifier.fillMaxWidth().height(380.dp))
            }

            Card(Modifier.fillMaxWidth().appear(1), padding = 18.dp) {
                Row {
                    StatBlock(fmt(total), "кг всего", Modifier.weight(1f))
                    StatBlock(if (cap > 0) "${(fill * 100).toInt()}%" else "—", "кузова", Modifier.weight(1f))
                    StatBlock(zones.size.toString(), plural(zones.size, "зона", "зоны", "зон"), Modifier.weight(1f))
                }
                if (cap > 0) {
                    Spacer(Modifier.height(14.dp))
                    Gauge("ЗАПОЛНЕНИЕ ПО ВЕСУ", fill.coerceIn(0f, 1.2f), if (fill > 1f) "перегруз ${fmt(total - cap)} кг" else "${fmt(cap - total)} кг в запасе")
                }
                if (zones.size > 1) {
                    Spacer(Modifier.height(14.dp))
                    Gauge("ЦЕНТР ТЯЖЕСТИ: КАБИНА → ДВЕРИ", com.toFloat(), when {
                        com > 0.62 -> "смещён к дверям — тяжёлое из ближних зон ставьте вниз и вплотную вперёд"
                        com < 0.3 -> "смещён к кабине — норма для полного кузова"
                        else -> "сбалансировано"
                    }, marker = true)
                }
            }

            Text("ПРАВИЛА УКЛАДКИ", style = T.Label)
            Card(Modifier.fillMaxWidth().appear(2), padding = 16.dp) {
                Tip(Ic.Box, "Грузите от кабины к дверям в порядке зон — тогда на каждой точке нужное окажется под рукой.")
                Tip(Ic.Weight, "Внутри зоны тяжёлое — вниз и к центру, лёгкое и хрупкое — сверху.")
                if (pickups > 0) Tip(Ic.Return, "Оставьте место у дверей под возвраты и забираемое оборудование: $pickups ${plural(pickups, "позиция", "позиции", "позиций")}.")
                deliverEquip.forEach { (i, s) -> Tip(Ic.Fridge, "Оборудование для точки ${i + 1} (${s.point.display}) — отдельно, ничего не ставить сверху.") }
                if (fill > 1f) Tip(Ic.Warning, "Вес больше вместимости кузова — проверьте лист или разделите рейс.")
            }

            zones.forEachIndexed { zi, z ->
                Card(Modifier.fillMaxWidth().appear(3 + zi), padding = 16.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(34.dp).background(C.Ink), contentAlignment = Alignment.Center) {
                            Text("${zi + 1}", style = T.Num.copy(fontSize = 16.sp, color = Color.White))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(z.title, style = T.H3)
                            if (z.hint.isNotBlank()) Text(z.hint.uppercase(), style = T.Label)
                        }
                        Text("${fmt(z.weight)} кг", style = T.Num.copy(fontSize = 16.sp))
                    }
                    Spacer(Modifier.height(10.dp))
                    z.stops.forEachIndexed { k, (i, s) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.height(26.dp).widthIn(min = 40.dp).border(1.5.dp, C.Ink).padding(horizontal = 5.dp), contentAlignment = Alignment.Center) {
                                Text(boxLabel(s, i), style = T.Num.copy(fontSize = 12.sp), maxLines = 1)
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(s.point.display, style = T.BodyStrong, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (k == 0 && z.stops.size > 1) { Pill("вниз", Color.White, C.Ink); Spacer(Modifier.width(6.dp)) }
                            Text("${fmt(s.weight)} кг", style = T.Small)
                        }
                    }
                }
            }
        }
        PrimaryButton("Загружено — поехали", { vm.go() }, Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), icon = Ic.Play, height = 62.dp)
    }
}

@Composable
private fun Tip(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = C.Ink, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, style = T.Body.copy(color = C.Ink, fontSize = 14.sp))
    }
}

@Composable
private fun Gauge(label: String, value: Float, caption: String, marker: Boolean = false) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(value) { a.animateTo(value, tween(1100, easing = FastOutSlowInEasing)) }
    Text(label, style = T.Label)
    Spacer(Modifier.height(6.dp))
    Canvas(Modifier.fillMaxWidth().height(10.dp)) {
        drawRect(C.Field)
        if (marker) {
            // шкала с бегунком
            for (q in 1..3) drawRect(C.Line, Offset(size.width * q / 4f - 0.5.dp.toPx(), 0f), Size(1.dp.toPx(), size.height))
            val x = size.width * a.value.coerceIn(0f, 1f)
            drawRect(C.Ink, Offset(x - 3.dp.toPx(), -2.dp.toPx()), Size(6.dp.toPx(), size.height + 4.dp.toPx()))
        } else {
            val w = size.width * a.value.coerceIn(0f, 1f)
            drawRect(if (a.value > 1f) C.Danger else C.Ink, Offset.Zero, Size(w, size.height))
        }
    }
    Spacer(Modifier.height(4.dp))
    Text(caption, style = T.Small)
}

/** Кузов сверху: кабина вверху, двери внизу. Коробки «въезжают» в кузов в порядке загрузки. */
@Composable
private fun VanScheme(zones: List<Zone>, n: Int, modifier: Modifier) {
    val tm = rememberTextMeasurer()
    val prog = remember(zones) { Animatable(0f) }
    LaunchedEffect(zones) { prog.animateTo(1f, tween(500 + n * 140, easing = LinearEasing)) }
    val numStyle = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
    val numDark = numStyle.copy(color = C.Ink)
    val labelStyle = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = C.Mute, letterSpacing = 1.2.sp)
    val maxW = zones.flatMap { it.stops }.maxOfOrNull { it.second.weight }?.coerceAtLeast(1.0) ?: 1.0
    Canvas(modifier.padding(vertical = 18.dp)) {
        val bw = min(size.width * 0.62f, 260.dp.toPx())
        val left = (size.width - bw) / 2
        val cabH = 54.dp.toPx()
        val top = cabH + 8.dp.toPx()
        val bodyH = size.height - top - 18.dp.toPx()
        val st = 2.dp.toPx()
        // кабина
        drawRoundRect(C.Ink, Offset(left + bw * 0.08f, 0f), Size(bw * 0.84f, cabH), CornerRadius(18.dp.toPx(), 18.dp.toPx()))
        drawRect(Color.White.copy(alpha = 0.18f), Offset(left + bw * 0.16f, cabH * 0.28f), Size(bw * 0.68f, cabH * 0.32f))
        val cl = tm.measure("КАБИНА", labelStyle.copy(color = Color.White.copy(alpha = 0.7f)))
        drawText(cl, topLeft = Offset(size.width / 2 - cl.size.width / 2f, cabH * 0.66f))
        // кузов
        drawRect(C.Surface, Offset(left, top), Size(bw, bodyH))
        drawRect(C.Ink, Offset(left, top), Size(bw, bodyH), style = Stroke(st))
        // двери
        val dl = tm.measure("ДВЕРИ", labelStyle)
        drawText(dl, topLeft = Offset(size.width / 2 - dl.size.width / 2f, top + bodyH + 3.dp.toPx()))
        drawLine(C.Surface, Offset(left + st, top + bodyH), Offset(left + bw - st, top + bodyH), st * 1.5f)
        drawLine(C.Ink, Offset(left, top + bodyH), Offset(left + bw * 0.48f, top + bodyH + 6.dp.toPx()), st)
        drawLine(C.Ink, Offset(left + bw, top + bodyH), Offset(left + bw * 0.52f, top + bodyH + 6.dp.toPx()), st)

        if (zones.isEmpty()) return@Canvas
        val zh = bodyH / zones.size
        var order = 0 // порядок загрузки — для анимации
        zones.forEachIndexed { zi, z ->
            val zt = top + zi * zh
            if (zi > 0) {
                var x = left + 4.dp.toPx()
                while (x < left + bw - 4.dp.toPx()) { drawLine(C.Line, Offset(x, zt), Offset(x + 5.dp.toPx(), zt), 1.dp.toPx()); x += 9.dp.toPx() }
            }
            val zl = tm.measure("${zi + 1}", labelStyle.copy(color = C.Ink, fontSize = 11.sp))
            drawText(zl, topLeft = Offset(left - zl.size.width - 8.dp.toPx(), zt + zh / 2 - zl.size.height / 2f))
            // коробки: размер по весу, раскладываем рядами
            val pad = 8.dp.toPx(); val gap = 6.dp.toPx()
            var cx = left + pad; var cy = zt + pad; var rowH = 0f
            z.stops.forEachIndexed { k, (i, s) ->
                val label = boxLabel(s, i)
                val tw = tm.measure(label, numStyle).size.width + 8.dp.toPx()
                val side = max(tw, 30.dp.toPx() + 18.dp.toPx() * (s.weight / maxW).toFloat()).coerceAtMost(zh - 2 * pad)
                if (cx + side > left + bw - pad) { cx = left + pad; cy += rowH + gap; rowH = 0f }
                val appear = ((prog.value * (n + 2)) - order).coerceIn(0f, 1f)
                order++
                if (appear > 0f && cy + side <= zt + zh + 0.5f) {
                    val drop = (1f - appear) * 30.dp.toPx()
                    val heavy = k == 0 && z.stops.size > 1
                    val o = Offset(cx, cy - drop)
                    if (heavy) drawRect(C.Ink.copy(alpha = appear), o, Size(side, side))
                    else {
                        drawRect(C.Surface.copy(alpha = appear), o, Size(side, side))
                        drawRect(C.Ink.copy(alpha = appear), o, Size(side, side), style = Stroke(1.5.dp.toPx()))
                    }
                    val t = tm.measure(label, if (heavy) numStyle else numDark)
                    drawText(t, topLeft = Offset(o.x + side / 2 - t.size.width / 2f, o.y + side / 2 - t.size.height / 2f), alpha = appear)
                }
                cx += side + gap; rowH = max(rowH, side)
            }
        }
    }
}

// =====================================================================
// Проверка позывного
// =====================================================================

private sealed interface CheckState {
    object Empty : CheckState
    data class Found(val point: String) : CheckState
    data class Suggest(val list: List<Pair<String, String>>) : CheckState
    object None : CheckState
}

@Composable
fun CheckScreen(vm: AppVm) {
    @Suppress("UNUSED_VARIABLE") val v = vm.dbVer
    var q by remember { mutableStateOf("") }
    var pq by remember { mutableStateOf("") }
    var relink by remember { mutableStateOf(false) }
    val norm = vm.db.norm(q)
    // Подсказки по мере ввода: сначала позывные, которые начинаются с введённого, потом содержащие его
    val state: CheckState = when {
        norm.isEmpty() -> CheckState.Empty
        relink -> CheckState.None
        vm.db.calls.containsKey(norm) -> CheckState.Found(vm.db.calls[norm]!!)
        else -> {
            val starts = vm.db.calls.entries.filter { it.key.startsWith(norm) }.sortedBy { it.key }
            val contains = vm.db.calls.entries.filter { !it.key.startsWith(norm) && it.key.contains(norm) }.sortedBy { it.key }
            val list = (starts + contains).take(12).map { it.key to it.value }
            if (list.isEmpty()) CheckState.None else CheckState.Suggest(list)
        }
    }
    Column(Modifier.fillMaxSize()) {
        TopBar("Проверить позывной", { vm.screen = Screen.HOME }, subtitle = "Какой точке принадлежит")
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 20.dp)) {
            Field(q, { q = it; relink = false }, "Позывной", leading = Ic.Search, placeholder = "Например, 226юв")
            Spacer(Modifier.height(12.dp))
            AnimatedContent(
                state, label = "chk",
                contentKey = { it::class },
                transitionSpec = { androidx.compose.animation.fadeIn(tween(200)).togetherWith(androidx.compose.animation.fadeOut(tween(120))) }
            ) { st ->
                when (st) {
                    CheckState.Empty -> Text("Начните вводить — подходящие позывные появятся сразу под строкой поиска.", style = T.Body)
                    is CheckState.Suggest -> Column {
                        Text("ПОДХОДЯЩИЕ ПОЗЫВНЫЕ", style = T.Label)
                        Spacer(Modifier.height(6.dp))
                        st.list.forEachIndexed { k, (c, pn) ->
                            val p = vm.db.point(pn)
                            Row(
                                Modifier.fillMaxWidth().appear(k, c).border(1.dp, C.Line).background(C.Surface)
                                    .pressable { q = c }.padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // совпавшая часть — жирным графитом, остаток — серым
                                val i0 = c.indexOf(norm)
                                Text(
                                    androidx.compose.ui.text.buildAnnotatedString {
                                        if (i0 >= 0) {
                                            withStyle(androidx.compose.ui.text.SpanStyle(color = C.Mute)) { append(c.substring(0, i0)) }
                                            append(c.substring(i0, i0 + norm.length))
                                            withStyle(androidx.compose.ui.text.SpanStyle(color = C.Mute)) { append(c.substring(i0 + norm.length)) }
                                        } else append(c)
                                    },
                                    style = T.H3, modifier = Modifier.width(110.dp), maxLines = 1
                                )
                                Column(Modifier.weight(1f)) {
                                    Text(p?.display ?: pn, style = T.BodyStrong, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    if (p != null && p.address.isNotBlank()) Text(p.address, style = T.Small, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Icon(Ic.ChevronRight, null, tint = C.Mute, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                    is CheckState.Found -> {
                        val p = vm.db.point(st.point)
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Column(Modifier.fillMaxWidth().background(C.seaGradient).padding(18.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconBubble(Ic.Check, C.Ink, Color.White, 34.dp, 18.dp)
                                    Spacer(Modifier.width(10.dp))
                                    Text("ПОЗЫВНОЙ $norm", style = T.Label.copy(color = Color.White.copy(alpha = 0.7f)))
                                }
                                Spacer(Modifier.height(12.dp))
                                Text(p?.display ?: st.point, style = T.H2.copy(color = Color.White))
                                if (p != null) {
                                    if (p.address.isNotBlank()) Text(p.address, style = T.Body.copy(color = Color.White.copy(alpha = 0.75f)))
                                    Text("Код точки: ${p.name}", style = T.Small.copy(color = Color.White.copy(alpha = 0.6f)))
                                    p.saturdayBadge?.let { Spacer(Modifier.height(8.dp)); Pill(it, C.Ink, Color.White, Ic.Clock) }
                                    if (p.commentText.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(p.commentText, style = T.BodyStrong.copy(color = Color.White)) }
                                    val others = vm.db.callsignsOf(p.name)
                                    if (others.size > 1) { Spacer(Modifier.height(8.dp)); Text("Все позывные точки: " + others.joinToString(", "), style = T.Small.copy(color = Color.White.copy(alpha = 0.6f))) }
                                } else Text("Точки с таким кодом нет в базе", style = T.Small.copy(color = Color.White.copy(alpha = 0.6f)))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                SecondaryButton("Перепривязать", { relink = true }, Modifier.weight(1f), icon = Ic.Edit)
                                SecondaryButton("Отвязать", { vm.unlinkCallsign(q) }, Modifier.weight(1f), icon = Ic.Trash, tint = C.Danger)
                            }
                        }
                    }
                    CheckState.None -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (!relink) Row(Modifier.fillMaxWidth().background(C.DangerSoft).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Ic.Warning, null, tint = C.Danger, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(10.dp))
                            Text("Такого позывного нет. Выберите точку — позывной $norm привяжется к ней.", style = T.Body.copy(color = C.Ink, fontSize = 14.sp))
                        }
                        Text(if (relink) "ВЫБЕРИТЕ НОВУЮ ТОЧКУ ДЛЯ $norm" else "ПРИВЯЗАТЬ К ТОЧКЕ", style = T.Label)
                        Field(pq, { pq = it }, "", leading = Ic.Search, placeholder = "Название, код или адрес точки")
                        val hits = vm.db.points.filter { pq.isBlank() || it.name.contains(pq, true) || it.title.contains(pq, true) || it.address.contains(pq, true) }.take(12)
                        hits.forEachIndexed { k, pt ->
                            Row(Modifier.fillMaxWidth().appear(k, pt.name).border(1.dp, C.Line).background(C.Surface)
                                .pressable { vm.linkCallsign(q, pt.name); relink = false; pq = "" }.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Icon(Ic.Pin, null, tint = C.Ink, modifier = Modifier.size(19.dp))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(pt.display, style = T.H3, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(listOf(pt.name, pt.address).filter { it.isNotBlank() }.joinToString(", "), style = T.Small, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Icon(Ic.ChevronRight, null, tint = C.Mute, modifier = Modifier.size(18.dp))
                            }
                        }
                        if (relink) GhostButton("Отмена", { relink = false })
                    }
                }
            }
        }
    }
}

/** Плашка субботнего ограничения приёма. */
@Composable
fun SaturdayNotice(p: Point) {
    val b = p.saturdayBadge ?: return
    val inf = rememberInfiniteTransition(label = "sat")
    val a by inf.animateFloat(0.55f, 1f, infiniteRepeatable(tween(900), androidx.compose.animation.core.RepeatMode.Reverse), label = "sa")
    Row(Modifier.fillMaxWidth().background(C.Danger).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Ic.Clock, null, tint = Color.White, modifier = Modifier.size(22.dp).graphicsLayer { alpha = a })
        Spacer(Modifier.width(12.dp))
        Column {
            Text("СУББОТА", style = T.Label.copy(color = Color.White.copy(alpha = 0.75f)))
            Text(b, style = T.H2.copy(color = Color.White))
        }
    }
}
