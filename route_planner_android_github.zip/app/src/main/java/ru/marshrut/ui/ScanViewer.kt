package ru.marshrut.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.io.File

/**
 * Фото страниц листа: пальцами приближаем и двигаем, двойное касание — приблизить/вернуть.
 * Чтобы в дороге свериться с листом, не доставая бумагу.
 * marked — те же страницы с пометками «от руки» (номера точек по порядку объезда), пока готовятся — marking.
 */
@Composable
fun ScanViewer(src: List<File>, marked: List<File> = emptyList(), marking: Boolean = false, onClose: () -> Unit) {
    var page by remember { mutableIntStateOf(0) }
    var withMarks by remember { mutableStateOf(true) }
    val hasMarks = marked.size == src.size
    val files = if (withMarks && hasMarks) marked else src
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val file = files[page.coerceIn(0, files.lastIndex)]
            val bmp = remember(file, file.lastModified()) { BitmapFactory.decodeFile(file.path)?.asImageBitmap() }
            var scale by remember(file) { mutableFloatStateOf(1f) }
            var offset by remember(file) { mutableStateOf(Offset.Zero) }
            if (bmp != null) Image(
                bmp, "Страница ${page + 1}",
                Modifier.fillMaxSize()
                    .pointerInput(file) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 6f)
                            offset = if (scale == 1f) Offset.Zero else offset + pan
                        }
                    }
                    .pointerInput(file) {
                        detectTapGestures(onDoubleTap = { if (scale > 1f) { scale = 1f; offset = Offset.Zero } else scale = 2.5f })
                    }
                    .graphicsLayer { scaleX = scale; scaleY = scale; translationX = offset.x; translationY = offset.y },
                contentScale = ContentScale.Fit
            )
            Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).padding(start = 8.dp)) {
                    Text("Страница ${page + 1} из ${files.size}", style = T.BodyStrong, color = Color.White)
                    if (marking) Text("Размечаем лист по маршруту…", style = T.Small, color = Color.White.copy(alpha = 0.75f))
                }
                RoundIconButton(Ic.Close, onClose, size = 44.dp)
            }
            if (files.size > 1 || hasMarks) Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (files.size > 1) SecondaryButton("", { if (page > 0) page-- }, Modifier.width(64.dp), icon = Ic.ChevronLeft)
                if (hasMarks) SecondaryButton(if (withMarks) "Без пометок" else "С пометками", { withMarks = !withMarks }, Modifier.weight(1f), icon = Ic.Edit)
                else Spacer(Modifier.weight(1f))
                if (files.size > 1) SecondaryButton("", { if (page < files.lastIndex) page++ }, Modifier.width(64.dp), icon = Ic.ChevronRight)
            }
        }
    }
}
