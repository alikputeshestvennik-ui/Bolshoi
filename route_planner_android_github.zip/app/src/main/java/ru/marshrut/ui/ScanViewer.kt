package ru.marshrut.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.io.File

/**
 * Фото страниц листа: пальцами приближаем и двигаем, двойное касание — приблизить/вернуть.
 * Чтобы в дороге свериться с листом, не доставая бумагу.
 */
@Composable
fun ScanViewer(files: List<File>, onClose: () -> Unit) {
    var page by remember { mutableIntStateOf(0) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val file = files[page.coerceIn(0, files.lastIndex)]
            val bmp = remember(file) { BitmapFactory.decodeFile(file.path)?.asImageBitmap() }
            var scale by remember(file) { mutableFloatStateOf(1f) }
            var offset by remember(file) { mutableStateOf(Offset.Zero) }
            if (bmp != null) Image(
                bmp, "Страница ${page + 1}",
                Modifier.fillMaxSize()
                    .pointerInput(file) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 6f)
                            offset = if (scale == 1f) Offset.Zero else offset + pan
                        }
                    }
                    .pointerInput(file) {
                        detectTapGestures(onDoubleTap = { if (scale > 1f) { scale = 1f; offset = Offset.Zero } else scale = 2.5f })
                    }
                    .graphicsLayer { scaleX = scale; scaleY = scale; translationX = offset.x; translationY = offset.y },
                contentScale = ContentScale.Fit
            )
            Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("Страница ${page + 1} из ${files.size}", style = T.BodyStrong, color = Color.White, modifier = Modifier.weight(1f).padding(start = 8.dp))
                RoundIconButton(Ic.Close, onClose, size = 44.dp)
            }
            if (files.size > 1) Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SecondaryButton("Назад", { if (page > 0) page-- }, Modifier.weight(1f), icon = Ic.ChevronLeft)
                SecondaryButton("Дальше", { if (page < files.lastIndex) page++ }, Modifier.weight(1f), icon = Ic.ChevronRight)
            }
        }
    }
}
