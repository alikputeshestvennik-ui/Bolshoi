package ru.marshrut.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.marshrut.AppVm
import ru.marshrut.HistoryEntry
import ru.marshrut.Screen
import ru.marshrut.fmt
import ru.marshrut.km
import ru.marshrut.minutes
import ru.marshrut.money
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val ru = Locale("ru")
private fun day(t: Long) = SimpleDateFormat("d", ru).format(Date(t))
private fun month(t: Long) = SimpleDateFormat("LLLL yyyy", ru).format(Date(t)).replaceFirstChar { it.uppercase() }
private fun mon(t: Long) = SimpleDateFormat("MMM", ru).format(Date(t)).trimEnd('.').uppercase()
private fun weekdayTime(t: Long) = SimpleDateFormat("EEEE, HH:mm", ru).format(Date(t)).replaceFirstChar { it.uppercase() }

// ======================= Список =======================

@Composable
fun HistoryScreen(vm: AppVm) {
    val list = vm.history
    Column(Modifier.fillMaxSize()) {
        TopBar("История", { vm.screen = Screen.HOME }, subtitle = "Все маршруты")
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            if (list.isEmpty()) {
                item(key = "empty") {
                    Column(Modifier.fillMaxWidth().padding(vertical = 60.dp).appear(1)) {
                        Text("Пусто", style = T.Display)
                        Spacer(Modifier.height(10.dp))
                        Text("Завершённые и прерванные маршруты будут собираться здесь.", style = T.Body)
                    }
                }
            } else {
                item(key = "totals") {
                    val kmAll = list.sumOf { it.plan.distanceKm }
                    val stops = list.sumOf { it.done }
                    Card(Modifier.fillMaxWidth().appear(1), padding = 20.dp) {
                        Row {
                            StatBlock(list.size.toString(), plural(list.size, "маршрут", "маршрута", "маршрутов"), Modifier.weight(1f))
                            StatBlock(stops.toString(), "точек пройдено", Modifier.weight(1.2f))
                            StatBlock(km(kmAll), "км всего", Modifier.weight(1f))
                        }
                    }
                }
                var lastMonth = ""
                list.forEachIndexed { i, e ->
                    val m = month(e.date)
                    if (m != lastMonth) {
                        lastMonth = m
                        item(key = "m$m") { SectionLabel(m, Modifier.padding(top = 18.dp, bottom = 6.dp)) }
                    }
                    item(key = e.id) { HistoryRow(e, Modifier.appear(i + 2, e.id)) { vm.openHistory(e) } }
                }
            }
        }
    }
}

@Composable
private fun HistoryRow(e: HistoryEntry, modifier: Modifier, onClick: () -> Unit) {
    val p = e.plan
    Card(modifier.fillMaxWidth().pressable(scaleTo = 0.99f, onClick = onClick), padding = 18.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // дата — крупная цифра с месяцем, как в журнальной вёрстке
            Column(Modifier.width(64.dp)) {
                Text(day(e.date), style = T.H1.copy(fontSize = 38.sp, lineHeight = 38.sp))
                Text(mon(e.date), style = T.Label)
            }
            Box(Modifier.width(1.dp).height(52.dp).background(C.Line))
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(weekdayTime(e.date), style = T.BodyStrong, maxLines = 1)
                Text(
                    "${e.done} из ${p.stops.size} ${plural(p.stops.size, "точки", "точек", "точек")}, ${km(p.distanceKm)} км",
                    style = T.Small, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (e.aborted) Pill("Прерван", Color.White, C.Danger) else Pill("Завершён", Color.White, C.Ink)
                    val cash = p.stops.take(e.done).sumOf { it.fact }
                    if (cash > 0) Pill(money(cash), C.Ink2, C.Field)
                }
            }
            Icon(Ic.ChevronRight, null, tint = C.Mute, modifier = Modifier.size(20.dp))
        }
    }
}

// ======================= Детали =======================

@Composable
fun HistoryDetailScreen(vm: AppVm) {
    val e = vm.historyItem ?: run { vm.screen = Screen.HISTORY; return }
    val p = e.plan
    var askDelete by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        TopBar(weekdayTime(e.date), { vm.screen = Screen.HISTORY }, subtitle = "${day(e.date)} ${month(e.date)}") {
            RoundIconButton(Ic.Trash, { askDelete = true }, tint = C.Danger, size = 42.dp)
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "map") {
                Card(Modifier.fillMaxWidth().appear(0), padding = 0.dp) {
                    RouteMap(p, Modifier.fillMaxWidth().height(280.dp), if (e.aborted) e.done else p.stops.size)
                }
            }
            item(key = "stats") {
                Card(Modifier.fillMaxWidth().appear(1), padding = 18.dp) {
                    Row {
                        StatBlock("${e.done}/${p.stops.size}", "точек", Modifier.weight(1f))
                        StatBlock(km(p.distanceKm), "км", Modifier.weight(1f))
                        StatBlock(minutes(p.durationMin), "в пути", Modifier.weight(1.3f))
                        StatBlock(fmt(p.stops.sumOf { it.weight }), "кг", Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (e.aborted) Pill("Прерван", Color.White, C.Danger) else Pill("Завершён", Color.White, C.Ink)
                        val cash = p.stops.take(e.done).sumOf { it.fact }
                        if (cash > 0) Pill("Наличные ${money(cash)}", C.Ink2, C.Field, Ic.Cash)
                        if (p.header.isNotBlank()) Pill(p.header, C.Ink2, C.Field, Ic.Doc)
                    }
                }
            }
            if (p.excluded.isNotEmpty()) item(key = "ex") {
                Card(Modifier.fillMaxWidth(), padding = 16.dp) {
                    Text("НЕ ЗАЕЗЖАЛИ: ТОЛЬКО ВОЗВРАТ", style = T.Label)
                    Spacer(Modifier.height(8.dp))
                    p.excluded.forEach { x -> Text("${x.title} — ${x.label}", style = T.Body) }
                }
            }
            item(key = "label") { SectionLabel("Порядок объезда") }
            itemsIndexed(p.stops, key = { i, s -> "h$i" + s.point.name }) { i, s ->
                TimelineItem(i, s, i == p.stops.lastIndex, false, i < e.done, Modifier.appear(i + 2, s.point.name)) {}
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp)) {
            PrimaryButton("Поехать снова по этому маршруту", { vm.repeatRoute(e) }, Modifier.fillMaxWidth(), icon = Ic.Play)
        }
    }
    if (askDelete) ConfirmDialog(
        title = "Удалить из истории?",
        text = "Запись о маршруте исчезнет без возможности восстановления.",
        confirm = "Удалить",
        onConfirm = { askDelete = false; vm.deleteHistory(e) },
        onDismiss = { askDelete = false }
    )
}
