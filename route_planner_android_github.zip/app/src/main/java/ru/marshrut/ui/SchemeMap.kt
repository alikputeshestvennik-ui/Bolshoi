package ru.marshrut.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.marshrut.Plan
import ru.marshrut.RouteLeg
import ru.marshrut.routeLegs
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.pow

// ======================= Схема маршрута «как карта метро» =======================
//
// Направления — как в жизни, но только под 0°/45°/90°; длинные перегоны сжаты, соседние точки разведены,
// точки одного посёлка — ровной «станцией». Берег моря и главная гряда гор пересчитываются в ту же схему,
// чтобы стоять там же относительно точек, что и на местности.

/** Берег Южнобережья и Севастополя (широта, долгота) с запада на восток — упрощённо, для схемы. */
private val COAST = listOf(
    44.497 to 33.560, 44.493 to 33.600, 44.470 to 33.630,
    44.430 to 33.650, 44.418 to 33.700, 44.405 to 33.740, 44.388 to 33.780, 44.392 to 33.830, 44.398 to 33.880,
    44.393 to 33.940, 44.393 to 33.985, 44.402 to 34.005, 44.413 to 34.045, 44.423 to 34.075, 44.428 to 34.100,
    44.445 to 34.130, 44.465 to 34.150, 44.490 to 34.170, 44.505 to 34.200, 44.512 to 34.235, 44.530 to 34.270,
    44.548 to 34.295, 44.578 to 34.335, 44.620 to 34.370, 44.670 to 34.410
)

/** Главная гряда Крымских гор над побережьем: от Балаклавских высот до Бабугана. */
private val RIDGE = listOf(
    44.470 to 33.660, 44.440 to 33.720, 44.425 to 33.790, 44.428 to 33.860, 44.437 to 33.940, 44.447 to 34.010,
    44.455 to 34.065, 44.480 to 34.100, 44.520 to 34.135, 44.545 to 34.170, 44.565 to 34.215, 44.585 to 34.265, 44.615 to 34.310, 44.660 to 34.360
)

private class Scheme(
    val stops: List<Offset>, val depot: Offset?, val legs: List<RouteLeg>,
    val coast: List<List<Offset>>, val ridge: List<List<Offset>>
)

/** Широта/долгота → километры на плоскости (вниз — на юг). */
private fun km(lat: Double, lon: Double) = Offset((lon * 79.3).toFloat(), (-lat * 111.2).toFloat())

/**
 * Сжатие по одной оси: промежутки между соседними точками берутся в степени 0,3 —
 * длинный перегон укорачивается сильнее короткого, а порядок «западнее/восточнее» сохраняется.
 */
private fun axisMap(vals: List<Float>): (Float) -> Float {
    val xs = vals.map { (it * 1000).roundToInt() / 1000f }.distinct().sorted()
    val out = FloatArray(xs.size)
    for (i in 1 until xs.size) out[i] = out[i - 1] + (xs[i] - xs[i - 1]).toDouble().pow(0.3).toFloat()
    return f@{ v ->
        if (v <= xs.first()) return@f out[0] - (xs.first() - v).toDouble().pow(0.3).toFloat()
        if (v >= xs.last()) return@f out.last() + (v - xs.last()).toDouble().pow(0.3).toFloat()
        var i = 0; while (i < xs.size - 2 && v > xs[i + 1]) i++
        val t = if (xs[i + 1] > xs[i]) (v - xs[i]) / (xs[i + 1] - xs[i]) else 0f
        out[i] + t * (out[i + 1] - out[i])
    }
}

private fun buildScheme(plan: Plan): Scheme {
    val legs = routeLegs(plan)
    val realStops = plan.stops.map { km(it.point.lat, it.point.lon) }
    val depReal = plan.depot?.let { km(it.lat, it.lon) }
    val real = listOfNotNull(depReal) + realStops
    val fx = axisMap(real.map { it.x }); val fy = axisMap(real.map { it.y })
    val p = real.map { floatArrayOf(fx(it.x), fy(it.y)) }
    // Раздвигаем слипшиеся точки: не ближе 7,5% размера схемы
    val ext = maxOf(p.maxOf { it[0] } - p.minOf { it[0] }, p.maxOf { it[1] } - p.minOf { it[1] }).coerceAtLeast(0.1f)
    val md = 0.075f * ext
    repeat(400) {
        var moved = false
        for (i in p.indices) for (j in i + 1 until p.size) {
            var dx = p[j][0] - p[i][0]; var dy = p[j][1] - p[i][1]; var d = hypot(dx, dy)
            if (d < md) {
                if (d < 1e-6f) { dx = 0.01f * (j - i); dy = 0.013f; d = hypot(dx, dy) }
                val push = (md - d) / 2; val ux = dx / d; val uy = dy / d
                p[i][0] -= ux * push; p[i][1] -= uy * push; p[j][0] += ux * push; p[j][1] += uy * push; moved = true
            }
        }
        if (!moved) return@repeat
    }
    val abs = p.map { Offset(it[0], it[1]) }
    val depot = if (depReal != null) abs.first() else null
    val stops = if (depReal != null) abs.drop(1) else abs

    // Берег и горы — тем же сжатием плюс те же сдвиги, что получили ближайшие точки
    fun tr(q: Offset): Offset {
        var sx = 0f; var sy = 0f; var sw = 0f
        for (i in real.indices) {
            val d2 = (q - real[i]).getDistanceSquared(); val w = 1f / ((d2 + 1f) * (d2 + 1f))
            sx += (abs[i].x + fx(q.x) - fx(real[i].x)) * w; sy += (abs[i].y + fy(q.y) - fy(real[i].y)) * w; sw += w
        }
        return Offset(sx / sw, sy / sw)
    }
    // Только в районе самих точек: на длинном перегоне от склада сжатие слишком сильное
    val x0 = realStops.minOf { it.x }; val x1 = realStops.maxOf { it.x }
    val y0 = realStops.minOf { it.y } - 6f; val y1 = realStops.maxOf { it.y } + 6f
    fun pieces(line: List<Pair<Double, Double>>): List<List<Offset>> {
        val dense = ArrayList<Offset>()
        for (k in 0 until line.size - 1) {
            val a = km(line[k].first, line[k].second); val b = km(line[k + 1].first, line[k + 1].second)
            val n = ((b - a).getDistance() / 0.3f).toInt().coerceAtLeast(1)
            for (j in 0 until n) dense.add(a + (b - a) * (j / n.toFloat()))
        }
        dense.add(km(line.last().first, line.last().second))
        val out = ArrayList<List<Offset>>(); var cur = ArrayList<Offset>()
        for (q in dense) {
            if (q.x in x0..x1 && q.y in y0..y1) cur.add(tr(q))
            else { if (cur.size >= 2) out.add(cur); cur = ArrayList() }
        }
        if (cur.size >= 2) out.add(cur)
        return out
    }
    return Scheme(stops, depot, legs, pieces(COAST), pieces(RIDGE))
}

/** Отрезок «как в метро»: прямо и под 45° с одним изломом; flip — где излом. */
private fun octi(a: Offset, b: Offset, flip: Boolean): List<Offset> {
    val dx = b.x - a.x; val dy = b.y - a.y; val adx = kotlin.math.abs(dx); val ady = kotlin.math.abs(dy)
    val sx = if (dx >= 0) 1 else -1; val sy = if (dy >= 0) 1 else -1
    if (adx < 1f || ady < 1f) return listOf(a, b)
    val m = if (adx > ady) { if (!flip) Offset(a.x + sx * (adx - ady), a.y) else Offset(a.x + sx * ady, b.y) }
            else { if (!flip) Offset(a.x, a.y + sy * (ady - adx)) else Offset(b.x, a.y + sy * adx) }
    return listOf(a, m, b)
}

private fun crosses(p1: Offset, p2: Offset, p3: Offset, p4: Offset): Boolean {
    fun o(a: Offset, b: Offset, c: Offset) = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)
    return o(p3, p4, p1) * o(p3, p4, p2) < 0 && o(p1, p2, p3) * o(p1, p2, p4) < 0
}

@Composable
fun SchemeMap(plan: Plan, modifier: Modifier = Modifier, current: Int = -1) {
    val sc = remember(plan) { buildScheme(plan) }
    val tm = rememberTextMeasurer()
    val num = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = C.Ink)
    val numOn = num.copy(color = Color.White)
    val town = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = C.Ink)
    val seaFill = Color(0xFFE6EDF1); val wave = Color(0xFFC9D6DE); val mount = Color(0xFFB4B3AE)
    var zoom by remember(plan) { mutableFloatStateOf(1f) }
    var off by remember(plan) { mutableStateOf(Offset.Zero) }

    Box(modifier) {
        Canvas(
            Modifier.matchParentSize().clipToBounds()
                .pointerInput(plan) {
                    // Два пальца — масштаб; один палец двигает схему только когда она увеличена
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        do {
                            val ev = awaitPointerEvent()
                            val fingers = ev.changes.count { it.pressed }
                            if (fingers >= 2 || (fingers == 1 && zoom > 1.01f)) {
                                val z = if (fingers >= 2) ev.calculateZoom() else 1f
                                val c = ev.calculateCentroid(useCurrent = true)
                                val nz = (zoom * z).coerceIn(1f, 6f)
                                val no = if (c == Offset.Unspecified) off else c - (c - off) * (nz / zoom)
                                zoom = nz
                                val o = no + ev.calculatePan()
                                off = Offset(o.x.coerceIn(size.width * (1 - nz), 0f), o.y.coerceIn(size.height * (1 - nz), 0f))
                                ev.changes.forEach { if (it.positionChanged()) it.consume() }
                            }
                        } while (ev.changes.any { it.pressed })
                    }
                }
                .pointerInput(plan) { detectTapGestures(onDoubleTap = { zoom = 1f; off = Offset.Zero }) }
        ) {
            if (sc.stops.isEmpty()) return@Canvas
            val all = sc.stops + listOfNotNull(sc.depot)
            val bx0 = all.minOf { it.x }; val bx1 = all.maxOf { it.x }
            val by0 = all.minOf { it.y }; val by1 = all.maxOf { it.y }
            val pad = 34.dp.toPx(); val padR = 70.dp.toPx()
            val unit = minOf((size.width - pad - padR) / (bx1 - bx0).coerceAtLeast(0.01f),
                (size.height - pad * 2) / (by1 - by0).coerceAtLeast(0.01f), 64.dp.toPx())
            val cx = pad + ((size.width - pad - padR) - (bx1 - bx0) * unit) / 2
            val cy = pad + ((size.height - pad * 2) - (by1 - by0) * unit) / 2
            fun at(p: Offset) = Offset(cx + (p.x - bx0) * unit, cy + (p.y - by0) * unit) * zoom + off

            // Море: всё «ниже» береговой линии
            sc.coast.forEach { line ->
                val pts = line.map { at(it) }
                val sea = Path().apply {
                    // Море тянем до краёв схемы
                    moveTo(-size.width, pts.first().y); lineTo(pts.first().x, pts.first().y); pts.drop(1).forEach { lineTo(it.x, it.y) }
                    lineTo(size.width * 2, pts.last().y); lineTo(size.width * 2, size.height * 3); lineTo(-size.width, size.height * 3); close()
                }
                drawPath(sea, seaFill)
                val shore = Path().apply { moveTo(pts.first().x, pts.first().y); pts.drop(1).forEach { lineTo(it.x, it.y) } }
                drawPath(shore, wave, style = Stroke(1.5.dp.toPx()))
                // Волны вдоль берега — примерно через каждые 60 dp
                var run = 0f
                for (i in 0 until pts.size - 1) {
                    val a = pts[i]; val b = pts[i + 1]; run += (b - a).getDistance()
                    if (run < 60.dp.toPx()) continue
                    run = 0f
                    val w = Offset(b.x, b.y + 16.dp.toPx())
                    val p = Path().apply {
                        moveTo(w.x - 8.dp.toPx(), w.y)
                        quadraticBezierTo(w.x - 4.dp.toPx(), w.y - 3.dp.toPx(), w.x, w.y)
                        quadraticBezierTo(w.x + 4.dp.toPx(), w.y + 3.dp.toPx(), w.x + 8.dp.toPx(), w.y)
                    }
                    drawPath(p, wave, style = Stroke(1.2.dp.toPx(), cap = StrokeCap.Round))
                }
            }
            // Горы: цепочка треугольников по гряде
            sc.ridge.forEach { line ->
                val pts = line.map { at(it) }
                var acc = 0f; val stepPx = 20.dp.toPx()
                for (i in 0 until pts.size - 1) {
                    val a = pts[i]; val b = pts[i + 1]; val d = (b - a).getDistance(); if (d < 1f) continue
                    var t = (stepPx - acc) / d
                    while (t <= 1f) {
                        val c = a + (b - a) * t; val hw = 5.dp.toPx(); val h = 7.dp.toPx()
                        drawPath(Path().apply { moveTo(c.x - hw, c.y + h / 2); lineTo(c.x, c.y - h / 2); lineTo(c.x + hw, c.y + h / 2); close() }, mount)
                        t += stepPx / d
                    }
                    acc = ((acc + d) % stepPx)
                }
            }

            // Линия маршрута «как метро»: для каждого отрезка излом выбираем так, чтобы меньше пересекать уже нарисованное
            val seq = (listOfNotNull(sc.depot) + sc.stops).map { at(it) }
            val poly = arrayListOf(seq.first()); val segs = ArrayList<Pair<Offset, Offset>>()
            for (i in 0 until seq.size - 1) {
                val opts = listOf(octi(seq[i], seq[i + 1], false), octi(seq[i], seq[i + 1], true))
                val best = opts.minByOrNull { pts -> (0 until pts.size - 1).sumOf { k -> segs.dropLast(1).count { (u, v) -> crosses(pts[k], pts[k + 1], u, v) } } }!!
                for (k in 0 until best.size - 1) segs.add(best[k] to best[k + 1])
                poly.addAll(best.drop(1))
            }
            val path = Path().apply { moveTo(poly[0].x, poly[0].y); poly.drop(1).forEach { lineTo(it.x, it.y) } }
            drawPath(path, Color.White, style = Stroke(9.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawPath(path, C.Ink, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            if (sc.depot != null && plan.end != null) {
                val ret = octi(seq.last(), seq.first(), true)
                val rp = Path().apply { moveTo(ret[0].x, ret[0].y); ret.drop(1).forEach { lineTo(it.x, it.y) } }
                drawPath(rp, C.Mute, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))))
            }

            // Точки — кружки с номером; склад — квадрат
            val r = 9.dp.toPx()
            val taken = ArrayList<Rect>()
            sc.stops.forEachIndexed { i, s0 ->
                val c = at(s0)
                val on = i == current; val done = current >= 0 && i < current
                drawCircle(Color.White, r + 2.dp.toPx(), c)
                drawCircle(if (on) C.Ink else Color.White, r, c)
                drawCircle(if (done) C.Mute else C.Ink, r, c, style = Stroke(2.dp.toPx()))
                val t = tm.measure("${i + 1}", if (on) numOn else num)
                drawText(t, topLeft = Offset(c.x - t.size.width / 2f, c.y - t.size.height / 2f))
                taken.add(Rect(c, r + 3.dp.toPx()))
            }
            sc.depot?.let { d ->
                val c = at(d); val h = 8.dp.toPx()
                drawRect(C.Ink, Offset(c.x - h, c.y - h), Size(h * 2, h * 2))
                drawRect(Color.White, Offset(c.x - h / 2.4f, c.y - h / 2.4f), Size(h / 1.2f, h / 1.2f))
                taken.add(Rect(c, h + 3.dp.toPx()))
            }

            // Подписи посёлков: сбоку от группы точек, там, где не задеваем точки, линию и другие подписи
            val linePts = ArrayList<Offset>()
            for (i in 0 until poly.size - 1) {
                val a = poly[i]; val b = poly[i + 1]; val n = ((b - a).getDistance() / 6f).toInt().coerceAtLeast(1)
                for (j in 0..n) linePts.add(a + (b - a) * (j / n.toFloat()))
            }
            sc.legs.forEach { leg ->
                val nums = if (leg.to > leg.from) "${leg.from + 1}–${leg.to + 1}" else "${leg.from + 1}"
                val t = tm.measure("${leg.place} · $nums", town)
                val w = t.size.width.toFloat(); val h = t.size.height.toFloat()
                val pts = (leg.from..leg.to).map { at(sc.stops[it]) }; val m = r + 6.dp.toPx()
                val lx = pts.minOf { it.x } - m; val rx = pts.maxOf { it.x } + m
                val ty = pts.minOf { it.y } - m; val by = pts.maxOf { it.y } + m
                val mx = (lx + rx) / 2; val my = (ty + by) / 2
                val cands = listOf(Offset(rx, my - h / 2), Offset(lx - w, my - h / 2), Offset(mx - w / 2, ty - h), Offset(mx - w / 2, by),
                    Offset(rx, ty - h), Offset(rx, by), Offset(lx - w, ty - h), Offset(lx - w, by)).map { Rect(it, Size(w, h)) }
                fun bad(rc: Rect) = taken.any { it.overlaps(rc) } || linePts.any { rc.inflate(3.dp.toPx()).contains(it) }
                val rc = cands.firstOrNull { !bad(it) && it.left >= 0 && it.right <= size.width && it.top >= 0 && it.bottom <= size.height } ?: cands.first()
                drawRoundRect(Color.White.copy(alpha = 0.9f), rc.topLeft - Offset(3.dp.toPx(), 1.dp.toPx()),
                    Size(rc.width + 6.dp.toPx(), rc.height + 2.dp.toPx()), androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()))
                drawText(t, topLeft = rc.topLeft)
                taken.add(rc)
            }
        }
    }
}
