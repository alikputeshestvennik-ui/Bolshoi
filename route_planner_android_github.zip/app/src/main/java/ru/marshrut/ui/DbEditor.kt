package ru.marshrut.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ru.marshrut.AppVm
import ru.marshrut.DbDraft

// ======================= Редактор базы (только редактор) =======================

/**
 * Вся база в одном списке: точка и её позывные правятся в одной карточке.
 * Поиск идёт по коду, названию, адресу и позывным; фильтр «Требуют внимания» показывает точки с замечаниями.
 */
@Composable
fun DbEditorScreen(vm: AppVm) {
    val d = vm.draft
    var q by remember { mutableStateOf("") }
    var onlyIssues by remember { mutableStateOf(false) }
    var open by remember { mutableStateOf<Int?>(null) }
    var askDiscard by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val issues = remember(d.points.toList(), d.calls.toList()) { vm.draftIssues() }
    val needle = q.trim().lowercase()
    val signNeedle = vm.db.norm(q)
    val attention = issues.count { it.value.isNotEmpty() }
    val orphans = d.orphans()
    val list = d.points.filter { p ->
        (!onlyIssues || issues[p.key].orEmpty().isNotEmpty()) && (needle.isEmpty() ||
            listOf(p.name, p.title, p.address).any { it.lowercase().contains(needle) } ||
            (signNeedle.isNotEmpty() && d.callsOf(p).any { vm.db.norm(it.callsign).contains(signNeedle) }))
    }.let { l -> if (onlyIssues) l.sortedByDescending { p -> issues[p.key].orEmpty().count { it.serious } } else l }
    // Новая точка — сразу наверх списка
    LaunchedEffect(open) { if (open != null && d.points.firstOrNull()?.key == open) listState.animateScrollToItem(0) }

    Column(Modifier.fillMaxSize()) {
        TopBar("База точек", { vm.closeDbEditor() },
            subtitle = "${d.points.size} ${plural(d.points.size, "точка", "точки", "точек")} · " +
                "${d.calls.count { it.callsign.isNotBlank() }} позывных") {
            GhostButton("Отменить", { askDiscard = true }, tint = C.Danger)
        }
        Field(q, { q = it }, "", Modifier.padding(horizontal = 20.dp), leading = Ic.Search,
            placeholder = "Код, название, адрес или позывной")
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Все · ${d.points.size}" to false, "Требуют внимания · $attention" to true).forEach { (label, v) ->
                val on = onlyIssues == v
                Box(Modifier.weight(1f).height(42.dp).background(if (on) C.Ink else C.Field).pressable { onlyIssues = v },
                    contentAlignment = Alignment.Center) {
                    Text(label, style = T.BodyStrong, color = if (on) Color.White else if (v && attention > 0) C.Danger else C.Ink)
                }
            }
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            state = listState,
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (orphans.isNotEmpty()) item(key = "orphans") { OrphanCalls(d, orphans) }
            item(key = "add") {
                SecondaryButton("Новая точка", {
                    val p = d.addPoint(); d.addCall(p)
                    q = ""; onlyIssues = false; open = p.key
                }, Modifier.fillMaxWidth(), icon = Ic.Plus)
            }
            if (list.isEmpty()) item(key = "empty") {
                Text(if (onlyIssues && needle.isEmpty()) "Замечаний нет — база в порядке" else "Ничего не найдено",
                    style = T.Body, color = C.Mute, modifier = Modifier.padding(vertical = 24.dp).fillMaxWidth())
            }
            items(list, key = { it.key }) { p ->
                PointCard(vm, d, p, issues[p.key].orEmpty(), open == p.key) { open = if (open == p.key) null else p.key }
            }
        }
        PrimaryButton("Сохранить и выложить", { vm.closeDbEditor() },
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), icon = Ic.Check)
    }
    if (askDiscard) ConfirmDialog(
        title = "Отменить правки?",
        text = "Все изменения, сделанные в этом окне, пропадут. База останется как была.",
        confirm = "Отменить правки",
        onConfirm = { askDiscard = false; vm.closeDbEditor(discard = true) },
        onDismiss = { askDiscard = false }
    )
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
private fun PointCard(vm: AppVm, d: DbDraft, p: DbDraft.P, issues: List<AppVm.Issue>, open: Boolean, onToggle: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val haptic = LocalHapticFeedback.current
    var manual by remember(p.key) { mutableStateOf(false) }
    var mapAt by remember(p.key) { mutableStateOf<Pair<Double, Double>?>(null) }
    var askDelete by remember(p.key) { mutableStateOf(false) }
    val coords = DbDraft.parseCoords(p.coords)
    val calls = d.callsOf(p)
    val signs = calls.map { it.callsign.trim() }.filter { it.isNotEmpty() }
    Column(Modifier.fillMaxWidth().background(C.Surface).border(1.dp, if (open) C.Ink else C.Line)) {
        Row(Modifier.fillMaxWidth().pressable(scaleTo = 0.99f, onClick = onToggle).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(p.display.ifBlank { "Новая точка" }, style = T.BodyStrong, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (signs.isNotEmpty()) Text(signs.joinToString(" · "), style = T.BodyStrong.copy(color = C.Ink2), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(listOf(p.name, p.address).filter { it.isNotBlank() }.joinToString(" · "), style = T.Small, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (issues.isNotEmpty()) FlowRow(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    issues.forEach { Pill(it.text, if (it.serious) Color.White else C.Ink2, if (it.serious) C.Danger else C.Field) }
                }
            }
            Spacer(Modifier.width(8.dp))
            Icon(if (open) Ic.ChevronDown else Ic.ChevronRight, null, tint = C.Mute, modifier = Modifier.size(20.dp))
        }
        Expand(open) {
            Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Позывные — прямо здесь, без отдельной вкладки
                Text("ПОЗЫВНЫЕ", style = T.Label)
                calls.forEach { c ->
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Field(c.callsign, { d.update(c.copy(callsign = it)) }, "", Modifier.weight(1f), placeholder = "Например, 166ЮС",
                                keyboard = KeyboardOptions(capitalization = KeyboardCapitalization.Characters))
                            RoundIconButton(Ic.Trash, { d.removeCall(c) }, tint = C.Danger, size = 46.dp)
                        }
                        d.sameSign(c, vm.db::norm)?.let { other ->
                            val from = d.pointOf(other)?.display ?: other.point
                            Text("Этот позывной сейчас у «$from» — после сохранения он будет вести сюда", style = T.Small, color = C.Danger,
                                modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
                GhostButton("Добавить позывной", { d.addCall(p) }, icon = Ic.Plus)

                Field(p.title, { d.update(p.copy(title = it)) }, "Название")
                Field(p.address, { d.update(p.copy(address = it)) }, "Адрес", singleLine = false)
                Field(p.name, { d.update(p.copy(name = it)) }, "Код точки", placeholder = "Например, 7ю")

                // Координаты: карта; нажатие — вставить скопированные; долгое — адрес в Яндекс Картах
                Text("КООРДИНАТЫ", style = T.Label)
                Box(
                    Modifier.fillMaxWidth().background(C.Field).border(1.5.dp, if (coords == null) C.Danger else Color.Transparent)
                        .combinedClickable(
                            onClick = {
                                val c = clip.getText()?.text?.let { DbDraft.parseCoords(it) }
                                if (c != null) { d.update(p.copy(coords = coordsText(c.first, c.second))); vm.info = "Координаты вставлены" }
                                else manual = true
                            },
                            onLongClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                val query = listOf(p.address, p.title).firstOrNull { it.isNotBlank() } ?: p.name
                                if (query.isBlank()) vm.error = "Сначала впишите адрес точки" else ru.marshrut.openMapsSearch(ctx, query)
                            }
                        ).padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Ic.Locate, null, tint = C.Mute, modifier = Modifier.size(19.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(p.coords.ifBlank { "не указаны" }, style = T.BodyStrong, color = if (coords == null) C.Danger else C.Ink)
                    }
                }
                SecondaryButton("Указать на карте", {
                    if (coords != null) mapAt = coords else vm.mapStart(p.address) { mapAt = it }
                }, Modifier.fillMaxWidth(), icon = Ic.Map)
                Text("Нажатие на поле вставит скопированные координаты, долгое нажатие откроет адрес в Яндекс Картах.", style = T.Small)
                if (manual) Field(p.coords, { d.update(p.copy(coords = it)) }, "Координаты вручную", placeholder = "44.58196, 34.34338",
                    keyboard = KeyboardOptions(keyboardType = KeyboardType.Text))
                Field(p.comment, { d.update(p.copy(comment = it)) }, "Комментарий к выгрузке", singleLine = false, leading = Ic.Note)
                GhostButton("Удалить точку", { askDelete = true }, Modifier.align(Alignment.End), icon = Ic.Trash, tint = C.Danger)
            }
        }
    }
    mapAt?.let { start ->
        MapPickerDialog(p.display.ifBlank { p.address.ifBlank { "Новая точка" } }, start,
            onPick = { la, lo -> d.update(p.copy(coords = coordsText(la, lo))); mapAt = null; vm.info = "Точка поставлена" },
            onDismiss = { mapAt = null })
    }
    if (askDelete) ConfirmDialog(
        title = "Удалить точку?",
        text = "«${p.display.ifBlank { "Новая точка" }}» и её позывные" + (if (signs.isEmpty()) "" else " (${signs.joinToString(", ")})") +
            " пропадут из базы после сохранения.",
        confirm = "Удалить",
        onConfirm = { askDelete = false; d.remove(p) },
        onDismiss = { askDelete = false }
    )
}

/** Позывные, которые ведут на несуществующую точку: вписать код точки или удалить. */
@Composable
private fun OrphanCalls(d: DbDraft, orphans: List<DbDraft.C>) {
    Column(Modifier.fillMaxWidth().background(C.DangerSoft).border(1.dp, C.Danger).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Позывные без точки", style = T.BodyStrong, color = C.Danger)
        Text("Впишите код существующей точки или удалите позывной.", style = T.Small)
        orphans.forEach { c ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(c.callsign, { d.update(c.copy(callsign = it)) }, "", Modifier.weight(1f))
                Field(c.point, { d.attach(c, it) }, "", Modifier.weight(1f), placeholder = "Код точки")
                RoundIconButton(Ic.Trash, { d.removeCall(c) }, tint = C.Danger, size = 46.dp)
            }
        }
    }
}
