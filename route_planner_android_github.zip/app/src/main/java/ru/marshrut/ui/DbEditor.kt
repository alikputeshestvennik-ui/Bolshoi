package ru.marshrut.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ru.marshrut.AppVm
import ru.marshrut.DbDraft

// ======================= Редактор базы (только редактор) =======================

@Composable
fun DbEditorScreen(vm: AppVm) {
    val d = vm.draft
    var tab by remember { mutableStateOf(0) }
    var q by remember { mutableStateOf("") }
    var open by remember { mutableStateOf<Int?>(null) }
    var askDiscard by remember { mutableStateOf(false) }
    val needle = q.trim().lowercase()
    Column(Modifier.fillMaxSize()) {
        TopBar("База точек", { vm.closeDbEditor() }, subtitle = "Редактор · ${d.points.size} точек · ${d.calls.size} позывных") {
            GhostButton("Отменить", { askDiscard = true }, tint = C.Danger)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Точки", "Позывные").forEachIndexed { i, label ->
                val on = tab == i
                Box(Modifier.weight(1f).height(44.dp).background(if (on) C.Ink else C.Field).pressable { tab = i; open = null },
                    contentAlignment = Alignment.Center) { Text(label, style = T.BodyStrong, color = if (on) Color.White else C.Ink) }
            }
        }
        Spacer(Modifier.height(10.dp))
        Field(q, { q = it }, "", Modifier.padding(horizontal = 20.dp), leading = Ic.Search,
            placeholder = if (tab == 0) "Код, название, адрес, позывной" else "Позывной или код точки")
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (tab == 0) {
                item {
                    SecondaryButton("Добавить точку", { val p = d.addPoint(); q = ""; open = p.key }, Modifier.fillMaxWidth(), icon = Ic.Plus)
                }
                val list = d.points.filter { p ->
                    needle.isEmpty() || listOf(p.name, p.title, p.address).any { it.lowercase().contains(needle) } ||
                        d.callsOf(p).any { it.callsign.lowercase().contains(needle) }
                }
                items(list, key = { it.key }) { p ->
                    PointEditor(vm, d, p, open == p.key) { open = if (open == p.key) null else p.key }
                }
            } else {
                item {
                    SecondaryButton("Добавить позывной", { d.addCall(); q = "" }, Modifier.fillMaxWidth(), icon = Ic.Plus)
                }
                val names = d.points.map { it.name.trim() }.toSet()
                val list = d.calls.filter { c -> needle.isEmpty() || c.callsign.lowercase().contains(needle) || c.point.lowercase().contains(needle) }
                items(list, key = { it.key }) { c -> CallEditor(d, c, c.point.trim() in names) }
            }
        }
        PrimaryButton("Сохранить и выложить", { vm.closeDbEditor() },
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), icon = Ic.Check)
    }
    if (askDiscard) ConfirmDialog(
        title = "Отменить правки?",
        text = "Все изменения, сделанные в этом окне, пропадут. База останется как была.",
        confirm = "Отменить правки",
        onConfirm = { askDiscard = false; vm.closeDbEditor(discard = true) },
        onDismiss = { askDiscard = false }
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PointEditor(vm: AppVm, d: DbDraft, p: DbDraft.P, open: Boolean, onToggle: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val haptic = LocalHapticFeedback.current
    var manual by remember(p.key) { mutableStateOf(false) }
    val noCoords = DbDraft.parseCoords(p.coords) == null
    Column(Modifier.fillMaxWidth().background(C.Surface).border(1.dp, if (open) C.Ink else C.Line)) {
        Row(Modifier.fillMaxWidth().pressable(scaleTo = 0.99f, onClick = onToggle).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(p.display.ifBlank { "Новая точка" }, style = T.BodyStrong, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(listOf(p.name, p.address).filter { it.isNotBlank() }.joinToString(" · "), style = T.Small, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (noCoords) { Spacer(Modifier.width(8.dp)); Pill("Нет координат", Color.White, C.Danger) }
            Spacer(Modifier.width(8.dp))
            Icon(if (open) Ic.ChevronDown else Ic.ChevronRight, null, tint = C.Mute, modifier = Modifier.size(20.dp))
        }
        Expand(open) {
            Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Field(p.name, { d.update(p.copy(name = it)) }, "Код точки")
                Field(p.title, { d.update(p.copy(title = it)) }, "Название")
                Field(p.address, { d.update(p.copy(address = it)) }, "Адрес", singleLine = false)
                // Координаты: долгое нажатие — адрес в Яндекс Картах; нажатие — вставить скопированные там координаты
                Text("КООРДИНАТЫ", style = T.Label)
                Box(
                    Modifier.fillMaxWidth().background(C.Field).border(1.5.dp, if (noCoords) C.Danger else Color.Transparent)
                        .combinedClickable(
                            onClick = {
                                val c = clip.getText()?.text?.let { DbDraft.parseCoords(it) }
                                if (c != null) { d.update(p.copy(coords = "${c.first}, ${c.second}")); vm.info = "Координаты вставлены" }
                                else manual = true
                            },
                            onLongClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                val query = listOf(p.address, p.title).firstOrNull { it.isNotBlank() } ?: p.name
                                if (query.isBlank()) vm.error = "Сначала впишите адрес точки" else ru.marshrut.openMapsSearch(ctx, query)
                            }
                        ).padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Ic.Locate, null, tint = C.Mute, modifier = Modifier.size(19.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(p.coords.ifBlank { "не указаны" }, style = T.BodyStrong, color = if (noCoords) C.Danger else C.Ink)
                    }
                }
                Text("Долгое нажатие — адрес откроется в Яндекс Картах. Скопируйте там координаты, вернитесь и нажмите на поле — они вставятся.",
                    style = T.Small)
                if (manual) Field(p.coords, { d.update(p.copy(coords = it)) }, "Координаты вручную", placeholder = "44.58196, 34.34338",
                    keyboard = KeyboardOptions(keyboardType = KeyboardType.Text))
                Field(p.comment, { d.update(p.copy(comment = it)) }, "Комментарий к выгрузке", singleLine = false, leading = Ic.Note)
                val cs = d.callsOf(p)
                Text(if (cs.isEmpty()) "Позывных нет" else "Позывные: " + cs.joinToString(", ") { it.callsign }, style = T.Small)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GhostButton("Добавить позывной", { d.addCall(p.name) }, icon = Ic.Plus)
                    Spacer(Modifier.weight(1f))
                    GhostButton("Удалить точку", { d.remove(p) }, icon = Ic.Trash, tint = C.Danger)
                }
            }
        }
    }
}

@Composable
private fun CallEditor(d: DbDraft, c: DbDraft.C, pointOk: Boolean) {
    Row(Modifier.fillMaxWidth().background(C.Surface).border(1.dp, if (pointOk) C.Line else C.Danger).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Field(c.callsign, { d.update(c.copy(callsign = it)) }, "Позывной", Modifier.weight(1f))
        Field(c.point, { d.update(c.copy(point = it)) }, if (pointOk) "Код точки" else "Нет такой точки", Modifier.weight(1f))
        RoundIconButton(Ic.Trash, { d.removeCall(c) }, tint = C.Danger, size = 42.dp)
    }
}
