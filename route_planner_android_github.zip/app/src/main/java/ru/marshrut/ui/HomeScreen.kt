package ru.marshrut.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.marshrut.AppVm
import ru.marshrut.Screen
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun HomeScreen(vm: AppVm, onPick: () -> Unit, onImp: () -> Unit, onExp: () -> Unit) {
    @Suppress("UNUSED_VARIABLE") val v = vm.dbVer
    var askAbort by remember { androidx.compose.runtime.mutableStateOf(false) }
    val today = remember { LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale("ru"))).replaceFirstChar { it.uppercase() } }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(top = 12.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Типографская шапка без логотипа
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.appear(0).padding(top = 4.dp)) {
            Text(today.uppercase(), style = T.Label, modifier = Modifier.weight(1f))
            RoundIconButton(Ic.Clock, { vm.screen = Screen.HISTORY }, size = 42.dp)
            Spacer(Modifier.width(8.dp))
            RoundIconButton(Ic.Sliders, { vm.screen = Screen.SETTINGS }, size = 42.dp)
        }
        Column(Modifier.appear(1)) {
            Text("Маршрут", style = T.Display.copy(fontSize = 64.sp, lineHeight = 60.sp, letterSpacing = (-3).sp))
            Box(Modifier.padding(top = 10.dp).width(56.dp).height(4.dp).background(C.Ink))
        }

        // Активный маршрут
        val p = vm.plan
        if (vm.hasActiveRoute && p != null) {
            Card(Modifier.fillMaxWidth().appear(1), radius = 26.dp, padding = 20.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBubble(Ic.Truck, C.Sea, C.SeaSoft)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (vm.started) "Маршрут в пути" else "Маршрут построен", style = T.H3)
                        Text(
                            if (vm.started) "Точка ${vm.stopIndex + 1} из ${p.stops.size}" else "${p.stops.size} ${plural(p.stops.size, "точка", "точки", "точек")}, ${ru.marshrut.km(p.distanceKm)} км",
                            style = T.Small
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                SegmentedProgress(p.stops.size, if (vm.started) vm.stopIndex else -1)
                if (vm.started) {
                    Spacer(Modifier.height(12.dp))
                    Text(p.stops.getOrNull(vm.stopIndex)?.point?.display.orEmpty(), style = T.BodyStrong, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Spacer(Modifier.height(16.dp))
                PrimaryButton(if (vm.started) "Продолжить" else "Открыть маршрут", vm::resume, Modifier.fillMaxWidth(), icon = Ic.Play)
                GhostButton("Прервать маршрут", { askAbort = true }, Modifier.align(Alignment.CenterHorizontally).padding(top = 6.dp), icon = Ic.Close, tint = C.Danger)
            }
            if (askAbort) ConfirmDialog(
                title = "Прервать маршрут?",
                text = "Ведение остановится, уведомление в шторке закроется.",
                confirm = "Прервать маршрут",
                onConfirm = { askAbort = false; vm.abortRoute() },
                onDismiss = { askAbort = false }
            )
        }

        // Новый лист
        Card(Modifier.fillMaxWidth().appear(2), radius = 28.dp, padding = 20.dp) {
            Text("Новый маршрутный лист", style = T.H2)
            Spacer(Modifier.height(4.dp))
            Text("Фото, скан или PDF — от одной до четырёх страниц.", style = T.Body)
            Spacer(Modifier.height(16.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RectangleShape)
                    .background(if (vm.uris.isEmpty()) C.Field else C.SeaSoft)
                    .drawBehind {
                        drawRoundRect(
                            color = if (vm.uris.isEmpty()) C.Mute.copy(alpha = 0.45f) else C.SeaBright,
                            cornerRadius = CornerRadius.Zero,
                            style = Stroke(1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
                        )
                    }
                    .pressable(onClick = onPick)
                    .padding(vertical = 22.dp, horizontal = 18.dp)
                    .animateContentSize(spring(dampingRatio = 0.8f)),
                contentAlignment = Alignment.Center
            ) {
                AnimatedContent(vm.uris.size, label = "files") { n ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBubble(if (n == 0) Ic.Scan else Ic.Check, if (n == 0) C.Ink2 else C.Surface, if (n == 0) C.Surface else C.Sea, 46.dp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(if (n == 0) "Выбрать страницы" else "Выбрано: ${pages(n)}", style = T.H3)
                            Text(if (n == 0) "Нажмите, чтобы открыть галерею или файлы" else "Нажмите, чтобы выбрать заново", style = T.Small)
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            PrimaryButton("Распознать", vm::recognize, Modifier.fillMaxWidth(), icon = Ic.Sparkle, enabled = vm.uris.isNotEmpty() && vm.busy == null)
        }

        // История
        Card(Modifier.fillMaxWidth().appear(3).pressable(scaleTo = 0.99f) { vm.screen = Screen.HISTORY }, padding = 20.dp) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBubble(Ic.Clock, Color.White, C.Ink)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("История маршрутов", style = T.H3)
                    val last = vm.history.firstOrNull()
                    Text(
                        if (last == null) "Пока пусто — появится после первого маршрута"
                        else "${vm.history.size} ${plural(vm.history.size, "маршрут", "маршрута", "маршрутов")}, последний ${shortDate(last.date)}",
                        style = T.Small
                    )
                }
                Icon(Ic.ArrowRight, null, tint = C.Ink, modifier = Modifier.size(22.dp))
            }
        }

        // База
        Card(Modifier.fillMaxWidth().appear(4), radius = 24.dp, padding = 20.dp) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBubble(Ic.Database, C.Lavender, C.LavenderSoft)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("База точек", style = T.H3)
                    Text("Листы «Точки» и «Позывные»", style = T.Small)
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Metric(vm.db.points.size.toString(), "точек", Modifier.weight(1f))
                Metric(vm.db.calls.size.toString(), "позывных", Modifier.weight(1f))
                Metric(vm.db.points.count { it.comment.isNotBlank() }.toString(), "с комментарием", Modifier.weight(1f))
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SecondaryButton("Импорт", onImp, Modifier.weight(1f), icon = Ic.Import)
                SecondaryButton("Экспорт", onExp, Modifier.weight(1f), icon = Ic.Export)
            }
        }
    }
}

@Composable
private fun Metric(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier.drawBehind { drawRect(C.Ink, size = androidx.compose.ui.geometry.Size(2.dp.toPx(), size.height)) }.padding(start = 12.dp, top = 2.dp, bottom = 2.dp)) {
        AnimatedContent(value, label = "m") { Text(it, style = T.Num) }
        Text(label, style = T.Small.copy(fontSize = 12.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

fun shortDate(t: Long): String = java.text.SimpleDateFormat("d MMM, HH:mm", Locale("ru")).format(java.util.Date(t))

fun pages(n: Int): String {
    val m10 = n % 10; val m100 = n % 100
    val w = when {
        m10 == 1 && m100 != 11 -> "страница"
        m10 in 2..4 && m100 !in 12..14 -> "страницы"
        else -> "страниц"
    }
    return "$n $w"
}

fun plural(n: Int, one: String, few: String, many: String): String {
    val m10 = n % 10; val m100 = n % 100
    return when {
        m10 == 1 && m100 != 11 -> one
        m10 in 2..4 && m100 !in 12..14 -> few
        else -> many
    }
}
