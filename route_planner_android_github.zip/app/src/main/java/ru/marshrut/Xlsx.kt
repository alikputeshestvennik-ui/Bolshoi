package ru.marshrut

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Минимальное чтение/запись .xlsx без тяжёлых библиотек. Старый бинарный .xls не поддерживается. */
object Xlsx {
    private fun parser(b: ByteArray): XmlPullParser =
        Xml.newPullParser().also { it.setInput(b.inputStream(), null) }

    fun read(input: InputStream): Map<String, List<List<String>>> {
        val files = HashMap<String, ByteArray>()
        ZipInputStream(input).use { z ->
            var e = z.nextEntry
            while (e != null) { files[e.name] = z.readBytes(); e = z.nextEntry }
        }
        val sst = files["xl/sharedStrings.xml"]?.let { parseSst(it) } ?: emptyList()
        val rels = HashMap<String, String>()
        files["xl/_rels/workbook.xml.rels"]?.let { b ->
            val p = parser(b); var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && p.name == "Relationship")
                    rels[p.getAttributeValue(null, "Id") ?: ""] = p.getAttributeValue(null, "Target") ?: ""
                ev = p.next()
            }
        }
        val out = LinkedHashMap<String, List<List<String>>>()
        files["xl/workbook.xml"]?.let { b ->
            val p = parser(b); var ev = p.eventType; var n = 0
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && p.name == "sheet") {
                    n++
                    val name = p.getAttributeValue(null, "name") ?: "Sheet$n"
                    val rid = p.getAttributeValue(null, "r:id") ?: ""
                    val t = rels[rid] ?: ""
                    val path = when {
                        t.startsWith("/") -> t.drop(1)
                        t.isNotEmpty() -> "xl/$t"
                        else -> "xl/worksheets/sheet$n.xml"
                    }
                    files[path]?.let { out[name] = parseSheet(it, sst) }
                }
                ev = p.next()
            }
        }
        return out
    }

    private fun parseSst(b: ByteArray): List<String> {
        val p = parser(b); val list = ArrayList<String>(); val sb = StringBuilder()
        var inT = false; var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) { "si" -> sb.setLength(0); "t" -> inT = true }
                XmlPullParser.TEXT -> if (inT) sb.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) { "t" -> inT = false; "si" -> list.add(sb.toString()) }
            }
            ev = p.next()
        }
        return list
    }

    private fun colIndex(ref: String): Int {
        var n = 0
        for (ch in ref) { if (ch in 'A'..'Z') n = n * 26 + (ch - 'A' + 1) else break }
        return n - 1
    }

    private fun parseSheet(b: ByteArray, sst: List<String>): List<List<String>> {
        val p = parser(b); val rows = ArrayList<List<String>>()
        var cur = ArrayList<String>(); var type = ""; var ref = ""
        var inV = false; val sb = StringBuilder(); var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "row" -> cur = ArrayList()
                    "c" -> { ref = p.getAttributeValue(null, "r") ?: ""; type = p.getAttributeValue(null, "t") ?: ""; sb.setLength(0) }
                    "v", "t" -> inV = true
                }
                XmlPullParser.TEXT -> if (inV) sb.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "v", "t" -> inV = false
                    "c" -> {
                        val col = colIndex(ref)
                        while (cur.size < col) cur.add("")
                        val s = sb.toString()
                        cur.add(if (type == "s") sst.getOrElse(s.trim().toIntOrNull() ?: -1) { "" } else s)
                    }
                    "row" -> rows.add(cur)
                }
            }
            ev = p.next()
        }
        return rows
    }

    /** Управляющие символы (бывают после распознавания) делают xml нечитаемым — выкидываем их. */
    private fun esc(s: String) = s.filter { it == '\t' || it == '\n' || it == '\r' || (it >= ' ' && it != '\uFFFE' && it != '\uFFFF') }
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun colName(i: Int): String {
        var n = i + 1; val sb = StringBuilder()
        while (n > 0) { val r = (n - 1) % 26; sb.insert(0, 'A' + r); n = (n - 1) / 26 }
        return sb.toString()
    }

    fun write(out: OutputStream, sheets: List<Pair<String, List<List<String>>>>) {
        ZipOutputStream(out).use { z ->
            fun put(n: String, s: String) { z.putNextEntry(ZipEntry(n)); z.write(s.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            val h = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
            put("[Content_Types].xml", h + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                sheets.indices.joinToString("") { "<Override PartName=\"/xl/worksheets/sheet${it + 1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" } +
                "</Types>")
            put("_rels/.rels", h + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
            put("xl/workbook.xml", h + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" " +
                "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>" +
                sheets.mapIndexed { i, s -> "<sheet name=\"${esc(s.first)}\" sheetId=\"${i + 1}\" r:id=\"rId${i + 1}\"/>" }.joinToString("") +
                "</sheets></workbook>")
            put("xl/_rels/workbook.xml.rels", h + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                sheets.indices.joinToString("") { "<Relationship Id=\"rId${it + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet${it + 1}.xml\"/>" } +
                "</Relationships>")
            sheets.forEachIndexed { i, (_, rows) ->
                val sb = StringBuilder(h).append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
                rows.forEachIndexed { r, row ->
                    sb.append("<row r=\"${r + 1}\">")
                    row.forEachIndexed { c, v ->
                        sb.append("<c r=\"${colName(c)}${r + 1}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(v)}</t></is></c>")
                    }
                    sb.append("</row>")
                }
                sb.append("</sheetData></worksheet>")
                put("xl/worksheets/sheet${i + 1}.xml", sb.toString())
            }
        }
    }
}
