package ru.marshrut

import okhttp3.Credentials
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Резервная копия на Яндекс Диске по WebDAV — без своего сервера, телефон говорит с Диском напрямую.
 * Вход: логин Яндекса и пароль приложения (id.yandex.ru → Безопасность → Пароли приложений → «Файлы»).
 * Обычный пароль от аккаунта Диск по WebDAV не принимает.
 * На Диске: папка «Маршрут» с базой и историей, в «Маршрут/Архив» — копия базы на каждый день.
 */
object Cloud {
    const val DIR = "Маршрут"
    const val DB = "marshrut_db.xlsx"
    const val HISTORY = "history.json"
    private const val ARCHIVE = "Архив"
    private val base = "https://webdav.yandex.ru".toHttpUrl()
    private val http = Net.http.newBuilder().callTimeout(90, TimeUnit.SECONDS).readTimeout(90, TimeUnit.SECONDS).build()
    private val BIN = "application/octet-stream".toMediaType()

    class AuthError : Exception("Яндекс не принял логин или пароль приложения")

    private fun auth(login: String, pass: String) = Credentials.basic(login, pass, Charsets.UTF_8)
    private fun url(vararg path: String): HttpUrl = base.newBuilder().apply { path.forEach { addPathSegment(it) } }.build()

    private fun call(auth: String, r: Request.Builder, ok: (Int) -> Boolean): ByteArray? =
        http.newCall(r.header("Authorization", auth).build()).execute().use { resp ->
            if (resp.code == 401 || resp.code == 403) throw AuthError()
            if (resp.code == 404) return null
            if (!ok(resp.code)) error("Яндекс Диск ответил кодом ${resp.code}")
            resp.body?.bytes()
        }

    /** 201 — папка создана, 405 — уже была. */
    private fun mkdir(auth: String, vararg path: String) {
        call(auth, Request.Builder().url(url(*path)).method("MKCOL", null)) { it == 201 || it == 405 }
    }

    private fun put(auth: String, data: ByteArray, vararg path: String) {
        call(auth, Request.Builder().url(url(*path)).put(data.toRequestBody(BIN))) { it in 200..299 }
            ?: error("Яндекс Диск не нашёл папку «${path.dropLast(1).joinToString("/")}»")
    }

    /** Кладёт файлы в «Маршрут»; если задан день — ещё и копию базы в архив под этой датой. */
    fun upload(login: String, pass: String, files: Map<String, ByteArray>, archiveDay: String?) {
        val a = auth(login, pass)
        mkdir(a, DIR)
        files.forEach { (name, data) -> put(a, data, DIR, name) }
        val dbData = files[DB]
        if (archiveDay != null && dbData != null) {
            mkdir(a, DIR, ARCHIVE)
            put(a, dbData, DIR, ARCHIVE, "$archiveDay $DB")
        }
    }

    /** Файл из папки «Маршрут» или null, если его там нет. */
    fun download(login: String, pass: String, name: String): ByteArray? =
        call(auth(login, pass), Request.Builder().url(url(DIR, name)).get()) { it == 200 }

    /** Понятный текст ошибки для экрана. */
    fun describe(e: Throwable): String = when (e) {
        is AuthError -> e.message!!
        is java.net.UnknownHostException, is java.net.ConnectException -> "Нет связи с Яндекс Диском — проверьте интернет"
        is java.net.SocketTimeoutException, is java.io.InterruptedIOException -> "Яндекс Диск долго не отвечает"
        else -> e.message ?: e.javaClass.simpleName
    }
}
