package ru.marshrut

import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Резервная копия на Яндекс Диске через REST API — без своего сервера, телефон говорит с Диском напрямую.
 * Вход по коду: приложение показывает код, пользователь вводит его на ya.ru/device и разрешает доступ.
 * Доступ только к папке приложения: Диск → Приложения → <имя приложения в Яндекс OAuth>.
 * Там база и история, в «Архив» — копия базы на каждый день.
 * ID и секрет приложения вшиваются при сборке из секретов GitHub (YANDEX_OAUTH_CLIENT_ID, YANDEX_OAUTH_CLIENT_SECRET).
 */
object Cloud {
    const val DB = "marshrut_db.xlsx"
    const val HISTORY = "history.json"
    private const val ARCHIVE = "Архив"
    private const val API = "https://cloud-api.yandex.net/v1/disk/resources"
    private const val OAUTH = "https://oauth.yandex.ru"
    private val http = Net.http.newBuilder().callTimeout(90, TimeUnit.SECONDS).readTimeout(90, TimeUnit.SECONDS).build()
    private val BIN = "application/octet-stream".toMediaType()

    private val clientId get() = BuildConfig.YANDEX_OAUTH_CLIENT_ID.trim()
    private val clientSecret get() = BuildConfig.YANDEX_OAUTH_CLIENT_SECRET.trim()
    val configured get() = clientId.isNotBlank() && clientSecret.isNotBlank()

    class AuthError : Exception("Вход в Яндекс устарел — войдите заново")
    class Tokens(val access: String, val refresh: String)
    class DeviceCode(val deviceCode: String, val userCode: String, val url: String, val interval: Int, val expiresIn: Int)

    // ---------- вход по коду ----------

    private fun oauth(path: String, form: FormBody): Pair<Int, JSONObject> =
        http.newCall(Request.Builder().url(OAUTH + path).post(form).build()).execute().use { r ->
            r.code to runCatching { JSONObject(r.body?.string().orEmpty()) }.getOrDefault(JSONObject())
        }

    private fun oauthError(j: JSONObject): String =
        j.optString("error_description").ifBlank { j.optString("error") }.ifBlank { "неизвестная ошибка" }

    fun deviceCode(): DeviceCode {
        val (code, j) = oauth("/device/code", FormBody.Builder().add("client_id", clientId).add("device_name", "Маршрут").build())
        if (code != 200) error("Яндекс не выдал код: ${oauthError(j)}")
        return DeviceCode(j.getString("device_code"), j.getString("user_code"),
            j.optString("verification_url").ifBlank { "https://ya.ru/device" }, j.optInt("interval", 5), j.optInt("expires_in", 300))
    }

    /** Токены, когда пользователь подтвердил вход, или null, пока ещё не подтвердил. */
    fun pollToken(deviceCode: String): Tokens? {
        val (code, j) = oauth("/token", FormBody.Builder().add("grant_type", "device_code").add("code", deviceCode)
            .add("client_id", clientId).add("client_secret", clientSecret).build())
        if (code == 200) return Tokens(j.getString("access_token"), j.optString("refresh_token"))
        if (j.optString("error") in setOf("authorization_pending", "slow_down")) return null
        error(oauthError(j))
    }

    private fun refresh(token: String): Tokens {
        val (code, j) = oauth("/token", FormBody.Builder().add("grant_type", "refresh_token").add("refresh_token", token)
            .add("client_id", clientId).add("client_secret", clientSecret).build())
        if (code != 200) throw AuthError()
        return Tokens(j.getString("access_token"), j.optString("refresh_token").ifBlank { token })
    }

    /** Запрос с токеном; если Яндекс его не принял — один раз обновляем токен и повторяем. */
    private fun <T> authed(st: Settings, block: (String) -> T): T = try {
        block(st.yaToken)
    } catch (e: AuthError) {
        if (st.yaRefresh.isBlank()) throw e
        val t = refresh(st.yaRefresh)
        st.yaToken = t.access; st.yaRefresh = t.refresh
        block(t.access)
    }

    // ---------- файлы ----------

    private fun endpoint(suffix: String, path: String, vararg q: Pair<String, String>): HttpUrl =
        (API + suffix).toHttpUrl().newBuilder().addQueryParameter("path", path)
            .apply { q.forEach { addQueryParameter(it.first, it.second) } }.build()

    private fun api(token: String, r: Request.Builder): Pair<Int, String> =
        http.newCall(r.header("Authorization", "OAuth $token").build()).execute().use { it.code to it.body?.string().orEmpty() }

    private fun fail(code: Int, body: String): Nothing {
        if (code == 401) throw AuthError()
        val msg = runCatching { JSONObject(body).let { it.optString("description").ifBlank { it.optString("message") } } }.getOrDefault("")
        error("Яндекс Диск ответил кодом $code" + if (msg.isNotBlank()) ": $msg" else "")
    }

    /** 201 — папка создана, 409 — уже была. */
    private fun mkdir(token: String, path: String) {
        val (c, b) = api(token, Request.Builder().url(endpoint("", path)).put(ByteArray(0).toRequestBody(null)))
        if (c != 201 && c != 409) fail(c, b)
    }

    private fun put(token: String, path: String, data: ByteArray) {
        val (c, b) = api(token, Request.Builder().url(endpoint("/upload", path, "overwrite" to "true")).get())
        if (c != 200) fail(c, b)
        val href = JSONObject(b).getString("href")
        http.newCall(Request.Builder().url(href).put(data.toRequestBody(BIN)).build()).execute().use {
            if (it.code !in 200..299) error("Загрузка на Яндекс Диск не удалась: код ${it.code}")
        }
    }

    /** Кладёт файлы в папку приложения; если задан день — ещё и копию базы в архив под этой датой. */
    fun upload(st: Settings, files: Map<String, ByteArray>, archiveDay: String?) = authed(st) { t ->
        // Папку приложения Диск обычно создаёт сам; если её ещё нет — создаём, ответ «уже есть» не ошибка
        runCatching { mkdir(t, "app:/") }
        files.keys.mapNotNull { it.substringBeforeLast('/', "").ifBlank { null } }.toSet().forEach { mkdir(t, "app:/$it") }
        files.forEach { (name, data) -> put(t, "app:/$name", data) }
        val dbData = files[DB]
        if (archiveDay != null && dbData != null) {
            mkdir(t, "app:/$ARCHIVE")
            put(t, "app:/$ARCHIVE/$archiveDay $DB", dbData)
        }
    }

    private fun get(token: String, path: String): ByteArray? {
        val (c, b) = api(token, Request.Builder().url(endpoint("/download", path)).get())
        if (c == 404) return null
        if (c != 200) fail(c, b)
        return http.newCall(Request.Builder().url(JSONObject(b).getString("href")).get().build()).execute().use {
            if (it.code != 200) error("Скачать с Яндекс Диска не удалось: код ${it.code}")
            it.body!!.bytes()
        }
    }

    /** Файл из папки приложения или null, если его там нет. */
    fun download(st: Settings, name: String): ByteArray? = authed(st) { t -> get(t, "app:/$name") }

    // ---------- общая база ----------
    /** Папка с общей базой внутри папки приложения владельца; открыта по публичной ссылке только для чтения. */
    const val SHARED_DIR = "Общая база"
    private const val SHARED_PATH = "app:/$SHARED_DIR/$DB"
    private const val PUBLIC = "https://cloud-api.yandex.net/v1/disk/public/resources"

    /** Владелец: создаёт папку общей базы и открывает её по ссылке. Повторный вызов отдаёт ту же ссылку. */
    fun publishShared(st: Settings): String = authed(st) { t ->
        runCatching { mkdir(t, "app:/") }
        mkdir(t, "app:/$SHARED_DIR")
        val path = "app:/$SHARED_DIR"
        val (c, b) = api(t, Request.Builder().url(endpoint("/publish", path)).put(ByteArray(0).toRequestBody(null)))
        if (c != 200) fail(c, b)
        val (c2, b2) = api(t, Request.Builder().url(endpoint("", path, "fields" to "public_url")).get())
        if (c2 != 200) fail(c2, b2)
        JSONObject(b2).optString("public_url").ifBlank { error("Яндекс не выдал ссылку") }
    }

    private fun publicUrl(suffix: String, url: String, vararg q: Pair<String, String>): HttpUrl =
        (PUBLIC + suffix).toHttpUrl().newBuilder().addQueryParameter("public_key", url).addQueryParameter("path", "/$DB")
            .apply { q.forEach { addQueryParameter(it.first, it.second) } }.build()

    private fun plain(u: HttpUrl): Pair<Int, String> =
        http.newCall(Request.Builder().url(u).get().build()).execute().use { it.code to it.body?.string().orEmpty() }

    /** Отпечаток общей базы по ссылке — меняется, когда редактор выложил новую версию. null — базы ещё нет. */
    fun publicMd5(url: String): String? {
        val (c, b) = plain(publicUrl("", url, "fields" to "md5"))
        if (c == 404) return null
        if (c != 200) fail(c, b)
        return JSONObject(b).optString("md5").ifBlank { null }
    }

    /** Общая база по ссылке — без входа и без права записи. */
    fun downloadPublic(url: String): ByteArray? {
        val (c, b) = plain(publicUrl("/download", url))
        if (c == 404) return null
        if (c != 200) fail(c, b)
        return http.newCall(Request.Builder().url(JSONObject(b).getString("href")).get().build()).execute().use {
            if (it.code != 200) error("Скачать общую базу не удалось: код ${it.code}")
            it.body!!.bytes()
        }
    }

    /** Редактор: общая база его ключом записи (ключ владельца). */
    fun downloadShared(token: String): ByteArray? = get(token, SHARED_PATH)

    /**
     * Выкладывает общую базу, только если там всё ещё та версия, что мы скачали (expected — её md5, null — файла не было).
     * false — другой редактор успел раньше: надо скачать заново и слить ещё раз.
     */
    fun uploadShared(token: String, data: ByteArray, expected: String?): Boolean {
        val (c, b) = api(token, Request.Builder().url(endpoint("", SHARED_PATH, "fields" to "md5")).get())
        val now = when (c) { 404 -> null; 200 -> JSONObject(b).optString("md5").ifBlank { null }; else -> fail(c, b) }
        if (now != expected) return false
        put(token, SHARED_PATH, data)
        return true
    }

    fun md5Of(data: ByteArray): String =
        java.security.MessageDigest.getInstance("MD5").digest(data).joinToString("") { "%02x".format(it) }

    /** Понятный текст ошибки для экрана. */
    fun describe(e: Throwable): String = when (e) {
        is AuthError -> e.message!!
        is java.net.UnknownHostException, is java.net.ConnectException -> "Нет связи с Яндексом — проверьте интернет"
        is java.net.SocketTimeoutException, is java.io.InterruptedIOException -> "Яндекс долго не отвечает"
        else -> e.message ?: e.javaClass.simpleName
    }
}
