package ru.marshrut

import androidx.compose.runtime.mutableStateListOf

/**
 * Черновик базы для полного редактирования (только редактор): правки копятся здесь
 * и применяются к базе одним разом при выходе из редактора — тогда же уходят в облако.
 * Позывной привязан к карточке точки (owner), а не к коду, поэтому у новой точки позывные
 * можно добавлять сразу, а смена кода их не теряет.
 */
class DbDraft {
    /** Точка: orig — код, под которым она была в базе (null — новая); координаты — строкой, как вводит человек. */
    data class P(val key: Int, val orig: String?, val name: String, val title: String, val address: String, val coords: String, val comment: String) {
        val display get() = title.ifBlank { name }
    }
    /** Позывной: owner — ключ точки; null — позывной ведёт на код point, которого нет в базе. */
    data class C(val key: Int, val callsign: String, val owner: Int?, val point: String = "")
    class Built(val points: List<Point>, val calls: Map<String, String>)

    val points = mutableStateListOf<P>()
    val calls = mutableStateListOf<C>()
    private var next = 0

    fun load(db: Db) {
        points.clear(); calls.clear(); next = 0
        db.points.forEach { points.add(P(next++, it.name, it.name, it.title, it.address, if (it.hasCoords) "${it.lat}, ${it.lon}" else "", it.comment)) }
        val byName = points.associateBy { it.name }
        db.calls.forEach { (cs, p) -> calls.add(C(next++, cs, byName[p]?.key, p)) }
    }

    fun update(p: P) { val i = points.indexOfFirst { it.key == p.key }; if (i >= 0) points[i] = p }
    fun update(c: C) { val i = calls.indexOfFirst { it.key == c.key }; if (i >= 0) calls[i] = c }
    fun addPoint(): P = P(next++, null, "", "", "", "", "").also { points.add(0, it) }
    fun addCall(p: P): C = C(next++, "", p.key).also { calls.add(it) }
    fun removeCall(c: C) { calls.removeAll { it.key == c.key } }
    /** Удаляет точку вместе с её позывными. */
    fun remove(p: P) {
        points.removeAll { it.key == p.key }
        calls.removeAll { it.owner == p.key }
    }

    fun callsOf(p: P) = calls.filter { it.owner == p.key }
    /** Позывные, которые ведут на несуществующую точку. */
    fun orphans() = calls.filter { it.owner == null }
    fun pointOf(c: C) = c.owner?.let { k -> points.firstOrNull { it.key == k } }
    /** Привязать позывной без точки к точке с этим кодом, если такая есть. */
    fun attach(c: C, code: String) {
        val p = points.firstOrNull { it.name.trim().equals(code.trim(), ignoreCase = true) }
        update(c.copy(owner = p?.key, point = code))
    }
    /** Тот же позывной у другой точки (для подсказки «будет перенесён»). */
    fun sameSign(c: C, norm: (String) -> String): C? {
        val k = norm(c.callsign.trim()); if (k.isEmpty()) return null
        return calls.firstOrNull { it.key != c.key && it.owner != c.owner && norm(it.callsign.trim()) == k }
    }

    /** Итог правок или текст первой ошибки. Одинаковый позывной у двух точек остаётся у той, где его вписали последним. */
    fun build(norm: (String) -> String): Pair<Built?, String?> {
        val out = ArrayList<Point>()
        val names = HashMap<Int, String>()
        val seen = HashSet<String>()
        for (p in points) {
            val name = p.name.trim()
            if (name.isEmpty()) return null to "У точки «${p.display.ifBlank { p.address }.ifBlank { "новая" }}» пустой код"
            if (!seen.add(name)) return null to "Код «$name» повторяется у двух точек"
            val c = if (p.coords.isBlank()) 0.0 to 0.0 else parseCoords(p.coords)
                ?: return null to "У точки «$name» не распознаны координаты: «${p.coords}»"
            if (c.first !in -90.0..90.0 || c.second !in -180.0..180.0) return null to "У точки «$name» координаты вне карты: «${p.coords}»"
            names[p.key] = name
            out.add(Point(name, p.address.trim(), c.first, c.second, p.title.trim(), p.comment.trim()))
        }
        val cs = LinkedHashMap<String, String>()
        for (c in calls) {
            val sign = c.callsign.trim()
            if (sign.isEmpty()) continue
            val point = c.owner?.let { names[it] } ?: c.point.trim()
            if (point !in seen) return null to "Позывной «$sign» ведёт на точку «$point», которой нет"
            cs.remove(norm(sign)); cs[norm(sign)] = point
        }
        return Built(out, cs) to null
    }

    companion object {
        /** «44.581956, 34.343381» из Яндекс Карт, а также с запятой в дробях и без пробела. */
        fun parseCoords(s: String): Pair<Double, Double>? {
            val n = Regex("-?\\d+[.,]\\d+").findAll(s).map { it.value.replace(',', '.').toDouble() }.toList()
            return if (n.size >= 2) n[0] to n[1] else null
        }
    }
}
