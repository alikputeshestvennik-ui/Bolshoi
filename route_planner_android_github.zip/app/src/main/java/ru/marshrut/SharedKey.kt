package ru.marshrut

import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Строка общей базы из секрета сборки SHARED_DB: публичная ссылка на базу (читать может любой телефон)
 * и ключ записи на Диск владельца, зашифрованный паролем редактора. Без пароля ключ не достать.
 * Формат: v1|ссылка|соль|iv|шифр (всё, кроме версии, в base64).
 */
object SharedKey {
    class Parsed(val url: String, val salt: ByteArray, val iv: ByteArray, val cipher: ByteArray)

    private val enc = Base64.getUrlEncoder().withoutPadding()
    private val dec = Base64.getUrlDecoder()

    fun parse(s: String): Parsed? = runCatching {
        val p = s.trim().split('|')
        if (p.size != 5 || p[0] != "v1") return null
        Parsed(String(dec.decode(p[1]), Charsets.UTF_8), dec.decode(p[2]), dec.decode(p[3]), dec.decode(p[4]))
    }.getOrNull()

    private fun key(password: String, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password.trim().toCharArray(), salt, 120_000, 256)
        val raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return SecretKeySpec(raw, "AES")
    }

    fun make(url: String, token: String, password: String): String {
        val rnd = SecureRandom()
        val salt = ByteArray(16).also(rnd::nextBytes)
        val iv = ByteArray(12).also(rnd::nextBytes)
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key(password, salt), GCMParameterSpec(128, iv)) }
        val ct = c.doFinal(token.toByteArray(Charsets.UTF_8))
        return listOf("v1", enc.encodeToString(url.toByteArray(Charsets.UTF_8)), enc.encodeToString(salt), enc.encodeToString(iv), enc.encodeToString(ct))
            .joinToString("|")
    }

    /** Ключ записи или null, если пароль неверный. Долго (~0,5 с) — вызывать не в главном потоке. */
    fun unlock(p: Parsed, password: String): String? = runCatching {
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, key(password, p.salt), GCMParameterSpec(128, p.iv)) }
        String(c.doFinal(p.cipher), Charsets.UTF_8)
    }.getOrNull()
}
