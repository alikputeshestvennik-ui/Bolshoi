package ru.marshrut

import kotlin.math.max

/**
 * Порядок объезда. Стоимость ноги = расстояние * (1 + ALPHA * текущая загрузка / вместимость)
 *  — тяжёлый груз «дороже» возить, поэтому тяжёлые точки стремятся в начало.
 * Штраф за сквозной проезд: если по пути a→b проезжаем мимо ещё не посещённой точки x
 *  (объезд через x почти не удлиняет путь), нога получает штраф.
 * Узлы: 0..n-1 — точки; если задан склад, он последний (индекс n) и всегда первый в маршруте.
 */
class Optimizer(private val d: Array<DoubleArray>, private val w: DoubleArray, private val cap: Double, private val fixedStart: Int?) {
    private val n = d.size
    private val total = w.sum()
    private val alpha = 0.6
    private val ref = max(cap, total).coerceAtLeast(1.0)

    fun cost(o: IntArray): Double {
        var load = total; var c = 0.0
        for (i in 0 until o.size - 1) {
            val a = o[i]; val b = o[i + 1]
            load -= w[a]
            val f = 1 + alpha * max(load, 0.0) / ref
            var leg = d[a][b] * f
            for (k in i + 2 until o.size) {
                val x = o[k]
                if (d[a][x] + d[x][b] < 1.1 * d[a][b]) leg += 0.5 * d[a][b] * f
            }
            c += leg
        }
        return c
    }

    private fun greedy(start: Int): IntArray {
        val left = (0 until n).filter { it != start }.toMutableList()
        val o = arrayListOf(start); var load = total - w[start]
        while (left.isNotEmpty()) {
            val a = o.last(); val f = 1 + alpha * max(load, 0.0) / ref
            val b = left.minBy { d[a][it] * f - 0.15 * w[it] / ref * d[a][it] }
            left.remove(b); o.add(b); load -= w[b]
        }
        return o.toIntArray()
    }

    private fun improve(start: IntArray): IntArray {
        var best = start; var bc = cost(best); var better = true; var guard = 0
        val lo = if (fixedStart != null) 1 else 0
        while (better && guard++ < 60) {
            better = false
            for (i in lo until n - 1) for (j in i + 1 until n) { // 2-opt
                val c = best.copyOf(); var a = i; var b = j
                while (a < b) { val t = c[a]; c[a] = c[b]; c[b] = t; a++; b-- }
                val cc = cost(c); if (cc < bc - 1e-6) { best = c; bc = cc; better = true }
            }
            for (i in lo until n) for (j in lo until n) { // or-opt: переставить одну точку
                if (i == j) continue
                val l = best.toMutableList(); val v = l.removeAt(i); l.add(j, v)
                val c = l.toIntArray(); val cc = cost(c); if (cc < bc - 1e-6) { best = c; bc = cc; better = true }
            }
        }
        return best
    }

    fun solve(): IntArray {
        if (n <= 2) return IntArray(n) { it }
        if (fixedStart != null) return improve(greedy(fixedStart))
        var best: IntArray? = null; var bc = Double.MAX_VALUE
        val step = max(1, n / 8)
        for (s in 0 until n step step) { val r = improve(greedy(s)); val c = cost(r); if (c < bc) { bc = c; best = r } }
        return best!!
    }

    fun distance(o: IntArray): Double { var s = 0.0; for (i in 0 until o.size - 1) s += d[o[i]][o[i + 1]]; return s }
}
