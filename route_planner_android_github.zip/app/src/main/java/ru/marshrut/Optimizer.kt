package ru.marshrut

import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * Оптимизация порядка объезда «как у опытного водителя».
 *
 * Стоимость маршрута (в условных секундах):
 *  1. Время в пути по дорогам (OSRM, матрица асимметрична — учитываются односторонние улицы)
 *     + небольшой вес километража (топливо).
 *  2. Груз: каждая нога дороже, пока кузов полный — тяжёлые выгрузки тяготеют к началу.
 *  3. «Проехал мимо»: если по пути a→b мы проезжаем рядом с ещё не посещённой точкой x
 *     (заезд почти не удлиняет путь), — штраф. Живой водитель не проезжает мимо своей точки.
 *  4. «Соседи вместе»: точки в пределах ~250 м друг от друга должны идти подряд.
 *  5. «Без петель»: самопересечения маршрута на карте штрафуются — человек не рисует восьмёрки.
 *  7. «Без разворотов на трассе»: к точке на широкой дороге не заезжаем «туда и обратно» — разворот грузовика
 *     там означает доехать до развязки; точки на трассе ставятся туда, где трасса проходится насквозь.
 *  8. «Своя сторона трассы»: магазин на трассе обслуживается, когда едем так, что он справа
 *     (сторону дороги определяет сервер дорог — куда «прижимается» точка).
 *  6. «Не в гору гружёным»: набор высоты по дороге, умноженный на вес в кузове, — сначала выгружаемся,
 *     потом поднимаемся (спуск к магазину и подъём обратно на ЮБШ с тонной — в конец, когда кузов пуст).
 *
 * Поиск: несколько стартовых решений (ближайший сосед, вставка с сожалением, вставка дальнего),
 * затем локальный поиск (Or-opt 1–3 с разворотом, 2-opt, обмен) и итеративный поиск с «встряской»
 * (double-bridge) в пределах бюджета времени. Для ≤ 8 точек — полный перебор.
 *
 * start — откуда выезжаем (склад или текущее место), end — где заканчиваем (склад). Могут совпадать.
 */
class Optimizer(
    private val dur: Array<DoubleArray>,
    private val dist: Array<DoubleArray>,
    private val lat: DoubleArray,
    private val lon: DoubleArray,
    private val w: DoubleArray,
    cap: Double,
    private val start: Int?,
    private val end: Int?,
    private val budgetMs: Long = 2500,
    private val mode: Mode = Mode.HUMAN,
    /** Крайний срок приезда в секундах от старта (NaN — без ограничения). Например, субботний «приём до 13:00». */
    private val deadline: DoubleArray? = null,
    private val serviceSec: Double = 420.0,
    /** Подъём по дороге из i в j, м (null — рельеф неизвестен). */
    private val climb: Array<DoubleArray>? = null,
    /** Точка на широкой дороге (трасса, магистраль): развернуться там с грузовиком — заезд до развязки. */
    private val wide: BooleanArray? = null,
    /**
     * Направление, в котором магазин на трассе оказывается справа (восток +x, север +y); (0,0) — неизвестно.
     * Подъехать или уехать против него — проехать мимо, развернуться на развязке и вернуться.
     */
    private val headX: DoubleArray? = null,
    private val headY: DoubleArray? = null
) {
    enum class Mode { HUMAN, FAST, HEAVY }
    private val human = mode != Mode.FAST

    private val clients: IntArray = (0 until dur.size).filter { it != start && it != end }.toIntArray()
    private val n = clients.size
    private val total = clients.sumOf { w[it] }
    private val ref = max(cap, total).coerceAtLeast(1.0)
    // груз: в «человеческом» режиме — лёгкий тай-брейкер, иначе маршрут «скачет» за тяжёлыми точками
    private val alpha = when (mode) { Mode.HUMAN -> 0.12; Mode.FAST -> 0.0; Mode.HEAVY -> 0.7 }
    private val kmWeight = if (mode == Mode.FAST) 0.0 else 25.0 // секунд за километр
    /**
     * Подъём с грузом: секунд «цены» за каждый метр в гору на каждую тонну в кузове. Крутой спуск к магазину
     * и подъём обратно с тонной на Транзите — то, чего опытный водитель избегает: выгружается до подъёма.
     */
    private val climbWeight = if (mode == Mode.FAST || climb == null) 0.0 else 5.0

    // Локальная проекция в метры для геометрии
    private val x: DoubleArray
    private val y: DoubleArray
    private val near = ArrayList<IntArray>() // пары соседних точек

    init {
        val lat0 = clients.map { lat[it] }.average().takeIf { !it.isNaN() } ?: 0.0
        val k = Math.cos(Math.toRadians(lat0)) * 111320.0
        x = DoubleArray(dur.size) { lon[it] * k }
        y = DoubleArray(dur.size) { lat[it] * 110540.0 }
        for (i in 0 until n) for (j in i + 1 until n) {
            val a = clients[i]; val b = clients[j]
            val dx = x[a] - x[b]; val dy = y[a] - y[b]
            if (dx * dx + dy * dy < 250.0 * 250.0) near.add(intArrayOf(a, b))
        }
    }

    private fun far(a: Int, b: Int): Double { val dx = x[a] - x[b]; val dy = y[a] - y[b]; return Math.sqrt(dx * dx + dy * dy) }

    private fun leg(a: Int, b: Int) = dur[a][b] + dist[a][b] / 1000.0 * kmWeight

    private fun seq(o: IntArray): IntArray {
        val l = ArrayList<Int>(o.size + 2)
        if (start != null) l.add(start)
        o.forEach { l.add(it) }
        if (end != null) l.add(end)
        return l.toIntArray()
    }

    private fun ccw(ax: Double, ay: Double, bx: Double, by: Double, cx: Double, cy: Double) =
        (cy - ay) * (bx - ax) > (by - ay) * (cx - ax)

    private fun crosses(a: Int, b: Int, c: Int, d: Int): Boolean {
        if (a == c || a == d || b == c || b == d) return false
        return ccw(x[a], y[a], x[c], y[c], x[d], y[d]) != ccw(x[b], y[b], x[c], y[c], x[d], y[d]) &&
            ccw(x[a], y[a], x[b], y[b], x[c], y[c]) != ccw(x[a], y[a], x[b], y[b], x[d], y[d])
    }

    private val pos = IntArray(dur.size)

    fun cost(o: IntArray): Double {
        val s = seq(o)
        var load = total; var c = 0.0; var t = 0.0
        for (i in 0 until s.size - 1) {
            val a = s[i]; val b = s[i + 1]
            t += dur[a][b]
            if (deadline != null && b != start && b != end) {
                val dl = deadline[b]
                if (!dl.isNaN() && t > dl) c += 1800.0 + (t - dl) * 4.0
                t += serviceSec
            }
            if (a != start && a != end) load -= w[a]
            val f = 1 + alpha * max(load, 0.0) / ref
            val base = leg(a, b)
            var l = base * f
            if (climbWeight > 0) l += climb!![a][b] * max(load, 0.0) / 1000.0 * climbWeight
            // проехал мимо своей точки
            val db = dur[a][b]
            if (human) for (k in i + 2 until s.size) {
                val xk = s[k]; if (xk == start || xk == end) continue
                // заезд в x по пути почти бесплатен, а мы его откладываем — так живой водитель не делает
                val detour = dur[a][xk] + dur[xk][b] - db
                if (detour < max(20.0, 0.06 * db)) l += 90.0
            }
            c += l
        }
        // Разворот на широкой дороге: приехали к точке на трассе и уезжаем почти обратно (заехали «туда и назад»).
        // Соседние точки (ближе 300 м, например ЮБШ 13 и 13д) считаем одной остановкой
        if (human && wide != null) for (i in 1 until s.size - 1) {
            val b = s[i]; if (!wide[b]) continue
            var p = i - 1; while (p > 0 && far(s[p], b) < 300.0) p--
            var q = i + 1; while (q < s.size - 1 && far(s[q], b) < 300.0) q++
            val a = s[p]; val cc = s[q]
            if (far(a, b) < 300.0 || far(b, cc) < 300.0) continue
            val ux = x[b] - x[a]; val uy = y[b] - y[a]; val vx = x[cc] - x[b]; val vy = y[cc] - y[b]
            val cos = (ux * vx + uy * vy) / (Math.sqrt(ux * ux + uy * uy) * Math.sqrt(vx * vx + vy * vy))
            if (cos < -0.7) c += 600.0
        }
        // Магазин на трассе — со своей стороны: ЮБШ 32 справа по ходу на восток, ЮБШ 13 — по ходу на запад.
        // Приехали или уехали против этого направления — значит, разворот на развязке
        if (headX != null && headY != null) for (i in 1 until s.size - 1) {
            val b = s[i]; val hx = headX[b]; val hy = headY[b]
            if (hx == 0.0 && hy == 0.0) continue
            var p = i - 1; while (p > 0 && far(s[p], b) < 300.0) p--
            var q = i + 1; while (q < s.size - 1 && far(s[q], b) < 300.0) q++
            val a = s[p]; val cc = s[q]
            val ax = x[b] - x[a]; val ay = y[b] - y[a]; val al = Math.sqrt(ax * ax + ay * ay)
            if (al > 300.0 && ax * hx + ay * hy < -0.2 * al) c += 600.0
            val dx = x[cc] - x[b]; val dy = y[cc] - y[b]; val dl = Math.sqrt(dx * dx + dy * dy)
            if (dl > 300.0 && dx * hx + dy * hy < -0.2 * dl) c += 600.0
        }
        // соседи не подряд
        if (human && near.isNotEmpty()) {
            for (i in s.indices) pos[s[i]] = i
            for (p in near) if (kotlin.math.abs(pos[p[0]] - pos[p[1]]) != 1) c += 120.0
        }
        // самопересечения
        if (human) for (i in 0 until s.size - 1) for (j in i + 2 until s.size - 1)
            if (crosses(s[i], s[i + 1], s[j], s[j + 1])) c += 120.0
        return c
    }

    fun distance(o: IntArray): Double { val s = seq(o); var d = 0.0; for (i in 0 until s.size - 1) d += dist[s[i]][s[i + 1]]; return d }
    fun duration(o: IntArray): Double { val s = seq(o); var d = 0.0; for (i in 0 until s.size - 1) d += dur[s[i]][s[i + 1]]; return d }

    // ---------- стартовые решения ----------
    private fun nearest(first: Int?): IntArray {
        val left = clients.toMutableList(); val o = ArrayList<Int>()
        var cur = start ?: first ?: clients[0]
        if (start == null) { left.remove(cur); o.add(cur) }
        var load = total - if (start == null) w[cur] else 0.0
        while (left.isNotEmpty()) {
            val f = 1 + alpha * max(load, 0.0) / ref
            val c = cur
            val b = left.minBy { leg(c, it) * f - 0.2 * w[it] / ref * leg(c, it) }
            left.remove(b); o.add(b); load -= w[b]; cur = b
        }
        return o.toIntArray()
    }

    /** Вставка с сожалением (regret-2) по чистому времени. */
    private fun regret(): IntArray {
        val left = clients.toMutableList(); val o = ArrayList<Int>()
        val seed = if (start != null) left.maxBy { dur[start][it] } else left.maxBy { a -> left.sumOf { dur[a][it] } }
        o.add(seed); left.remove(seed)
        fun insCost(v: Int, p: Int): Double {
            val prev = if (p == 0) start else o[p - 1]
            val next = if (p == o.size) end else o[p]
            var c = 0.0
            if (prev != null) c += leg(prev, v)
            if (next != null) c += leg(v, next)
            if (prev != null && next != null) c -= leg(prev, next)
            return c
        }
        while (left.isNotEmpty()) {
            var bestV = -1; var bestP = 0; var bestR = -Double.MAX_VALUE
            for (v in left) {
                var c1 = Double.MAX_VALUE; var c2 = Double.MAX_VALUE; var p1 = 0
                for (p in 0..o.size) {
                    val c = insCost(v, p)
                    if (c < c1) { c2 = c1; c1 = c; p1 = p } else if (c < c2) c2 = c
                }
                val r = (if (c2 == Double.MAX_VALUE) 0.0 else c2 - c1) - 0.001 * c1
                if (r > bestR) { bestR = r; bestV = v; bestP = p1 }
            }
            o.add(bestP, bestV); left.remove(bestV)
        }
        return o.toIntArray()
    }

    // ---------- локальный поиск ----------
    private fun localSearch(start: IntArray, deadline: Long): Pair<IntArray, Double> {
        var best = start.copyOf(); var bc = cost(best)
        var improved = true
        while (improved && System.currentTimeMillis() < deadline) {
            improved = false
            // Or-opt: перенос отрезка длиной 1..3 (с разворотом и без)
            loop@ for (len in 1..3) {
                for (i in 0..n - len) {
                    for (j in 0..n - len) {
                        if (j == i) continue
                        for (rev in 0..1) {
                            if (rev == 1 && len == 1) continue
                            val c = moveSeg(best, i, len, j, rev == 1)
                            val cc = cost(c)
                            if (cc < bc - 1e-6) { best = c; bc = cc; improved = true; continue@loop }
                        }
                    }
                }
            }
            if (improved) continue
            // 2-opt
            for (i in 0 until n - 1) for (j in i + 1 until n) {
                val c = best.copyOf(); var a = i; var b = j
                while (a < b) { val t = c[a]; c[a] = c[b]; c[b] = t; a++; b-- }
                val cc = cost(c); if (cc < bc - 1e-6) { best = c; bc = cc; improved = true }
            }
            if (improved) continue
            // обмен двух точек
            for (i in 0 until n - 1) for (j in i + 1 until n) {
                val c = best.copyOf(); val t = c[i]; c[i] = c[j]; c[j] = t
                val cc = cost(c); if (cc < bc - 1e-6) { best = c; bc = cc; improved = true }
            }
        }
        return best to bc
    }

    private fun moveSeg(o: IntArray, i: Int, len: Int, j: Int, reverse: Boolean): IntArray {
        val l = o.toMutableList()
        val seg = ArrayList<Int>(len); repeat(len) { seg.add(l.removeAt(i)) }
        if (reverse) seg.reverse()
        l.addAll(min(j, l.size), seg)
        return l.toIntArray()
    }

    private fun doubleBridge(o: IntArray, r: Random): IntArray {
        if (n < 8) { // маленький маршрут — случайный разворот отрезка
            val c = o.copyOf(); var a = r.nextInt(n); var b = r.nextInt(n); if (a > b) { val t = a; a = b; b = t }
            while (a < b) { val t = c[a]; c[a] = c[b]; c[b] = t; a++; b-- }
            return c
        }
        val p = (1 until n).shuffled(r).take(3).sorted()
        val a = o.copyOfRange(0, p[0]); val b = o.copyOfRange(p[0], p[1]); val c = o.copyOfRange(p[1], p[2]); val d = o.copyOfRange(p[2], n)
        return a + c + b + d
    }

    private fun exhaustive(): IntArray {
        var best = clients.copyOf(); var bc = cost(best)
        val a = clients.copyOf()
        fun permute(k: Int) {
            if (k == n) { val c = cost(a); if (c < bc) { bc = c; best = a.copyOf() }; return }
            for (i in k until n) {
                var t = a[k]; a[k] = a[i]; a[i] = t
                permute(k + 1)
                t = a[k]; a[k] = a[i]; a[i] = t
            }
        }
        permute(0)
        return best
    }

    fun solve(): IntArray {
        if (n <= 1) return clients.copyOf()
        if (n <= 8) return exhaustive()
        val deadline = System.currentTimeMillis() + budgetMs
        val starts = ArrayList<IntArray>()
        starts.add(regret())
        if (start != null) starts.add(nearest(null))
        else { val step = max(1, n / 6); for (s in 0 until n step step) starts.add(nearest(clients[s])) }
        var best: IntArray? = null; var bc = Double.MAX_VALUE
        val localDeadline = System.currentTimeMillis() + budgetMs / 2
        for (s in starts) {
            if (best != null && System.currentTimeMillis() > localDeadline) break
            val (o, c) = localSearch(s, deadline)
            if (c < bc) { bc = c; best = o }
        }
        var cur = best!!; var cc = bc
        val r = Random(42)
        while (System.currentTimeMillis() < deadline) {
            val (o, c) = localSearch(doubleBridge(cur, r), deadline)
            if (c < cc * 1.002) { cur = o; cc = c }
            if (c < bc - 1e-6) { best = o; bc = c }
        }
        return best!!
    }
}
