package ru.marshrut

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

fun dial(ctx: android.content.Context, phone: String) {
    runCatching { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone.filter { it.isDigit() || it == '+' })).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

class MainActivity : ComponentActivity() {
    private val vm: AppVm by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App(vm) } }
    }
}

@Composable
fun App(vm: AppVm) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { l ->
        if (l.isNotEmpty()) { vm.uris.clear(); vm.uris.addAll(l) }
    }
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importDb) }
    val exp = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { it?.let(vm::exportDb) }

    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().imePadding().padding(12.dp)) {
            if (vm.busy != null) { LinearProgressIndicator(Modifier.fillMaxWidth()); Text(vm.busy!!, Modifier.padding(vertical = 6.dp)) }
            vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 6.dp)) }
            when (vm.screen) {
                "home" -> Home(vm, { pick.launch(arrayOf("image/*", "application/pdf")) }, { imp.launch(arrayOf("*/*")) }, { exp.launch("marshrut_db.xlsx") })
                "settings" -> SettingsScreen(vm)
                "review" -> Review(vm)
                "match" -> Match(vm)
                "result" -> Result(vm)
            }
        }
    }
}

@Composable
fun Home(vm: AppVm, onPick: () -> Unit, onImp: () -> Unit, onExp: () -> Unit) {
    @Suppress("UNUSED_VARIABLE") val v = vm.dbVer
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Маршрут", fontSize = 28.sp)
        Text("Прикрепите 2–4 страницы маршрутного листа (фото, скан или PDF).")
        Button(onPick, Modifier.fillMaxWidth()) { Text("Выбрать сканы") }
        Text("Выбрано файлов: ${vm.uris.size}")
        Button(vm::recognize, Modifier.fillMaxWidth(), enabled = vm.uris.isNotEmpty() && vm.busy == null) { Text("Распознать") }
        HorizontalDivider()
        Text("База: точек ${vm.db.points.size}, позывных ${vm.db.calls.size}")
        OutlinedButton(onImp, Modifier.fillMaxWidth()) { Text("Импорт БД (.xlsx: «Точки», «Позывные»)") }
        OutlinedButton(onExp, Modifier.fillMaxWidth()) { Text("Экспорт БД") }
        OutlinedButton({ vm.screen = "settings" }, Modifier.fillMaxWidth()) { Text("Настройки") }
    }
}

@Composable
fun SettingsScreen(vm: AppVm) {
    val st = vm.st
    var key by remember { mutableStateOf(st.apiKey) }
    var folder by remember { mutableStateOf(st.folder) }
    var model by remember { mutableStateOf(st.model) }
    var osrm by remember { mutableStateOf(st.osrm) }
    var depot by remember { mutableStateOf(st.depot) }
    var cap by remember { mutableStateOf(st.capacity) }
    var wc by remember { mutableStateOf(st.withClient) }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Настройки", fontSize = 24.sp)
        OutlinedTextField(key, { key = it }, label = { Text("API-ключ Yandex AI Studio") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(folder, { folder = it }, label = { Text("ID каталога (folder id)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(model, { model = it }, label = { Text("Модель (URI из консоли)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(osrm, { osrm = it }, label = { Text("Адрес OSRM") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(depot, { depot = it }, label = { Text("Старт (широта, долгота), можно пусто") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(cap, { cap = it }, label = { Text("Вместимость кузова, кг") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Switch(wc, { wc = it })
            Text("  Читать клиента и адрес (удобно для новых точек, но дольше)", Modifier.weight(1f), fontSize = 14.sp)
        }
        Button({
            st.withClient = wc; st.apiKey = key; st.folder = folder; st.model = model; st.osrm = osrm; st.depot = depot; st.capacity = cap
            vm.screen = "home"
        }, Modifier.fillMaxWidth()) { Text("Сохранить") }
    }
}

@Composable
fun ColumnScope.Review(vm: AppVm) {
    var open by remember { mutableStateOf<Int?>(null) }
    Text("Проверьте распознанное", fontSize = 22.sp)
    val ctx = LocalContext.current
    var agOpen by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { agOpen = !agOpen }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(12.dp).heightIn(max = 280.dp).verticalScroll(rememberScrollState())) {
            Text("Агенты (титульный лист): " + vm.agents.joinToString("; ") { "${it.num} ${it.name}".trim() }.ifBlank { "нет" }, fontSize = 14.sp)
            if (agOpen) {
                vm.agents.forEachIndexed { i, a ->
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedTextField(a.num, { vm.agents[i] = a.copy(num = it) }, label = { Text("№") }, modifier = Modifier.width(64.dp), singleLine = true)
                        OutlinedTextField(a.name, { vm.agents[i] = a.copy(name = it) }, label = { Text("Имя") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    OutlinedTextField(a.phone, { vm.agents[i] = a.copy(phone = it) }, label = { Text("Телефон") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Row {
                        if (a.phone.isNotBlank()) TextButton({ dial(ctx, a.phone) }) { Text("Позвонить") }
                        TextButton({ vm.agents.removeAt(i) }) { Text("Удалить") }
                    }
                }
                TextButton({ vm.agents.add(Agent()) }) { Text("+ агент") }
            }
        }
    }
    if (vm.header.isNotBlank()) Text(vm.header, fontSize = 12.sp, color = Color.Gray)
    val sum = vm.rows.sumOf { it.weight }
    val tot = listOfNotNull(vm.total, vm.totalNoSg)
    if (tot.isNotEmpty()) {
        val ok = tot.any { kotlin.math.abs(it - sum) < 0.5 }
        Text("Σ вес строк: ${fmt(sum)} · по «ИТОГО ВЕС»: ${tot.joinToString(" / ") { fmt(it) }}" + if (ok) " ✓" else " — не сходится, проверьте веса",
            fontSize = 13.sp, color = if (ok) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error)
    }
    TextButton({ vm.sortByAgent = !vm.sortByAgent }) { Text(if (vm.sortByAgent) "Сортировка: по имени агента" else "Сортировка: как в листе") }
    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        val shown = if (vm.sortByAgent) vm.rows.sortedWith(compareBy({ vm.agentFor(it.agent)?.name ?: "яяя" }, { it.callsign })) else vm.rows.toList()
        items(shown, key = { it.id }) { r ->
            Card(
                Modifier.fillMaxWidth().clickable { open = if (open == r.id) null else r.id },
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(r.callsign.ifBlank { "(пусто)" }, fontSize = 18.sp)
                    if (vm.sortByAgent) Text(vm.agentFor(r.agent)?.name?.ifBlank { null } ?: "агент не найден", fontSize = 12.sp, color = Color.Gray)
                    if (open == r.id) {
                        var w by remember(r.id) { mutableStateOf(fmt(r.weight)) }
                        OutlinedTextField(r.callsign, { vm.update(r.copy(callsign = it)) }, label = { Text("Позывной") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(w, { w = it; vm.update(r.copy(weight = it.toD() ?: 0.0)) }, label = { Text("Вес") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(r.fact, { vm.update(r.copy(fact = it)) }, label = { Text("Факт") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(r.calc, { vm.update(r.copy(calc = it)) }, label = { Text("Расчет") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(r.client, { vm.update(r.copy(client = it)) }, label = { Text("Клиент") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(r.address, { vm.update(r.copy(address = it)) }, label = { Text("Адрес") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(r.agent, { vm.update(r.copy(agent = it)) }, label = { Text("Агент (№ до «/»)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(r.invoice, { vm.update(r.copy(invoice = it)) }, label = { Text("Накладная (АСП-…, возврат, оборудование)") }, modifier = Modifier.fillMaxWidth())
                        vm.contactsOf(r).forEach { a -> if (a.phone.isNotBlank()) TextButton({ dial(ctx, a.phone) }) { Text("Позвонить: ${a.name.ifBlank { a.num }}") } }
                        if (r.extra.isNotBlank()) Text(r.extra, fontSize = 12.sp, color = Color.Gray)
                        TextButton({ vm.delRow(r.id) }) { Text("Удалить строку") }
                    }
                }
            }
        }
    }
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton({ vm.addRow() }, Modifier.weight(1f)) { Text("+ строка") }
        Button({ vm.startMatch() }, Modifier.weight(2f), enabled = vm.rows.isNotEmpty() && vm.busy == null) { Text("Далее: точки") }
    }
    TextButton({ vm.screen = "home" }) { Text("Назад") }
}

@Composable
fun Match(vm: AppVm) {
    @Suppress("UNUSED_VARIABLE") val v = vm.dbVer
    val rowId = vm.queue.getOrNull(vm.qi) ?: return
    val r = vm.rows.firstOrNull { it.id == rowId } ?: return
    var q by remember(rowId) { mutableStateOf(r.client.trim().split(" ").firstOrNull().orEmpty()) }
    var creating by remember(rowId) { mutableStateOf(false) }
    val ctx = LocalContext.current
    val suspicious = vm.manual(r)
    val suggested = if (r.callsign.isBlank()) null else vm.db.pointFor(r.callsign)
    val hits = vm.db.points.filter { q.isBlank() || it.name.contains(q, true) || it.address.contains(q, true) || it.title.contains(q, true) }.take(8)
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Строка ${vm.qi + 1} из ${vm.queue.size}", color = Color.Gray)
        Text(r.callsign.ifBlank { "(без позывного)" }, fontSize = 24.sp)
        if (r.client.isNotBlank() || r.address.isNotBlank()) Text(listOf(r.client, r.address).filter { it.isNotBlank() }.joinToString(" — "), fontSize = 16.sp)
        if (r.invoice.isNotBlank()) Text("накладная ${r.invoice}", fontSize = 12.sp, color = Color.Gray)
        val who = vm.contactsOf(r).joinToString(", ") { it.name.ifBlank { it.num } }
        Text("вес ${fmt(r.weight)} · факт ${r.fact.ifBlank { "—" }} · расчет ${r.calc.ifBlank { "—" }}" + if (who.isNotBlank()) " · $who" else "")
        vm.contactsOf(r).forEach { a -> if (a.phone.isNotBlank()) OutlinedButton({ dial(ctx, a.phone) }) { Text("Позвонить: ${a.name.ifBlank { a.num }}") } }
        if (r.extra.isNotBlank()) Text(r.extra, fontSize = 12.sp, color = Color.Gray)
        Text(
            if (suspicious) "Есть факт и/или ЧЗ — выбор не сохраняется в базу. Выберите точку вручную или следуйте по позывному кнопкой выше."
            else "Позывной не найден в базе — выберите точку или создайте новую."
        )
        if (suggested != null) {
            val txt = "${suggested.name}" + if (suggested.label.isNotBlank()) " — ${suggested.label}" else ""
            if (suspicious) {
                Text("Позывной есть в базе:", fontSize = 13.sp, color = Color.Gray)
                OutlinedButton({ vm.choose(rowId, suggested.name) }, Modifier.fillMaxWidth()) { Text("Следовать по позывному: $txt") }
            } else {
                Text("Из базы по позывному:", fontSize = 13.sp, color = Color.Gray)
                Button({ vm.choose(rowId, suggested.name) }, Modifier.fillMaxWidth()) { Text("✓ $txt") }
            }
        }
        OutlinedTextField(q, { q = it }, label = { Text("Поиск точки") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        hits.filter { it.name != suggested?.name }.forEach { p ->
            OutlinedButton({ vm.choose(rowId, p.name) }, Modifier.fillMaxWidth()) { Text(p.name + if (p.label.isNotBlank()) " — ${p.label}" else "") }
        }
        Button({ creating = true }, Modifier.fillMaxWidth()) { Text("Создать новую точку") }
        TextButton({ vm.skip() }) { Text("Пропустить строку (не везём)") }
    }
    if (creating) NewPointDialog(vm, r.callsign, r.client, r.address, { creating = false }) { vm.createPoint(rowId, it) }
}

@Composable
fun NewPointDialog(vm: AppVm, callsign: String, initName: String, initAddr: String, onClose: () -> Unit, onOk: (Point) -> Unit) {
    var name by remember { mutableStateOf(initName) }
    var addr by remember { mutableStateOf(initAddr) }
    var lat by remember { mutableStateOf("") }
    var lon by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Новая точка" + if (callsign.isNotBlank()) " ($callsign)" else "") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Название") }, singleLine = true)
                OutlinedTextField(addr, { addr = it }, label = { Text("Адрес") })
                OutlinedButton({ vm.geocode(addr) { c -> if (c == null) msg = "Адрес не найден" else { lat = c.first.toString(); lon = c.second.toString(); msg = "Координаты найдены" } } }) { Text("Найти координаты по адресу") }
                OutlinedTextField(lat, { lat = it }, label = { Text("Широта") }, singleLine = true)
                OutlinedTextField(lon, { lon = it }, label = { Text("Долгота") }, singleLine = true)
                if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton({
                val la = lat.toD(); val lo = lon.toD()
                if (name.isBlank() || la == null || lo == null) msg = "Нужны название и координаты"
                else onOk(Point(name.trim(), addr.trim(), la, lo))
            }) { Text("Создать") }
        },
        dismissButton = { TextButton(onClose) { Text("Отмена") } }
    )
}

@Composable
fun ColumnScope.Result(vm: AppVm) {
    val ctx = LocalContext.current
    val p = vm.plan ?: return
    Text("Маршрут: ${p.stops.size} точек, ≈ ${String.format(java.util.Locale.US, "%.1f", p.distanceKm)} км", fontSize = 20.sp)
    Text("В кузове на старте: ${fmt(p.stops.sumOf { it.weight })} кг", color = Color.Gray)
    var open by remember { mutableStateOf<Int?>(null) }
    LazyColumn(Modifier.weight(1f).padding(vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items(p.stops.size) { i ->
            val s = p.stops[i]
            Card(Modifier.fillMaxWidth().clickable { open = if (open == i) null else i }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(12.dp)) {
                    Text("${i + 1}. ${s.point.title.ifBlank { s.point.name }}", fontSize = 17.sp)
                    if (open == i) {
                        if (s.point.address.isNotBlank()) Text(s.point.address, fontSize = 12.sp, color = Color.Gray)
                        Spacer(Modifier.height(4.dp))
                        s.rows.forEach { r ->
                            Text("${r.invoice.ifBlank { "накладная" }} · ${fmt(r.weight)} кг", fontSize = 14.sp)
                            if (r.factSum != 0.0) Text("💰 Забрать наличные: ${fmt(r.factSum)}", fontSize = 13.sp, color = Color(0xFF2E7D32))
                            if (r.isReturn) Text("↩ Забрать возврат", fontSize = 13.sp, color = Color(0xFFB26A00))
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("вывезти ${fmt(s.weight)} кг · останется ${fmt(s.remaining)}", fontSize = 12.sp, color = Color.Gray)
                        s.agents.forEach { num ->
                            val ag = vm.agentFor(num)
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                Text("Агент: " + (ag?.name?.ifBlank { null } ?: num), fontSize = 12.sp, color = Color.Gray)
                                if (ag != null && ag.phone.isNotBlank()) TextButton({ dial(ctx, ag.phone) }) { Text("Позвонить") }
                            }
                        }
                    }
                }
            }
        }
    }
    p.links.forEachIndexed { i, url ->
        Button({
            runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }, Modifier.fillMaxWidth()) { Text(if (p.links.size == 1) "Открыть в навигаторе" else "Открыть участок ${i + 1} из ${p.links.size}") }
    }
    TextButton({ vm.screen = "home" }) { Text("Новый маршрутный лист") }
}
