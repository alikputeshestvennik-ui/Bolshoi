package ru.marshrut

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import ru.marshrut.ui.BusyOverlay
import ru.marshrut.ui.C
import ru.marshrut.ui.DriveScreen
import ru.marshrut.ui.EquipScreen
import ru.marshrut.ui.ErrorBanner
import ru.marshrut.ui.FinishScreen
import ru.marshrut.ui.HomeScreen
import ru.marshrut.ui.MarshrutTheme
import ru.marshrut.ui.MatchScreen
import ru.marshrut.ui.OverviewScreen
import ru.marshrut.ui.ReviewScreen
import ru.marshrut.ui.SettingsScreen

fun dial(ctx: Context, phone: String) {
    runCatching { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone.filter { it.isDigit() || it == '+' })).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

/** Ведение до одной точки: Яндекс Навигатор → Яндекс Карты → браузер. */
fun openNavigator(ctx: Context, p: Point) {
    val tries = listOf(
        Intent(Intent.ACTION_VIEW, Uri.parse("yandexnavi://build_route_on_map?lat_to=${p.lat}&lon_to=${p.lon}")).setPackage("ru.yandex.yandexnavi"),
        Intent(Intent.ACTION_VIEW, Uri.parse("yandexmaps://maps.yandex.ru/?rtext=~${p.lat},${p.lon}&rtt=auto")),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://yandex.ru/maps/?rtext=~${p.lat},${p.lon}&rtt=auto"))
    )
    for (i in tries) {
        try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) { }
    }
}

fun openUrl(ctx: Context, url: String) {
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

class MainActivity : ComponentActivity() {
    private val vm: AppVm by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(C.Bg2.toArgb(), C.Bg2.toArgb()),
            navigationBarStyle = SystemBarStyle.light(C.Bg.toArgb(), C.Bg.toArgb())
        )
        super.onCreate(savedInstanceState)
        setContent { MarshrutTheme { App(vm) } }
    }
}

@Composable
fun App(vm: AppVm) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { l ->
        if (l.isNotEmpty()) { vm.uris.clear(); vm.uris.addAll(l) }
    }
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importDb) }
    val exp = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { it?.let(vm::exportDb) }

    BackHandler(enabled = vm.screen != Screen.HOME && vm.busy == null) {
        when (vm.screen) {
            Screen.SETTINGS, Screen.REVIEW, Screen.OVERVIEW -> vm.screen = Screen.HOME
            Screen.FINISH -> vm.finishRoute()
            Screen.MATCH -> vm.backMatch()
            Screen.EQUIP -> vm.screen = Screen.REVIEW
            Screen.DRIVE -> vm.screen = Screen.OVERVIEW
            Screen.HOME -> {}
        }
    }

    Box(Modifier.fillMaxSize()) {
        ru.marshrut.ui.AuroraBackground()
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            AnimatedContent(
                targetState = vm.screen,
                transitionSpec = {
                    val fwd = targetState.ordinal >= initialState.ordinal
                    val dir = if (fwd) 1 else -1
                    (slideInHorizontally(spring(dampingRatio = 0.9f, stiffness = 380f)) { it / 4 * dir } +
                        fadeIn(tween(260, delayMillis = 40)) + scaleIn(tween(320), initialScale = 0.985f))
                        .togetherWith(slideOutHorizontally(tween(260)) { -it / 6 * dir } + fadeOut(tween(180)))
                },
                label = "screen"
            ) { s ->
                when (s) {
                    Screen.HOME -> HomeScreen(vm, { pick.launch(arrayOf("image/*", "application/pdf")) }, { imp.launch(arrayOf("*/*")) }, { exp.launch("marshrut_db.xlsx") })
                    Screen.SETTINGS -> SettingsScreen(vm)
                    Screen.REVIEW -> ReviewScreen(vm)
                    Screen.MATCH -> MatchScreen(vm)
                    Screen.EQUIP -> EquipScreen(vm)
                    Screen.OVERVIEW -> OverviewScreen(vm)
                    Screen.DRIVE -> DriveScreen(vm)
                    Screen.FINISH -> FinishScreen(vm)
                }
            }
        }
        Column(Modifier.systemBarsPadding().align(Alignment.TopCenter)) {
            ErrorBanner(vm.error, { vm.error = null })
        }
        BusyOverlay(vm.busy)
    }
}
