package ru.marshrut

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.window.layout.FoldingFeature
import androidx.window.layout.WindowInfoTracker
import kotlinx.coroutines.launch
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import ru.marshrut.ui.BusyOverlay
import ru.marshrut.ui.C
import ru.marshrut.ui.DriveScreen
import ru.marshrut.ui.EquipScreen
import ru.marshrut.ui.ErrorBanner
import ru.marshrut.ui.FinishScreen
import ru.marshrut.ui.HomeScreen
import ru.marshrut.ui.MarshrutTheme
import ru.marshrut.ui.MatchScreen
import ru.marshrut.ui.OverviewScreen
import ru.marshrut.ui.ReviewScreen
import ru.marshrut.ui.SettingsScreen

/** Уход в другое приложение по нашей же кнопке (сканы, навигатор, звонок, файлы) — при возврате заставку не показываем. */
object IntroGuard { @Volatile var skipNext = false }

fun dial(ctx: Context, phone: String) {
    runCatching { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone.filter { it.isDigit() || it == '+' })).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); IntroGuard.skipNext = true }
}

/** Ведение до одной точки: Яндекс Навигатор → Яндекс Карты → браузер. */
fun openNavigator(ctx: Context, p: Point) {
    val tries = listOf(
        Intent(Intent.ACTION_VIEW, Uri.parse("yandexnavi://build_route_on_map?lat_to=${p.lat}&lon_to=${p.lon}")).setPackage("ru.yandex.yandexnavi"),
        Intent(Intent.ACTION_VIEW, Uri.parse("yandexmaps://maps.yandex.ru/?rtext=~${p.lat},${p.lon}&rtt=auto")),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://yandex.ru/maps/?rtext=~${p.lat},${p.lon}&rtt=auto"))
    )
    for (i in tries) {
        try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); IntroGuard.skipNext = true; return } catch (_: Exception) { }
    }
}

fun openUrl(ctx: Context, url: String) {
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); IntroGuard.skipNext = true }
}

class MainActivity : ComponentActivity() {
    private val vm: AppVm by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(C.Bg2.toArgb(), C.Bg2.toArgb()),
            navigationBarStyle = SystemBarStyle.light(C.Bg.toArgb(), C.Bg.toArgb())
        )
        super.onCreate(savedInstanceState)
        // Galaxy Flip / Fold: следим за положением сгиба
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                WindowInfoTracker.getOrCreate(this@MainActivity).windowLayoutInfo(this@MainActivity).collect { info ->
                    val f = info.displayFeatures.filterIsInstance<FoldingFeature>().firstOrNull()
                    vm.fold = if (f != null && f.state == FoldingFeature.State.HALF_OPENED && f.orientation == FoldingFeature.Orientation.HORIZONTAL)
                        f.bounds.top to f.bounds.bottom else null
                }
            }
        }
        setContent { MarshrutTheme { App(vm) } }
    }

    /** Запуск и возврат из свёрнутого состояния — заставка с логотипом. */
    override fun onStart() {
        super.onStart()
        if (vm.fromBackground) {
            vm.fromBackground = false
            if (IntroGuard.skipNext) IntroGuard.skipNext = false else if (vm.intro == null) vm.intro = ""
        }
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) vm.fromBackground = true
    }
}

@Composable
fun App(vm: AppVm) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { l ->
        if (l.isNotEmpty()) { vm.uris.clear(); vm.uris.addAll(l) }
    }
    val activity = androidx.compose.ui.platform.LocalContext.current as android.app.Activity
    val scan = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == android.app.Activity.RESULT_OK) {
            val pages = com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult.fromActivityResultIntent(r.data)
                ?.pages?.map { it.imageUri } ?: emptyList()
            if (pages.isNotEmpty()) { vm.uris.clear(); vm.uris.addAll(pages); vm.recognize() }
        }
    }
    val startScan: () -> Unit = {
        IntroGuard.skipNext = true
        val opts = com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(false)
            .setPageLimit(4)
            .setResultFormats(com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
            .setScannerMode(com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        com.google.mlkit.vision.documentscanner.GmsDocumentScanning.getClient(opts).getStartScanIntent(activity)
            .addOnSuccessListener { scan.launch(androidx.activity.result.IntentSenderRequest.Builder(it).build()) }
            .addOnFailureListener { vm.error = "Сканер недоступен: ${it.message ?: "нужны сервисы Google Play"}" }
    }
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let { u -> vm.pendingImport = u } }
    val exp = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { it?.let(vm::exportDb) }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { vm.refreshNotification() }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        val need = ArrayList<String>()
        if (vm.st.startFromGps) { need.add(android.Manifest.permission.ACCESS_FINE_LOCATION); need.add(android.Manifest.permission.ACCESS_COARSE_LOCATION) }
        if (android.os.Build.VERSION.SDK_INT >= 33) need.add(android.Manifest.permission.POST_NOTIFICATIONS)
        val ctx = vm.getApplication<android.app.Application>()
        val missing = need.filter { ctx.checkSelfPermission(it) != android.content.pm.PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) perm.launch(missing.toTypedArray())
    }

    BackHandler(enabled = vm.screen != Screen.HOME && vm.busy == null) {
        when (vm.screen) {
            Screen.SETTINGS, Screen.REVIEW, Screen.OVERVIEW -> vm.screen = Screen.HOME
            Screen.FINISH -> vm.finishRoute()
            Screen.HISTORY, Screen.CHECK -> vm.screen = Screen.HOME
            Screen.LOAD -> vm.screen = Screen.OVERVIEW
            Screen.HISTORY_DETAIL -> vm.screen = Screen.HISTORY
            Screen.MATCH -> vm.backMatch()
            Screen.EQUIP -> vm.screen = Screen.REVIEW
            Screen.DRIVE -> vm.screen = Screen.OVERVIEW
            Screen.HOME -> {}
        }
    }

    Box(Modifier.fillMaxSize()) {
        ru.marshrut.ui.AuroraBackground()
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            AnimatedContent(
                targetState = vm.screen,
                transitionSpec = {
                    val fwd = targetState.ordinal >= initialState.ordinal
                    val dir = if (fwd) 1 else -1
                    (slideInHorizontally(spring(dampingRatio = 0.9f, stiffness = 380f)) { it / 4 * dir } +
                        fadeIn(tween(260, delayMillis = 40)) + scaleIn(tween(320), initialScale = 0.985f))
                        .togetherWith(slideOutHorizontally(tween(260)) { -it / 6 * dir } + fadeOut(tween(180)))
                },
                label = "screen"
            ) { s ->
                when (s) {
                    Screen.HOME -> HomeScreen(vm, { IntroGuard.skipNext = true; pick.launch(arrayOf("image/*", "application/pdf")) }, { IntroGuard.skipNext = true; imp.launch(arrayOf("*/*")) }, { IntroGuard.skipNext = true; exp.launch("marshrut_db.xlsx") }, startScan)
                    Screen.SETTINGS -> SettingsScreen(vm)
                    Screen.REVIEW -> ReviewScreen(vm)
                    Screen.MATCH -> MatchScreen(vm)
                    Screen.EQUIP -> EquipScreen(vm)
                    Screen.OVERVIEW -> OverviewScreen(vm)
                    Screen.DRIVE -> DriveScreen(vm)
                    Screen.FINISH -> FinishScreen(vm)
                    Screen.HISTORY -> ru.marshrut.ui.HistoryScreen(vm)
                    Screen.CHECK -> ru.marshrut.ui.CheckScreen(vm)
                    Screen.LOAD -> ru.marshrut.ui.LoadScreen(vm)
                    Screen.HISTORY_DETAIL -> ru.marshrut.ui.HistoryDetailScreen(vm)
                }
            }
        }
        Column(Modifier.systemBarsPadding().align(Alignment.TopCenter)) {
            ErrorBanner(vm.error, { vm.error = null })
            ru.marshrut.ui.InfoBanner(vm.info, { vm.info = null })
        }
        BusyOverlay(vm.busy)
        vm.pendingImport?.let { u ->
            ru.marshrut.ui.ConfirmDialog(
                title = "Обновить базу",
                text = "«Заменить целиком» удалит из телефона всё, чего нет в файле. «Только обновить» добавит новое и исправит изменённое, ничего не удаляя.",
                confirm = "Заменить целиком",
                onConfirm = { vm.pendingImport = null; vm.replaceDb(u) },
                onDismiss = { vm.pendingImport = null },
                secondary = "Только обновить",
                onSecondary = { vm.pendingImport = null; vm.importDb(u) }
            )
        }
        vm.pendingLinks.firstOrNull()?.let { (cs, pt) ->
            val title = vm.db.point(pt)?.display ?: pt
            ru.marshrut.ui.ConfirmDialog(
                title = "Запомнить позывной?",
                text = "Позывной $cs будет привязан к точке «$title». Проверьте, что он распознан без ошибок — иначе в базу попадёт лишний позывной.",
                confirm = "Запомнить",
                onConfirm = { vm.confirmLink(true) },
                onDismiss = { vm.confirmLink(false) }
            )
        }
        vm.intro?.let { c -> ru.marshrut.ui.DeliveryIntro(c) { vm.intro = null } }
    }
}
