package ru.marshrut

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Агент внутри приложения: водитель пишет задачу обычным текстом, модель по шагам смотрит лист, базу и раскладку
 * и предлагает правки. Читать может сама, а всё, что меняет данные, — только после «Да» водителя.
 * Протокол — простой JSON в ответе модели, поэтому работает с любой моделью gptunnel.
 */
class AiAgent(private val vm: AppVm, private val scope: CoroutineScope) {
    /** Реплика в чате. proposal — действие, ждущее «Да/Нет»; undo — откат выполненного действия. */
    class Msg(val role: Role, val text: String, val proposal: Proposal? = null, val undo: (() -> String)? = null)
    enum class Role { USER, AGENT, NOTE, ERROR }
    class Proposal(val tool: String, val args: JSONObject, val text: String) {
        var state by mutableStateOf(0) // 0 — ждёт, 1 — выполнено, 2 — отказ
    }

    val msgs = mutableStateListOf<Msg>()
    var busy by mutableStateOf<String?>(null)
    private val history = JSONArray()
    private var pending: Proposal? = null
    private val undone = HashSet<Msg>()

    fun clear() { msgs.clear(); while (history.length() > 0) history.remove(0); pending = null; undone.clear() }
    fun isUndone(m: Msg) = m in undone

    fun send(text: String) {
        val t = text.trim(); if (t.isEmpty() || busy != null) return
        if (pending != null) { pending?.state = 2; history.put(user("Водитель не ответил на предложение и написал новое.")); pending = null }
        msgs.add(Msg(Role.USER, t)); history.put(user(t)); run()
    }

    fun answer(p: Proposal, yes: Boolean) {
        if (pending !== p || busy != null) return
        pending = null
        if (!yes) { p.state = 2; history.put(user("Водитель отказался: ${p.text}")); run(); return }
        scope.launch {
            busy = "Выполняю"
            val res = runCatching { act(p.tool, p.args) }
            busy = null
            res.onSuccess { (txt, undo) ->
                p.state = 1
                msgs.add(Msg(Role.NOTE, "Сделано: $txt", undo = undo))
                history.put(user("РЕЗУЛЬТАТ ${p.tool}: выполнено — $txt"))
            }.onFailure {
                p.state = 2
                msgs.add(Msg(Role.ERROR, "Не получилось: ${it.message}"))
                history.put(user("РЕЗУЛЬТАТ ${p.tool}: ошибка — ${it.message}"))
            }
            run()
        }
    }

    fun undo(m: Msg) {
        val u = m.undo ?: return; if (m in undone) return
        val t = runCatching { u() }.getOrElse { "не вышло: ${it.message}" }
        undone.add(m); msgs.add(Msg(Role.NOTE, "Откатил: $t")); history.put(user("Водитель откатил действие: $t"))
    }

    private fun user(t: String) = JSONObject().put("role", "user").put("content", t)

    private fun run() = scope.launch {
        busy = "Думаю"
        try {
            repeat(8) {
                val msgsForModel = JSONArray().put(JSONObject().put("role", "system").put("content", system()))
                for (i in 0 until history.length()) msgsForModel.put(history.get(i))
                val (raw, meter) = withContext(Dispatchers.IO) { Net.agentTurn(vm.st, msgsForModel) }
                vm.usageLog.addExtra(meter, "Агент · " + vm.st.agentModel); vm.usageVer++
                history.put(JSONObject().put("role", "assistant").put("content", raw))
                val j = parse(raw)
                val say = j?.optString("say").orEmpty().trim()
                if (say.isNotEmpty()) msgs.add(Msg(Role.AGENT, say))
                val tool = j?.optJSONObject("tool")
                val name = tool?.optString("name").orEmpty()
                if (j == null) { if (raw.isNotBlank()) msgs.add(Msg(Role.AGENT, raw.trim())); return@launch }
                if (name.isEmpty()) return@launch
                val args = tool?.optJSONObject("args") ?: JSONObject()
                if (name in WRITE) {
                    val p = Proposal(name, args, describe(name, args))
                    pending = p; msgs.add(Msg(Role.AGENT, p.text, proposal = p)); return@launch
                }
                busy = label(name, args)
                val res = runCatching { look(name, args) }.getOrElse { "ОШИБКА: ${it.message}" }
                msgs.add(Msg(Role.NOTE, label(name, args)))
                history.put(user("РЕЗУЛЬТАТ $name:\n" + res.take(12000)))
                busy = "Думаю"
            }
            msgs.add(Msg(Role.NOTE, "Остановился: слишком много шагов подряд. Уточните задачу."))
        } catch (e: Exception) {
            msgs.add(Msg(Role.ERROR, "Агент недоступен: ${e.message ?: e}. Нужен интернет."))
        } finally { busy = null }
    }

    private fun parse(raw: String): JSONObject? {
        val a = raw.indexOf('{'); val b = raw.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return runCatching { JSONObject(raw.substring(a, b + 1)) }.getOrNull()
    }

    // ---------- что знает модель ----------
    private fun system(): String = """
Ты — агент в приложении «Маршрут» для водителя-экспедитора (Крым, склад в Севастополе). Отвечай по-русски, коротко и по делу, на «ты».
Приложение распознаёт маршрутный лист (строки: позывной клиента, накладная, клиент, адрес, вес, факт — наличные), раскладывает накладные по точкам базы и строит раскладку (порядок объезда).
Сейчас: ${context()}

Каждый твой ответ — ТОЛЬКО JSON: {"say": "что сказать водителю (можно пусто)", "tool": {"name": "...", "args": {...}} или null}.
Одно действие за ответ. Получив РЕЗУЛЬТАТ, продолжай. Когда задача решена или нужен ответ водителя — tool: null.

Смотреть (выполняются сразу):
- sheet {} — строки листа: id|позывной|клиент|адрес|накладная|вес|факт|расчёт|заметки|агент
- groups {} — как строки разложены по точкам на проверке: ключ|вид|точка|адрес|позывные|id строк
- find_points {"q": "текст"} — поиск в базе по названию, адресу или позывному
- point {"name": "имя точки"} — точка базы целиком
- callsign {"cs": "457ЮС"} — какой точке принадлежит позывной
- layout {} — текущая раскладка: №|точка|адрес|позывные|вес|накладные
- photo_row {"row_id": 12} — перечитать строку на фото листа (если сомневаешься в распознавании)
Менять (приложение спросит водителя «Да/Нет», ты только предлагаешь):
- edit_row {"row_id": 12, "field": "callsign|client|address|invoice|weight|fact|notes|agent", "value": "..."}
- set_address {"point": "имя", "address": "..."}
- set_coords {"point": "имя", "lat": 44.4, "lon": 34.0}
- geocode {"point": "имя"} — найти координаты по адресу точки и поставить
- link_callsign {"cs": "457ЮС", "point": "имя"} — привязать позывной к точке
- merge_new {"group": "ключ группы", "point": "имя"} — новая точка с проверки — это точка из базы

Правила: цифры (вес, деньги, количества) бери только из РЕЗУЛЬТАТОВ, не выдумывай. Не знаешь — посмотри инструментом. Имена точек пиши точно как в результатах.
В одном посёлке может быть улица с тем же названием, что в другом (Севастопольское шоссе — Гаспра, Кореиз, Оползневое): сверяй посёлок.
""".trimIndent()

    private fun context(): String {
        val p = vm.plan
        val sheet = if (vm.rows.isEmpty()) "распознанного листа нет" else "лист «${vm.header.take(80)}», строк ${vm.rows.size}" +
            (if (vm.draftBuilt) ", раскладка построена" else ", раскладка ещё не построена")
        val lay = if (p != null && p.stops.isNotEmpty()) "; последняя раскладка: ${p.stops.size} точек, «${p.header.take(60)}»" else ""
        return "$sheet$lay; в базе ${vm.db.points.size} точек; экран: ${vm.agentFrom}"
    }

    private fun label(name: String, a: JSONObject) = when (name) {
        "sheet" -> "смотрю строки листа"
        "groups" -> "смотрю, как разложены точки"
        "find_points" -> "ищу в базе: ${a.optString("q")}"
        "point" -> "смотрю точку ${a.optString("name")}"
        "callsign" -> "смотрю позывной ${a.optString("cs")}"
        "layout" -> "смотрю раскладку"
        "photo_row" -> "перечитываю строку на фото"
        else -> name
    }

    private val WRITE = setOf("edit_row", "set_address", "set_coords", "geocode", "link_callsign", "merge_new")

    private fun rowById(a: JSONObject) = vm.rows.firstOrNull { it.id == a.optInt("row_id", -1) } ?: error("нет строки ${a.opt("row_id")}")
    private fun pointBy(n: String) = vm.db.point(n) ?: vm.db.points.firstOrNull { it.display.equals(n, true) } ?: error("нет точки «$n»")
    private fun fieldName(f: String) = mapOf("callsign" to "позывной", "client" to "клиент", "address" to "адрес", "invoice" to "накладная",
        "weight" to "вес", "fact" to "факт", "notes" to "заметки", "agent" to "агент")[f] ?: f

    private fun describe(name: String, a: JSONObject): String = when (name) {
        "edit_row" -> { val r = vm.rows.firstOrNull { it.id == a.optInt("row_id", -1) }
            "Поменять в строке ${r?.invoiceLabel ?: a.opt("row_id")} (${r?.client.orEmpty()}) ${fieldName(a.optString("field"))} на «${a.optString("value")}»?" }
        "set_address" -> "Поменять адрес точки «${a.optString("point")}» на «${a.optString("address")}»?"
        "set_coords" -> "Поставить точку «${a.optString("point")}» в ${a.optDouble("lat")}, ${a.optDouble("lon")}?"
        "geocode" -> "Найти координаты точки «${a.optString("point")}» по её адресу и поставить?"
        "link_callsign" -> "Привязать позывной ${a.optString("cs")} к точке «${a.optString("point")}»?"
        "merge_new" -> "Слить новую точку с «${a.optString("point")}»?"
        else -> "$name ${a}?"
    }

    // ---------- смотреть ----------
    private suspend fun look(name: String, a: JSONObject): String = when (name) {
        "sheet" -> if (vm.rows.isEmpty()) "листа нет" else vm.rows.joinToString("\n") { r ->
            listOf(r.id, r.callsign, r.client, r.address, r.invoice, r.weight, r.fact, r.calc, r.notes, r.agent).joinToString("|") }
        "groups" -> if (vm.rows.isEmpty()) "листа нет" else vm.reviewGroups().joinToString("\n") { g ->
            val kind = when (g.kind) { AppVm.RGroup.KNOWN -> "из базы"; AppVm.RGroup.NEW -> "новая"; AppVm.RGroup.MANUAL -> "вручную"; else -> "только возврат" }
            listOf(g.key, kind, g.point?.name ?: g.title, g.address, g.callsigns.joinToString(","), g.rows.joinToString(",") { it.id.toString() }).joinToString("|") }
        "find_points" -> {
            val q = a.optString("q").trim(); val cs = vm.db.norm(q)
            vm.db.points.filter { p -> q.isBlank() || listOf(p.name, p.title, p.address).any { it.contains(q, true) } ||
                (cs.isNotEmpty() && vm.db.callsignsOf(p.name).any { it.contains(cs) }) }.take(15)
                .joinToString("\n") { pointLine(it) }.ifBlank { "ничего не найдено" }
        }
        "point" -> pointLine(pointBy(a.optString("name"))) + (vm.db.point(a.optString("name"))?.commentText?.let { if (it.isBlank()) "" else "\nкомментарий: $it" } ?: "")
        "callsign" -> vm.db.pointFor(a.optString("cs"))?.let { pointLine(it) } ?: "позывной не привязан ни к одной точке"
        "layout" -> vm.plan?.stops?.withIndex()?.joinToString("\n") { (i, s) ->
            listOf(i + 1, s.point.display, s.point.address, s.callsigns.joinToString(","), s.weight, s.rows.joinToString(",") { it.invoiceLabel }).joinToString("|") }
            ?: "раскладки нет"
        "photo_row" -> {
            val r = rowById(a)
            val jpegs = vm.scans.map { it.readBytes() }.ifEmpty { error("фото листа нет — его снимали не из приложения или лист старый") }
            val (txt, meter) = withContext(Dispatchers.IO) {
                Net.readRowFromPhoto(vm.st, jpegs, "клиент «${r.client}», вес ${r.weight}, накладная ${r.invoice}")
            }
            vm.usageLog.addExtra(meter, "Агент · фото строки"); vm.usageVer++
            txt
        }
        else -> "нет такого инструмента: $name"
    }

    private fun pointLine(p: Point) = listOf(p.name, p.display, p.address, if (p.hasCoords) "${p.lat},${p.lon}" else "без координат",
        "позывные: " + vm.db.callsignsOf(p.name).joinToString(",").ifBlank { "нет" }).joinToString("|")

    // ---------- менять (после «Да») ----------
    private suspend fun act(name: String, a: JSONObject): Pair<String, (() -> String)?> = when (name) {
        "edit_row" -> {
            val r = rowById(a); val v = a.optString("value")
            val n = when (a.optString("field")) {
                "callsign" -> r.copy(callsign = v); "client" -> r.copy(client = v); "address" -> r.copy(address = v)
                "invoice" -> r.copy(invoice = v); "weight" -> r.copy(weight = v.replace(',', '.').toDoubleOrNull() ?: error("вес не число: $v"))
                "fact" -> r.copy(fact = v); "notes" -> r.copy(notes = v); "agent" -> r.copy(agent = v)
                else -> error("нет поля ${a.optString("field")}")
            }
            vm.update(n); vm.saveDraft()
            "${fieldName(a.optString("field"))} в строке ${r.invoiceLabel} → «$v»" to { vm.update(r); vm.saveDraft(); "строка ${r.invoiceLabel} как была" }
        }
        "set_address" -> {
            val p = pointBy(a.optString("point")); val v = a.optString("address").trim()
            vm.db.addPoint(p.copy(address = v)); vm.dbVer++
            "адрес «${p.display}» → $v" to { vm.db.addPoint(p); vm.dbVer++; "адрес «${p.display}» снова ${p.address}" }
        }
        "set_coords" -> {
            val p = pointBy(a.optString("point"))
            val la = a.optDouble("lat"); val lo = a.optDouble("lon"); if (la.isNaN() || lo.isNaN()) error("нет координат")
            vm.db.addPoint(p.copy(lat = la, lon = lo)); vm.dbVer++
            "«${p.display}» поставлена в $la, $lo" to { vm.db.addPoint(p); vm.dbVer++; "«${p.display}» на старом месте" }
        }
        "geocode" -> {
            val p = pointBy(a.optString("point"))
            val g = withContext(Dispatchers.IO) { Net.geocode(p.address, vm.depotCoordsPublic()) } ?: error("адрес «${p.address}» не нашёлся")
            vm.db.addPoint(p.copy(lat = g.lat, lon = g.lon)); vm.dbVer++
            "«${p.display}» по адресу: ${g.lat}, ${g.lon}" + (if (g.precision != Net.Precision.HOUSE) " (приблизительно)" else "") to
                { vm.db.addPoint(p); vm.dbVer++; "«${p.display}» на старом месте" }
        }
        "link_callsign" -> {
            val cs = a.optString("cs").trim(); val p = pointBy(a.optString("point"))
            val old = vm.db.calls[vm.db.norm(cs)]
            vm.linkCallsign(cs, p.name)
            "$cs → «${p.display}»" to { if (old != null) vm.linkCallsign(cs, old) else vm.unlinkCallsign(cs); "$cs как был" + (old?.let { " (у «$it»)" } ?: "") }
        }
        "merge_new" -> {
            val g = vm.reviewGroups().firstOrNull { it.key == a.optString("group") } ?: error("нет группы ${a.optString("group")}")
            val p = pointBy(a.optString("point"))
            vm.mergeNewInto(g, p.name)
            "«${g.title}» слита с «${p.display}»" to null
        }
        else -> error("нет действия $name")
    }
}
