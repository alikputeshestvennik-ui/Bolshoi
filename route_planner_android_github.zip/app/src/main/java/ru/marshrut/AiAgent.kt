package ru.marshrut

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Агент внутри приложения: водитель пишет задачу обычным текстом, модель по шагам смотрит лист, базу и раскладку
 * и предлагает правки. Читать может сама, а всё, что меняет данные, — только после «Да» водителя.
 * Протокол — простой JSON в ответе модели, поэтому работает с любой моделью gptunnel.
 */
class AiAgent(private val vm: AppVm, private val scope: CoroutineScope) {
    /** Реплика в чате. proposal — действие, ждущее «Да/Нет»; undo — откат выполненного действия. */
    class Msg(val role: Role, val text: String, val proposal: Proposal? = null, val undo: (() -> String)? = null)
    enum class Role { USER, AGENT, NOTE, ERROR }
    class Proposal(val tool: String, val args: JSONObject, val text: String) {
        var state by mutableStateOf(0) // 0 — ждёт, 1 — выполнено, 2 — отказ
    }

    val msgs = mutableStateListOf<Msg>()
    var busy by mutableStateOf<String?>(null)
    private val history = JSONArray()
    private var pending: Proposal? = null
    private val undone = HashSet<Msg>()

    private val ctx get() = vm.getApplication<android.app.Application>()

    init {
        // Ответ торгового пришёл, пока агент в памяти, — сразу пересказываем
        Inbox.listener = { scope.launch { checkInbox() } }
    }

    /** Забрать ответы торговых и попросить модель пересказать смысл. */
    fun checkInbox() {
        val got = Inbox.take(ctx); if (got.isEmpty()) return
        got.forEach { m ->
            msgs.add(Msg(Role.NOTE, "${m.via} от ${m.from}: «${m.text}»"))
            history.put(user("ВХОДЯЩЕЕ (${m.via}) от ${m.from}: ${m.text}\nПерескажи водителю смысл одной-двумя фразами и, если нужно, предложи действие."))
        }
        if (busy == null) run()
    }

    private fun chKey(phone: String) = "ch_" + Inbox.digits(phone)
    private fun channel(phone: String) = ctx.getSharedPreferences("inbox", 0).getString(chKey(phone), "sms") ?: "sms"

    fun clear() { msgs.clear(); while (history.length() > 0) history.remove(0); pending = null; undone.clear() }
    fun isUndone(m: Msg) = m in undone

    fun send(text: String) {
        val t = text.trim(); if (t.isEmpty() || busy != null) return
        if (pending != null) { pending?.state = 2; history.put(user("Водитель не ответил на предложение и написал новое.")); pending = null }
        msgs.add(Msg(Role.USER, t)); history.put(user(t)); run()
    }

    fun answer(p: Proposal, yes: Boolean) {
        if (pending !== p || busy != null) return
        pending = null
        if (!yes) { p.state = 2; history.put(user("Водитель отказался: ${p.text}")); run(); return }
        scope.launch {
            busy = "Выполняю"
            val res = runCatching { act(p.tool, p.args) }
            // Перестановка пересчитывает раскладку в фоне — ждём, чтобы агент дальше видел уже новый порядок
            var waited = 0
            while (vm.busy != null && waited < 60_000) { kotlinx.coroutines.delay(150); waited += 150 }
            busy = null
            res.onSuccess { (txt, undo) ->
                p.state = 1
                msgs.add(Msg(Role.NOTE, "Сделано: $txt", undo = undo))
                history.put(user("РЕЗУЛЬТАТ ${p.tool}: выполнено — $txt"))
            }.onFailure {
                p.state = 2
                msgs.add(Msg(Role.ERROR, "Не получилось: ${it.message}"))
                history.put(user("РЕЗУЛЬТАТ ${p.tool}: ошибка — ${it.message}"))
            }
            run()
        }
    }

    fun undo(m: Msg) {
        val u = m.undo ?: return; if (m in undone) return
        val t = runCatching { u() }.getOrElse { "не вышло: ${it.message}" }
        undone.add(m); msgs.add(Msg(Role.NOTE, "Откатил: $t")); history.put(user("Водитель откатил действие: $t"))
    }

    private fun user(t: String) = JSONObject().put("role", "user").put("content", t)

    private fun run() = scope.launch {
        busy = "Думаю"
        try {
            repeat(8) {
                val msgsForModel = JSONArray().put(JSONObject().put("role", "system").put("content", system()))
                for (i in 0 until history.length()) msgsForModel.put(history.get(i))
                val (raw, meter) = withContext(Dispatchers.IO) { Net.agentTurn(vm.st, msgsForModel) }
                vm.usageLog.addExtra(meter, "Агент · " + vm.st.agentModel); vm.usageVer++
                history.put(JSONObject().put("role", "assistant").put("content", raw))
                val j = parse(raw)
                val say = j?.optString("say").orEmpty().trim()
                if (say.isNotEmpty()) msgs.add(Msg(Role.AGENT, say))
                val tool = j?.optJSONObject("tool")
                val name = tool?.optString("name").orEmpty()
                if (j == null) { if (raw.isNotBlank()) msgs.add(Msg(Role.AGENT, raw.trim())); return@launch }
                if (name.isEmpty()) return@launch
                val args = tool?.optJSONObject("args") ?: JSONObject()
                if (name in WRITE) {
                    val p = Proposal(name, args, describe(name, args))
                    pending = p; msgs.add(Msg(Role.AGENT, p.text, proposal = p)); return@launch
                }
                busy = label(name, args)
                val res = runCatching { look(name, args) }.getOrElse { "ОШИБКА: ${it.message}" }
                msgs.add(Msg(Role.NOTE, label(name, args)))
                history.put(user("РЕЗУЛЬТАТ $name:\n" + res.take(12000)))
                busy = "Думаю"
            }
            msgs.add(Msg(Role.NOTE, "Остановился: слишком много шагов подряд. Уточните задачу."))
        } catch (e: Exception) {
            msgs.add(Msg(Role.ERROR, "Агент недоступен: ${e.message ?: e}. Нужен интернет."))
        } finally { busy = null }
    }

    private fun parse(raw: String): JSONObject? {
        val a = raw.indexOf('{'); val b = raw.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return runCatching { JSONObject(raw.substring(a, b + 1)) }.getOrNull()
    }

    // ---------- что знает модель ----------
    private fun system(): String = """
Тебя зовут ${vm.agentName}. Ты — агент в приложении «Маршрут» для водителя-экспедитора (Крым, склад в Севастополе). Отвечай по-русски, коротко и по делу, на «ты».
Приложение распознаёт маршрутный лист (строки: позывной клиента, накладная, клиент, адрес, вес, факт — наличные), раскладывает накладные по точкам базы и строит раскладку (порядок объезда).
Сейчас: ${context()}

Каждый твой ответ — ТОЛЬКО JSON: {"say": "что сказать водителю (можно пусто)", "tool": {"name": "...", "args": {...}} или null}.
Одно действие за ответ. Получив РЕЗУЛЬТАТ, продолжай. Когда задача решена или нужен ответ водителя — tool: null.

Смотреть (выполняются сразу):
- sheet {} — строки листа: id|позывной|клиент|адрес|накладная|вес|факт|расчёт|заметки|агент
- groups {} — как строки разложены по точкам на проверке: ключ|вид|точка|адрес|позывные|id строк
- find_points {"q": "текст"} — поиск в базе по названию, адресу или позывному
- point {"name": "имя точки"} — точка базы целиком
- callsign {"cs": "457ЮС"} — какой точке принадлежит позывной
- layout {} — текущая раскладка: №|точка|адрес|позывные|вес|накладные
- photo_row {"row_id": 12} — перечитать строку на фото листа (если сомневаешься в распознавании)
- variants {} — варианты порядка этой раскладки («Как вы ездили», «Комфортный», «По весу»…) и какой выбран
- history {"q": "текст"} — прошлые листы и поездки: id|дата|день недели|вид|точек|шапка листа (q — часть шапки, название точки или день: «вторник»; пусто — последние)
- history_order {"id": 123} — порядок точек прошлого листа
- drive {"points": ["склад", "имя точки", "имя точки", ...]} — время и км по этому порядку из уже посчитанных дорог (без запросов к 2ГИС). Сравнивай варианты порядка этим, а не на глаз
- agents {} — торговые этого листа: номер|имя|телефон|канал (sms или max)
Менять (приложение спросит водителя «Да/Нет», ты только предлагаешь):
- edit_row {"row_id": 12, "field": "callsign|client|address|invoice|weight|fact|notes|agent", "value": "..."}
- set_address {"point": "имя", "address": "..."}
- set_coords {"point": "имя", "lat": 44.4, "lon": 34.0}
- geocode {"point": "имя"} — найти координаты по адресу точки и поставить
- link_callsign {"cs": "457ЮС", "point": "имя"} — привязать позывной к точке
- merge_new {"group": "ключ группы", "point": "имя"} — новая точка с проверки — это точка из базы
- move_stop {"from": 5, "to": 2} — переставить точку раскладки с места from на место to (номера с 1)
- set_order {"order": [3, 1, 2, ...]} — весь порядок: старые номера точек в новом порядке, каждый ровно один раз
- order_like {"id": 123} — порядок как в прошлом листе: общие точки — как там, остальные — в конце
- choose_variant {"name": "По весу"} — выбрать вариант раскладки
- send_sms {"to": "имя торгового", "text": "..."} — отправить SMS торговому; ответ придёт сам, ты его перескажешь
- open_max {"to": "имя торгового", "text": "..."} — открыть Max с готовым текстом (водитель сам выберет чат и нажмёт «Отправить»); ответ из уведомления Max придёт сам
- set_channel {"to": "имя торгового", "via": "sms|max"} — как писать этому торговому по умолчанию
- remember_order {} — запомнить текущий порядок для следующих листов (уходит и другим водителям) — только если водитель прямо просит запомнить

Писать торговым: по умолчанию SMS, Max — если у торгового канал max или водитель сам попросил. Текст — вежливо, коротко, по делу, от имени водителя, с номером накладной и клиентом, если о них речь.
Правила: цифры (вес, деньги, количества) бери только из РЕЗУЛЬТАТОВ, не выдумывай. Не знаешь — посмотри инструментом. Имена точек пиши точно как в результатах.
В одном посёлке может быть улица с тем же названием, что в другом (Севастопольское шоссе — Гаспра, Кореиз, Оползневое): сверяй посёлок.
""".trimIndent()

    private fun context(): String {
        val p = vm.plan
        val sheet = if (vm.rows.isEmpty()) "распознанного листа нет" else "лист «${vm.header.take(80)}», строк ${vm.rows.size}" +
            (if (vm.draftBuilt) ", раскладка построена" else ", раскладка ещё не построена")
        val lay = if (p != null && p.stops.isNotEmpty()) "; последняя раскладка: ${p.stops.size} точек, «${p.header.take(60)}»" else ""
        return "$sheet$lay; в базе ${vm.db.points.size} точек; экран: ${vm.agentFrom}"
    }

    private fun label(name: String, a: JSONObject) = when (name) {
        "sheet" -> "смотрю строки листа"
        "groups" -> "смотрю, как разложены точки"
        "find_points" -> "ищу в базе: ${a.optString("q")}"
        "point" -> "смотрю точку ${a.optString("name")}"
        "callsign" -> "смотрю позывной ${a.optString("cs")}"
        "layout" -> "смотрю раскладку"
        "photo_row" -> "перечитываю строку на фото"
        "variants" -> "смотрю варианты"
        "history" -> "смотрю историю" + a.optString("q").let { if (it.isBlank()) "" else ": $it" }
        "history_order" -> "смотрю порядок прошлого листа"
        "drive" -> "считаю время в пути"
        "agents" -> "смотрю торговых"
        else -> name
    }

    private val WRITE = setOf("send_sms", "open_max", "set_channel", "edit_row", "set_address", "set_coords", "geocode", "link_callsign", "merge_new",
        "move_stop", "set_order", "order_like", "choose_variant", "remember_order")

    private fun rowById(a: JSONObject) = vm.rows.firstOrNull { it.id == a.optInt("row_id", -1) } ?: error("нет строки ${a.opt("row_id")}")
    private fun pointBy(n: String) = vm.db.point(n) ?: vm.db.points.firstOrNull { it.display.equals(n, true) } ?: error("нет точки «$n»")
    private fun fieldName(f: String) = mapOf("callsign" to "позывной", "client" to "клиент", "address" to "адрес", "invoice" to "накладная",
        "weight" to "вес", "fact" to "факт", "notes" to "заметки", "agent" to "агент")[f] ?: f

    private fun describe(name: String, a: JSONObject): String = when (name) {
        "edit_row" -> { val r = vm.rows.firstOrNull { it.id == a.optInt("row_id", -1) }
            "Поменять в строке ${r?.invoiceLabel ?: a.opt("row_id")} (${r?.client.orEmpty()}) ${fieldName(a.optString("field"))} на «${a.optString("value")}»?" }
        "set_address" -> "Поменять адрес точки «${a.optString("point")}» на «${a.optString("address")}»?"
        "set_coords" -> "Поставить точку «${a.optString("point")}» в ${a.optDouble("lat")}, ${a.optDouble("lon")}?"
        "geocode" -> "Найти координаты точки «${a.optString("point")}» по её адресу и поставить?"
        "link_callsign" -> "Привязать позывной ${a.optString("cs")} к точке «${a.optString("point")}»?"
        "merge_new" -> "Слить новую точку с «${a.optString("point")}»?"
        "move_stop" -> { val st = vm.plan?.stops; val f = a.optInt("from"); val t = a.optInt("to")
            "Переставить «${st?.getOrNull(f - 1)?.point?.display ?: "точку $f"}» с ${f}-го места на ${t}-е?" }
        "set_order" -> "Поменять порядок раскладки: " + orderPreview(orderArg(a)) + "?"
        "order_like" -> vm.history.firstOrNull { it.id == a.optLong("id") }.let { e ->
            "Разложить в порядке листа от ${e?.let { day(it.date) } ?: a.opt("id")}?" }
        "choose_variant" -> "Выбрать вариант «${a.optString("name")}»?"
        "send_sms" -> "Отправить SMS ${agentBy(a.optString("to"))?.let { "${it.name} (${it.phone})" } ?: a.optString("to")}:\n«${a.optString("text")}»?"
        "open_max" -> "Открыть Max для ${a.optString("to")} с текстом:\n«${a.optString("text")}»?"
        "set_channel" -> "Писать ${a.optString("to")} по умолчанию в ${if (a.optString("via") == "max") "Max" else "SMS"}?"
        "remember_order" -> "Запомнить текущий порядок для следующих листов? Он уйдёт и другим водителям."
        else -> "$name ${a}?"
    }

    // ---------- смотреть ----------
    private suspend fun look(name: String, a: JSONObject): String = when (name) {
        "sheet" -> if (vm.rows.isEmpty()) "листа нет" else vm.rows.joinToString("\n") { r ->
            listOf(r.id, r.callsign, r.client, r.address, r.invoice, r.weight, r.fact, r.calc, r.notes, r.agent).joinToString("|") }
        "groups" -> if (vm.rows.isEmpty()) "листа нет" else vm.reviewGroups().joinToString("\n") { g ->
            val kind = when (g.kind) { AppVm.RGroup.KNOWN -> "из базы"; AppVm.RGroup.NEW -> "новая"; AppVm.RGroup.MANUAL -> "вручную"; else -> "только возврат" }
            listOf(g.key, kind, g.point?.name ?: g.title, g.address, g.callsigns.joinToString(","), g.rows.joinToString(",") { it.id.toString() }).joinToString("|") }
        "find_points" -> {
            val q = a.optString("q").trim(); val cs = vm.db.norm(q)
            vm.db.points.filter { p -> q.isBlank() || listOf(p.name, p.title, p.address).any { it.contains(q, true) } ||
                (cs.isNotEmpty() && vm.db.callsignsOf(p.name).any { it.contains(cs) }) }.take(15)
                .joinToString("\n") { pointLine(it) }.ifBlank { "ничего не найдено" }
        }
        "point" -> pointLine(pointBy(a.optString("name"))) + (vm.db.point(a.optString("name"))?.commentText?.let { if (it.isBlank()) "" else "\nкомментарий: $it" } ?: "")
        "callsign" -> vm.db.pointFor(a.optString("cs"))?.let { pointLine(it) } ?: "позывной не привязан ни к одной точке"
        "layout" -> vm.plan?.stops?.withIndex()?.joinToString("\n") { (i, s) ->
            listOf(i + 1, s.point.display, s.point.address, s.callsigns.joinToString(","), s.weight, s.rows.joinToString(",") { it.invoiceLabel }).joinToString("|") }
            ?: "раскладки нет"
        "photo_row" -> {
            val r = rowById(a)
            val jpegs = vm.scans.map { it.readBytes() }.ifEmpty { error("фото листа нет — его снимали не из приложения или лист старый") }
            val (txt, meter) = withContext(Dispatchers.IO) {
                Net.readRowFromPhoto(vm.st, jpegs, "клиент «${r.client}», вес ${r.weight}, накладная ${r.invoice}")
            }
            vm.usageLog.addExtra(meter, "Агент · фото строки"); vm.usageVer++
            txt
        }
        "variants" -> vm.variants.joinToString("\n") { v ->
            (if (v === vm.plan || v.stops.map { it.point.name } == vm.plan?.stops?.map { it.point.name }) "[выбран] " else "") +
                v.variant.ifBlank { "без названия" } + ": " + v.stops.joinToString(" → ") { it.point.display } }.ifBlank { "вариантов нет — открыта раскладка из истории или свой порядок" }
        "history" -> {
            val q = a.optString("q").trim().lowercase()
            vm.history.filter { e -> q.isEmpty() || day(e.date).lowercase().contains(q) || e.plan.header.lowercase().contains(q) ||
                e.plan.stops.any { it.point.display.lowercase().contains(q) } }.take(15)
                .joinToString("\n") { e -> listOf(e.id, day(e.date), if (e.layout) "раскладка" else "поездка", e.plan.stops.size, e.plan.header.take(90)).joinToString("|") }
                .ifBlank { "ничего не найдено" }
        }
        "history_order" -> vm.history.firstOrNull { it.id == a.optLong("id") }?.plan?.stops?.withIndex()
            ?.joinToString("\n") { (i, s) -> "${i + 1}|${s.point.display}|${s.point.address}" } ?: "нет такого листа"
        "drive" -> {
            val names = a.optJSONArray("points")?.let { arr -> (0 until arr.length()).map { arr.optString(it) } }.orEmpty()
            val pts = names.map { n -> if (n.equals("склад", true)) (vm.plan?.depot ?: error("склад не задан")) else pointBy(n) }
            if (pts.size < 2) error("нужно хотя бы две точки")
            val legs = vm.driveLegs(pts)
            legs.withIndex().joinToString("\n") { (i, l) ->
                "${pts[i].display} → ${pts[i + 1].display}: ${"%.0f".format(l.first)} мин, ${"%.1f".format(l.second)} км (${l.third})" } +
                "\nИТОГО: ${"%.0f".format(legs.sumOf { it.first })} мин, ${"%.1f".format(legs.sumOf { it.second })} км"
        }
        "agents" -> vm.agents.joinToString("\n") { listOf(it.num, it.name, it.phone, channel(it.phone)).joinToString("|") }.ifBlank { "торговых на листе нет" }
        else -> "нет такого инструмента: $name"
    }

    private fun agentBy(q: String): Agent? {
        val t = q.trim().lowercase(); if (t.isEmpty()) return null
        return vm.agents.firstOrNull { it.num == t } ?: vm.agents.firstOrNull { it.name.lowercase().contains(t) || t.contains(it.name.lowercase().substringBefore(' ')) }
            ?: Inbox.digits(t).takeIf { it.length == 10 }?.let { d -> vm.agents.firstOrNull { Inbox.digits(it.phone) == d } ?: Agent(name = q, phone = q) }
    }

    private fun day(t: Long) = java.text.SimpleDateFormat("EEEE d MMMM HH:mm", java.util.Locale("ru")).format(java.util.Date(t))
    private fun orderArg(a: JSONObject): List<Int> = a.optJSONArray("order")?.let { arr -> (0 until arr.length()).map { arr.optInt(it) } }.orEmpty()
    private fun orderPreview(o: List<Int>): String {
        val st = vm.plan?.stops ?: return o.joinToString(", ")
        return o.take(6).joinToString(" → ") { st.getOrNull(it - 1)?.point?.display ?: "$it" } + if (o.size > 6) " → …" else ""
    }

    /** Применить порядок (индексы остановок текущего плана с 0) и вернуть откат к прежнему. */
    private fun reorder(idx: List<Int>, what: String): Pair<String, (() -> String)?> {
        val p = vm.plan ?: error("раскладки нет")
        if (vm.started) error("поездка уже начата — порядок не меняю")
        if (idx.size != p.stops.size || idx.toSet() != p.stops.indices.toSet()) error("порядок должен включать каждую точку ровно один раз")
        val before = p.stops.map { it.point.name }
        vm.applyOrder(idx, remember = false)
        return what to {
            val cur = vm.plan?.stops?.map { it.point.name }.orEmpty()
            val back = before.mapNotNull { n -> cur.indexOf(n).takeIf { it >= 0 } }
            if (back.size == cur.size) { vm.applyOrder(back, remember = false); "порядок как был" } else "порядок уже другой — откатить нельзя"
        }
    }

    private fun pointLine(p: Point) = listOf(p.name, p.display, p.address, if (p.hasCoords) "${p.lat},${p.lon}" else "без координат",
        "позывные: " + vm.db.callsignsOf(p.name).joinToString(",").ifBlank { "нет" }).joinToString("|")

    // ---------- менять (после «Да») ----------
    private suspend fun act(name: String, a: JSONObject): Pair<String, (() -> String)?> = when (name) {
        "edit_row" -> {
            val r = rowById(a); val v = a.optString("value")
            val n = when (a.optString("field")) {
                "callsign" -> r.copy(callsign = v); "client" -> r.copy(client = v); "address" -> r.copy(address = v)
                "invoice" -> r.copy(invoice = v); "weight" -> r.copy(weight = v.replace(',', '.').toDoubleOrNull() ?: error("вес не число: $v"))
                "fact" -> r.copy(fact = v); "notes" -> r.copy(notes = v); "agent" -> r.copy(agent = v)
                else -> error("нет поля ${a.optString("field")}")
            }
            vm.update(n); vm.saveDraft()
            "${fieldName(a.optString("field"))} в строке ${r.invoiceLabel} → «$v»" to { vm.update(r); vm.saveDraft(); "строка ${r.invoiceLabel} как была" }
        }
        "set_address" -> {
            val p = pointBy(a.optString("point")); val v = a.optString("address").trim()
            vm.db.addPoint(p.copy(address = v)); vm.dbVer++
            "адрес «${p.display}» → $v" to { vm.db.addPoint(p); vm.dbVer++; "адрес «${p.display}» снова ${p.address}" }
        }
        "set_coords" -> {
            val p = pointBy(a.optString("point"))
            val la = a.optDouble("lat"); val lo = a.optDouble("lon"); if (la.isNaN() || lo.isNaN()) error("нет координат")
            vm.db.addPoint(p.copy(lat = la, lon = lo)); vm.dbVer++
            "«${p.display}» поставлена в $la, $lo" to { vm.db.addPoint(p); vm.dbVer++; "«${p.display}» на старом месте" }
        }
        "geocode" -> {
            val p = pointBy(a.optString("point"))
            val g = withContext(Dispatchers.IO) { Net.geocode(p.address, vm.depotCoordsPublic()) } ?: error("адрес «${p.address}» не нашёлся")
            vm.db.addPoint(p.copy(lat = g.lat, lon = g.lon)); vm.dbVer++
            "«${p.display}» по адресу: ${g.lat}, ${g.lon}" + (if (g.precision != Net.Precision.HOUSE) " (приблизительно)" else "") to
                { vm.db.addPoint(p); vm.dbVer++; "«${p.display}» на старом месте" }
        }
        "link_callsign" -> {
            val cs = a.optString("cs").trim(); val p = pointBy(a.optString("point"))
            val old = vm.db.calls[vm.db.norm(cs)]
            vm.linkCallsign(cs, p.name)
            "$cs → «${p.display}»" to { if (old != null) vm.linkCallsign(cs, old) else vm.unlinkCallsign(cs); "$cs как был" + (old?.let { " (у «$it»)" } ?: "") }
        }
        "merge_new" -> {
            val g = vm.reviewGroups().firstOrNull { it.key == a.optString("group") } ?: error("нет группы ${a.optString("group")}")
            val p = pointBy(a.optString("point"))
            vm.mergeNewInto(g, p.name)
            "«${g.title}» слита с «${p.display}»" to null
        }
        "move_stop" -> {
            val p = vm.plan ?: error("раскладки нет")
            val f = a.optInt("from") - 1; val t = a.optInt("to") - 1
            if (f !in p.stops.indices || t !in p.stops.indices) error("нет места ${a.opt("from")} или ${a.opt("to")}")
            val o = p.stops.indices.toMutableList(); val x = o.removeAt(f); o.add(t, x)
            reorder(o, "«${p.stops[f].point.display}» теперь ${t + 1}-я")
        }
        "set_order" -> reorder(orderArg(a).map { it - 1 }, "порядок изменён: " + orderPreview(orderArg(a)))
        "order_like" -> {
            val p = vm.plan ?: error("раскладки нет")
            val e = vm.history.firstOrNull { it.id == a.optLong("id") } ?: error("нет такого листа")
            val pos = e.plan.stops.withIndex().associate { (i, s) -> s.point.name to i }
            val o = p.stops.indices.sortedWith(compareBy({ pos[p.stops[it].point.name] ?: Int.MAX_VALUE }, { it }))
            val common = p.stops.count { it.point.name in pos }
            reorder(o, "порядок как ${day(e.date)} (общих точек $common из ${p.stops.size})")
        }
        "choose_variant" -> {
            val v = vm.variants.firstOrNull { it.variant.equals(a.optString("name"), true) } ?: error("нет варианта «${a.optString("name")}»")
            val before = vm.plan
            vm.chooseVariant(v)
            "выбран вариант «${v.variant}»" to { before?.let { vm.chooseVariant(it) }; "вариант как был" }
        }
        "send_sms" -> {
            val ag = agentBy(a.optString("to")) ?: error("нет торгового «${a.optString("to")}»")
            if (ag.phone.isBlank()) error("у ${ag.name} нет телефона")
            if (ctx.checkSelfPermission(android.Manifest.permission.SEND_SMS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                error("нет разрешения на SMS — разрешите в окне выше и попросите отправить ещё раз")
            val num = Inbox.digits(ag.phone).let { if (it.length == 10) "+7$it" else ag.phone }
            val sm = if (android.os.Build.VERSION.SDK_INT >= 31) ctx.getSystemService(android.telephony.SmsManager::class.java) else @Suppress("DEPRECATION") android.telephony.SmsManager.getDefault()
            val text = a.optString("text")
            sm.sendMultipartTextMessage(num, null, sm.divideMessage(text), null, null)
            Inbox.watch(ctx, ag.name, ag.phone, "sms")
            "SMS ${ag.name} отправлено, жду ответ" to null
        }
        "open_max" -> {
            val ag = agentBy(a.optString("to"))
            val text = a.optString("text")
            val send = android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/plain").putExtra(android.content.Intent.EXTRA_TEXT, text)
                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            val max = listOf("ru.oneme.app").firstOrNull { runCatching { ctx.packageManager.getPackageInfo(it, 0) }.isSuccess }
            if (max != null) ctx.startActivity(android.content.Intent(send).setPackage(max))
            else ctx.startActivity(android.content.Intent.createChooser(send, "Отправить в Max").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
            ag?.let { Inbox.watch(ctx, it.name, it.phone, "max") }
            "открыл Max — выбери чат ${ag?.name.orEmpty()} и нажми «Отправить»" to null
        }
        "set_channel" -> {
            val ag = agentBy(a.optString("to")) ?: error("нет торгового «${a.optString("to")}»")
            val via = if (a.optString("via") == "max") "max" else "sms"
            val old = channel(ag.phone)
            ctx.getSharedPreferences("inbox", 0).edit().putString(chKey(ag.phone), via).apply()
            "${ag.name}: по умолчанию ${if (via == "max") "Max" else "SMS"}" to { ctx.getSharedPreferences("inbox", 0).edit().putString(chKey(ag.phone), old).apply(); "${ag.name}: как было" }
        }
        "remember_order" -> {
            val p = vm.plan ?: error("раскладки нет")
            vm.applyOrder(p.stops.indices.toList(), remember = true)
            "порядок запомнен" to null
        }
        else -> error("нет действия $name")
    }
}
