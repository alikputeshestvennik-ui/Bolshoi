package ru.marshrut

data class Row(
    val id: Int,
    val callsign: String = "",
    val weight: Double = 0.0,
    val fact: String = "",
    val calc: String = "",
    val extra: String = "",
    val agent: String = "",
    val client: String = "",
    val address: String = "",
    val invoice: String = ""
) {
    /** Правило: ручной выбор точки только если «Факт» не пуст и не ноль и/или в «Расчет» стоит ЧЗ. Остальные коды (ПМ и др.) не мешают поиску по базе. */
    val isReturn get() = invoice.contains("возврат", true)
    val isEquipment get() = invoice.contains("оборудован", true)
    val factSum get() = fact.toD()?.takeIf { it != 0.0 } ?: 0.0
    val needsChoice: Boolean
        get() {
            fun filled(v: String): Boolean {
                val t = v.trim().replace(',', '.')
                if (t.isEmpty() || t == "-" || t == "—" || t == "–") return false
                return t.toDoubleOrNull()?.let { it != 0.0 } ?: true
            }
            return filled(fact) || calc.uppercase().contains("ЧЗ")
        }
}

data class Agent(val num: String = "", val name: String = "", val phone: String = "")

data class Recognized(val agents: List<Agent>, val rows: List<Row>, val header: String, val total: Double?, val totalNoSg: Double?, val truncated: Boolean = false)

data class Point(val name: String, val address: String = "", val lat: Double = 0.0, val lon: Double = 0.0, val title: String = "") {
    val label get() = listOf(title, address).filter { it.isNotBlank() }.joinToString(", ")
    val hasCoords get() = !(lat == 0.0 && lon == 0.0)
}

data class PlanStop(
    val point: Point,
    val callsigns: List<String>,
    val agents: List<String>,
    val weight: Double,
    val fact: Double,
    val remaining: Double,
    val rows: List<Row> = emptyList()
)

data class Plan(val stops: List<PlanStop>, val distanceKm: Double, val links: List<String>)

fun String.toD(): Double? = trim().replace(',', '.').replace(" ", "").toDoubleOrNull()
fun fmt(d: Double): String = String.format(java.util.Locale.US, "%.3f", d).trimEnd('0').trimEnd('.')
