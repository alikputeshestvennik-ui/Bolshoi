package ru.marshrut

data class Row(
    val id: Int,
    val callsign: String = "",
    val weight: Double = 0.0,
    val fact: String = "",
    val calc: String = "",
    val extra: String = "",
    val agent: String = "",
    val client: String = "",
    val address: String = "",
    val invoice: String = ""
) {
    val needsChoice: Boolean
        get() {
            val f = fact.trim().replace(',', '.')
            val factSet = f.isNotEmpty() && f != "-" && f != "—" && (f.toDoubleOrNull()?.let { it != 0.0 } ?: true)
            return factSet || calc.uppercase().contains("ЧЗ")
        }
}

data class Agent(val num: String = "", val name: String = "", val phone: String = "")

data class Recognized(val agents: List<Agent>, val rows: List<Row>, val header: String, val total: Double?, val totalNoSg: Double?)

data class Point(val name: String, val address: String = "", val lat: Double = 0.0, val lon: Double = 0.0) {
    val hasCoords get() = !(lat == 0.0 && lon == 0.0)
}

data class PlanStop(
    val point: Point,
    val callsigns: List<String>,
    val agents: List<String>,
    val weight: Double,
    val fact: Double,
    val remaining: Double
)

data class Plan(val stops: List<PlanStop>, val distanceKm: Double, val links: List<String>)

fun String.toD(): Double? = trim().replace(',', '.').replace(" ", "").toDoubleOrNull()
fun fmt(d: Double): String = String.format(java.util.Locale.US, "%.3f", d).trimEnd('0').trimEnd('.')
