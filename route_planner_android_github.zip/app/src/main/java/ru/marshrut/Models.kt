package ru.marshrut

import java.util.Locale

/** Тип строки маршрутного листа по тексту в колонке накладной. */
enum class Kind { GOODS, RETURN, EQUIPMENT }

/** Направление оборудования, уточняется пользователем. */
enum class EquipDir { UNKNOWN, PICKUP, DELIVER }

data class Row(
    val id: Int,
    val callsign: String = "",
    val weight: Double = 0.0,
    val fact: String = "",
    val calc: String = "",
    val notes: String = "",
    val sum: String = "",
    val agent: String = "",
    val client: String = "",
    val address: String = "",
    val invoice: String = "",
    val equip: EquipDir = EquipDir.UNKNOWN
) {
    /** «оборуд» ловит и опечатки окончаний (оборудлвание, оборудование, оборуд.) */
    val isEquipment get() = invoice.contains("оборуд", true) || invoice.contains("обрудов", true)
    val isReturn get() = !isEquipment && invoice.contains("возврат", true)
    val kind get() = when { isEquipment -> Kind.EQUIPMENT; isReturn -> Kind.RETURN; else -> Kind.GOODS }
    val factSum get() = fact.toD()?.takeIf { it != 0.0 } ?: 0.0

    /** Правило: ручной выбор точки, если «Факт» не пуст и не ноль и/или в «Расчет» стоит ЧЗ. */
    val needsChoice: Boolean
        get() {
            fun filled(v: String): Boolean {
                val t = v.trim().replace(',', '.')
                if (t.isEmpty() || t == "-" || t == "—" || t == "–") return false
                return t.toDoubleOrNull()?.let { it != 0.0 } ?: true
            }
            return filled(fact) || calc.uppercase().contains("ЧЗ")
        }

    /** Заметка для показа: служебные пометки вида «переподписать…» скрываем. */
    val visibleNotes: String get() = if (notes.contains("переподпис", true) || notes.contains("перподпис", true)) "" else notes

    /** Только последние 4 цифры номера возвратной накладной. */
    val returnTail: String
        get() {
            val digits = Regex("\\d+").findAll(invoice).map { it.value }.maxByOrNull { it.length }.orEmpty()
            return if (digits.isEmpty()) "" else digits.takeLast(4)
        }

    /** Как показывать накладную пользователю. */
    val invoiceLabel: String
        get() = when (kind) {
            Kind.RETURN -> if (returnTail.isEmpty()) "Возврат" else "Возврат …$returnTail"
            Kind.EQUIPMENT -> "Оборудование"
            Kind.GOODS -> invoice.ifBlank { "Накладная" }
        }
}

data class Agent(val num: String = "", val name: String = "", val phone: String = "")

data class Recognized(val agents: List<Agent>, val rows: List<Row>, val header: String, val total: Double?, val totalNoSg: Double?, val truncated: Boolean = false)

data class Point(
    val name: String,
    val address: String = "",
    val lat: Double = 0.0,
    val lon: Double = 0.0,
    val title: String = "",
    /** Комментарий к выгрузке из листа «Точки» (необязательная колонка). */
    val comment: String = ""
) {
    val label get() = listOf(title, address).filter { it.isNotBlank() }.joinToString(", ")
    val display get() = title.ifBlank { name }
    val hasCoords get() = !(lat == 0.0 && lon == 0.0)
}

data class PlanStop(
    val point: Point,
    val callsigns: List<String>,
    val contacts: List<Agent>,
    val weight: Double,
    val fact: Double,
    val remaining: Double,
    val rows: List<Row> = emptyList(),
    /** Отрезок от предыдущей точки (или от старта). */
    val legKm: Double = 0.0,
    val legMin: Double = 0.0
) {
    val returns get() = rows.filter { it.kind == Kind.RETURN }
    val equipment get() = rows.filter { it.kind == Kind.EQUIPMENT }
    val goods get() = rows.filter { it.kind == Kind.GOODS }
}

/** Точка, исключённая правилом «только возврат, товара нет». */
data class Excluded(val title: String, val callsign: String, val label: String)

data class Plan(
    val stops: List<PlanStop>,
    val distanceKm: Double,
    val durationMin: Double,
    val links: List<String>,
    val path: List<Pair<Double, Double>> = emptyList(),
    val depot: Point? = null,
    val excluded: List<Excluded> = emptyList(),
    val header: String = "",
    /** Финиш маршрута (склад) и последний отрезок до него. */
    val end: Point? = null,
    val endKm: Double = 0.0,
    val endMin: Double = 0.0
)

fun String.toD(): Double? = trim().replace(',', '.').replace(" ", "").replace("\u00A0", "").toDoubleOrNull()
fun fmt(d: Double): String = String.format(Locale.US, "%.3f", d).trimEnd('0').trimEnd('.')

/** 12500.5 -> «12 500,5» */
fun money(d: Double): String {
    val s = String.format(Locale.US, "%,.2f", d).replace(',', ' ').replace('.', ',')
    val t = s.removeSuffix(",00").let { if (it.endsWith("0") && it.contains(',')) it.dropLast(1) else it }
    return "$t\u00A0₽"
}

fun km(d: Double): String = if (d < 10) String.format(Locale.US, "%.1f", d).replace('.', ',') else String.format(Locale.US, "%.0f", d)

fun minutes(m: Double): String {
    val t = m.toInt().coerceAtLeast(1)
    return if (t < 60) "$t мин" else "${t / 60} ч ${t % 60} мин"
}
