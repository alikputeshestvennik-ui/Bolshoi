package ru.marshrut

import java.util.Locale

/** Тип строки маршрутного листа по тексту в колонке накладной. */
enum class Kind { GOODS, RETURN, EQUIPMENT }

/** Направление оборудования, уточняется пользователем. */
enum class EquipDir { UNKNOWN, PICKUP, DELIVER }

data class Row(
    val id: Int,
    val callsign: String = "",
    val weight: Double = 0.0,
    val fact: String = "",
    val calc: String = "",
    val notes: String = "",
    val sum: String = "",
    val agent: String = "",
    val client: String = "",
    val address: String = "",
    val invoice: String = "",
    val equip: EquipDir = EquipDir.UNKNOWN
) {
    /** «оборуд» ловит и опечатки окончаний (оборудлвание, оборудование, оборуд.) */
    val isEquipment get() = invoice.contains("оборуд", true) || invoice.contains("обрудов", true)
    val isReturn get() = !isEquipment && invoice.contains("возврат", true)
    val kind get() = when { isEquipment -> Kind.EQUIPMENT; isReturn -> Kind.RETURN; else -> Kind.GOODS }
    val factSum get() = fact.toD()?.takeIf { it != 0.0 } ?: 0.0

    /** Правило: ручной выбор точки, если «Факт» не пуст и не ноль и/или в «Расчет» стоит ЧЗ. */
    val needsChoice: Boolean
        get() {
            fun filled(v: String): Boolean {
                val t = v.trim().replace(',', '.')
                if (t.isEmpty() || t == "-" || t == "—" || t == "–") return false
                return t.toDoubleOrNull()?.let { it != 0.0 } ?: true
            }
            return filled(fact) || calc.uppercase().contains("ЧЗ")
        }

    /** Заметка для показа: служебные пометки вида «переподписать…» скрываем. */
    val visibleNotes: String get() = if (notes.contains("переподпис", true) || notes.contains("перподпис", true)) "" else notes

    /** Только последние 4 цифры номера возвратной накладной. */
    val returnTail: String
        get() {
            val digits = Regex("\\d+").findAll(invoice).map { it.value }.maxByOrNull { it.length }.orEmpty()
            return if (digits.isEmpty()) "" else digits.takeLast(4)
        }

    /** Как показывать накладную пользователю. */
    val invoiceLabel: String
        get() = when (kind) {
            Kind.RETURN -> if (returnTail.isEmpty()) "Возврат" else "Возврат …$returnTail"
            Kind.EQUIPMENT -> "Оборудование"
            Kind.GOODS -> invoice.ifBlank { "Накладная" }
        }
}

data class Agent(val num: String = "", val name: String = "", val phone: String = "")

data class Recognized(val agents: List<Agent>, val rows: List<Row>, val header: String, val total: Double?, val totalNoSg: Double?, val truncated: Boolean = false,
    /** Сколько строк, где нейросеть приняла сумму за факт, исправлено. */
    val factsCleared: Int = 0,
    /** Сколько позывных исправлено (номер «П/д» вместо позывного). */
    val callsFixed: Int = 0,
    /** Вес не сошёлся с итогом, лист перечитан с подсказкой. */
    val reread: Boolean = false,
    /** Расход нейросети на этот лист: все запросы, включая перечитывания и дочитывания. */
    val meter: Meter = Meter(),
    /** Вес груза по шапке листа (СГ + «без СГ») — запасной итог. */
    val headerTotal: Double? = null)

data class Point(
    val name: String,
    val address: String = "",
    val lat: Double = 0.0,
    val lon: Double = 0.0,
    val title: String = "",
    /** Комментарий к выгрузке из листа «Точки» (необязательная колонка). */
    val comment: String = ""
) {
    val label get() = listOf(title, address).filter { it.isNotBlank() }.joinToString(", ")
    /** Комментарий без служебных звёздочек. */
    val commentText get() = comment.replace("*", "").trim()
    /** «*» — по субботам приём до 13:00, «**» — до 12:00. Возвращает минуты от полуночи. */
    val saturdayLimitMin: Int? get() = when { comment.contains("**") -> 12 * 60; comment.contains("*") -> 13 * 60; else -> null }
    /** Плашка ограничения, если сегодня суббота. */
    val saturdayBadge: String? get() =
        if (isSaturday()) saturdayLimitMin?.let { "Приём до ${it / 60}:00" } else null
    val display get() = title.ifBlank { name }
    val hasCoords get() = !(lat == 0.0 && lon == 0.0)
}

data class PlanStop(
    val point: Point,
    val callsigns: List<String>,
    val contacts: List<Agent>,
    val weight: Double,
    val fact: Double,
    val remaining: Double,
    val rows: List<Row> = emptyList(),
    /** Отрезок от предыдущей точки (или от старта). */
    val legKm: Double = 0.0,
    val legMin: Double = 0.0
) {
    val returns get() = rows.filter { it.kind == Kind.RETURN }
    val equipment get() = rows.filter { it.kind == Kind.EQUIPMENT }
    val goods get() = rows.filter { it.kind == Kind.GOODS }
}

/** Точка, исключённая правилом «только возврат, товара нет». */
/** Строка, не попавшая в объезд, и причина. */
data class Excluded(
    val title: String, val callsign: String, val label: String, val reason: String = REASON_RETURN,
    /** Наличные по документу (для «заберёт торговый») и имя агента. */
    val cash: Double = 0.0, val agent: String = "", val phone: String = ""
) {
    companion object {
        const val REASON_RETURN = "Только возврат, товара нет"
        const val REASON_AGENT = "Заберёт торговый"
    }
}

data class Plan(
    val stops: List<PlanStop>,
    val distanceKm: Double,
    val durationMin: Double,
    val links: List<String>,
    val path: List<Pair<Double, Double>> = emptyList(),
    val depot: Point? = null,
    val excluded: List<Excluded> = emptyList(),
    val header: String = "",
    /** Финиш маршрута (склад) и последний отрезок до него. */
    val end: Point? = null,
    val endKm: Double = 0.0,
    val endMin: Double = 0.0,
    /** Название варианта маршрута, выбранного пользователем. */
    val variant: String = ""
) {
    val agentHandoff get() = excluded.filter { it.reason == Excluded.REASON_AGENT }
}

fun isSaturday(): Boolean = java.time.LocalDate.now().dayOfWeek == java.time.DayOfWeek.SATURDAY

fun String.toD(): Double? = trim().replace(',', '.').replace(" ", "").replace("\u00A0", "").toDoubleOrNull()
fun fmt(d: Double): String = String.format(Locale.US, "%.3f", d).trimEnd('0').trimEnd('.')

/** 12500.5 -> «12 500,5» */
fun money(d: Double): String {
    val s = String.format(Locale.US, "%,.2f", d).replace(',', ' ').replace('.', ',')
    val t = s.removeSuffix(",00").let { if (it.endsWith("0") && it.contains(',')) it.dropLast(1) else it }
    return "$t\u00A0₽"
}

fun km(d: Double): String = if (d < 10) String.format(Locale.US, "%.1f", d).replace('.', ',') else String.format(Locale.US, "%.0f", d)

fun minutes(m: Double): String {
    val t = m.toInt().coerceAtLeast(1)
    return if (t < 60) "$t мин" else "${t / 60} ч ${t % 60} мин"
}

/** Запись истории: снимок маршрута и чем он закончился. */
data class HistoryEntry(val id: Long, val date: Long, val plan: Plan, val done: Int, val aborted: Boolean)

/** Населённый пункт точки: «Гаспра, ул Мира, д 3» → «Гаспра». */
fun localityOf(p: Point): String =
    Net.splitAddress(p.address).place?.trim()?.ifBlank { null } ?: p.address.substringBefore(',').trim().ifBlank { p.display }

/** Посёлки по порядку объезда с числом точек: соседние точки одного посёлка — одно звено. */
fun routeLocalities(plan: Plan): List<Pair<String, Int>> {
    val out = ArrayList<Pair<String, Int>>()
    plan.stops.forEach { s ->
        val l = localityOf(s.point)
        if (out.isNotEmpty() && out.last().first.equals(l, ignoreCase = true)) out[out.size - 1] = out.last().first to out.last().second + 1
        else out.add(l to 1)
    }
    return out
}

/** Звено маршрута: подряд идущие точки одного посёлка — номера точек, вес, деньги, возвраты, дорога до него. */
data class RouteLeg(val place: String, val from: Int, val to: Int, val weight: Double, val cash: Double, val returns: Int, val km: Double, val min: Double)

fun routeLegs(plan: Plan): List<RouteLeg> {
    val out = ArrayList<RouteLeg>()
    plan.stops.forEachIndexed { i, s ->
        val l = localityOf(s.point)
        val last = out.lastOrNull()
        if (last != null && last.place.equals(l, ignoreCase = true))
            out[out.size - 1] = last.copy(to = i, weight = last.weight + s.weight, cash = last.cash + s.fact,
                returns = last.returns + s.returns.size, km = last.km + s.legKm, min = last.min + s.legMin)
        else out.add(RouteLeg(l, i, i, s.weight, s.fact, s.returns.size, s.legKm, s.legMin))
    }
    return out
}

/** Короткая сводка маршрута для водителя: куда едем, что тяжёлое, где деньги и возвраты. Без нейросети — из данных маршрута. */
fun routeSummary(plan: Plan): String {
    val sb = StringBuilder()
    if (plan.header.isNotBlank()) sb.append(plan.header.substringBefore(',').trim()).append('\n')
    sb.append(routeLocalities(plan).joinToString(" → ") { (l, n) -> if (n > 1) "$l ($n)" else l }).append('\n')
    sb.append("${plan.stops.size} точ. · ${km(plan.distanceKm)} км · ${minutes(plan.durationMin)} · ${fmt(plan.stops.sumOf { it.weight })} кг\n")
    plan.stops.withIndex().maxByOrNull { it.value.weight }?.let { (i, s) ->
        sb.append("Самое тяжёлое: ${s.point.display} — ${fmt(s.weight)} кг (точка ${i + 1})\n")
    }
    plan.stops.withIndex().filter { it.value.fact > 0 }.forEach { (i, s) ->
        sb.append("Деньги: ${s.point.display} — ${money(s.fact)} (точка ${i + 1})\n")
    }
    plan.stops.withIndex().filter { it.value.returns.isNotEmpty() }.forEach { (i, s) ->
        sb.append("Забрать возврат: ${s.point.display} (точка ${i + 1})\n")
    }
    return sb.toString().trim()
}
