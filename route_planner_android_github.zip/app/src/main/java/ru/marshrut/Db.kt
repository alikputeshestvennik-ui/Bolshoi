package ru.marshrut

import android.content.Context
import java.io.File
import java.io.InputStream
import java.io.OutputStream

/** БД: лист «Точки» (Название, Адрес, Широта, Долгота) и лист «Позывные» (Позывной, Точка). Связь по названию точки. */
class Db(private val ctx: Context) {
    val points = ArrayList<Point>()
    val calls = LinkedHashMap<String, String>() // нормализованный позывной -> название точки
    private val file get() = File(ctx.filesDir, "db.xlsx")

    init { if (file.exists()) runCatching { file.inputStream().use { load(it) } } }

    fun norm(s: String) = s.uppercase().filter { !it.isWhitespace() }
    fun point(name: String) = points.firstOrNull { it.name == name }
    fun pointFor(callsign: String): Point? = calls[norm(callsign)]?.let { point(it) }
    fun callsignsOf(name: String) = calls.filterValues { it == name }.keys.toList()

    private fun col(h: List<String>, vararg keys: String) =
        h.indexOfFirst { c -> keys.any { c.lowercase().contains(it) } }

    fun load(inp: InputStream) {
        val sheets = Xlsx.read(inp)
        val pts = sheets.entries.firstOrNull { it.key.trim().equals("Точки", true) }?.value ?: sheets.values.firstOrNull() ?: emptyList()
        val cls = sheets.entries.firstOrNull { it.key.trim().equals("Позывные", true) }?.value ?: sheets.values.drop(1).firstOrNull() ?: emptyList()
        val np = ArrayList<Point>(); val nc = LinkedHashMap<String, String>()
        if (pts.isNotEmpty()) {
            val h = pts[0]
            val cName = col(h, "назв", "точк").let { if (it < 0) 0 else it }
            val cAddr = col(h, "адрес").let { if (it < 0) 1 else it }
            val cLat = col(h, "шир", "lat"); val cLon = col(h, "долг", "lon", "lng"); val cBoth = col(h, "коорд")
            for (r in pts.drop(1)) {
                val name = r.getOrNull(cName)?.trim().orEmpty()
                if (name.isEmpty()) continue
                var lat = 0.0; var lon = 0.0
                if (cLat >= 0 && cLon >= 0) { lat = r.getOrNull(cLat)?.toD() ?: 0.0; lon = r.getOrNull(cLon)?.toD() ?: 0.0 }
                else if (cBoth >= 0) {
                    val n = Regex("-?\\d+[.,]\\d+").findAll(r.getOrNull(cBoth).orEmpty()).map { it.value.toD() ?: 0.0 }.toList()
                    if (n.size >= 2) { lat = n[0]; lon = n[1] }
                }
                np.add(Point(name, r.getOrNull(cAddr)?.trim().orEmpty(), lat, lon))
            }
        }
        if (cls.isNotEmpty()) {
            val h = cls[0]
            val cCall = col(h, "позыв").let { if (it < 0) 0 else it }
            val cPt = h.indices.firstOrNull { it != cCall } ?: 1
            for (r in cls.drop(1)) {
                val c = r.getOrNull(cCall)?.trim().orEmpty(); val p = r.getOrNull(cPt)?.trim().orEmpty()
                if (c.isNotEmpty() && p.isNotEmpty()) nc[norm(c)] = p
            }
        }
        points.clear(); points.addAll(np); calls.clear(); calls.putAll(nc)
    }

    fun write(o: OutputStream) {
        val pr = listOf(listOf("Название", "Адрес", "Широта", "Долгота")) +
            points.map { listOf(it.name, it.address, it.lat.toString(), it.lon.toString()) }
        val cr = listOf(listOf("Позывной", "Точка")) + calls.map { listOf(it.key, it.value) }
        Xlsx.write(o, listOf("Точки" to pr, "Позывные" to cr))
    }

    fun save() { file.outputStream().use { write(it) } }

    fun addPoint(p: Point) { points.removeAll { it.name == p.name }; points.add(p); save() }
    fun link(callsign: String, pointName: String) { calls[norm(callsign)] = pointName; save() }
}
