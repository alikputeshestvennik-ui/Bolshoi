package ru.marshrut

import android.content.Context
import java.io.File
import java.io.InputStream
import java.io.OutputStream

/** БД: лист «Точки» (Точка, Название, Адрес, Координаты «lat, lon») и лист «Позывные» (Позывной, Точка). Заголовок необязателен. */
class Db(private val ctx: Context) {
    val points = ArrayList<Point>()
    val calls = LinkedHashMap<String, String>() // нормализованный позывной -> название точки
    private val file get() = File(ctx.filesDir, "db.xlsx")

    init { if (file.exists()) runCatching { file.inputStream().use { load(it) } } }

    fun norm(s: String) = s.uppercase().filter { !it.isWhitespace() }
    fun point(name: String) = points.firstOrNull { it.name == name }
    fun pointFor(callsign: String): Point? = calls[norm(callsign)]?.let { point(it) }
    fun callsignsOf(name: String) = calls.filterValues { it == name }.keys.toList()

    private val num = Regex("^-?\\d+[.,]\\d+$")
    private val pair = Regex("^\\s*-?\\d+[.,]\\d+\\s*[;,\\s]\\s*-?\\d+[.,]\\d+\\s*$")
    private val headerWords = setOf("название", "адрес", "широта", "долгота", "координаты", "точка", "позывной", "позывные", "lat", "lon", "lng")
    private fun isHeader(r: List<String>) = r.any { it.trim().lowercase() in headerWords }

    /** Ищет координаты в строке: одна ячейка «lat, lon» или две отдельные числовые. Возвращает (lat, lon, индексы занятых ячеек). */
    private fun coordsOf(r: List<String>): Triple<Double, Double, Set<Int>>? {
        r.forEachIndexed { i, c ->
            if (pair.matches(c)) {
                val n = Regex("-?\\d+[.,]\\d+").findAll(c).map { it.value.toD() ?: 0.0 }.toList()
                if (n.size >= 2) return Triple(n[0], n[1], setOf(i))
            }
        }
        val idx = r.indices.filter { num.matches(r[it].trim()) }
        if (idx.size >= 2) return Triple(r[idx[0]].toD() ?: 0.0, r[idx[1]].toD() ?: 0.0, setOf(idx[0], idx[1]))
        return null
    }

    fun load(inp: InputStream) {
        val sheets = Xlsx.read(inp)
        val pts = sheets.entries.firstOrNull { it.key.trim().equals("Точки", true) }?.value ?: sheets.values.firstOrNull() ?: emptyList()
        val cls = sheets.entries.firstOrNull { it.key.trim().equals("Позывные", true) }?.value ?: sheets.values.drop(1).firstOrNull() ?: emptyList()
        val np = ArrayList<Point>(); val nc = LinkedHashMap<String, String>()
        // Формат листа «Точки»: [Точка, Название, Адрес, Координаты]; заголовок необязателен, колонки определяются по содержимому.
        for (r in pts) {
            if (r.all { it.isBlank() } || isHeader(r)) continue
            val name = r.getOrNull(0)?.trim().orEmpty()
            if (name.isEmpty()) continue
            val c = coordsOf(r.drop(1).let { rest -> listOf("") + rest })
            val used = c?.third ?: emptySet()
            val text = r.indices.drop(1).filter { it !in used && r[it].isNotBlank() }.map { r[it].trim() }
            val title = if (text.size >= 2) text[0] else ""
            val addr = if (text.size >= 2) text[1] else text.firstOrNull().orEmpty()
            np.add(Point(name, addr, c?.first ?: 0.0, c?.second ?: 0.0, title))
        }
        for (r in cls) {
            if (isHeader(r)) continue
            val c = r.getOrNull(0)?.trim().orEmpty(); val p = r.getOrNull(1)?.trim().orEmpty()
            if (c.isNotEmpty() && p.isNotEmpty()) nc[norm(c)] = p
        }
        points.clear(); points.addAll(np); calls.clear(); calls.putAll(nc)
    }

    fun write(o: OutputStream) {
        val pr = listOf(listOf("Точка", "Название", "Адрес", "Координаты")) +
            points.map { listOf(it.name, it.title, it.address, if (it.hasCoords) "${it.lat}, ${it.lon}" else "") }
        val cr = listOf(listOf("Позывной", "Точка")) + calls.map { listOf(it.key, it.value) }
        Xlsx.write(o, listOf("Точки" to pr, "Позывные" to cr))
    }

    fun save() { file.outputStream().use { write(it) } }

    fun addPoint(p: Point) { points.removeAll { it.name == p.name }; points.add(p); save() }
    fun link(callsign: String, pointName: String) { calls[norm(callsign)] = pointName; save() }
}
