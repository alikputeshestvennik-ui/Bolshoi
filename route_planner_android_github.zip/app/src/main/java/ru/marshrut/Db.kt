package ru.marshrut

import android.content.Context
import java.io.File
import java.io.InputStream
import java.io.OutputStream

/**
 * БД: лист «Точки» (Точка, Название, Адрес, Координаты «lat, lon», Комментарий) и лист «Позывные» (Позывной, Точка).
 * Заголовок необязателен. Колонка «Комментарий» необязательна — это комментарий к выгрузке на точке.
 */
class Db(private val ctx: Context) {
    companion object {
        const val SEED_VERSION = 2
        /** Латинские буквы, похожие на кириллические: распознавание иногда путает «C» и «С», «B» и «В». */
        private val LOOKALIKE = mapOf('A' to 'А', 'B' to 'В', 'C' to 'С', 'E' to 'Е', 'H' to 'Н', 'K' to 'К',
            'M' to 'М', 'O' to 'О', 'P' to 'Р', 'T' to 'Т', 'X' to 'Х', 'Y' to 'У')
    }
    val points = ArrayList<Point>()
    val calls = LinkedHashMap<String, String>() // нормализованный позывной -> название точки
    private val file get() = File(ctx.filesDir, "db.xlsx")
    private val bak get() = File(ctx.filesDir, "db.bak.xlsx")

    /** Итог обновления базы из xlsx. */
    data class MergeResult(val pointsUpdated: Int, val pointsAdded: Int, val callsUpdated: Int, val callsAdded: Int)

    /** Позывной без регистра, пробелов, «_» и «-», латиница-двойник → кириллица: «1583_ЯВ» = «1583 ЯВ» = «1583ЯВ», «127ЮC» = «127ЮС». */
    fun norm(s: String) = s.uppercase().filter { !it.isWhitespace() && it != '_' && it != '-' }.map { LOOKALIKE[it] ?: it }.joinToString("")
    fun point(name: String) = points.firstOrNull { it.name == name }
    fun pointFor(callsign: String): Point? = calls[norm(callsign)]?.let { point(it) }

    private val num = Regex("^-?\\d+[.,]\\d+$")
    private val pair = Regex("^\\s*-?\\d+[.,]\\d+\\s*[;,\\s]\\s*-?\\d+[.,]\\d+\\s*$")
    private val headerWords = setOf("название", "адрес", "широта", "долгота", "координаты", "точка", "позывной", "позывные",
        "комментарий", "комментарии", "комментарий к выгрузке", "lat", "lon", "lng")
    private fun isHeader(r: List<String>) = r.any { it.trim().lowercase() in headerWords }

    private fun pairOf(c: String): Pair<Double, Double>? {
        if (!pair.matches(c)) return null
        val n = Regex("-?\\d+[.,]\\d+").findAll(c).map { it.value.toD() ?: 0.0 }.toList()
        return if (n.size >= 2) n[0] to n[1] else null
    }

    /** Ищет координаты в строке: одна ячейка «lat, lon» или две отдельные числовые. */
    private fun coordsOf(r: List<String>): Triple<Double, Double, Set<Int>>? {
        r.forEachIndexed { i, c -> pairOf(c)?.let { return Triple(it.first, it.second, setOf(i)) } }
        val idx = r.indices.filter { num.matches(r[it].trim()) }
        if (idx.size >= 2) return Triple(r[idx[0]].toD() ?: 0.0, r[idx[1]].toD() ?: 0.0, setOf(idx[0], idx[1]))
        return null
    }

    /** Индексы колонок по заголовку, если он есть. */
    private class Cols(val name: Int, val title: Int, val addr: Int, val coords: Int, val lat: Int, val lon: Int, val comment: Int)

    private fun colsFrom(h: List<String>): Cols {
        fun find(vararg keys: String) = h.indexOfFirst { c -> val t = c.trim().lowercase(); keys.any { t.startsWith(it) } }
        return Cols(
            find("точка").let { if (it < 0) 0 else it }, find("назван"), find("адрес"),
            find("координат"), find("широт", "lat"), find("долгот", "lon", "lng"), find("коммент", "примеч")
        )
    }

    fun load(inp: InputStream) {
        val (np, nc) = parse(inp)
        points.clear(); points.addAll(np); calls.clear(); calls.putAll(nc)
    }

    /**
     * Обновление из xlsx того же формата. Точка совпала по коду или названию — переписывается
     * (пустые ячейки нового файла старые данные не стирают), иначе добавляется. Позывной — так же.
     * Всё, чего нет в новом файле, остаётся нетронутым.
     */
    fun merge(inp: InputStream): MergeResult {
        val (np, nc) = parse(inp)
        if (np.isEmpty() && nc.isEmpty()) error("Файл не похож на базу: нужны листы «Точки» и «Позывные» в том же формате")
        var pu = 0; var pa = 0; var cu = 0; var ca = 0
        for (p in np) {
            val i = points.indexOfFirst { it.name == p.name || (p.title.isNotBlank() && it.title.trim().equals(p.title.trim(), true)) }
            if (i < 0) { points.add(p); pa++; continue }
            val o = points[i]
            val m = Point(
                name = p.name,
                address = p.address.ifBlank { o.address },
                lat = if (p.hasCoords) p.lat else o.lat,
                lon = if (p.hasCoords) p.lon else o.lon,
                title = p.title.ifBlank { o.title },
                comment = p.comment.ifBlank { o.comment }
            )
            if (m != o) {
                points[i] = m; pu++
                // код точки сменился — переносим на него привязанные позывные
                if (o.name != m.name) calls.entries.forEach { e -> if (e.value == o.name) e.setValue(m.name) }
            }
        }
        for ((k, v) in nc) {
            val old = calls[k]
            if (old == null) { calls[k] = v; ca++ } else if (old != v) { calls[k] = v; cu++ }
        }
        return MergeResult(pu, pa, cu, ca)
    }

    /** Полная замена базы содержимым файла: всё, чего нет в файле, удаляется. */
    fun replace(inp: InputStream) {
        val (np, nc) = parse(inp)
        if (np.isEmpty()) error("Файл не похож на базу: нужны листы «Точки» и «Позывные» в том же формате")
        points.clear(); points.addAll(np); calls.clear(); calls.putAll(nc)
    }

    private fun parse(inp: InputStream): Pair<List<Point>, Map<String, String>> {
        val sheets = Xlsx.read(inp)
        val pts = sheets.entries.firstOrNull { it.key.trim().equals("Точки", true) }?.value ?: sheets.values.firstOrNull() ?: emptyList()
        val cls = sheets.entries.firstOrNull { it.key.trim().equals("Позывные", true) }?.value ?: sheets.values.drop(1).firstOrNull() ?: emptyList()
        val np = ArrayList<Point>(); val nc = LinkedHashMap<String, String>()
        var cols: Cols? = null
        for (r in pts) {
            if (r.all { it.isBlank() }) continue
            if (isHeader(r)) { cols = colsFrom(r); continue }
            fun cell(i: Int) = if (i < 0) "" else r.getOrNull(i)?.trim().orEmpty()
            val c = cols
            if (c != null) {
                val name = cell(c.name); if (name.isEmpty()) continue
                val ll = pairOf(cell(c.coords)) ?: run {
                    val la = cell(c.lat).toD(); val lo = cell(c.lon).toD()
                    if (la != null && lo != null) la to lo else null
                }
                np.add(Point(name, cell(c.addr), ll?.first ?: 0.0, ll?.second ?: 0.0, cell(c.title), cell(c.comment)))
                continue
            }
            val name = cell(0); if (name.isEmpty()) continue
            val d = cell(3)
            if (pairOf(d) != null || d.isEmpty()) {
                // Стандартная раскладка: A точка, B название, C адрес, D координаты, E… комментарий
                val ll = pairOf(d)
                val comment = r.drop(4).map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")
                np.add(Point(name, cell(2), ll?.first ?: 0.0, ll?.second ?: 0.0, cell(1), comment))
            } else {
                // Нестандартная раскладка — определяем колонки по содержимому
                val co = coordsOf(listOf("") + r.drop(1))
                val used = co?.third ?: emptySet()
                val lastCoord = used.maxOrNull() ?: Int.MAX_VALUE
                val before = r.indices.drop(1).filter { it !in used && it < lastCoord && r[it].isNotBlank() }.map { r[it].trim() }
                val after = r.indices.filter { it > lastCoord && r[it].isNotBlank() }.map { r[it].trim() }
                val title = if (before.size >= 2) before[0] else ""
                val addr = if (before.size >= 2) before[1] else before.firstOrNull().orEmpty()
                val extra = (if (before.size > 2) before.drop(2) else emptyList()) + after
                np.add(Point(name, addr, co?.first ?: 0.0, co?.second ?: 0.0, title, extra.joinToString("\n")))
            }
        }
        for (r in cls) {
            if (isHeader(r)) continue
            val c = r.getOrNull(0)?.trim().orEmpty(); val p = r.getOrNull(1)?.trim().orEmpty()
            if (c.isNotEmpty() && p.isNotEmpty()) nc[norm(c)] = p
        }
        return np to nc
    }

    fun write(o: OutputStream) {
        val pr = listOf(listOf("Точка", "Название", "Адрес", "Координаты", "Комментарий")) +
            points.map { listOf(it.name, it.title, it.address, if (it.hasCoords) "${it.lat}, ${it.lon}" else "", it.comment) }
        val cr = listOf(listOf("Позывной", "Точка")) + calls.map { listOf(it.key, it.value) }
        Xlsx.write(o, listOf("Точки" to pr, "Позывные" to cr))
    }

    /** База целиком как xlsx — для резервной копии. */
    fun bytes(): ByteArray = java.io.ByteArrayOutputStream().also { write(it) }.toByteArray()

    // ---------- общая база с другими телефонами ----------
    /** Снимок базы на момент последней синхронизации: по нему видно, что с тех пор поменяли на этом телефоне. */
    private val syncBase get() = File(ctx.filesDir, "db.sync.xlsx")
    /** Следующая синхронизация пойдёт как первая: общая база главнее, ничего не удаляется. */
    fun forgetSyncBase() { syncBase.delete() }

    private fun content(data: ByteArray) = data.inputStream().use { parse(it) }
    /** Совпадает ли xlsx по содержимому с базой телефона (сами файлы различаются временем внутри архива). */
    fun sameAs(data: ByteArray): Boolean = runCatching { content(data) == content(bytes()) }.getOrDefault(false)

    /**
     * Слияние с общей базой владельца. Что на этом телефоне поменяли или добавили сами (например, новую точку в рейсе) —
     * остаётся как здесь, всё остальное, в том числе правки и удаления владельца, берётся из общей базы.
     * Первая синхронизация ничего не удаляет: совпавшие точки переписываются общими, свои точки телефона добавляются.
     */
    @Synchronized fun syncWith(remote: ByteArray) {
        val base = syncBase.takeIf { it.exists() }?.let { f -> runCatching { content(f.readBytes()) }.getOrNull() }
        if (base == null) { runCatching { merge(remote.inputStream()) }; return }
        val (rp, rc) = content(remote)
        // Своя база — тоже через xlsx, чтобы сравнивать с образцом в одном и том же виде
        val (lp, lc) = content(bytes())
        val lpm = lp.associateBy { it.name }; val bpm = base.first.associateBy { it.name }; val rpm = rp.associateBy { it.name }
        val np = (lpm.keys + rpm.keys).mapNotNull { n -> if (lpm[n] != bpm[n]) lpm[n] else rpm[n] }
        val nc = LinkedHashMap<String, String>()
        (lc.keys + rc.keys).forEach { k -> (if (lc[k] != base.second[k]) lc[k] else rc[k])?.let { nc[k] = it } }
        points.clear(); points.addAll(np); calls.clear(); calls.putAll(nc)
    }

    /** Запоминает общую базу, с которой только что слились: следующий раз свои правки отличаются от неё. */
    fun markSynced(shared: ByteArray) { runCatching { syncBase.writeBytes(shared) } }

    /**
     * Сохранение без риска потерять базу: пишем во временный файл и только потом подменяем основной,
     * прошлая версия остаётся резервной. Если приложение выгрузят посреди записи, база не обнулится.
     */
    @Synchronized fun save() {
        val tmp = File(ctx.filesDir, "db.tmp.xlsx")
        tmp.outputStream().use { write(it) }
        if (file.exists()) file.copyTo(bak, overwrite = true)
        if (!tmp.renameTo(file)) { tmp.copyTo(file, overwrite = true); tmp.delete() }
        runCatching { exportCopy() }
    }

    /**
     * Копия базы в «Загрузки/Маршрут/marshrut_db.xlsx» — переживает удаление приложения.
     * После переустановки её можно вернуть кнопкой «Обновить из xlsx».
     */
    private fun exportCopy() {
        if (android.os.Build.VERSION.SDK_INT < 29) return
        val sp = ctx.getSharedPreferences("db", 0)
        val cr = ctx.contentResolver
        val saved = sp.getString("copy", null)?.let { android.net.Uri.parse(it) }
        if (saved != null && runCatching { cr.openOutputStream(saved, "wt")!!.use { write(it) } }.isSuccess) return
        val v = android.content.ContentValues().apply {
            put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, "marshrut_db.xlsx")
            put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "Download/Маршрут")
        }
        val uri = cr.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return
        cr.openOutputStream(uri, "wt")!!.use { write(it) }
        sp.edit().putString("copy", uri.toString()).apply()
    }

    /** Полная замена базы правками из редактора. */
    fun setAll(p: List<Point>, c: Map<String, String>) { points.clear(); points.addAll(p); calls.clear(); calls.putAll(c); save() }

    fun addPoint(p: Point) { points.removeAll { it.name == p.name }; points.add(p); save() }
    fun link(callsign: String, pointName: String) { calls[norm(callsign)] = pointName; save() }
    fun unlink(callsign: String) { calls.remove(norm(callsign)); save() }
    /** Позывные, привязанные к точке. */
    fun callsignsOf(pointName: String) = calls.filterValues { it == pointName }.keys.toList()

    // ВАЖНО: блок стоит в самом конце класса. Kotlin выполняет init по порядку объявления,
    // и раньше база читалась до того, как были созданы регулярки и список заголовков, — чтение падало молча.
    /** База пришла пустой или повреждённой и была заново заполнена встроенной. */
    var restored = false; private set

    init {
        val sp = ctx.getSharedPreferences("db", 0)
        // Основной файл, при сбое — резервная копия; пустая или битая база не считается загруженной
        val loaded = listOf(file, bak).any { f ->
            f.exists() && runCatching { f.inputStream().use { load(it) } }.isSuccess && points.isNotEmpty()
        }
        if (!loaded) { points.clear(); calls.clear() }
        // Встроенная база: если своей нет — как есть, на уже установленном приложении — один раз вливается поверх
        if (!loaded || sp.getInt("seed", 0) < SEED_VERSION) {
            runCatching {
                ctx.assets.open("db.xlsx").use { if (points.isEmpty() && calls.isEmpty()) load(it) else merge(it) }
                save()
                sp.edit().putInt("seed", SEED_VERSION).apply()
                restored = !loaded
            }
        }
    }
}
