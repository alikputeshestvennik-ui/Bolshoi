package ru.marshrut

import android.content.Context
import java.io.File
import java.io.InputStream
import java.io.OutputStream

/**
 * БД: лист «Точки» (Точка, Название, Адрес, Координаты «lat, lon», Комментарий) и лист «Позывные» (Позывной, Точка).
 * Заголовок необязателен. Колонка «Комментарий» необязательна — это комментарий к выгрузке на точке.
 */
class Db(private val ctx: Context) {
    val points = ArrayList<Point>()
    val calls = LinkedHashMap<String, String>() // нормализованный позывной -> название точки
    private val file get() = File(ctx.filesDir, "db.xlsx")

    init { if (file.exists()) runCatching { file.inputStream().use { load(it) } } }

    fun norm(s: String) = s.uppercase().filter { !it.isWhitespace() }
    fun point(name: String) = points.firstOrNull { it.name == name }
    fun pointFor(callsign: String): Point? = calls[norm(callsign)]?.let { point(it) }

    private val num = Regex("^-?\\d+[.,]\\d+$")
    private val pair = Regex("^\\s*-?\\d+[.,]\\d+\\s*[;,\\s]\\s*-?\\d+[.,]\\d+\\s*$")
    private val headerWords = setOf("название", "адрес", "широта", "долгота", "координаты", "точка", "позывной", "позывные",
        "комментарий", "комментарии", "комментарий к выгрузке", "lat", "lon", "lng")
    private fun isHeader(r: List<String>) = r.any { it.trim().lowercase() in headerWords }

    private fun pairOf(c: String): Pair<Double, Double>? {
        if (!pair.matches(c)) return null
        val n = Regex("-?\\d+[.,]\\d+").findAll(c).map { it.value.toD() ?: 0.0 }.toList()
        return if (n.size >= 2) n[0] to n[1] else null
    }

    /** Ищет координаты в строке: одна ячейка «lat, lon» или две отдельные числовые. */
    private fun coordsOf(r: List<String>): Triple<Double, Double, Set<Int>>? {
        r.forEachIndexed { i, c -> pairOf(c)?.let { return Triple(it.first, it.second, setOf(i)) } }
        val idx = r.indices.filter { num.matches(r[it].trim()) }
        if (idx.size >= 2) return Triple(r[idx[0]].toD() ?: 0.0, r[idx[1]].toD() ?: 0.0, setOf(idx[0], idx[1]))
        return null
    }

    /** Индексы колонок по заголовку, если он есть. */
    private class Cols(val name: Int, val title: Int, val addr: Int, val coords: Int, val lat: Int, val lon: Int, val comment: Int)

    private fun colsFrom(h: List<String>): Cols {
        fun find(vararg keys: String) = h.indexOfFirst { c -> val t = c.trim().lowercase(); keys.any { t.startsWith(it) } }
        return Cols(
            find("точка").let { if (it < 0) 0 else it }, find("назван"), find("адрес"),
            find("координат"), find("широт", "lat"), find("долгот", "lon", "lng"), find("коммент", "примеч")
        )
    }

    fun load(inp: InputStream) {
        val sheets = Xlsx.read(inp)
        val pts = sheets.entries.firstOrNull { it.key.trim().equals("Точки", true) }?.value ?: sheets.values.firstOrNull() ?: emptyList()
        val cls = sheets.entries.firstOrNull { it.key.trim().equals("Позывные", true) }?.value ?: sheets.values.drop(1).firstOrNull() ?: emptyList()
        val np = ArrayList<Point>(); val nc = LinkedHashMap<String, String>()
        var cols: Cols? = null
        for (r in pts) {
            if (r.all { it.isBlank() }) continue
            if (isHeader(r)) { cols = colsFrom(r); continue }
            fun cell(i: Int) = if (i < 0) "" else r.getOrNull(i)?.trim().orEmpty()
            val c = cols
            if (c != null) {
                val name = cell(c.name); if (name.isEmpty()) continue
                val ll = pairOf(cell(c.coords)) ?: run {
                    val la = cell(c.lat).toD(); val lo = cell(c.lon).toD()
                    if (la != null && lo != null) la to lo else null
                }
                np.add(Point(name, cell(c.addr), ll?.first ?: 0.0, ll?.second ?: 0.0, cell(c.title), cell(c.comment)))
                continue
            }
            val name = cell(0); if (name.isEmpty()) continue
            val d = cell(3)
            if (pairOf(d) != null || d.isEmpty()) {
                // Стандартная раскладка: A точка, B название, C адрес, D координаты, E… комментарий
                val ll = pairOf(d)
                val comment = r.drop(4).map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")
                np.add(Point(name, cell(2), ll?.first ?: 0.0, ll?.second ?: 0.0, cell(1), comment))
            } else {
                // Нестандартная раскладка — определяем колонки по содержимому
                val co = coordsOf(listOf("") + r.drop(1))
                val used = co?.third ?: emptySet()
                val lastCoord = used.maxOrNull() ?: Int.MAX_VALUE
                val before = r.indices.drop(1).filter { it !in used && it < lastCoord && r[it].isNotBlank() }.map { r[it].trim() }
                val after = r.indices.filter { it > lastCoord && r[it].isNotBlank() }.map { r[it].trim() }
                val title = if (before.size >= 2) before[0] else ""
                val addr = if (before.size >= 2) before[1] else before.firstOrNull().orEmpty()
                val extra = (if (before.size > 2) before.drop(2) else emptyList()) + after
                np.add(Point(name, addr, co?.first ?: 0.0, co?.second ?: 0.0, title, extra.joinToString("\n")))
            }
        }
        for (r in cls) {
            if (isHeader(r)) continue
            val c = r.getOrNull(0)?.trim().orEmpty(); val p = r.getOrNull(1)?.trim().orEmpty()
            if (c.isNotEmpty() && p.isNotEmpty()) nc[norm(c)] = p
        }
        points.clear(); points.addAll(np); calls.clear(); calls.putAll(nc)
    }

    fun write(o: OutputStream) {
        val pr = listOf(listOf("Точка", "Название", "Адрес", "Координаты", "Комментарий")) +
            points.map { listOf(it.name, it.title, it.address, if (it.hasCoords) "${it.lat}, ${it.lon}" else "", it.comment) }
        val cr = listOf(listOf("Позывной", "Точка")) + calls.map { listOf(it.key, it.value) }
        Xlsx.write(o, listOf("Точки" to pr, "Позывные" to cr))
    }

    fun save() { file.outputStream().use { write(it) } }

    fun addPoint(p: Point) { points.removeAll { it.name == p.name }; points.add(p); save() }
    fun link(callsign: String, pointName: String) { calls[norm(callsign)] = pointName; save() }
}
