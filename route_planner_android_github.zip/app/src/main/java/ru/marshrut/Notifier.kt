package ru.marshrut

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat

/**
 * Постоянное уведомление с текущим этапом маршрута.
 * На Android 16 запрашивается «продвижение» в Live Updates (статус-бар, экран блокировки, Now Bar там, где он поддерживает).
 */
object Notifier {
    private const val CH = "route_live"
    private const val ID = 4207

    private fun allowed(ctx: Context) =
        Build.VERSION.SDK_INT < 33 || ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun nm(ctx: Context): NotificationManager {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            nm.createNotificationChannel(NotificationChannel(CH, "Маршрут в пути", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Текущая точка и прогресс маршрута"
                setSound(null, null); enableVibration(false); setShowBadge(false)
            })
        }
        return nm
    }

    private fun open(ctx: Context) = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun nav(ctx: Context, p: Point) = PendingIntent.getActivity(
        ctx, 1, Intent(Intent.ACTION_VIEW, Uri.parse("https://yandex.ru/maps/?rtext=~${p.lat},${p.lon}&rtt=auto")),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun base(ctx: Context, title: String, text: String, chip: String) =
        NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_stat_route)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_NAVIGATION)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setColor(0xFF17181B.toInt())
            .setContentIntent(open(ctx))
            .also {
                // Live Updates (Android 16): ключи передаём строками, чтобы не зависеть от compileSdk
                it.extras.putBoolean("android.requestPromotedOngoing", true)
                it.extras.putString("android.shortCriticalText", chip)
            }

    fun stage(ctx: Context, plan: Plan, i: Int) {
        if (!allowed(ctx) || plan.stops.isEmpty()) return
        val s = plan.stops[i.coerceIn(0, plan.stops.lastIndex)]
        val n = plan.stops.size
        val left = plan.stops.drop(i + 1).sumOf { it.legKm } + plan.endKm
        val details = buildList {
            add("Выгрузить ${fmt(s.weight)} кг")
            if (s.fact > 0) add("Наличные ${money(s.fact)}")
            if (s.returns.isNotEmpty()) add("Забрать возврат")
            if (s.equipment.isNotEmpty()) add("Оборудование")
            s.point.saturdayBadge?.let { add(it) }
            if (s.point.commentText.isNotBlank()) add(s.point.commentText)
        }.joinToString("\n")
        val next = plan.stops.getOrNull(i + 1)?.point?.display
        val b = base(ctx, "${i + 1} из $n · ${s.point.display}", s.point.address.ifBlank { "Выгрузить ${fmt(s.weight)} кг" }, "${i + 1}/$n")
            .setSubText(if (left > 0) "ещё ${km(left)} км" else "последняя точка")
            .setProgress(n, i, false)
            .setStyle(NotificationCompat.BigTextStyle().bigText(details + if (next != null) "\nДальше: $next" else "\nДальше: склад"))
            .addAction(0, "Навигатор", nav(ctx, s.point))
        runCatching { nm(ctx).notify(ID, b.build()) }
    }

    fun toWarehouse(ctx: Context, plan: Plan) {
        val e = plan.end ?: return cancel(ctx)
        if (!allowed(ctx)) return
        val b = base(ctx, "Возвращаемся на склад", "${km(plan.endKm)} км, ${minutes(plan.endMin)}", "Склад")
            .setProgress(1, 1, false)
            .addAction(0, "Навигатор", nav(ctx, e))
        runCatching { nm(ctx).notify(ID, b.build()) }
    }

    fun cancel(ctx: Context) { runCatching { ctx.getSystemService(NotificationManager::class.java).cancel(ID) } }
}
