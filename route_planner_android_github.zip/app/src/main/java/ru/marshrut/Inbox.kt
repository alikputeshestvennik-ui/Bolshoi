package ru.marshrut

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject

/**
 * Ответы торговых для агента. Агент пишет торговому (SMS или Max) и «ждёт» его: входящее от этого человека
 * складывается сюда, показывается уведомлением и пересказывается агентом. Чужие SMS и уведомления не читаем.
 */
object Inbox {
    class Msg(val from: String, val text: String, val via: String, val ts: Long)
    /** Агент в памяти — сразу отдаём ему новое; иначе он заберёт при открытии. */
    @Volatile var listener: ((Msg) -> Unit)? = null

    private fun sp(ctx: Context) = ctx.getSharedPreferences("inbox", 0)
    fun digits(p: String) = p.filter { it.isDigit() }.takeLast(10)

    /** Ждём ответ: по номеру (SMS) или по имени (Max), сутки. */
    fun watch(ctx: Context, name: String, phone: String, via: String) {
        val a = JSONArray(sp(ctx).getString("watch", "[]"))
        val now = System.currentTimeMillis()
        val keep = JSONArray()
        for (i in 0 until a.length()) a.getJSONObject(i).let { if (now - it.optLong("ts") < 24 * 3600_000L && !(it.optString("name") == name && it.optString("via") == via)) keep.put(it) }
        keep.put(JSONObject().put("name", name).put("phone", digits(phone)).put("via", via).put("ts", now))
        sp(ctx).edit().putString("watch", keep.toString()).apply()
    }

    private fun watched(ctx: Context): List<JSONObject> {
        val a = JSONArray(sp(ctx).getString("watch", "[]")); val now = System.currentTimeMillis()
        return (0 until a.length()).map { a.getJSONObject(it) }.filter { now - it.optLong("ts") < 24 * 3600_000L }
    }

    fun incoming(ctx: Context, m: Msg) {
        val a = JSONArray(sp(ctx).getString("new", "[]"))
        a.put(JSONObject().put("from", m.from).put("text", m.text).put("via", m.via).put("ts", m.ts))
        sp(ctx).edit().putString("new", a.toString()).apply()
        notify(ctx, m)
        listener?.invoke(m)
    }

    /** Забрать непрочитанные ответы (агент перескажет их). */
    fun take(ctx: Context): List<Msg> {
        val a = JSONArray(sp(ctx).getString("new", "[]"))
        sp(ctx).edit().putString("new", "[]").apply()
        return (0 until a.length()).map { a.getJSONObject(it) }.map { Msg(it.optString("from"), it.optString("text"), it.optString("via"), it.optLong("ts")) }
    }

    /** Ответ по SMS от того, кому писали. */
    fun fromSms(ctx: Context, phone: String, text: String) {
        val d = digits(phone); if (d.length < 10) return
        val w = watched(ctx).firstOrNull { it.optString("via") == "sms" && it.optString("phone") == d } ?: return
        incoming(ctx, Msg(w.optString("name"), text, "SMS", System.currentTimeMillis()))
    }

    /** Уведомление Max: заголовок — имя собеседника. Берём, только если ждём ответа от похожего имени. */
    fun fromMax(ctx: Context, title: String, text: String) {
        fun words(s: String) = s.lowercase().replace('ё', 'е').split(Regex("[^\\p{L}]+")).filter { it.length >= 3 }
        val tw = words(title)
        val w = watched(ctx).firstOrNull { it.optString("via") == "max" && words(it.optString("name")).any { n -> n in tw } } ?: return
        incoming(ctx, Msg(w.optString("name"), text, "Max", System.currentTimeMillis()))
    }

    private fun notify(ctx: Context, m: Msg) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel("agent_inbox") == null)
            nm.createNotificationChannel(NotificationChannel("agent_inbox", "Ответы торговых", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(ctx, 7, Intent(ctx, MainActivity::class.java).putExtra("openAgent", true)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        runCatching {
            nm.notify((m.ts % 100000).toInt() + 5000, NotificationCompat.Builder(ctx, "agent_inbox")
                .setSmallIcon(R.drawable.ic_stat_route).setContentTitle("${m.from} ответил(а) · ${m.via}")
                .setContentText(m.text).setStyle(NotificationCompat.BigTextStyle().bigText(m.text))
                .setAutoCancel(true).setContentIntent(open).build())
        }
    }
}

/** Входящие SMS: передаём в Inbox, он сам решит, ждём ли мы ответа от этого номера. */
class SmsIn : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val parts = runCatching { Telephony.Sms.Intents.getMessagesFromIntent(intent) }.getOrNull() ?: return
        parts.groupBy { it.originatingAddress.orEmpty() }.forEach { (from, ms) ->
            Inbox.fromSms(ctx, from, ms.joinToString("") { it.messageBody.orEmpty() })
        }
    }
}

/** Уведомления мессенджера Max — только чтобы увидеть ответ торгового, которому писал агент. */
class MaxListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        val label = runCatching { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() }.getOrDefault("")
        if (!(pkg.contains("oneme", true) || label.equals("Max", true) || label.equals("Макс", true))) return
        val ex = sbn.notification.extras
        val title = ex.getCharSequence("android.title")?.toString().orEmpty()
        val text = (ex.getCharSequence("android.bigText") ?: ex.getCharSequence("android.text"))?.toString().orEmpty()
        if (title.isNotBlank() && text.isNotBlank()) Inbox.fromMax(this, title, text)
    }
}
