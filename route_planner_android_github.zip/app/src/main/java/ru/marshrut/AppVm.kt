package ru.marshrut

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

class AppVm(private val app: Application) : AndroidViewModel(app) {
    val st = Settings(app.getSharedPreferences("s", 0))
    val db = Db(app)
    var dbVer by mutableIntStateOf(0)

    var screen by mutableStateOf("home")
    val uris = mutableStateListOf<Uri>()
    var busy by mutableStateOf<String?>(null)
    var error by mutableStateOf<String?>(null)
    val agents = mutableStateListOf<Agent>()
    var sortByAgent by mutableStateOf(false)
    var header by mutableStateOf("")
    var total by mutableStateOf<Double?>(null)
    var totalNoSg by mutableStateOf<Double?>(null)
    private fun k(s: String) = s.uppercase().filter { !it.isWhitespace() }
    fun agentFor(num: String): Agent? = k(num).let { n -> if (n.isEmpty()) null else agents.firstOrNull { k(it.num) == n } }
    fun contactsOf(r: Row): List<Agent> = listOfNotNull(agentFor(r.agent))
    val rows = mutableStateListOf<Row>()
    val queue = mutableStateListOf<Int>()
    var qi by mutableIntStateOf(0)
    private val assigned = HashMap<Int, String>()
    var plan by mutableStateOf<Plan?>(null)

    // ---------- изображения ----------
    private fun jpeg(b: Bitmap): ByteArray {
        val m = 2000f / maxOf(b.width, b.height)
        val s = if (m < 1f) Bitmap.createScaledBitmap(b, (b.width * m).toInt(), (b.height * m).toInt(), true) else b
        return ByteArrayOutputStream().also { s.compress(Bitmap.CompressFormat.JPEG, 85, it) }.toByteArray()
    }

    private fun toJpegs(uri: Uri): List<ByteArray> {
        val cr = app.contentResolver
        val out = ArrayList<ByteArray>()
        if ((cr.getType(uri) ?: "").contains("pdf")) {
            cr.openFileDescriptor(uri, "r")!!.use { fd ->
                PdfRenderer(fd).use { r ->
                    for (i in 0 until r.pageCount) r.openPage(i).use { pg ->
                        val sc = 1800f / maxOf(pg.width, pg.height)
                        val bm = Bitmap.createBitmap((pg.width * sc).toInt(), (pg.height * sc).toInt(), Bitmap.Config.ARGB_8888)
                        bm.eraseColor(Color.WHITE)
                        pg.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        out.add(jpeg(bm))
                    }
                }
            }
        } else {
            var bm = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it) } ?: error("Не удалось открыть изображение")
            val rot = runCatching {
                cr.openInputStream(uri)!!.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) }
            }.getOrDefault(1)
            val deg = when (rot) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
            if (deg != 0f) bm = Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, Matrix().apply { postRotate(deg) }, true)
            out.add(jpeg(bm))
        }
        return out
    }

    // ---------- распознавание ----------
    fun recognize() {
        if (st.apiKey.isEmpty() || st.folder.isEmpty()) { error = "Укажите API-ключ и ID каталога в настройках"; return }
        viewModelScope.launch {
            busy = "Отправляем сканы в облако и распознаём…"; error = null
            try {
                val rec = withContext(Dispatchers.IO) { Net.recognize(st, uris.flatMap { toJpegs(it) }) }
                agents.clear(); agents.addAll(rec.agents); rows.clear(); rows.addAll(rec.rows)
                header = rec.header; total = rec.total; totalNoSg = rec.totalNoSg; screen = "review"
            } catch (e: Exception) { error = e.message ?: e.toString() } finally { busy = null }
        }
    }

    fun update(r: Row) { val i = rows.indexOfFirst { it.id == r.id }; if (i >= 0) rows[i] = r }
    fun addRow() { rows.add(Row((rows.maxOfOrNull { it.id } ?: -1) + 1)) }
    fun delRow(id: Int) { rows.removeAll { it.id == id } }

    // ---------- сопоставление ----------
    fun startMatch() {
        error = null; assigned.clear(); queue.clear(); qi = 0
        for (r in rows) {
            val p = if (r.callsign.isBlank() || r.needsChoice) null else db.pointFor(r.callsign)
            if (p == null) queue.add(r.id) else assigned[r.id] = p.name
        }
        if (queue.isEmpty()) buildRoute() else screen = "match"
    }

    fun choose(rowId: Int, pointName: String) {
        val r = rows.first { it.id == rowId }
        assigned[rowId] = pointName
        if (!r.needsChoice && r.callsign.isNotBlank() && db.calls[db.norm(r.callsign)] != pointName) { db.link(r.callsign, pointName); dbVer++ }
        next()
    }

    fun createPoint(rowId: Int, p: Point) { db.addPoint(p); dbVer++; choose(rowId, p.name) }
    fun skip() = next()
    private fun next() { qi++; if (qi >= queue.size) buildRoute() }

    // ---------- маршрут ----------
    fun buildRoute() {
        viewModelScope.launch {
            busy = "Строим маршрут…"; error = null
            try {
                val groups = rows.filter { assigned.containsKey(it.id) }.groupBy { assigned[it.id]!! }
                if (groups.isEmpty()) error("Нет точек для маршрута")
                val pts = groups.keys.map { db.point(it) ?: error("Точка «$it» не найдена в БД") }
                val noCoords = pts.filter { !it.hasCoords }
                if (noCoords.isNotEmpty()) error("Нет координат у точек: " + noCoords.joinToString { it.name } + ". Допишите в xlsx и импортируйте БД.")
                val depotNums = Regex("-?\\d+[.,]\\d+").findAll(st.depot).map { it.value.toD() ?: 0.0 }.toList()
                val depot = if (depotNums.size >= 2) Point("Старт", "", depotNums[0], depotNums[1]) else null
                val nodes = pts + listOfNotNull(depot)
                val w = DoubleArray(nodes.size) { i -> if (i < pts.size) groups[pts[i].name]!!.sumOf { it.weight } else 0.0 }
                val res = withContext(Dispatchers.IO) {
                    val m = Net.matrix(st, nodes)
                    val opt = Optimizer(m, w, st.capacity.toD() ?: 0.0, if (depot != null) nodes.size - 1 else null)
                    val o = opt.solve()
                    o to opt.distance(o)
                }
                val (order, dist) = res
                var load = w.sum(); val stops = ArrayList<PlanStop>()
                for (i in order) {
                    if (i >= pts.size) continue
                    val g = groups[pts[i].name]!!
                    load -= w[i]
                    stops.add(PlanStop(pts[i], g.map { it.callsign }.filter { it.isNotBlank() }.distinct(),
                        g.map { it.agent }.filter { it.isNotBlank() }.distinct(), w[i],
                        g.sumOf { it.fact.toD() ?: 0.0 }, load))
                }
                val seq = order.map { nodes[it] }
                val links = run {
                    val l = ArrayList<String>(); var s = 0
                    while (s < seq.size - 1 || (s == 0 && seq.size == 1)) {
                        val part = seq.subList(s, minOf(s + 10, seq.size))
                        l.add("https://yandex.ru/maps/?rtext=" + part.joinToString("~") { "${it.lat},${it.lon}" } + "&rtt=auto")
                        s += 9
                    }
                    l
                }
                plan = Plan(stops, dist / 1000.0, links); screen = "result"
            } catch (e: Exception) { error = e.message ?: e.toString(); screen = "home" } finally { busy = null }
        }
    }

    // ---------- БД ----------
    fun importDb(u: Uri) {
        try { app.contentResolver.openInputStream(u)!!.use { db.load(it) }; db.save(); dbVer++; error = null }
        catch (e: Exception) { error = "Не удалось импортировать БД (нужен .xlsx): ${e.message}" }
    }
    fun exportDb(u: Uri) {
        try { app.contentResolver.openOutputStream(u)!!.use { db.write(it) } } catch (e: Exception) { error = e.message }
    }
    fun geocode(addr: String, cb: (Pair<Double, Double>?) -> Unit) {
        viewModelScope.launch { cb(withContext(Dispatchers.IO) { runCatching { Net.geocode(addr) }.getOrNull() }) }
    }
}
