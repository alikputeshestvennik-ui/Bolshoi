package ru.marshrut

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/** Подготовленная страница листа и её миниатюра для экрана. */
class PageImg(val bmp: Bitmap) {
    val thumb: androidx.compose.ui.graphics.ImageBitmap by lazy {
        val k = 360f / maxOf(bmp.width, bmp.height)
        (if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true) else bmp)
            .asImageBitmap()
    }
}

class AppVm(private val app: Application) : AndroidViewModel(app) {
    val st = Settings(app.getSharedPreferences("s", 0))
    val usageLog = UsageLog(app.getSharedPreferences("s", 0))
    /** Меняется после каждого распознавания — экран настроек перечитывает расход. */
    var usageVer by mutableIntStateOf(0)
    val db = Db(app)
    private val store = Store(app)
    var dbVer by mutableIntStateOf(0)

    var screen by mutableStateOf(Screen.HOME)
    val uris = mutableStateListOf<Uri>()
    var busy by mutableStateOf<String?>(null)
    var error by mutableStateOf<String?>(null)
    val agents = mutableStateListOf<Agent>()
    var sortByAgent by mutableStateOf(false)
    var header by mutableStateOf("")
    var total by mutableStateOf<Double?>(null)
    var totalNoSg by mutableStateOf<Double?>(null)
    /** Номер агента по цифрам: «6», «6.», «№6», «6/» — один агент; без цифр — как написано. */
    private fun k(s: String) = s.filter { it.isDigit() }.trimStart('0').ifEmpty { s.uppercase().filter { !it.isWhitespace() } }
    fun agentFor(num: String): Agent? = k(num).let { n -> if (n.isEmpty()) null else agents.firstOrNull { k(it.num) == n } }
    fun contactsOf(r: Row): List<Agent> = listOfNotNull(agentFor(r.agent))
    /** Агенты, у которых накладная на товар с фактом или ЧЗ сомнительна: её может забрать торговый. */
    // «Наталич» нейросеть иногда читает как «Наталин» — ловим оба
    private val doubtfulAgents = listOf("горшков", "леонов", "мамедов", "мазалов", "наталич", "наталин")
    fun doubtfulAgent(r: Row): Boolean =
        (agentFor(r.agent)?.name.orEmpty() + " " + r.agent).lowercase().let { who -> doubtfulAgents.any { it in who } }
    /** Сомнительная строка: точку выбирают вручную (позывной не ищем по базе), есть вариант «Заберёт торговый». */
    fun manual(r: Row): Boolean = r.needsChoice && r.kind == Kind.GOODS && doubtfulAgent(r)
    val rows = mutableStateListOf<Row>()
    val queue = mutableStateListOf<Int>()
    var qi by mutableIntStateOf(0)
    private val assigned = HashMap<Int, String>()
    private val excludedRows = HashSet<Int>()
    /** Сомнительные строки с фактом, которые заберёт торговый представитель — в объезд не идут. */
    private val agentRows = HashSet<Int>()

    // ---------- ведение по маршруту ----------
    var plan by mutableStateOf<Plan?>(null)
    var stopIndex by mutableIntStateOf(0)
    var started by mutableStateOf(false)
    /** Направление последнего перехода между точками: 1 вперёд, -1 назад — для анимации. */
    var direction by mutableIntStateOf(1)
    /** Оплата наличных по точкам: индекс точки → оплатили / нет. */
    val paid = androidx.compose.runtime.mutableStateMapOf<Int, Boolean>()
    /** Частичные оплаты: на точке две фактовые накладные, а деньги дали за одну. */
    val paidAmount = androidx.compose.runtime.mutableStateMapOf<Int, Double>()
    /** Показать вопрос «Оплатили?» перед переходом к следующей точке. */
    var askPaid by mutableStateOf(false)
    /** Оплата документов, которые забирает торговый: индекс в plan.excluded → оплатили / нет. */
    val agentPaid = androidx.compose.runtime.mutableStateMapOf<Int, Boolean>()
    fun setAgentPaid(i: Int, v: Boolean) { agentPaid[i] = v; persist() }
    /** Документы, уже переданные торговому — пропадают из плашки по одному. */
    val handed = mutableStateListOf<Int>()
    fun handOver(i: Int, paidOk: Boolean?) {
        if (paidOk != null) agentPaid[i] = paidOk
        if (i !in handed) handed.add(i)
        persist()
    }
    /** Варианты маршрута, из которых выбирает пользователь. */
    val variants = mutableStateListOf<Plan>()
    fun chooseVariant(p: Plan) { if (!started) { plan = p; persist() } }

    // ---------- история ----------
    val history = mutableStateListOf<HistoryEntry>()
    var historyItem by mutableStateOf<HistoryEntry?>(null)

    private fun record(p: Plan, done: Int, aborted: Boolean) {
        val now = System.currentTimeMillis()
        history.add(0, HistoryEntry(now, now, p, done, aborted))
        store.saveHistory(history)
        autoBackup()
    }

    fun openHistory(e: HistoryEntry) { historyItem = e; screen = Screen.HISTORY_DETAIL }
    fun deleteHistory(e: HistoryEntry) { history.removeAll { it.id == e.id }; store.saveHistory(history); historyItem = null; screen = Screen.HISTORY }

    /** Снова поехать по сохранённому маршруту (тот же порядок точек). */
    fun repeatRoute(e: HistoryEntry) {
        Notifier.cancel(app)
        plan = e.plan; stopIndex = 0; started = false; aborted = false; variants.clear(); paid.clear(); agentPaid.clear(); handed.clear(); paidAmount.clear()
        store.save(Store.Session(e.plan, 0, false)); screen = Screen.OVERVIEW
    }

    init {
        history.addAll(store.history())
        store.load()?.let { s ->
            plan = s.plan; stopIndex = s.index.coerceIn(0, maxOf(0, s.plan.stops.size - 1)); started = s.started
            paid.putAll(s.paid); agentPaid.putAll(s.agentPaid); handed.addAll(s.handed); paidAmount.putAll(s.paidAmount)
            if (started) Notifier.stage(app, s.plan, stopIndex)
        }
    }

    val hasActiveRoute get() = plan != null && plan!!.stops.isNotEmpty()

    private fun persist() {
        plan?.let {
            store.save(Store.Session(it, stopIndex, started, paid.toMap(), agentPaid.toMap(), handed.toSet(), paidAmount.toMap()))
            if (started) Notifier.stage(app, it, stopIndex)
        }
    }

    /** Сгиб Galaxy Flip/Fold в положении «ноутбук»: верх и низ сгиба в пикселях окна, иначе null. */
    var fold by mutableStateOf<Pair<Int, Int>?>(null)

    /** Повторно показать уведомление (например, после выдачи разрешения). */
    fun refreshNotification() { plan?.let { if (started && screen != Screen.FINISH) Notifier.stage(app, it, stopIndex) } }

    // ---------- изображения ----------
    private val textReader by lazy {
        com.google.mlkit.vision.text.TextRecognition.getClient(com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    /** Сколько страниц автоматически повернули при последней подготовке. */
    private var turned = 0

    /**
     * Модели плохо читают повёрнутый лист, поэтому перед отправкой страницу ставим прямо.
     * 1) Телефон читает уменьшенную копию и по направлению строк (откуда и куда идёт текст)
     *    голосует за один из четырёх поворотов — длинные строки весят больше.
     * 2) Если голосование неуверенное, читаем лист во всех четырёх положениях и берём то,
     *    где распознаётся больше чисел (в маршрутном листе их много).
     * Автоматика может ошибиться, поэтому результат всегда показывается миниатюрой с кнопкой «Повернуть».
     */
    private fun autoAngle(bm: Bitmap): Int = runCatching {
        val k = 1200f / maxOf(bm.width, bm.height)
        val small = if (k < 1f) Bitmap.createScaledBitmap(bm, (bm.width * k).toInt(), (bm.height * k).toInt(), true) else bm
        fun read(deg: Int): com.google.mlkit.vision.text.Text = com.google.android.gms.tasks.Tasks.await(
            textReader.process(com.google.mlkit.vision.common.InputImage.fromBitmap(small, deg)), 20, java.util.concurrent.TimeUnit.SECONDS)
        val r0 = read(0)
        // Голосование по направлению строк: 0 — текст идёт слева направо, 90 — сверху вниз и т.д.
        val votes = DoubleArray(4)
        for (l in r0.textBlocks.flatMap { it.lines }) {
            val c = l.cornerPoints ?: continue
            if (c.size < 2 || l.text.count { it.isLetterOrDigit() } < 3) continue
            val dx = (c[1].x - c[0].x).toDouble(); val dy = (c[1].y - c[0].y).toDouble()
            val len = Math.hypot(dx, dy)
            if (len < 15) continue
            val ang = (Math.toDegrees(Math.atan2(dy, dx)) + 360) % 360
            votes[(((ang + 45) % 360) / 90).toInt()] += len
        }
        val total = votes.sum()
        val top = votes.indices.maxByOrNull { votes[it] } ?: 0
        if (total > 300 && votes[top] > total * 0.7) {
            // Текст идёт под углом top*90° по часовой — значит, лист надо повернуть на столько же против часовой
            return@runCatching (360 - top * 90) % 360
        }
        fun score(t: com.google.mlkit.vision.text.Text): Int {
            val words = t.textBlocks.flatMap { it.lines }.flatMap { it.elements }.map { it.text.trim('.', ',', ';', ':') }
            return words.sumOf { w -> w.count { it.isDigit() } } + words.count { Regex("^\\d{2,}([.,]\\d+)?$").matches(it) } * 6
        }
        listOf(0, 90, 180, 270).maxByOrNull { d -> score(if (d == 0) r0 else read(d)) } ?: 0
    }.getOrDefault(0)

    private fun rotated(bm: Bitmap, deg: Int): Bitmap =
        if (deg % 360 == 0) bm else Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, Matrix().apply { postRotate(deg.toFloat()) }, true)

    /** Страницы уже в том виде, в каком уйдут на распознавание. */
    val pages = mutableStateListOf<PageImg>()
    var preparing by mutableStateOf(false)

    /** Готовит выбранные страницы: открывает, выравнивает, показывает миниатюры. После сканера может сразу распознать. */
    fun prepare(autoStart: Boolean) {
        val list = uris.toList()
        viewModelScope.launch {
            busy = "Выравниваем страницы"; preparing = true; error = null; turned = 0; pages.clear()
            try {
                val ready = withContext(Dispatchers.IO) {
                    list.flatMap { toBitmaps(it) }.map { bm -> autoAngle(bm).let { d -> if (d != 0) turned++; PageImg(rotated(bm, d)) } }
                }
                pages.addAll(ready)
                if (turned > 0) info = "Повёрнуто страниц: $turned. Проверьте миниатюры — если что-то не так, нажмите «Повернуть»"
            } catch (e: Exception) { error = e.message ?: e.toString() } finally { busy = null; preparing = false }
            // После сканера распознаём сразу, но только если ничего не поворачивали — иначе ждём проверки
            if (autoStart && turned == 0 && pages.isNotEmpty()) recognize()
        }
    }

    /** Ручной поворот миниатюры на 90° по часовой. */
    fun rotatePage(i: Int) { if (i in pages.indices) pages[i] = PageImg(rotated(pages[i].bmp, 90)) }

    private fun jpeg(b: Bitmap): ByteArray {
        val m = 2000f / maxOf(b.width, b.height)
        val s = if (m < 1f) Bitmap.createScaledBitmap(b, (b.width * m).toInt(), (b.height * m).toInt(), true) else b
        return ByteArrayOutputStream().also { s.compress(Bitmap.CompressFormat.JPEG, 85, it) }.toByteArray()
    }

    /** Страница не больше 2000 px по длинной стороне — столько же уходит в нейросеть. */
    private fun fit(b: Bitmap): Bitmap {
        val m = 2000f / maxOf(b.width, b.height)
        return if (m < 1f) Bitmap.createScaledBitmap(b, (b.width * m).toInt(), (b.height * m).toInt(), true) else b
    }

    private fun toBitmaps(uri: Uri): List<Bitmap> {
        val cr = app.contentResolver
        val out = ArrayList<Bitmap>()
        if ((cr.getType(uri) ?: "").contains("pdf")) {
            cr.openFileDescriptor(uri, "r")!!.use { fd ->
                PdfRenderer(fd).use { r ->
                    for (i in 0 until r.pageCount) r.openPage(i).use { pg ->
                        val sc = 1800f / maxOf(pg.width, pg.height)
                        val bm = Bitmap.createBitmap((pg.width * sc).toInt(), (pg.height * sc).toInt(), Bitmap.Config.ARGB_8888)
                        bm.eraseColor(Color.WHITE)
                        pg.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        out.add(bm)
                    }
                }
            }
        } else {
            val bm = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it) } ?: error("Не удалось открыть изображение")
            val rot = runCatching {
                cr.openInputStream(uri)!!.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) }
            }.getOrDefault(1)
            out.add(rotated(fit(bm), when (rot) { 6 -> 90; 3 -> 180; 8 -> 270; else -> 0 }))
        }
        return out
    }

    // ---------- распознавание ----------
    fun recognize() {
        if (st.useGemini) {
            if (st.gptKey.isEmpty()) { error = "В сборке нет ключа gptunnel — добавьте секрет GPTUNNEL_KEY на GitHub"; return }
            if (st.gptModel.isBlank()) { error = "Впишите название модели gptunnel в настройках"; return }
        } else if (st.apiKey.isEmpty() || st.model.isEmpty() || st.folder.isEmpty()) { error = "В сборке нет ключа или модели Yandex — проверьте секреты YANDEX_API_KEY, DEEPSEEK_MODEL, QWEN_MODEL"; return }
        viewModelScope.launch {
            busy = "Отправляем сканы в облако"; error = null
            try {
                val imgs = pages.toList()
                if (imgs.isEmpty()) error("Сначала выберите или отсканируйте страницы")
                val jpegs = withContext(Dispatchers.IO) { imgs.map { jpeg(it.bmp) } }
                withContext(Dispatchers.IO) { saveScans(jpegs) }
                val t0 = System.currentTimeMillis()
                Net.reference = referenceForModel()
                val rec = withContext(Dispatchers.IO) { Net.recognize(st, jpegs, { i, n -> busy = "Распознаём страницу $i из $n" }, { busy = it }, ::splitsByNotes) }
                usageLog.add(rec.meter, Net.meterLog.toList()); usageVer++
                val took = "Распознано за ${((System.currentTimeMillis() - t0) / 1000.0).let { if (it < 10) String.format(java.util.Locale("ru"), "%.1f", it) else it.toInt().toString() }} с · " +
                    String.format(java.util.Locale("ru"), "%.2f ₽", rec.meter.rub)
                pins.clear()
                agents.clear(); agents.addAll(rec.agents); rows.clear(); rows.addAll(rec.rows); merged.clear(); mergeSel.clear()
                val shifted = fixShiftedRows()
                val checked = checkCallsigns() + shifted
                val learnedN = applyLearned()
                original = rows.associateBy { it.id }
                runCatching { java.io.File(scanDir, "header.txt").writeText(rec.header) }; scansHeader = rec.header
                header = rec.header; total = rec.total; totalNoSg = rec.totalNoSg; screen = Screen.REVIEW
                if (rec.reread) info = "Вес строк не сошёлся с итогом — лист перечитан, пропущенные строки найдены"
                if (rec.truncated) error = "Ответ модели обрезан на одной из страниц — проверьте, что все строки на месте."
                else if (checked > 0 || rec.callsFixed > 0) {
                    val left = rows.count { it.callsign.isBlank() || !it.callsign.any { c -> c.isLetter() } }
                    if (left == 0) info = "Позывные сверены с базой по адресам и клиентам: исправлено ${maxOf(checked, rec.callsFixed)}"
                    else error = "$left " + ru.marshrut.ui.plural(left, "строка", "строки", "строк") + " без позывного в базе — точки найдутся по адресу на карте"
                }
                else if (rec.factsCleared > 0) error = "Нейросеть приняла «Сумму» за «Факт» в ${rec.factsCleared} " +
                    ru.marshrut.ui.plural(rec.factsCleared, "строке", "строках", "строках") + " — факт там очищен. Проверьте строки, где наличные действительно брали."
                val took2 = if (learnedN > 0) "$took · учтены ваши исправления: $learnedN" else took
                info = info?.let { "$took2. $it" } ?: took2
            } catch (e: GeminiDown) { geminiDown = e.message
            } catch (e: Exception) { error = e.message ?: e.toString() } finally { busy = null; st.forceQwen = false }
        }
    }

    /** Gemini не ответил: показываем выбор вместо молчаливого перехода на Qwen. */
    var geminiDown by mutableStateOf<String?>(null)
    fun retryGemini() { geminiDown = null; recognize() }
    fun readWithQwen() { geminiDown = null; st.forceQwen = true; recognize() }

    // ---------- фото листа ----------
    private val scanDir get() = java.io.File(app.filesDir, "scan")
    /** Фото страниц последнего распознанного листа — смотреть в дороге, не доставая бумагу. */
    var scans by mutableStateOf(scanDir.listFiles()?.filter { it.name.endsWith(".jpg") }?.sortedBy { it.name }.orEmpty())
        private set
    private fun saveScans(jpegs: List<ByteArray>) {
        scanDir.mkdirs(); scanDir.listFiles()?.forEach { it.delete() }
        jpegs.forEachIndexed { i, b -> java.io.File(scanDir, "page_${i + 1}.jpg").writeBytes(b) }
        scans = scanDir.listFiles()?.filter { it.name.endsWith(".jpg") }?.sortedBy { it.name }.orEmpty()
    }
    var showScans by mutableStateOf(false)
    /** Лист, на котором Форд уже заезжал на экране проверки — повторно не играем. */
    var fordPlayed = ""
    /** Шапка листа, к которому относятся сохранённые фото: из истории другой маршрут — чужое фото не показываем. */
    var scansHeader by mutableStateOf(runCatching { java.io.File(scanDir, "header.txt").readText() }.getOrDefault(""))
        private set
    fun scansFor(header: String) = scans.isNotEmpty() && header.isNotBlank() && header == scansHeader

    /** Фото листа с пометками «от руки»: номера точек по порядку объезда, факт, возвраты. */
    var marked by mutableStateOf<List<java.io.File>>(emptyList())
        private set
    var marking by mutableStateOf(false)
        private set
    private val markDir get() = java.io.File(app.cacheDir, "marks")
    private val annotator by lazy { SheetAnnotator(app) }

    fun openScans() { showScans = true; markScans() }

    /** Размечает фото по текущему маршруту; если порядок точек не менялся — берёт готовые из кеша. */
    private fun markScans() {
        val p = plan
        if (p == null || !scansFor(p.header)) { marked = emptyList(); return }
        if (marking) return
        // Порядок строк в листе: номер строки по возрастанию id (так они шли при распознавании)
        // Берём все строки листа, включая не попавшие в объезд, — иначе между соседями «пропадают» строки
        val seqOf = (this.rows.map { it.id } + p.stops.flatMap { it.rows }.map { it.id }).distinct().sorted()
            .withIndex().associate { (i, id) -> id to i }
        val rows = p.stops.flatMapIndexed { i, s ->
            s.rows.map { r -> SheetRow(r.invoice, i + 1, r.fact.takeIf { r.factSum != 0.0 }, r.isReturn, r.weight, seqOf[r.id] ?: -1) }
        }
        val factTotal = p.stops.sumOf { s -> s.rows.sumOf { it.factSum } }
        val total = if (factTotal > 0) String.format(java.util.Locale.US, "%.2f", factTotal) else null
        val files = scans
        val sig = (files.map { it.name + it.lastModified() } + rows.map { "${it.invoice}|${it.order}|${it.fact}" } + listOf(total.orEmpty(), "v12"))
            .joinToString("\n").hashCode().toString()
        val sigFile = java.io.File(markDir, "sig.txt")
        val ready = files.map { java.io.File(markDir, it.name) }
        if (runCatching { sigFile.readText() }.getOrNull() == sig && ready.all { it.exists() }) { marked = ready; return }
        marked = emptyList(); marking = true
        viewModelScope.launch {
            try {
                withContext(Dispatchers.Default) {
                    markDir.deleteRecursively(); markDir.mkdirs()
                    // Сначала читаем все страницы: точка может начинаться на одной и продолжаться на другой
                    val read = files.map { f -> BitmapFactory.decodeFile(f.path)?.let { annotator.prepare(it, rows) } }
                    val on = read.map { pg -> pg?.let { annotator.ordersOn(it, rows) }.orEmpty() }
                    val seen = read.map { pg -> pg?.let { annotator.foundOn(it, rows) }.orEmpty() }
                    val weights = p.stops.mapIndexed { i, s -> (i + 1) to s.weight }.toMap()
                    read.forEachIndexed { i, pg ->
                        pg ?: return@forEachIndexed
                        val up = on.take(i).flatten().toSet()
                        val down = on.drop(i + 1).flatten().toSet()
                        val elsewhere = seen.filterIndexed { j, _ -> j != i }.flatten().toSet()
                        val out = annotator.draw(pg, rows, total, weights, up, down, elsewhere)
                        ready[i].outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                    }
                    sigFile.writeText(sig)
                }
                marked = ready.filter { it.exists() }.takeIf { it.size == files.size }.orEmpty()
            } catch (_: Exception) { marked = emptyList() } finally { marking = false }
        }
    }

    /** Назад к проверке листа из готового маршрута: точки, новые точки и метки на карте сохраняются. */
    fun backToReview() { if (rows.isNotEmpty()) screen = Screen.REVIEW else error = "Строки листа не сохранились — распознайте лист заново" }

    /**
     * Новые точки маршрута, которые предлагаем добавить в базу, — в конце рейса. Если приложение перезапускалось,
     * восстанавливаем их из самого маршрута: у новой точки временное имя с «＋».
     */
    fun newPointsAtFinish(): List<NewPoint> {
        if (newPoints.isNotEmpty()) return newPoints.toList()
        val p = plan ?: return emptyList()
        return p.stops.filter { it.point.name.startsWith("＋") }.filter { s ->
            // Уже добавлена раньше (повтор из истории) — позывные привязываем молча и не спрашиваем снова
            val ex = existingFor(s.point.title.ifBlank { s.point.name.removePrefix("＋") }, s.point) ?: return@filter true
            s.rows.map { it.callsign.trim() }.filter { it.isNotBlank() }.distinct().forEach { cs -> db.link(cs, ex.name) }
            dbVer++; false
        }.map { s ->
            fun signs(rs: List<Row>) = rs.map { it.callsign.trim() }.filter { it.isNotBlank() }.distinct()
            NewPoint(s.point, signs(s.rows), null, s.rows.groupBy { it.client.trim() }.map { (c, rs) -> Member(c.ifBlank { s.point.address }, signs(rs)) })
        }
    }
    var finishNewPointsShown by mutableStateOf(false)
    /** На экране завершения: один раз предложить добавить новые точки рейса в базу. */
    fun offerNewPointsAtFinish() {
        if (finishNewPointsShown) return
        finishNewPointsShown = true
        val list = newPointsAtFinish()
        newPoints.clear(); newPoints.addAll(list)
    }

    fun update(r: Row) { val i = rows.indexOfFirst { it.id == r.id }; if (i >= 0) rows[i] = r }
    fun addRow() { rows.add(Row((rows.maxOfOrNull { it.id } ?: -1) + 1)) }
    fun delRow(id: Int) { rows.removeAll { it.id == id } }

    /** Позывные, у которых в листе только возвраты без товара — в маршрут не идут. */
    private fun returnOnlyCallsigns(): Set<String> = rows.filter { it.callsign.isNotBlank() }
        .groupBy { db.norm(it.callsign) }.filterValues { g -> g.all { it.kind == Kind.RETURN } }.keys

    val returnOnlyCount get() = returnOnlyCallsigns().size

    // ---------- сопоставление ----------
    /** Точки, найденные по клиенту и адресу из листа: в маршрут идут сразу, в базу — если пользователь согласится. */
    private val tempPoints = LinkedHashMap<String, Point>()
    /** Новая точка из листа, позывные, которые к ней привяжутся, и пометка, если адрес найден неточно. */
    data class NewPoint(val point: Point, val callsigns: List<String>, val approx: String? = null,
        /** Разные клиенты по одному адресу: каждый со своими позывными. Больше одного — спрашиваем, объединять ли. */
        val members: List<Member> = emptyList())
    data class Member(val client: String, val callsigns: List<String>)

    // Без \b и флага (?U): в Android они работают иначе, чем в обычной Java, — границы слова задаём явно
    private val STREET_TYPE by lazy { Regex("(?iu)(?<![\\p{L}\\d])(шоссе|улица|ул|переулок|пер|проспект|пр-т|бульвар|бул|набережная|наб|проезд|тупик|площадь|пл|спуск|аллея)(?![\\p{L}\\d])\\.?") }
    private fun keyPart(s: String?) = s.orEmpty().lowercase().replace('ё', 'е').replace(STREET_TYPE, "").filter { it.isLetterOrDigit() }

    /** Один адрес, записанный по-разному («ул», «шоссе», «д.», «13-Ф» / «13Ф», запятые), даёт один ключ. */
    private fun addressKey(address: String): String =
        Net.splitAddress(address).let { a -> listOf(a.place, a.street, a.house).joinToString("|") { keyPart(it) } }
            .takeIf { it.replace("|", "").isNotBlank() } ?: address.trim().lowercase()
    /** Улица и дом без населённого пункта: в листе и в базе посёлок иногда назван по-разному (Курпаты / Гаспра). */
    private fun streetKey(address: String): String? =
        Net.splitAddress(address).let { a -> if (a.street == null || a.house == null) null else keyPart(a.street) + "|" + keyPart(a.house) }
    /** Фамилия или первое слово названия: «Тихонюк В.В. ИП» → «тихонюк». */
    private fun surname(s: String) = s.trim().split(' ', ',').firstOrNull().orEmpty().lowercase().replace('ё', 'е').takeIf { it.length >= 4 }
    /** Насколько неточно найдены адреса новых точек (ключ — временное имя точки). */
    private val tempNotes = HashMap<String, String>()
    /** После построения маршрута: новые точки, которые предлагаем добавить в базу. */
    val newPoints = mutableStateListOf<NewPoint>()

    private fun depotCoords(): Pair<Double, Double>? {
        val n = Regex("-?\\d+[.,]\\d+").findAll(st.depot).map { it.value.toD() ?: 0.0 }.toList()
        return if (n.size >= 2) n[0] to n[1] else null
    }

    /**
     * Позывной есть в базе — берём точку из базы. Нет — точкой становится клиент из листа, адрес переводим
     * в координаты. Не нашёлся адрес, нет ни позывного, ни адреса, или строка сомнительная — выбор вручную.
     */
    /**
     * Ручной выбор задаётся сразу группе накладных: одна точка на позывной (или на клиента с адресом).
     * Сомнительные строки (Горшков, Леонов, Мамедова, Мазалов) — каждая отдельно.
     * Ключ — первая строка группы, значение — все строки группы.
     */
    private val groups = HashMap<Int, List<Int>>()
    fun groupOf(rowId: Int): List<Row> = (groups[rowId] ?: listOf(rowId)).mapNotNull { id -> rows.firstOrNull { it.id == id } }

    /**
     * Позывные, под которыми в листе стоят разные адреса. Обычно это ошибка распознавания: на снятом под углом листе
     * строка без позывного получает позывной соседней точки. Таким позывным не доверяем: строку ведёт адрес,
     * а сам позывной в базу не запоминаем.
     */
    private val sharedCallsigns = HashSet<String>()

    private fun groupKey(r: Row) = when {
        r.callsign.isNotBlank() && db.norm(r.callsign) !in sharedCallsigns -> "c:" + db.norm(r.callsign)
        r.client.isNotBlank() || r.address.isNotBlank() -> "a:" + r.client.trim().lowercase() + "|" + r.address.trim().lowercase()
        else -> "r:" + r.id
    }

    /** Очередь ручного выбора: сомнительные строки по одной, остальные — группами. */
    private fun buildQueue(doubtful: List<Row>, pending: List<Row>) {
        queue.clear(); groups.clear()
        doubtful.forEach { queue.add(it.id) }
        pending.groupBy(::groupKey).values.forEach { g -> groups[g.first().id] = g.map { it.id }; queue.add(g.first().id) }
        queue.sortBy { id -> rows.indexOfFirst { it.id == id } }
    }

    /**
     * Поиск точки базы для строки листа. Позывному нейросеть может ошибиться (сдвиг строк на снятом под углом листе,
     * номер «П/д» вместо позывного), поэтому позывной принимается, только если адрес или фамилия клиента сходятся
     * с точкой; иначе точку ведут адрес, улица с домом и фамилия — только при однозначном совпадении.
     */
    private inner class DbIndex {
        /** Адрес по частям в виде ключей: посёлок, улица (без «ул», «шоссе»…), дом. */
        private inner class Parts(address: String) {
            private val a = Net.splitAddress(address)
            val place = keyPart(a.place).ifBlank { null }
            val street = keyPart(a.street).ifBlank { null }
            val house = keyPart(a.house).ifBlank { null }
            /** Слова улицы: «Братьев Говориных» → [братьев, говориных]. */
            val words = a.street.orEmpty().lowercase().replace('ё', 'е').replace(STREET_TYPE, " ")
                .split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 4 }
        }

        /**
         * Похожесть улиц: целиком, либо по самому похожему слову («Говыриных» и «Братьев Говориных» — 0,89),
         * либо одна целиком входит в другую («Ленина» в «пр. Ленина»).
         */
        private fun streetSim(a: Parts, b: Parts): Double {
            val sa = a.street ?: return 0.0; val sb = b.street ?: return 0.0
            var best = similarity(sa, sb)
            if (minOf(sa.length, sb.length) >= 5 && (sa.contains(sb) || sb.contains(sa))) best = maxOf(best, 0.9)
            for (x in a.words) for (y in b.words) if (minOf(x.length, y.length) >= 5) best = maxOf(best, similarity(x, y) - 0.02)
            return best
        }
        private val parts = db.points.associateWith { Parts(it.address) }
        private val bySurname = db.points.mapNotNull { p -> personSurname(p.title.ifBlank { p.name })?.let { it to p } }
            .groupBy({ it.first }, { it.second }).filterValues { it.size == 1 }.mapValues { it.value.first() }

        /**
         * Точка базы по адресу строки: похожая улица (опечатки и «Амет-Хан»/«Амет-Хана» прощаются) и тот же дом;
         * если таких несколько — выигрывает тот же посёлок, а при ничьей не выбираем никого.
         * Без адреса — по фамилии клиента-человека («Тихонюк В.В. ИП»), но не по названию фирмы.
         */
        fun find(r: Row): Point? {
            val rp = Parts(r.address)
            if (rp.street != null && rp.house != null) {
                val scored = parts.mapNotNull { (p, pp) ->
                    if (pp.street == null || !sameHouse(pp.house, rp.house)) return@mapNotNull null
                    val ss = streetSim(rp, pp)
                    if (ss < 0.8) null else p to ss + (if (rp.place != null && pp.place != null && similarity(rp.place, pp.place) >= 0.8) 1.0 else 0.0)
                }.sortedByDescending { it.second }
                if (scored.isNotEmpty() && (scored.size == 1 || scored[0].second - scored[1].second > 0.05)) return scored[0].first
            }
            return personSurname(r.client)?.let { bySurname[it] }
        }

        /**
         * Точка по позывному спорит со строкой, если улица явно другая (а не опечатка) или на той же улице
         * другой дом, где стоит другая точка базы, — так ловится позывной соседней строки на снятом под углом листе.
         * Сравнить не с чем — верим позывному.
         */
        fun consistent(p: Point, r: Row): Boolean {
            val rp = Parts(r.address); val pp = parts[p] ?: return true
            if (rp.street == null || pp.street == null) return true
            if (streetSim(rp, pp) >= 0.75) {
                // Та же улица, но другой дом, и в базе есть точка ровно по дому строки (Садовая 24 и Садовая 26) —
                // позывной соседней точки, а не опечатка
                if (rp.house != null && pp.house != null && !sameHouse(rp.house, pp.house)) {
                    val other = find(r)
                    if (other != null && other.name != p.name && sameHouse(parts[other]?.house, rp.house)) return false
                }
                return true
            }
            // Улица другая; допускаем только тот же клиент-человек
            val sn = personSurname(r.client)
            return sn != null && sn == personSurname(p.title.ifBlank { p.name })
        }

        /** «3б» и «36», «58б» и «586» — один дом: на скане «б» похожа на 6. */
        private fun sameHouse(a: String?, b: String?) = a != null && b != null && (a == b || a.replace('б', '6') == b.replace('б', '6'))

        /**
         * Позывной с одной перепутанной цифрой («85ЮВ» вместо «86ЮВ», «8БЮВ» вместо «86ЮВ»): берём вариант,
         * только если он единственный и точка базы стоит на той же улице того же посёлка, что и строка.
         */
        fun variant(r: Row): Pair<String, Point>? {
            val cs = db.norm(r.callsign); if (cs.isEmpty()) return null
            val rp = Parts(r.address); if (rp.street == null) return null
            val hits = LinkedHashMap<String, Pair<String, Point>>()
            for (i in cs.indices) {
                val alts = LOOK[cs[i]] ?: continue
                for (c in alts) {
                    val v = cs.substring(0, i) + c + cs.substring(i + 1)
                    val p = db.pointFor(v) ?: continue
                    val pp = parts[p] ?: continue
                    if (pp.street == null || streetSim(rp, pp) < 0.8) continue
                    if (rp.place != null && pp.place != null && similarity(rp.place, pp.place) < 0.8) continue
                    hits.getOrPut(p.name) { v to p }
                }
            }
            return hits.values.singleOrNull()
        }

        fun resolve(r: Row): Point? {
            val byCs = if (r.callsign.isBlank()) null else db.pointFor(r.callsign)
            if (byCs != null && consistent(byCs, r)) return branch(byCs, r)
            // Позывной меняем, только если по адресу нашлась другая точка базы; иначе верим позывному
            return (find(r) ?: byCs)?.let { branch(it, r) }
        }

        /**
         * Магазины одного клиента под одним позывным: «Евлохин Первый», «Евлохин Второй». Какой из них —
         * говорит цифра в «Заметках» строки: 2 — «Второй», 3 — «Третий», пусто или 1 — «Первый».
         */
        private fun branch(p: Point, r: Row): Point {
            val m = ORDINAL.find(p.display.trim()) ?: return p
            val n = Regex("(?<![\\d.,:/№-])([1-3])(?![\\d.,:/])").find(r.notes + " " + r.calc)?.groupValues?.get(1)?.toInt() ?: 1
            val want = listOf("перв", "втор", "трет")[n - 1]
            val base = m.groupValues[1].trim()
            return db.points.firstOrNull { q ->
                ORDINAL.find(q.display.trim())?.let { it.groupValues[1].trim().equals(base, true) && it.groupValues[2].lowercase().startsWith(want) } == true
            } ?: p
        }
    }

    /** Точка на трассе по адресу: ЮБШ, шоссе, трасса, Южнобережное («м-н Магистраль» — название магазина, не дорога). */
    private val ROAD_WORDS = Regex("(?iu)(юбш|шоссе|трасс|южнобережн)")

    /** «Евлохин Второй» → основа «Евлохин» и порядковое слово. */
    private val ORDINAL = Regex("^(.+?)\\s+(перв\\S*|втор\\S*|трет\\S*)$", RegexOption.IGNORE_CASE)

    /** Что на скане путается с символом позывного: 5↔6, 3↔8, 6↔Б и буквы маршрута ЮВ↔ЮС. */
    private val LOOK = mapOf('5' to "6", '6' to "58Б", '8' to "36", '3' to "8", 'Б' to "6", 'В' to "С", 'С' to "В")

    /** Похожесть строк 0…1 по расстоянию Левенштейна: «аметхансултана» и «аметханасултана» — 0,93. */
    private fun similarity(a: String, b: String): Double {
        if (a == b) return 1.0
        if (a.isEmpty() || b.isEmpty()) return 0.0
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1); cur[0] = i
            for (j in 1..b.length) cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            prev = cur
        }
        return 1.0 - prev[b.length].toDouble() / maxOf(a.length, b.length)
    }

    /** Фамилия, только если клиент — человек: «Тихонюк В.В. ИП» → «тихонюк»; «ФИРМА МИСС НАТАЛИ ООО», «ПУД ООО» → нет. */
    private val PERSON = Regex("^([А-ЯЁ][а-яё]+(?:-[А-ЯЁ][а-яё]+)?)\\s+[А-ЯЁ]\\.\\s*[А-ЯЁ]?\\.?")
    private fun personSurname(s: String): String? =
        PERSON.find(s.trim())?.groupValues?.get(1)?.lowercase()?.replace('ё', 'е')
            ?: s.trim().takeIf { Regex("^[А-ЯЁ][а-яё]{3,}$").matches(it) }?.lowercase()?.replace('ё', 'е')

    // ---------- справочник для нейросети и память исправлений ----------
    val learned = Learned(app.getSharedPreferences("s", 0))
    /** Рельеф и ширина дорог у точек — с кешем в файле. */
    private val terrain by lazy { Terrain(app.filesDir) }
    /** Строки сразу после распознавания и автоисправлений — с ними сравниваем правки человека. */
    private var original: Map<Int, Row> = emptyMap()
    var learnedVer by mutableIntStateOf(0)

    private fun learnKey(client: String, address: String): String? {
        val c = client.lowercase().replace('ё', 'е').filter { it.isLetterOrDigit() }
        val a = addressKey(address)
        return if (c.isEmpty() && a.isEmpty()) null else "$c|$a"
    }
    private fun learnKey(r: Row) = learnKey(r.client, r.address)

    /** Строка с позывным точки, у которой есть «сёстры» по цифре в заметках (Евлохин Первый / Второй). */
    private fun splitsByNotes(r: Row): Boolean {
        val p = db.pointFor(r.callsign) ?: return false
        val m = ORDINAL.find(p.display.trim()) ?: return false
        val base = m.groupValues[1].trim()
        return db.points.count { q -> ORDINAL.find(q.display.trim())?.groupValues?.get(1)?.trim()?.equals(base, true) == true } > 1
    }

    /** Справочник «позывной: адрес — точка» для запроса к нейросети. */
    private fun referenceForModel(): String {
        val pts = db.points.associateBy { it.name }
        val lines = db.calls.entries.mapNotNull { (cs, name) ->
            val p = pts[name] ?: return@mapNotNull null
            val addr = p.address.ifBlank { null } ?: return@mapNotNull null
            "$cs: $addr — ${p.display}"
        }
        if (lines.isEmpty()) return ""
        return " ДОПОЛНИТЕЛЬНО — справочник позывных из базы клиентов (позывной: адрес — точка): " + lines.joinToString("; ") + ". " +
            "Справочник касается ТОЛЬКО колонки «Позывной»; все остальные колонки (клиент, адрес, вес, сумма, факт, расчет, заметки, агент) " +
            "читай с листа как есть и ничего в них не меняй по справочнику. В «Заметках» короткая цифра (1, 2) обязательна к выводу. " +
            "Справочник — для сверки, а не для замены: позывной всегда читай из ячейки «Позывной» своей строки. " +
            "Если цифры позывного неразборчивы или похожи (5 и 6, 3 и 8, б и 6), выбери из справочника вариант, адрес которого совпадает с адресом строки. " +
            "Если у строки получился позывной соседней точки (адрес из справочника не совпадает с адресом строки) — перепроверь, не съехал ли ты на соседнюю строку. " +
            "Позывных, которых нет в справочнике, не бойся — это новые точки, выводи их как напечатано. "
    }

    /** Применить запомненные исправления к только что распознанному листу. Возвращает, сколько применено. */
    private fun applyLearned(): Int {
        if (learned.size == 0) return 0
        var n = 0
        for (i in rows.indices) {
            var r = rows[i]
            learnKey(r)?.let { k -> learned.addrs[k]?.let { a -> if (addressKey(a) != addressKey(r.address)) { r = r.copy(address = a); n++ } } }
            learnKey(r)?.let { k -> learned.calls[k]?.let { c -> if (db.norm(c) != db.norm(r.callsign)) { r = r.copy(callsign = c); n++ } } }
            rows[i] = r
        }
        // Объединения: строка с запомненным ключом присоединяется к строке с ключом-целью
        val keyed = rows.mapNotNull { r -> learnKey(r)?.let { it to r } }
        for ((k, r) in keyed) {
            val target = learned.merges[k] ?: continue
            val lead = keyed.firstOrNull { (k2, l) -> k2 == target && l.id != r.id && l.id !in merged }?.second ?: continue
            if (r.id !in merged) { merged[r.id] = lead.id; n++ }
        }
        return n
    }

    /** Запомнить правки человека на экране проверки: позывной, адрес, объединения. */
    private fun learnFromReview() {
        if (original.isEmpty()) return
        var changed = false
        for (r in rows) {
            val o = original[r.id] ?: continue
            if (o.address.isNotBlank() && r.address.isNotBlank() && addressKey(o.address) != addressKey(r.address)) {
                learnKey(o.client, o.address)?.let { learned.addrs[it] = r.address; changed = true }
            }
            if (r.callsign.isNotBlank() && db.norm(o.callsign) != db.norm(r.callsign)) {
                learnKey(r)?.let { learned.calls[it] = r.callsign.trim(); changed = true }
            }
        }
        val byId = rows.associateBy { it.id }
        for ((f, lead) in merged) {
            val k = byId[f]?.let { learnKey(it) } ?: continue
            val t = byId[lead]?.let { learnKey(it) } ?: continue
            if (k != t && learned.merges[k] != t) { learned.merges[k] = t; changed = true }
        }
        if (changed) { learned.save(); learnedVer++ }
    }

    fun forgetLearned() { learned.clear(); learnedVer++; info = "Запомненные исправления удалены" }

    /**
     * Нейросеть на снятом под углом листе иногда сдвигает адрес на строку: последняя накладная клиента
     * получает адрес соседнего клиента. Узнаём по тому, что у всех остальных накладных того же клиента адрес один
     * и другой, а адрес строки совпадает с соседней строкой чужого клиента. Возвращаем адрес (и позывной) клиента.
     */
    private fun fixShiftedRows(): Int {
        fun cl(r: Row) = r.client.lowercase().replace('ё', 'е').filter { it.isLetterOrDigit() }
        var fixed = 0
        for (i in rows.indices) {
            val r = rows[i]
            val c = cl(r); if (c.length < 4 || r.address.isBlank()) continue
            val same = rows.filter { it.id != r.id && cl(it) == c && it.address.isNotBlank() }
            if (same.isEmpty()) continue
            val keys = same.map { addressKey(it.address) }.distinct()
            if (keys.size != 1 || keys[0] == addressKey(r.address)) continue
            val neigh = listOfNotNull(rows.getOrNull(i - 1), rows.getOrNull(i + 1)).filter { cl(it) != c }
            if (neigh.none { addressKey(it.address) == addressKey(r.address) }) continue
            val cs = same.map { it.callsign.trim() }.filter { it.isNotBlank() }.distinct().singleOrNull()
            // Съехал только адрес — позывной у строки тот же, что у остальных накладных клиента. Другой позывной —
            // это другой магазин того же клиента (Алко плаза в Форосе и в Алупке), ничего не трогаем
            if (r.callsign.isNotBlank() && (cs == null || db.norm(cs) != db.norm(r.callsign))) continue
            rows[i] = r.copy(address = same.first().address, callsign = cs ?: r.callsign)
            fixed++
        }
        return fixed
    }

    /**
     * Сразу после распознавания: позывные строк сверяются с базой по адресу и клиенту. Чужой или пустой позывной
     * заменяется позывным точки, найденной по адресу, — человеку не нужно искать перепутанные строки.
     * Возвращает, сколько позывных исправлено.
     */
    private fun checkCallsigns(): Int {
        val idx = DbIndex()
        var fixed = 0
        for (i in rows.indices) {
            val r = rows[i]
            if (r.address.isBlank() && r.client.isBlank()) continue
            val byCs = if (r.callsign.isBlank()) null else db.pointFor(r.callsign)
            // Позывной из базы и не спорит со строкой — не трогаем
            if (byCs != null && idx.consistent(byCs, r)) continue
            val p = idx.find(r) ?: run {
                // По адресу не нашли — может, в позывном перепутана цифра
                val v = idx.variant(r) ?: return@run null
                if (v.second.name != byCs?.name) { rows[i] = r.copy(callsign = v.first); fixed++ }
                null
            } ?: continue
            if (byCs?.name == p.name) continue
            val cs = db.callsignsOf(p.name).firstOrNull() ?: continue
            rows[i] = r.copy(callsign = cs)
            fixed++
        }
        return fixed
    }


    fun startMatch() {
        learnFromReview()
        error = null; assigned.clear(); queue.clear(); groups.clear(); excludedRows.clear(); agentRows.clear(); tempPoints.clear(); tempNotes.clear(); newPoints.clear(); qi = 0
        val ro = returnOnlyCallsigns()
        val unknown = ArrayList<Row>()
        val doubtful = ArrayList<Row>()
        val pending = ArrayList<Row>()
        sharedCallsigns.clear()
        rows.filter { it.callsign.isNotBlank() && it.address.isNotBlank() }.groupBy { db.norm(it.callsign) }
            .filterValues { g -> g.map { addressKey(it.address) }.distinct().size > 1 }.keys.let { sharedCallsigns.addAll(it) }
        val idx = DbIndex()
        for (r in rows) {
            if (r.id in merged) continue // объединённая вручную — едет вместе со своей точкой
            if (r.callsign.isNotBlank() && db.norm(r.callsign) in ro) { excludedRows.add(r.id); continue }
            if (manual(r)) { doubtful.add(r); continue }
            var p = idx.resolve(r)
            // Позывной общий на разные адреса: точка базы годится, только если её адрес совпадает со строкой
            if (p != null && r.callsign.isNotBlank() && db.norm(r.callsign) in sharedCallsigns && p.name == db.pointFor(r.callsign)?.name &&
                addressKey(p.address) != addressKey(r.address)) p = idx.find(r)
            when {
                p != null -> assigned[r.id] = p.name
                r.address.isNotBlank() -> unknown.add(r)
                else -> pending.add(r)
            }
        }
        if (sharedCallsigns.isNotEmpty()) error = "У позывн" + (if (sharedCallsigns.size == 1) "ого " else "ых ") +
            sharedCallsigns.joinToString(", ") + " в листе разные адреса — нейросеть, возможно, перепутала позывные строк. " +
            "Накладные разложены по адресам, проверьте остановки"
        if (unknown.isEmpty()) { buildQueue(doubtful, pending); proceedMatch(); return }
        viewModelScope.launch {
            try {
                val near = depotCoords()
                // Строки по одному адресу — одна остановка, даже если клиенты разные (один магазин, разные юрлица)
                val groups = unknown.groupBy { addressKey(it.address) }.values.toList()
                groups.forEachIndexed { i, g ->
                    busy = "Ищем адреса новых точек: ${i + 1} из ${groups.size}"
                    val r0 = g.first()
                    val addr = r0.address.trim()
                    // Место отмечено на карте на экране проверки — адрес не ищем
                    val c = pins["n:" + addressKey(addr)]?.let { (la, lo) -> Net.Geo(la, lo, Net.Precision.HOUSE) }
                        ?: withContext(Dispatchers.IO) { runCatching { Net.geocode(addr, near) }.getOrNull() }
                    if (c == null) { pending.addAll(g); return@forEachIndexed }
                    val title = g.map { it.client.trim() }.filter { it.isNotBlank() }.distinct().joinToString(" / ").ifBlank { addr }
                    // Временное имя (в базе такого нет); в базу точка уйдёт под названием клиента
                    val key = "＋$title · $addr"
                    tempPoints[key] = Point(key, addr, c.lat, c.lon, title)
                    c.note?.let { tempNotes[key] = it }
                    g.forEach { assigned[it.id] = key }
                }
            } finally { busy = null }
            buildQueue(doubtful, pending)
            proceedMatch()
        }
    }

    // ---------- точки прямо на экране проверки листа ----------
    /** Группа накладных одной остановки на экране проверки: точка базы, новая точка по адресу, ручной выбор или «не едем». */
    class RGroup(val key: String, val kind: Int, val point: Point?, val rows: List<Row>) {
        val title get() = point?.display ?: rows.map { it.client.trim() }.filter { it.isNotBlank() }.distinct().joinToString(" / ")
            .ifBlank { rows.first().address.ifBlank { rows.first().callsign.ifBlank { "Без позывного" } } }
        val address get() = point?.address?.ifBlank { null } ?: rows.firstOrNull { it.address.isNotBlank() }?.address.orEmpty()
        val weight get() = rows.sumOf { it.weight }
        val callsigns get() = rows.map { it.callsign.trim() }.filter { it.isNotBlank() }.distinct()
        companion object { const val KNOWN = 0; const val NEW = 1; const val MANUAL = 2; const val SKIP = 3 }
    }

    /** Место новой точки, отмеченное пальцем на карте до построения маршрута (ключ — группа «n:адрес»). */
    val pins = androidx.compose.runtime.mutableStateMapOf<String, Pair<Double, Double>>()

    /**
     * Те же правила, что при сопоставлении: позывной из базы (со сверкой адреса), иначе новая точка по адресу,
     * иначе ручной выбор. Считается сразу после распознавания — новые точки видны и уточняются до маршрута.
     */
    fun reviewGroups(): List<RGroup> {
        val ro = returnOnlyCallsigns()
        val shared = rows.filter { it.callsign.isNotBlank() && it.address.isNotBlank() }.groupBy { db.norm(it.callsign) }
            .filterValues { g -> g.map { addressKey(it.address) }.distinct().size > 1 }.keys
        val idx = DbIndex()
        val out = LinkedHashMap<String, Pair<Int, Point?>>(); val members = HashMap<String, MutableList<Row>>()
        for (r in rows) {
            val (key, kind, p) = when {
                r.callsign.isNotBlank() && db.norm(r.callsign) in ro -> Triple("s:" + db.norm(r.callsign), RGroup.SKIP, db.pointFor(r.callsign))
                manual(r) -> Triple("m:" + r.id, RGroup.MANUAL, null)
                else -> {
                    var p = idx.resolve(r)
                    if (p != null && r.callsign.isNotBlank() && db.norm(r.callsign) in shared && p.name == db.pointFor(r.callsign)?.name &&
                        addressKey(p.address) != addressKey(r.address)) p = idx.find(r)
                    when {
                        p != null -> Triple("p:" + p.name, RGroup.KNOWN, p)
                        r.address.isNotBlank() -> Triple("n:" + addressKey(r.address), RGroup.NEW, null)
                        else -> Triple("m:" + (if (r.callsign.isNotBlank()) db.norm(r.callsign) else r.id.toString()), RGroup.MANUAL, null)
                    }
                }
            }
            out.getOrPut(key) { kind to p }; members.getOrPut(key) { ArrayList() }.add(r)
        }
        // Объединённые вручную: строки переезжают в группу ведущей строки
        val keyOf = HashMap<Int, String>()
        members.forEach { (k, rs) -> rs.forEach { keyOf[it.id] = k } }
        for ((f, lead) in merged) {
            val from = keyOf[f] ?: continue; val to = keyOf[lead] ?: continue
            if (from == to) continue
            val row = members[from]?.firstOrNull { it.id == f } ?: continue
            members[from]!!.remove(row); members[to]!!.add(row); keyOf[f] = to
        }
        return out.filter { members[it.key]!!.isNotEmpty() }.map { (k, v) -> RGroup(k, v.first, v.second, members[k]!!) }
    }

    // ---------- ручное объединение точек на экране проверки ----------
    /** Строка → ведущая строка точки, к которой её присоединили (разные юрлица одного магазина, кривой адрес). */
    val merged = androidx.compose.runtime.mutableStateMapOf<Int, Int>()
    /** Режим объединения: выбранные группы (ключи). Пусто — режим выключен. */
    val mergeSel = mutableStateListOf<String>()
    val merging get() = mergeSel.isNotEmpty()

    /** Долгий тап: первый открывает объединение, следующий (на любой карточке) объединяет выбранные. */
    fun mergeLong(g: RGroup) {
        if (g.kind == RGroup.SKIP) { info = "Точка «${g.title}» только с возвратом — её не объединяем"; return }
        if (!merging) { mergeSel.add(g.key); return }
        if (g.key !in mergeSel) mergeSel.add(g.key)
        val all = reviewGroups().filter { it.key in mergeSel }
        mergeSel.clear()
        if (all.size < 2) return
        // Ведущая — точка из базы, иначе новая по адресу, иначе первая выбранная
        val target = all.minBy { when (it.kind) { RGroup.KNOWN -> 0; RGroup.NEW -> 1; else -> 2 } }
        val lead = target.rows.first { it.id !in merged }.id
        all.filter { it !== target }.forEach { o -> o.rows.forEach { merged[it.id] = lead } }
        info = "Объединено в «${target.title}»: ${all.size} " + ru.marshrut.ui.plural(all.size, "точка", "точки", "точек")
    }

    /** Короткий тап в режиме объединения: добавить или убрать точку. */
    fun mergeTap(g: RGroup) {
        if (g.kind == RGroup.SKIP) return
        if (g.key in mergeSel) mergeSel.remove(g.key) else mergeSel.add(g.key)
    }
    fun mergeCancel() = mergeSel.clear()

    /** Сколько строк присоединено к группе вручную. */
    fun mergedIn(g: RGroup) = g.rows.count { it.id in merged }
    /** Разъединить: присоединённые строки возвращаются на свои точки. */
    fun unmerge(g: RGroup) {
        g.rows.filter { it.id in merged }.forEach { learned.merges.remove(learnKey(it)) }
        learned.save()
        g.rows.forEach { merged.remove(it.id) }
    }

    /** Присоединённые строки едут туда же, куда ведущая. */
    private fun applyMerges() {
        for ((f, lead) in merged) {
            val to = assigned[lead]
            if (to != null) assigned[f] = to else assigned.remove(f)
        }
    }

    /** Отметить новую точку на карте: метка ставится пальцем, координаты пойдут в маршрут и в базу без поиска адреса. */
    fun pinNew(g: RGroup, lat: Double, lon: Double) { pins[g.key] = lat to lon; info = "Место точки «${g.title}» отмечено" }

    private fun proceedMatch() { if (queue.isEmpty()) afterMatch() else screen = Screen.MATCH }

    /**
     * Добавить выбранные новые точки в базу и привязать позывные. Несколько клиентов по одному адресу —
     * одна общая точка, а если пользователь выбрал «раздельно» (separate) — по точке на клиента с теми же координатами.
     */
    /** Точка базы, которая уже есть для этой новой: то же название и тот же адрес или место в пределах 50 м. */
    private fun existingFor(title: String, base: Point): Point? = db.points.firstOrNull { p ->
        p.display.trim().equals(title.trim(), ignoreCase = true) &&
            (addressKey(p.address) == addressKey(base.address) || (p.hasCoords && base.hasCoords &&
                Net.haversine(p.lat, p.lon, base.lat, base.lon) < 50.0))
    }

    fun addNewPoints(selected: List<NewPoint>, separate: Set<NewPoint> = emptySet()) {
        var added = 0
        fun add(title: String, base: Point, callsigns: List<String>) {
            // Уже в базе (например, маршрут повторён из истории) — только привязываем позывные, без второй копии
            existingFor(title, base)?.let { ex -> callsigns.forEach { cs -> db.link(cs, ex.name) }; return }
            var name = title.trim()
            if (db.point(name) != null) name = "$name, ${base.address}"
            db.addPoint(base.copy(name = name, title = title.trim()))
            callsigns.forEach { cs -> db.link(cs, name) }
            added++
        }
        for (np in selected) {
            if (np in separate && np.members.size > 1) np.members.forEach { m -> add(m.client, np.point, m.callsigns) }
            else add(np.point.title, np.point, np.callsigns)
        }
        newPoints.clear()
        if (added > 0) {
            dbVer++
            info = "Добавлено в базу: $added " + ru.marshrut.ui.plural(added, "точка", "точки", "точек")
        }
    }

    fun choose(rowId: Int, pointName: String) {
        val r = rows.first { it.id == rowId }
        groupOf(rowId).forEach { assigned[it.id] = pointName }
        if (!manual(r) && !r.needsChoice && r.callsign.isNotBlank() && db.norm(r.callsign) !in sharedCallsigns &&
            db.calls[db.norm(r.callsign)] != pointName) pendingLinks.add(r.callsign.trim() to pointName)
        next()
    }

    fun createPoint(rowId: Int, p: Point) { db.addPoint(p); dbVer++; choose(rowId, p.name) }
    fun skip() = next()
    fun agentTakes(rowId: Int) { groupOf(rowId).forEach { assigned.remove(it.id); agentRows.add(it.id) }; next() }
    fun backMatch() { if (qi > 0) qi-- else screen = Screen.REVIEW }
    private fun next() { qi++; if (qi >= queue.size) afterMatch() }

    // ---------- оборудование ----------
    fun pointOf(rowId: Int): Point? = assigned[rowId]?.let { db.point(it) }
    val equipRows get() = rows.filter { it.kind == Kind.EQUIPMENT && assigned.containsKey(it.id) }

    private fun afterMatch() {
        applyMerges()
        if (equipRows.any { it.equip == EquipDir.UNKNOWN }) screen = Screen.EQUIP else buildRoute()
    }

    fun setEquip(id: Int, d: EquipDir) { rows.firstOrNull { it.id == id }?.let { update(it.copy(equip = d)) } }
    fun equipDone() { if (equipRows.all { it.equip != EquipDir.UNKNOWN }) buildRoute() }

    // ---------- маршрут ----------
    fun buildRoute() {
        viewModelScope.launch {
            busy = "Считаем дороги и время"; error = null
            try {
                applyMerges()
                val all = rows.filter { assigned.containsKey(it.id) }.groupBy { assigned[it.id]!! }
                // Правило: у точки только возврат(ы), накладных на товар нет — точку не объезжаем
                val excludedGroups = all.filterValues { g -> g.all { it.kind == Kind.RETURN } }
                val groups = all.filterKeys { it !in excludedGroups.keys }
                val excluded = ArrayList<Excluded>()
                rows.filter { it.id in excludedRows }.forEach { r ->
                    excluded.add(Excluded(db.pointFor(r.callsign)?.display ?: r.client.ifBlank { r.callsign }, r.callsign, r.invoiceLabel))
                }
                excludedGroups.forEach { (name, g) -> g.forEach { r -> excluded.add(Excluded(db.point(name)?.display ?: name, r.callsign, r.invoiceLabel)) } }
                rows.filter { it.id in agentRows }.forEach { r ->
                    val who = agentFor(r.agent)?.name?.ifBlank { null } ?: r.agent.ifBlank { null }
                    val ag = agentFor(r.agent)
                    excluded.add(Excluded(db.pointFor(r.callsign)?.display ?: r.client.ifBlank { r.callsign.ifBlank { "Без позывного" } }, r.callsign,
                        r.invoiceLabel, Excluded.REASON_AGENT, r.factSum, who.orEmpty(), ag?.phone.orEmpty()))
                }
                if (groups.isEmpty()) error("Нет точек для маршрута")
                val pts = groups.keys.map { db.point(it) ?: tempPoints[it] ?: error("Точка «$it» не найдена в базе") }
                val noCoords = pts.filter { !it.hasCoords }
                if (noCoords.isNotEmpty()) error("Нет координат у точек: " + noCoords.joinToString { it.name } + ". Допишите в xlsx и импортируйте базу.")
                val warehouse = depotCoords()?.let { (la, lo) -> Point("Склад", "", la, lo, "Склад") }
                // Старт — там, где вы стоите (иначе склад). Финиш — склад.
                val here = if (st.startFromGps) { busy = "Определяем, где вы"; currentLocation() } else null
                val startPt = here ?: warehouse
                val endPt = if (st.endAtDepot) warehouse else null
                busy = "Считаем дороги и время"
                val extra = ArrayList<Point>()
                var sIdx: Int? = null; var eIdx: Int? = null
                if (startPt != null) { extra.add(startPt); sIdx = pts.size }
                if (endPt != null) {
                    if (endPt === startPt) eIdx = sIdx else { extra.add(endPt); eIdx = pts.size + extra.size - 1 }
                }
                val nodes = pts + extra
                val w = DoubleArray(nodes.size) { i -> if (i < pts.size) groups[pts[i].name]!!.sumOf { it.weight } else 0.0 }
                // Подъезд своей стороной — только к точкам на широких дорогах (через полосы ящики не носят)
                // Широкие дороги у точек нужны всегда: от них зависят и разворот, и (если включено) подъезд своей стороной
                val osmWide = withContext(Dispatchers.IO) { busy = "Смотрим дороги у точек"; runCatching { terrain.wideRoads(pts) }.getOrElse { BooleanArray(pts.size) } }
                // Запасной признак без интернета: трасса видна по адресу точки или строк листа («ЮБШ», «шоссе»…)
                val wideAt = BooleanArray(pts.size) { i ->
                    osmWide[i] || ROAD_WORDS.containsMatchIn(pts[i].address) ||
                        groups[pts[i].name].orEmpty().any { ROAD_WORDS.containsMatchIn(it.address) }
                }
                val curbAt = List(nodes.size) { i -> st.curbSide && i < pts.size && wideAt[i] }
                busy = "Считаем дороги и время"
                val m = withContext(Dispatchers.IO) { Net.matrix(st, nodes, curbAt) }
                // Рельеф: подъёмы между точками — чтобы не лезть в гору с полным кузовом
                val climb = withContext(Dispatchers.IO) { runCatching { terrain.climbMatrix(st, nodes) { busy = it } }.getOrNull() }
                busy = "Подбираем варианты маршрута"
                val si = sIdx; val ei = eIdx
                // Субботний «приём до …»: крайний срок в секундах от текущего момента
                val nowMin = java.time.LocalTime.now().let { it.hour * 60 + it.minute }
                val dl = DoubleArray(nodes.size) { i ->
                    val lim = if (i < pts.size && isSaturday()) pts[i].saturdayLimitMin else null
                    if (lim == null) Double.NaN else ((lim - nowMin) * 60.0).coerceAtLeast(0.0)
                }
                val modes = listOf(
                    Optimizer.Mode.HUMAN to "Как опытный водитель",
                    Optimizer.Mode.FAST to "Быстрее по времени",
                    Optimizer.Mode.HEAVY to "Тяжёлое — первым"
                )
                val solved = withContext(Dispatchers.Default) {
                    modes.map { (mode, name) ->
                        val o = Optimizer(m.dur, m.dist, DoubleArray(nodes.size) { nodes[it].lat }, DoubleArray(nodes.size) { nodes[it].lon },
                            w, st.capacity.toD() ?: 0.0, si, ei, budgetMs = 1600, mode = mode, deadline = if (dl.any { !it.isNaN() }) dl else null, climb = climb,
                            wide = BooleanArray(nodes.size) { it < pts.size && wideAt[it] },
                            headX = DoubleArray(nodes.size) { approachVec(nodes[it]).first }, headY = DoubleArray(nodes.size) { approachVec(nodes[it]).second })
                        Triple(o.solve(), o, name)
                    }.distinctBy { it.first.toList() }
                }
                busy = "Рисуем маршрут"
                val built = ArrayList<Plan>()
                for ((order, opt, name) in solved) {
                    val seq = listOfNotNull(startPt) + order.map { nodes[it] } + listOfNotNull(endPt)
                    val curb = listOfNotNull(startPt?.let { false }) + order.map { curbAt[it] } + listOfNotNull(endPt?.let { false })
                    val path = withContext(Dispatchers.IO) { Net.geometry(st, seq, curb) }
                    var load = w.sum(); val stops = ArrayList<PlanStop>()
                    var prev: Int? = si
                    for (i in order) {
                        val g = groups[pts[i].name]!!
                        load -= w[i]
                        val p = prev
                        stops.add(PlanStop(pts[i], g.map { it.callsign }.filter { it.isNotBlank() }.distinct(),
                            g.flatMap { contactsOf(it) }.distinct(), w[i], g.sumOf { it.factSum }, load, g,
                            if (p == null) 0.0 else m.dist[p][i] / 1000.0, if (p == null) 0.0 else m.dur[p][i] / 60.0))
                        prev = i
                    }
                    val lastI = order.lastOrNull()
                    val endKm = if (ei != null && lastI != null) m.dist[lastI][ei] / 1000.0 else 0.0
                    val endMin = if (ei != null && lastI != null) m.dur[lastI][ei] / 60.0 else 0.0
                    val links = run {
                        // В навигатор для грузовика уходит и Ласпинский перевал, иначе Яндекс сам поведёт через Байдарские ворота
                        val nav = Net.withDetours(st, seq)
                        val l = ArrayList<String>(); var s = 0
                        while (s < nav.size - 1 || (s == 0 && nav.size == 1)) {
                            val part = nav.subList(s, minOf(s + 10, nav.size))
                            l.add("https://yandex.ru/maps/?rtext=" + part.joinToString("~") { "${it.lat},${it.lon}" } + "&rtt=auto")
                            s += 9
                        }
                        l
                    }
                    built.add(Plan(stops, opt.distance(order) / 1000.0, opt.duration(order) / 60.0, links, path, startPt, excluded, header,
                        endPt, endKm, endMin, name))
                }
                variants.clear(); variants.addAll(built)
                // Новые точки, попавшие в маршрут, — предложим добавить в базу
                newPoints.clear()
                tempPoints.filterKeys { it in groups.keys }.forEach { (k, p) ->
                    val g = groups[k]!!
                    // Позывной, общий на разные адреса, к новой точке не привязываем — он увёл бы чужие накладные
                    fun signs(rs: List<Row>) = rs.map { it.callsign.trim() }.filter { it.isNotBlank() && db.norm(it) !in sharedCallsigns }.distinct()
                    val members = g.groupBy { it.client.trim() }.map { (client, rs) -> Member(client.ifBlank { p.address }, signs(rs)) }
                    newPoints.add(NewPoint(p, signs(g), tempNotes[k], members))
                }
                val approx = newPoints.count { it.approx != null }
                if (approx > 0 && error == null) error = "Адрес найден приблизительно у $approx " +
                    ru.marshrut.ui.plural(approx, "новой точки", "новых точек", "новых точек") + " — проверьте их на карте маршрута"
                plan = built.first()
                stopIndex = 0; started = false; aborted = false; paid.clear(); agentPaid.clear(); handed.clear(); paidAmount.clear(); persist()
                if (m.approximate) error = "Сервер дорог недоступен — расстояния оценены по прямой. Порядок всё равно оптимизирован."
                screen = Screen.OVERVIEW
            } catch (e: Exception) { error = e.message ?: e.toString(); screen = Screen.HOME } finally { busy = null }
        }
    }

    private suspend fun currentLocation(): Point? =
        locate(5 * 60_000)?.let { Point("Старт", "", it.latitude, it.longitude, "Вы здесь") }

    /** Место с GPS не старше maxAgeMs (иначе ждём свежее до 8 с). */
    @android.annotation.SuppressLint("MissingPermission")
    private suspend fun locate(maxAgeMs: Long): android.location.Location? = withContext(Dispatchers.Main) {
        val granted = listOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION)
            .any { app.checkSelfPermission(it) == android.content.pm.PackageManager.PERMISSION_GRANTED }
        if (!granted) return@withContext null
        val lm = app.getSystemService(android.location.LocationManager::class.java) ?: return@withContext null
        val providers = listOf(android.location.LocationManager.GPS_PROVIDER, android.location.LocationManager.NETWORK_PROVIDER)
            .filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }
        var best: android.location.Location? = providers.mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
        val stale = best == null || System.currentTimeMillis() - best.time > maxAgeMs
        if (stale && android.os.Build.VERSION.SDK_INT >= 30 && providers.isNotEmpty()) {
            val fresh = kotlinx.coroutines.withTimeoutOrNull(8000) {
                kotlinx.coroutines.suspendCancellableCoroutine<android.location.Location?> { cont ->
                    val cs = android.os.CancellationSignal()
                    cont.invokeOnCancellation { cs.cancel() }
                    runCatching {
                        lm.getCurrentLocation(providers.first(), cs, app.mainExecutor) { l -> if (cont.isActive) cont.resumeWith(Result.success(l)) }
                    }.onFailure { if (cont.isActive) cont.resumeWith(Result.success(null)) }
                }
            }
            if (fresh != null) best = fresh
        }
        best?.takeIf { System.currentTimeMillis() - it.time <= maxOf(maxAgeMs, 60_000) }
    }

    /**
     * Водитель стоит у точки: её координаты заменяются текущими с GPS — в базе (у редактора уйдёт всем)
     * и в текущем маршруте. Точка, которой ещё нет в базе, уточняется только в маршруте.
     */
    fun fixCoordsHere(stopIndex: Int) {
        val p = plan ?: return
        val stop = p.stops.getOrNull(stopIndex) ?: return
        viewModelScope.launch {
            busy = "Определяем, где вы"
            val here = try { locate(20_000) } finally { busy = null }
            if (here == null) { error = "Не удалось определить место — включите геолокацию и выйдите на открытое место"; return@launch }
            val old = stop.point
            val moved = Net.haversine(old.lat, old.lon, here.latitude, here.longitude).toInt()
            val fixed = old.copy(lat = here.latitude, lon = here.longitude)
            val inDb = db.point(old.name)
            if (inDb != null) { db.addPoint(inDb.copy(lat = here.latitude, lon = here.longitude)); dbVer++ }
            plan = p.copy(stops = p.stops.map { if (it.point.name == old.name) it.copy(point = fixed) else it })
            persist()
            val acc = if (here.hasAccuracy() && here.accuracy > 50) " Точность GPS всего ${here.accuracy.toInt()} м — лучше повторить на улице." else ""
            info = "Координаты «${old.display}» уточнены, сдвиг $moved м." + when {
                inDb == null -> " Точки ещё нет в базе — изменено только в этом маршруте."
                st.isEditor -> " Уйдёт всем водителям."
                else -> " Изменено на этом телефоне; в общую базу — через редактора."
            } + acc
            if (st.isEditor) { lastAutoSync = 0L; sync(manual = false) }
        }
    }

    /** Направление подъезда точки вектором (восток +x, север +y). */
    private fun approachVec(p: Point): Pair<Double, Double> = when (p.approach) {
        "запад" -> -1.0 to 0.0; "восток" -> 1.0 to 0.0; "север" -> 0.0 to 1.0; "юг" -> 0.0 to -1.0; else -> 0.0 to 0.0
    }

    /**
     * Отметить, с какой стороны подъезжать к точке (dir — «запад», «восток», «север», «юг» или null — с любой).
     * Пишется в комментарий точки в базе, у редактора уходит всем водителям; маршрут учтёт при следующем построении.
     */
    fun setApproach(name: String, dir: String?) {
        val inDb = db.point(name) ?: run { error = "Точки ещё нет в базе — сначала добавьте её"; return }
        val clean = inDb.comment.replace(APPROACH_TAG, "").trim()
        val comment = listOfNotNull(clean.ifBlank { null }, dir?.let { "[подъезд: $it]" }).joinToString(" ")
        val upd = inDb.copy(comment = comment)
        db.addPoint(upd); dbVer++
        plan?.let { p -> plan = p.copy(stops = p.stops.map { if (it.point.name == name) it.copy(point = it.point.copy(comment = comment)) else it }); persist() }
        info = "«${inDb.display}»: " + (if (dir == null) "подъезд с любой стороны" else "подъезд, двигаясь на $dir") +
            (if (st.isEditor) " — уйдёт всем водителям" else "") + ". Учтём при построении маршрута"
        if (st.isEditor) { lastAutoSync = 0L; sync(manual = false) }
    }

    // ---------- ведение ----------
    /** «Поехали» с обзора: сначала экран загрузки авто. */
    fun toLoading() { screen = Screen.LOAD }
    fun go() { started = true; direction = 1; persist(); intro = "Поехали"; screen = Screen.DRIVE }
    fun nextStop() {
        val p = plan ?: return
        direction = 1
        if ((p.stops.getOrNull(stopIndex)?.fact ?: 0.0) > 0 && paid[stopIndex] == null) { askPaid = true; return }
        if (stopIndex >= p.stops.size - 1) {
            screen = Screen.FINISH; store.save(null)
            record(p, p.stops.size, false)
            if (p.end != null) Notifier.toWarehouse(app, p) else Notifier.cancel(app)
            return
        }
        stopIndex++; persist()
    }
    /** amount — сколько получено: null — не оплатили, меньше суммы — оплатили не все накладные точки. */
    fun answerPaid(amount: Double?) {
        val fact = plan?.stops?.getOrNull(stopIndex)?.fact ?: 0.0
        paid[stopIndex] = amount != null && amount > 0.0
        if (amount != null && amount > 0.0 && amount < fact - 0.005) paidAmount[stopIndex] = amount else paidAmount.remove(stopIndex)
        askPaid = false; persist(); nextStop()
    }
    /** Сколько получено на точке. */
    fun received(i: Int): Double = if (paid[i] != true) 0.0 else paidAmount[i] ?: (plan?.stops?.getOrNull(i)?.fact ?: 0.0)
    /** Сколько наличных реально получено (только подтверждённые оплаты). */
    val cashCollected get() = (plan?.stops?.indices?.sumOf { received(it) } ?: 0.0) +
        (plan?.excluded?.withIndex()?.filter { agentPaid[it.index] == true }?.sumOf { it.value.cash } ?: 0.0)
    fun prevStop() { if (stopIndex > 0) { direction = -1; stopIndex--; persist() } }
    fun jumpTo(i: Int) { direction = if (i >= stopIndex) 1 else -1; stopIndex = i; started = true; persist(); screen = Screen.DRIVE }
    fun resume() { screen = if (started) Screen.DRIVE else Screen.OVERVIEW }
    fun finishRoute() { paidAmount.clear(); newPoints.clear(); finishNewPointsShown = false; aborted = false; paid.clear(); agentPaid.clear(); handed.clear(); variants.clear(); askPaid = false; plan = null; stopIndex = 0; started = false; store.save(null); Notifier.cancel(app); uris.clear(); pages.clear(); screen = Screen.HOME }

    /** Досрочно прервать маршрут: всё, что осталось, не объезжаем. */
    var aborted by mutableStateOf(false)
    fun abortRoute() {
        val p = plan ?: return
        aborted = true; store.save(null)
        record(p, if (started) stopIndex else 0, true)
        if (p.end != null) Notifier.toWarehouse(app, p) else Notifier.cancel(app)
        screen = Screen.FINISH
    }

    // ---------- проверка позывного ----------
    fun linkCallsign(callsign: String, pointName: String) { if (callsign.isNotBlank()) { db.link(callsign.trim(), pointName); dbVer++ } }
    fun unlinkCallsign(callsign: String) { db.unlink(callsign); dbVer++ }

    // ---------- БД ----------
    /** Короткое сообщение об успехе (обновление базы и т.п.). */
    var info by mutableStateOf<String?>(null)

    /** Обновление базы из xlsx: совпавшие точки и позывные переписываются, новые добавляются. */
    /** Позывные, которые ждут подтверждения «запомнить за точкой» — чтобы ошибки распознавания не попадали в базу. */
    val pendingLinks = androidx.compose.runtime.mutableStateListOf<Pair<String, String>>()
    fun confirmLink(save: Boolean) {
        val p = pendingLinks.removeFirstOrNull() ?: return
        if (save) { db.link(p.first, p.second); dbVer++ }
    }

    /** Заставка с логотипом: подпись под знаком или null, если заставки нет. */
    var intro by mutableStateOf<String?>(null)
    /** Приложение возвращается из фона (или запускается) — показать заставку. Переживает поворот и сгиб экрана. */
    var fromBackground = true

    /** Выбранный файл базы ждёт решения: обновить или заменить целиком. */
    var pendingImport by mutableStateOf<Uri?>(null)
    fun replaceDb(u: Uri) {
        try {
            app.contentResolver.openInputStream(u)!!.use { db.replace(it) }
            db.save(); dbVer++; error = null
            info = "База заменена: ${db.points.size} " + ru.marshrut.ui.plural(db.points.size, "точка", "точки", "точек") +
                ", ${db.calls.size} " + ru.marshrut.ui.plural(db.calls.size, "позывной", "позывных", "позывных")
        } catch (e: Exception) { error = "Не удалось заменить базу: ${e.message}" }
    }

    fun importDb(u: Uri) {
        try {
            val r = app.contentResolver.openInputStream(u)!!.use { db.merge(it) }
            db.save(); dbVer++; error = null
            fun pts(n: Int) = "$n " + ru.marshrut.ui.plural(n, "точка", "точки", "точек")
            fun cs(n: Int) = "$n " + ru.marshrut.ui.plural(n, "позывной", "позывных", "позывных")
            val parts = listOfNotNull(
                if (r.pointsUpdated > 0) "обновлено ${pts(r.pointsUpdated)}" else null,
                if (r.pointsAdded > 0) "добавлено ${pts(r.pointsAdded)}" else null,
                if (r.callsUpdated > 0) "обновлено ${cs(r.callsUpdated)}" else null,
                if (r.callsAdded > 0) "добавлено ${cs(r.callsAdded)}" else null
            )
            info = if (parts.isEmpty()) "Изменений нет — база уже актуальна" else parts.joinToString(", ").replaceFirstChar { it.uppercase() }
        } catch (e: Exception) { error = "Не удалось обновить базу: ${e.message}" }
    }
    fun exportDb(u: Uri) {
        try { app.contentResolver.openOutputStream(u)!!.use { db.write(it) } } catch (e: Exception) { error = e.message }
    }
    fun geocode(addr: String, cb: (Net.Geo?) -> Unit) {
        viewModelScope.launch { cb(withContext(Dispatchers.IO) { runCatching { Net.geocode(addr, depotCoords()) }.getOrNull() }) }
    }
    // ---------- резервная копия на Яндекс Диске ----------
    /** Время последней удачной копии и ошибка последней попытки — для экрана настроек. */
    var lastBackup by mutableStateOf(st.lastBackup)
    var backupError by mutableStateOf<String?>(null)
    private var cloudBusy = false

    private fun sha(parts: Collection<ByteArray>): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        parts.forEach { md.update(it) }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** Сама по себе: только если включено, вход задан и с прошлой копии что-то изменилось (или сегодня архива ещё нет). */
    fun autoBackup() { if (st.autoBackup && st.cloudReady) backup(manual = false) }

    /** Вход в Яндекс по коду: код, который пользователь вводит на ya.ru/device, пока ждём подтверждения. */
    var yaCode by mutableStateOf<Cloud.DeviceCode?>(null)
    var cloudConnected by mutableStateOf(st.cloudReady)
    private var loginJob: kotlinx.coroutines.Job? = null

    fun yandexLogin() {
        if (!Cloud.configured) { error = "В сборке нет ID приложения Яндекса — добавьте секреты CLIENT_ID и CLIENT_SECRET на GitHub"; return }
        loginJob?.cancel()
        loginJob = viewModelScope.launch {
            try {
                val dc = withContext(Dispatchers.IO) { Cloud.deviceCode() }
                yaCode = dc
                val until = System.currentTimeMillis() + dc.expiresIn * 1000L
                while (System.currentTimeMillis() < until) {
                    kotlinx.coroutines.delay(dc.interval.coerceAtLeast(2) * 1000L)
                    // Обрыв связи во время ожидания — не повод бросать вход, спросим ещё раз
                    val t = (try { withContext(Dispatchers.IO) { Cloud.pollToken(dc.deviceCode) } } catch (e: java.io.IOException) { null }) ?: continue
                    st.yaToken = t.access; st.yaRefresh = t.refresh; st.backupHash = ""
                    cloudConnected = true; yaCode = null; backupError = null
                    info = "Яндекс Диск подключён"
                    checkOwner()
                    backup(manual = false)
                    return@launch
                }
                yaCode = null; error = "Код устарел — нажмите «Войти через Яндекс» ещё раз"
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                yaCode = null; error = "Не удалось войти: ${Cloud.describe(e)}"
            }
        }
    }
    fun cancelLogin() { loginJob?.cancel(); yaCode = null }
    fun yandexLogout() {
        cancelLogin(); st.yaToken = ""; st.yaRefresh = ""; cloudConnected = false; backupError = null; isOwner = false
    }

    fun backup(manual: Boolean) {
        if (!st.cloudReady) { if (manual) error = "Сначала войдите через Яндекс"; return }
        if (cloudBusy) { if (manual) info = "Копия уже сохраняется"; return }
        val files = linkedMapOf(Cloud.DB to db.bytes())
        store.historyBytes()?.let { files[Cloud.HISTORY] = it }
        // Отпечаток по содержимому: сам xlsx каждый раз разный из-за времени внутри архива
        val hash = sha(listOf((db.points.toString() + db.calls.toString()).toByteArray()) + listOfNotNull(files[Cloud.HISTORY]))
        val today = java.time.LocalDate.now().toString()
        val archive = if (st.archiveDay != today) today else null
        if (!manual && hash == st.backupHash && archive == null) return
        cloudBusy = true
        if (manual) busy = "Сохраняем на Яндекс Диск"
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { Cloud.upload(st, files, archive) }
                val now = System.currentTimeMillis()
                st.backupHash = hash; st.archiveDay = today; st.lastBackup = now
                lastBackup = now; backupError = null
                if (manual) info = "Копия сохранена на Яндекс Диск"
            } catch (e: Exception) {
                backupError = Cloud.describe(e)
                if (e is Cloud.AuthError) { st.yaToken = ""; cloudConnected = false }
                if (manual) error = "Не удалось сохранить: ${Cloud.describe(e)}"
            } finally {
                cloudBusy = false
                if (manual) busy = null
            }
        }
    }

    /** Заменяет базу точек и историю маршрутов копией с Диска. Текущий маршрут не трогает. */
    fun restore() {
        if (!st.cloudReady) { error = "Сначала войдите через Яндекс"; return }
        if (cloudBusy) { info = "Подождите, идёт сохранение копии"; return }
        cloudBusy = true; busy = "Загружаем с Яндекс Диска"
        viewModelScope.launch {
            try {
                val (dbData, histData) = withContext(Dispatchers.IO) {
                    Cloud.download(st, Cloud.DB) to Cloud.download(st, Cloud.HISTORY)
                }
                if (dbData == null) error("На Диске ещё нет копии — сначала сохраните её с этого или старого телефона")
                db.replace(dbData.inputStream())
                // Копия может быть старой: общая база главнее, иначе старые данные разошлись бы всем водителям
                db.forgetSyncBase(); db.save(); dbVer++
                // Копия могла быть старше общей базы — сразу подтягиваем общую
                lastAutoSync = 0L; st.sharedMd5 = ""; sync(manual = false)
                if (histData != null) { store.restoreHistory(histData); history.clear(); history.addAll(store.history()) }
                backupError = null; error = null
                info = "Восстановлено: ${db.points.size} " + ru.marshrut.ui.plural(db.points.size, "точка", "точки", "точек") +
                    ", ${history.size} " + ru.marshrut.ui.plural(history.size, "маршрут", "маршрута", "маршрутов") + " в истории"
            } catch (e: Exception) {
                if (e is Cloud.AuthError) { st.yaToken = ""; cloudConnected = false }
                error = "Не удалось восстановить: ${Cloud.describe(e)}"
            } finally {
                cloudBusy = false; busy = null
            }
        }
    }

    // ---------- общая база: все читают, редакторы (по паролю) выкладывают ----------
    var lastSync by mutableStateOf(st.lastSync)
    var syncError by mutableStateOf<String?>(null)
    var isEditor by mutableStateOf(st.isEditor)
    /**
     * Владелец — телефон, вошедший в тот аккаунт Яндекса, на Диске которого лежит общая база из сборки.
     * Проверяем по ссылке: у владельца ссылка на его папку «Общая база» совпадает со ссылкой в APK.
     * Пока общей базы в сборке нет, подготовить её может любой вошедший — это первая настройка.
     */
    var isOwner by mutableStateOf(false)
    fun checkOwner() {
        val sh = st.shared
        if (!st.cloudReady || sh == null) { isOwner = false; return }
        viewModelScope.launch {
            val own = runCatching { withContext(Dispatchers.IO) { Cloud.ownSharedUrl(st) } }.getOrNull()
            isOwner = own != null && Cloud.sameLink(own, sh.url)
        }
    }

    /** Строка для секрета SHARED_DB, которую владелец только что подготовил. */
    var preparedShared by mutableStateOf<String?>(null)
    private var syncing = false
    private var lastAutoSync = 0L

    /**
     * Читатель: если по ссылке появилась новая версия — скачать и слить со своей (свои новые точки остаются).
     * Редактор: скачать общую, слить, выложить результат; если другой редактор успел раньше — повторить с его версией.
     */
    fun sync(manual: Boolean) {
        val sh = st.shared
        if (sh == null) { if (manual) error = "В этой сборке нет общей базы"; return }
        if (syncing) { if (manual) info = "Обновление уже идёт"; return }
        val now = System.currentTimeMillis()
        if (!manual && now - lastAutoSync < 60_000) return
        lastAutoSync = now
        val token = st.editorToken
        syncing = true
        if (manual) busy = if (token.isNotBlank()) "Выкладываем общую базу" else "Проверяем общую базу"
        viewModelScope.launch {
            try {
                var changed = false
                if (token.isBlank()) {
                    val md5 = withContext(Dispatchers.IO) { Cloud.publicMd5(sh.url) } ?: error("владелец ещё не выложил базу")
                    if (md5 != st.sharedMd5) {
                        val remote = withContext(Dispatchers.IO) { Cloud.downloadPublic(sh.url) } ?: error("владелец ещё не выложил базу")
                        db.syncWith(remote); db.save(); db.markSynced(remote); dbVer++
                        st.sharedMd5 = Cloud.md5Of(remote); changed = true
                    }
                } else {
                    var done = false
                    for (attempt in 1..3) {
                        val remote = withContext(Dispatchers.IO) { Cloud.downloadShared(token) }
                        if (remote != null) { db.syncWith(remote); db.save(); dbVer++ }
                        if (remote != null && db.sameAs(remote)) { db.markSynced(remote); st.sharedMd5 = Cloud.md5Of(remote); done = true; break }
                        val mine = db.bytes()
                        if (withContext(Dispatchers.IO) { Cloud.uploadShared(token, mine, remote?.let { Cloud.md5Of(it) }) }) {
                            db.markSynced(mine); st.sharedMd5 = Cloud.md5Of(mine); changed = true; done = true; break
                        }
                    }
                    if (!done) error("общую базу сейчас правит другой редактор, попробуйте ещё раз")
                }
                st.lastSync = System.currentTimeMillis(); lastSync = st.lastSync; syncError = null
                if (manual || changed) info = when {
                    token.isNotBlank() && changed -> "Изменения выложены в общую базу"
                    changed -> "Общая база обновлена: ${db.points.size} " + ru.marshrut.ui.plural(db.points.size, "точка", "точки", "точек")
                    else -> "Общая база уже свежая"
                }
            } catch (e: Exception) {
                syncError = if (token.isNotBlank() && e is Cloud.AuthError) "Ключ записи больше не действует — владельцу нужно подготовить базу заново" else Cloud.describe(e)
                if (manual) error = "Не удалось: $syncError"
            } finally {
                syncing = false
                if (manual) busy = null
            }
        }
    }

    /** Ввод пароля редактора: расшифровываем ключ записи из сборки. */
    fun becomeEditor(password: String) {
        val sh = st.shared ?: run { error = "В этой сборке нет общей базы"; return }
        if (password.isBlank()) { error = "Введите пароль"; return }
        busy = "Проверяем пароль"
        viewModelScope.launch {
            val token = withContext(Dispatchers.Default) { SharedKey.unlock(sh, password) }
            busy = null
            if (token == null) { error = "Неверный пароль"; return@launch }
            st.editorToken = token; isEditor = true; info = "Вы редактор общей базы"
            lastAutoSync = 0L; sync(manual = false)
        }
    }

    // ---------- полное редактирование базы (только редактор) ----------
    val draft = DbDraft()
    fun openDbEditor() { if (!isEditor) return; draft.load(db); screen = Screen.DB_EDIT }

    /** Замечание к точке в редакторе: serious — мешает маршруту, иначе — стоит проверить. */
    class Issue(val text: String, val serious: Boolean)
    fun draftIssues(): Map<Int, List<Issue>> {
        val keys = draft.points.associate { it.key to if (it.address.isBlank()) "" else addressKey(it.address) }
        val dup = keys.values.filter { it.isNotBlank() }.groupingBy { it }.eachCount()
        val owners = draft.calls.filter { it.callsign.isNotBlank() }.mapNotNull { it.owner }.toSet()
        return draft.points.associate { p ->
            val l = ArrayList<Issue>()
            if (DbDraft.parseCoords(p.coords) == null) l.add(Issue("Нет координат", true))
            if (p.key !in owners) l.add(Issue("Нет позывных", true))
            if (p.address.isBlank()) l.add(Issue("Нет адреса", false))
            else {
                if (Net.splitAddress(p.address).house == null) l.add(Issue("Нет дома", false))
                if ((dup[keys[p.key]] ?: 0) > 1) l.add(Issue("Адрес повторяется", false))
            }
            p.key to l
        }
    }
    /** Откуда открыть карту, если у точки нет координат: адрес, иначе склад, иначе Ялта. */
    fun mapStart(address: String, cb: (Pair<Double, Double>) -> Unit) {
        val fallback = depotCoords() ?: (44.4952 to 34.1663)
        if (address.isBlank()) { cb(fallback); return }
        busy = "Ищем адрес на карте"
        geocode(address) { g -> busy = null; cb(g?.let { it.lat to it.lon } ?: fallback) }
    }

    /** Выход из редактора: правки проверяются, записываются в базу и сразу выкладываются в общую. */
    fun closeDbEditor(discard: Boolean = false) {
        if (discard) { screen = Screen.SETTINGS; return }
        val (built, err) = draft.build(db::norm)
        if (built == null) { error = err; return }
        val changed = built.points != db.points.toList() || built.calls != db.calls.toMap()
        screen = Screen.SETTINGS
        if (!changed) return
        db.setAll(built.points, built.calls); dbVer++
        info = "База сохранена: ${built.points.size} " + ru.marshrut.ui.plural(built.points.size, "точка", "точки", "точек")
        lastAutoSync = 0L; sync(manual = true)
    }

    fun leaveEditor() { st.editorToken = ""; isEditor = false; info = "Теперь общая база только для чтения" }

    /**
     * Владелец (вошёл в Яндекс): открывает папку общей базы по ссылке, выкладывает туда свою базу
     * и готовит строку для секрета SHARED_DB — ссылку и свой ключ, зашифрованный паролем редактора.
     */
    fun prepareShared(password: String) {
        if (!st.cloudReady) { error = "Сначала войдите через Яндекс"; return }
        if (password.trim().length < 6) { error = "Пароль редактора — не короче 6 символов"; return }
        if (st.shared != null && !isOwner) { error = "Общая база в этой сборке принадлежит другому аккаунту Яндекса"; return }
        busy = "Готовим общую базу"
        viewModelScope.launch {
            try {
                val url = withContext(Dispatchers.IO) { Cloud.publishShared(st) }
                val token = st.yaToken
                val line = withContext(Dispatchers.Default) { SharedKey.make(url, token, password) }
                st.localShared = line; preparedShared = line
                st.editorToken = token; isEditor = true; isOwner = true
                busy = null
                lastAutoSync = 0L; sync(manual = true)
            } catch (e: Exception) {
                busy = null
                error = "Не удалось подготовить общую базу: ${Cloud.describe(e)}"
            }
        }
    }

    /** Раз в час, пока приложение открыто, — проверка обновлений общей базы. */
    private val hourly = viewModelScope.launch {
        while (true) { kotlinx.coroutines.delay(60 * 60_000L); sync(manual = false) }
    }

    init {
        sync(manual = false)
        checkOwner()
        if (db.restored) info = "Загружена встроенная база. Если раньше вы её дополняли, верните правки: «Обновить из xlsx» → Загрузки/Маршрут/marshrut_db.xlsx"
    }
}

enum class Screen { HOME, CHECK, SETTINGS, REVIEW, MATCH, EQUIP, OVERVIEW, LOAD, DRIVE, FINISH, HISTORY, HISTORY_DETAIL, DB_EDIT }
