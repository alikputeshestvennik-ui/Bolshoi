package ru.marshrut

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/** Подготовленная страница листа и её миниатюра для экрана. */
class PageImg(val bmp: Bitmap) {
    val thumb: androidx.compose.ui.graphics.ImageBitmap by lazy {
        val k = 360f / maxOf(bmp.width, bmp.height)
        (if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true) else bmp)
            .asImageBitmap()
    }
}

class AppVm(private val app: Application) : AndroidViewModel(app) {
    val st = Settings(app.getSharedPreferences("s", 0))
    val db = Db(app)
    private val store = Store(app)
    var dbVer by mutableIntStateOf(0)

    var screen by mutableStateOf(Screen.HOME)
    val uris = mutableStateListOf<Uri>()
    var busy by mutableStateOf<String?>(null)
    var error by mutableStateOf<String?>(null)
    val agents = mutableStateListOf<Agent>()
    var sortByAgent by mutableStateOf(false)
    var header by mutableStateOf("")
    var total by mutableStateOf<Double?>(null)
    var totalNoSg by mutableStateOf<Double?>(null)
    private fun k(s: String) = s.uppercase().filter { !it.isWhitespace() }
    fun agentFor(num: String): Agent? = k(num).let { n -> if (n.isEmpty()) null else agents.firstOrNull { k(it.num) == n } }
    fun contactsOf(r: Row): List<Agent> = listOfNotNull(agentFor(r.agent))
    /** Исключения из правила «факт/ЧЗ»: возврат, оборудование или агент Маврычев — идём по распознанному. */
    fun bypass(r: Row): Boolean = r.kind != Kind.GOODS ||
        agentFor(r.agent)?.name?.contains("маврыч", true) == true || r.agent.contains("маврыч", true)
    /** Нужен ли ручной выбор точки (позывной не ищем по базе). */
    fun manual(r: Row): Boolean = r.needsChoice && !bypass(r)
    val rows = mutableStateListOf<Row>()
    val queue = mutableStateListOf<Int>()
    var qi by mutableIntStateOf(0)
    private val assigned = HashMap<Int, String>()
    private val excludedRows = HashSet<Int>()
    /** Сомнительные строки с фактом, которые заберёт торговый представитель — в объезд не идут. */
    private val agentRows = HashSet<Int>()

    // ---------- ведение по маршруту ----------
    var plan by mutableStateOf<Plan?>(null)
    var stopIndex by mutableIntStateOf(0)
    var started by mutableStateOf(false)
    /** Направление последнего перехода между точками: 1 вперёд, -1 назад — для анимации. */
    var direction by mutableIntStateOf(1)
    /** Оплата наличных по точкам: индекс точки → оплатили / нет. */
    val paid = androidx.compose.runtime.mutableStateMapOf<Int, Boolean>()
    /** Показать вопрос «Оплатили?» перед переходом к следующей точке. */
    var askPaid by mutableStateOf(false)
    /** Оплата документов, которые забирает торговый: индекс в plan.excluded → оплатили / нет. */
    val agentPaid = androidx.compose.runtime.mutableStateMapOf<Int, Boolean>()
    fun setAgentPaid(i: Int, v: Boolean) { agentPaid[i] = v; persist() }
    /** Документы, уже переданные торговому — пропадают из плашки по одному. */
    val handed = mutableStateListOf<Int>()
    fun handOver(i: Int, paidOk: Boolean?) {
        if (paidOk != null) agentPaid[i] = paidOk
        if (i !in handed) handed.add(i)
        persist()
    }
    /** Варианты маршрута, из которых выбирает пользователь. */
    val variants = mutableStateListOf<Plan>()
    fun chooseVariant(p: Plan) { if (!started) { plan = p; persist() } }

    // ---------- история ----------
    val history = mutableStateListOf<HistoryEntry>()
    var historyItem by mutableStateOf<HistoryEntry?>(null)

    private fun record(p: Plan, done: Int, aborted: Boolean) {
        val now = System.currentTimeMillis()
        history.add(0, HistoryEntry(now, now, p, done, aborted))
        store.saveHistory(history)
        autoBackup()
    }

    fun openHistory(e: HistoryEntry) { historyItem = e; screen = Screen.HISTORY_DETAIL }
    fun deleteHistory(e: HistoryEntry) { history.removeAll { it.id == e.id }; store.saveHistory(history); historyItem = null; screen = Screen.HISTORY }

    /** Снова поехать по сохранённому маршруту (тот же порядок точек). */
    fun repeatRoute(e: HistoryEntry) {
        Notifier.cancel(app)
        plan = e.plan; stopIndex = 0; started = false; aborted = false; variants.clear(); paid.clear(); agentPaid.clear(); handed.clear()
        store.save(Store.Session(e.plan, 0, false)); screen = Screen.OVERVIEW
    }

    init {
        history.addAll(store.history())
        store.load()?.let { s ->
            plan = s.plan; stopIndex = s.index.coerceIn(0, maxOf(0, s.plan.stops.size - 1)); started = s.started
            paid.putAll(s.paid); agentPaid.putAll(s.agentPaid); handed.addAll(s.handed)
            if (started) Notifier.stage(app, s.plan, stopIndex)
        }
    }

    val hasActiveRoute get() = plan != null && plan!!.stops.isNotEmpty()

    private fun persist() {
        plan?.let {
            store.save(Store.Session(it, stopIndex, started, paid.toMap(), agentPaid.toMap(), handed.toSet()))
            if (started) Notifier.stage(app, it, stopIndex)
        }
    }

    /** Сгиб Galaxy Flip/Fold в положении «ноутбук»: верх и низ сгиба в пикселях окна, иначе null. */
    var fold by mutableStateOf<Pair<Int, Int>?>(null)

    /** Повторно показать уведомление (например, после выдачи разрешения). */
    fun refreshNotification() { plan?.let { if (started && screen != Screen.FINISH) Notifier.stage(app, it, stopIndex) } }

    // ---------- изображения ----------
    private val textReader by lazy {
        com.google.mlkit.vision.text.TextRecognition.getClient(com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    /** Сколько страниц автоматически повернули при последней подготовке. */
    private var turned = 0

    /**
     * Модели плохо читают повёрнутый лист, поэтому перед отправкой страницу ставим прямо.
     * 1) Телефон читает уменьшенную копию и по направлению строк (откуда и куда идёт текст)
     *    голосует за один из четырёх поворотов — длинные строки весят больше.
     * 2) Если голосование неуверенное, читаем лист во всех четырёх положениях и берём то,
     *    где распознаётся больше чисел (в маршрутном листе их много).
     * Автоматика может ошибиться, поэтому результат всегда показывается миниатюрой с кнопкой «Повернуть».
     */
    private fun autoAngle(bm: Bitmap): Int = runCatching {
        val k = 1200f / maxOf(bm.width, bm.height)
        val small = if (k < 1f) Bitmap.createScaledBitmap(bm, (bm.width * k).toInt(), (bm.height * k).toInt(), true) else bm
        fun read(deg: Int): com.google.mlkit.vision.text.Text = com.google.android.gms.tasks.Tasks.await(
            textReader.process(com.google.mlkit.vision.common.InputImage.fromBitmap(small, deg)), 20, java.util.concurrent.TimeUnit.SECONDS)
        val r0 = read(0)
        // Голосование по направлению строк: 0 — текст идёт слева направо, 90 — сверху вниз и т.д.
        val votes = DoubleArray(4)
        for (l in r0.textBlocks.flatMap { it.lines }) {
            val c = l.cornerPoints ?: continue
            if (c.size < 2 || l.text.count { it.isLetterOrDigit() } < 3) continue
            val dx = (c[1].x - c[0].x).toDouble(); val dy = (c[1].y - c[0].y).toDouble()
            val len = Math.hypot(dx, dy)
            if (len < 15) continue
            val ang = (Math.toDegrees(Math.atan2(dy, dx)) + 360) % 360
            votes[(((ang + 45) % 360) / 90).toInt()] += len
        }
        val total = votes.sum()
        val top = votes.indices.maxByOrNull { votes[it] } ?: 0
        if (total > 300 && votes[top] > total * 0.7) {
            // Текст идёт под углом top*90° по часовой — значит, лист надо повернуть на столько же против часовой
            return@runCatching (360 - top * 90) % 360
        }
        fun score(t: com.google.mlkit.vision.text.Text): Int {
            val words = t.textBlocks.flatMap { it.lines }.flatMap { it.elements }.map { it.text.trim('.', ',', ';', ':') }
            return words.sumOf { w -> w.count { it.isDigit() } } + words.count { Regex("^\\d{2,}([.,]\\d+)?$").matches(it) } * 6
        }
        listOf(0, 90, 180, 270).maxByOrNull { d -> score(if (d == 0) r0 else read(d)) } ?: 0
    }.getOrDefault(0)

    private fun rotated(bm: Bitmap, deg: Int): Bitmap =
        if (deg % 360 == 0) bm else Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, Matrix().apply { postRotate(deg.toFloat()) }, true)

    /** Страницы уже в том виде, в каком уйдут на распознавание. */
    val pages = mutableStateListOf<PageImg>()
    var preparing by mutableStateOf(false)

    /** Готовит выбранные страницы: открывает, выравнивает, показывает миниатюры. После сканера может сразу распознать. */
    fun prepare(autoStart: Boolean) {
        val list = uris.toList()
        viewModelScope.launch {
            busy = "Выравниваем страницы"; preparing = true; error = null; turned = 0; pages.clear()
            try {
                val ready = withContext(Dispatchers.IO) {
                    list.flatMap { toBitmaps(it) }.map { bm -> autoAngle(bm).let { d -> if (d != 0) turned++; PageImg(rotated(bm, d)) } }
                }
                pages.addAll(ready)
                if (turned > 0) info = "Повёрнуто страниц: $turned. Проверьте миниатюры — если что-то не так, нажмите «Повернуть»"
            } catch (e: Exception) { error = e.message ?: e.toString() } finally { busy = null; preparing = false }
            // После сканера распознаём сразу, но только если ничего не поворачивали — иначе ждём проверки
            if (autoStart && turned == 0 && pages.isNotEmpty()) recognize()
        }
    }

    /** Ручной поворот миниатюры на 90° по часовой. */
    fun rotatePage(i: Int) { if (i in pages.indices) pages[i] = PageImg(rotated(pages[i].bmp, 90)) }

    private fun jpeg(b: Bitmap): ByteArray {
        val m = 2000f / maxOf(b.width, b.height)
        val s = if (m < 1f) Bitmap.createScaledBitmap(b, (b.width * m).toInt(), (b.height * m).toInt(), true) else b
        return ByteArrayOutputStream().also { s.compress(Bitmap.CompressFormat.JPEG, 85, it) }.toByteArray()
    }

    /** Страница не больше 2000 px по длинной стороне — столько же уходит в нейросеть. */
    private fun fit(b: Bitmap): Bitmap {
        val m = 2000f / maxOf(b.width, b.height)
        return if (m < 1f) Bitmap.createScaledBitmap(b, (b.width * m).toInt(), (b.height * m).toInt(), true) else b
    }

    private fun toBitmaps(uri: Uri): List<Bitmap> {
        val cr = app.contentResolver
        val out = ArrayList<Bitmap>()
        if ((cr.getType(uri) ?: "").contains("pdf")) {
            cr.openFileDescriptor(uri, "r")!!.use { fd ->
                PdfRenderer(fd).use { r ->
                    for (i in 0 until r.pageCount) r.openPage(i).use { pg ->
                        val sc = 1800f / maxOf(pg.width, pg.height)
                        val bm = Bitmap.createBitmap((pg.width * sc).toInt(), (pg.height * sc).toInt(), Bitmap.Config.ARGB_8888)
                        bm.eraseColor(Color.WHITE)
                        pg.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        out.add(bm)
                    }
                }
            }
        } else {
            val bm = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it) } ?: error("Не удалось открыть изображение")
            val rot = runCatching {
                cr.openInputStream(uri)!!.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) }
            }.getOrDefault(1)
            out.add(rotated(fit(bm), when (rot) { 6 -> 90; 3 -> 180; 8 -> 270; else -> 0 }))
        }
        return out
    }

    // ---------- распознавание ----------
    fun recognize() {
        if (st.apiKey.isEmpty() || st.model.isEmpty() || st.folder.isEmpty()) { error = "В сборке нет ключа или модели Yandex — проверьте секреты YANDEX_API_KEY, DEEPSEEK_MODEL, QWEN_MODEL"; return }
        viewModelScope.launch {
            busy = "Отправляем сканы в облако"; error = null
            try {
                val imgs = pages.toList()
                if (imgs.isEmpty()) error("Сначала выберите или отсканируйте страницы")
                val jpegs = withContext(Dispatchers.IO) { imgs.map { jpeg(it.bmp) } }
                val rec = withContext(Dispatchers.IO) { Net.recognize(st, jpegs) { i, n -> busy = "Распознаём страницу $i из $n" } }
                agents.clear(); agents.addAll(rec.agents); rows.clear(); rows.addAll(rec.rows)
                header = rec.header; total = rec.total; totalNoSg = rec.totalNoSg; screen = Screen.REVIEW
                if (rec.truncated) error = "Ответ модели обрезан на одной из страниц — проверьте, что все строки на месте."
            } catch (e: Exception) { error = e.message ?: e.toString() } finally { busy = null }
        }
    }

    fun update(r: Row) { val i = rows.indexOfFirst { it.id == r.id }; if (i >= 0) rows[i] = r }
    fun addRow() { rows.add(Row((rows.maxOfOrNull { it.id } ?: -1) + 1)) }
    fun delRow(id: Int) { rows.removeAll { it.id == id } }

    /** Позывные, у которых в листе только возвраты без товара — в маршрут не идут. */
    private fun returnOnlyCallsigns(): Set<String> = rows.filter { it.callsign.isNotBlank() }
        .groupBy { db.norm(it.callsign) }.filterValues { g -> g.all { it.kind == Kind.RETURN } }.keys

    val returnOnlyCount get() = returnOnlyCallsigns().size

    // ---------- сопоставление ----------
    fun startMatch() {
        error = null; assigned.clear(); queue.clear(); excludedRows.clear(); agentRows.clear(); qi = 0
        val ro = returnOnlyCallsigns()
        for (r in rows) {
            if (r.callsign.isNotBlank() && db.norm(r.callsign) in ro) { excludedRows.add(r.id); continue }
            val p = if (r.callsign.isBlank() || manual(r)) null else db.pointFor(r.callsign)
            if (p == null) queue.add(r.id) else assigned[r.id] = p.name
        }
        if (queue.isEmpty()) afterMatch() else screen = Screen.MATCH
    }

    fun choose(rowId: Int, pointName: String) {
        val r = rows.first { it.id == rowId }
        assigned[rowId] = pointName
        if (!manual(r) && !r.needsChoice && r.callsign.isNotBlank() && db.calls[db.norm(r.callsign)] != pointName) pendingLinks.add(r.callsign.trim() to pointName)
        next()
    }

    fun createPoint(rowId: Int, p: Point) { db.addPoint(p); dbVer++; choose(rowId, p.name) }
    fun skip() = next()
    fun agentTakes(rowId: Int) { assigned.remove(rowId); agentRows.add(rowId); next() }
    fun backMatch() { if (qi > 0) qi-- else screen = Screen.REVIEW }
    private fun next() { qi++; if (qi >= queue.size) afterMatch() }

    // ---------- оборудование ----------
    fun pointOf(rowId: Int): Point? = assigned[rowId]?.let { db.point(it) }
    val equipRows get() = rows.filter { it.kind == Kind.EQUIPMENT && assigned.containsKey(it.id) }

    private fun afterMatch() {
        if (equipRows.any { it.equip == EquipDir.UNKNOWN }) screen = Screen.EQUIP else buildRoute()
    }

    fun setEquip(id: Int, d: EquipDir) { rows.firstOrNull { it.id == id }?.let { update(it.copy(equip = d)) } }
    fun equipDone() { if (equipRows.all { it.equip != EquipDir.UNKNOWN }) buildRoute() }

    // ---------- маршрут ----------
    fun buildRoute() {
        viewModelScope.launch {
            busy = "Считаем дороги и время"; error = null
            try {
                val all = rows.filter { assigned.containsKey(it.id) }.groupBy { assigned[it.id]!! }
                // Правило: у точки только возврат(ы), накладных на товар нет — точку не объезжаем
                val excludedGroups = all.filterValues { g -> g.all { it.kind == Kind.RETURN } }
                val groups = all.filterKeys { it !in excludedGroups.keys }
                val excluded = ArrayList<Excluded>()
                rows.filter { it.id in excludedRows }.forEach { r ->
                    excluded.add(Excluded(db.pointFor(r.callsign)?.display ?: r.client.ifBlank { r.callsign }, r.callsign, r.invoiceLabel))
                }
                excludedGroups.forEach { (name, g) -> g.forEach { r -> excluded.add(Excluded(db.point(name)?.display ?: name, r.callsign, r.invoiceLabel)) } }
                rows.filter { it.id in agentRows }.forEach { r ->
                    val who = agentFor(r.agent)?.name?.ifBlank { null } ?: r.agent.ifBlank { null }
                    val ag = agentFor(r.agent)
                    excluded.add(Excluded(db.pointFor(r.callsign)?.display ?: r.client.ifBlank { r.callsign.ifBlank { "Без позывного" } }, r.callsign,
                        r.invoiceLabel, Excluded.REASON_AGENT, r.factSum, who.orEmpty(), ag?.phone.orEmpty()))
                }
                if (groups.isEmpty()) error("Нет точек для маршрута")
                val pts = groups.keys.map { db.point(it) ?: error("Точка «$it» не найдена в базе") }
                val noCoords = pts.filter { !it.hasCoords }
                if (noCoords.isNotEmpty()) error("Нет координат у точек: " + noCoords.joinToString { it.name } + ". Допишите в xlsx и импортируйте базу.")
                val depotNums = Regex("-?\\d+[.,]\\d+").findAll(st.depot).map { it.value.toD() ?: 0.0 }.toList()
                val warehouse = if (depotNums.size >= 2) Point("Склад", "", depotNums[0], depotNums[1], "Склад") else null
                // Старт — там, где вы стоите (иначе склад). Финиш — склад.
                val here = if (st.startFromGps) { busy = "Определяем, где вы"; currentLocation() } else null
                val startPt = here ?: warehouse
                val endPt = if (st.endAtDepot) warehouse else null
                busy = "Считаем дороги и время"
                val extra = ArrayList<Point>()
                var sIdx: Int? = null; var eIdx: Int? = null
                if (startPt != null) { extra.add(startPt); sIdx = pts.size }
                if (endPt != null) {
                    if (endPt === startPt) eIdx = sIdx else { extra.add(endPt); eIdx = pts.size + extra.size - 1 }
                }
                val nodes = pts + extra
                val w = DoubleArray(nodes.size) { i -> if (i < pts.size) groups[pts[i].name]!!.sumOf { it.weight } else 0.0 }
                val m = withContext(Dispatchers.IO) { Net.matrix(st, nodes, curbCount = pts.size) }
                busy = "Подбираем варианты маршрута"
                val si = sIdx; val ei = eIdx
                // Субботний «приём до …»: крайний срок в секундах от текущего момента
                val nowMin = java.time.LocalTime.now().let { it.hour * 60 + it.minute }
                val dl = DoubleArray(nodes.size) { i ->
                    val lim = if (i < pts.size && isSaturday()) pts[i].saturdayLimitMin else null
                    if (lim == null) Double.NaN else ((lim - nowMin) * 60.0).coerceAtLeast(0.0)
                }
                val modes = listOf(
                    Optimizer.Mode.HUMAN to "Как опытный водитель",
                    Optimizer.Mode.FAST to "Быстрее по времени",
                    Optimizer.Mode.HEAVY to "Тяжёлое — первым"
                )
                val solved = withContext(Dispatchers.Default) {
                    modes.map { (mode, name) ->
                        val o = Optimizer(m.dur, m.dist, DoubleArray(nodes.size) { nodes[it].lat }, DoubleArray(nodes.size) { nodes[it].lon },
                            w, st.capacity.toD() ?: 0.0, si, ei, budgetMs = 1600, mode = mode, deadline = if (dl.any { !it.isNaN() }) dl else null)
                        Triple(o.solve(), o, name)
                    }.distinctBy { it.first.toList() }
                }
                busy = "Рисуем маршрут"
                val built = ArrayList<Plan>()
                for ((order, opt, name) in solved) {
                    val seq = listOfNotNull(startPt) + order.map { nodes[it] } + listOfNotNull(endPt)
                    val curb = listOfNotNull(startPt?.let { false }) + order.map { true } + listOfNotNull(endPt?.let { false })
                    val path = withContext(Dispatchers.IO) { Net.geometry(st, seq, curb) }
                    var load = w.sum(); val stops = ArrayList<PlanStop>()
                    var prev: Int? = si
                    for (i in order) {
                        val g = groups[pts[i].name]!!
                        load -= w[i]
                        val p = prev
                        stops.add(PlanStop(pts[i], g.map { it.callsign }.filter { it.isNotBlank() }.distinct(),
                            g.flatMap { contactsOf(it) }.distinct(), w[i], g.sumOf { it.factSum }, load, g,
                            if (p == null) 0.0 else m.dist[p][i] / 1000.0, if (p == null) 0.0 else m.dur[p][i] / 60.0))
                        prev = i
                    }
                    val lastI = order.lastOrNull()
                    val endKm = if (ei != null && lastI != null) m.dist[lastI][ei] / 1000.0 else 0.0
                    val endMin = if (ei != null && lastI != null) m.dur[lastI][ei] / 60.0 else 0.0
                    val links = run {
                        // В навигатор для грузовика уходит и Ласпинский перевал, иначе Яндекс сам поведёт через Байдарские ворота
                        val nav = Net.withDetours(st, seq)
                        val l = ArrayList<String>(); var s = 0
                        while (s < nav.size - 1 || (s == 0 && nav.size == 1)) {
                            val part = nav.subList(s, minOf(s + 10, nav.size))
                            l.add("https://yandex.ru/maps/?rtext=" + part.joinToString("~") { "${it.lat},${it.lon}" } + "&rtt=auto")
                            s += 9
                        }
                        l
                    }
                    built.add(Plan(stops, opt.distance(order) / 1000.0, opt.duration(order) / 60.0, links, path, startPt, excluded, header,
                        endPt, endKm, endMin, name))
                }
                variants.clear(); variants.addAll(built)
                plan = built.first()
                stopIndex = 0; started = false; aborted = false; paid.clear(); agentPaid.clear(); handed.clear(); persist()
                if (m.approximate) error = "Сервер дорог недоступен — расстояния оценены по прямой. Порядок всё равно оптимизирован."
                screen = Screen.OVERVIEW
            } catch (e: Exception) { error = e.message ?: e.toString(); screen = Screen.HOME } finally { busy = null }
        }
    }

    @android.annotation.SuppressLint("MissingPermission")
    private suspend fun currentLocation(): Point? = withContext(Dispatchers.Main) {
        val granted = listOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION)
            .any { app.checkSelfPermission(it) == android.content.pm.PackageManager.PERMISSION_GRANTED }
        if (!granted) return@withContext null
        val lm = app.getSystemService(android.location.LocationManager::class.java) ?: return@withContext null
        val providers = listOf(android.location.LocationManager.GPS_PROVIDER, android.location.LocationManager.NETWORK_PROVIDER)
            .filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }
        var best: android.location.Location? = providers.mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
        val stale = best == null || System.currentTimeMillis() - best.time > 5 * 60_000
        if (stale && android.os.Build.VERSION.SDK_INT >= 30 && providers.isNotEmpty()) {
            val fresh = kotlinx.coroutines.withTimeoutOrNull(8000) {
                kotlinx.coroutines.suspendCancellableCoroutine<android.location.Location?> { cont ->
                    val cs = android.os.CancellationSignal()
                    cont.invokeOnCancellation { cs.cancel() }
                    runCatching {
                        lm.getCurrentLocation(providers.first(), cs, app.mainExecutor) { l -> if (cont.isActive) cont.resumeWith(Result.success(l)) }
                    }.onFailure { if (cont.isActive) cont.resumeWith(Result.success(null)) }
                }
            }
            if (fresh != null) best = fresh
        }
        best?.let { Point("Старт", "", it.latitude, it.longitude, "Вы здесь") }
    }

    // ---------- ведение ----------
    /** «Поехали» с обзора: сначала экран загрузки авто. */
    fun toLoading() { screen = Screen.LOAD }
    fun go() { started = true; direction = 1; persist(); intro = "Поехали"; screen = Screen.DRIVE }
    fun nextStop() {
        val p = plan ?: return
        direction = 1
        if ((p.stops.getOrNull(stopIndex)?.fact ?: 0.0) > 0 && paid[stopIndex] == null) { askPaid = true; return }
        if (stopIndex >= p.stops.size - 1) {
            screen = Screen.FINISH; store.save(null)
            record(p, p.stops.size, false)
            if (p.end != null) Notifier.toWarehouse(app, p) else Notifier.cancel(app)
            return
        }
        stopIndex++; persist()
    }
    fun answerPaid(ok: Boolean) { paid[stopIndex] = ok; askPaid = false; persist(); nextStop() }
    /** Сколько наличных реально получено (только подтверждённые оплаты). */
    val cashCollected get() = (plan?.stops?.withIndex()?.filter { paid[it.index] == true }?.sumOf { it.value.fact } ?: 0.0) +
        (plan?.excluded?.withIndex()?.filter { agentPaid[it.index] == true }?.sumOf { it.value.cash } ?: 0.0)
    fun prevStop() { if (stopIndex > 0) { direction = -1; stopIndex--; persist() } }
    fun jumpTo(i: Int) { direction = if (i >= stopIndex) 1 else -1; stopIndex = i; started = true; persist(); screen = Screen.DRIVE }
    fun resume() { screen = if (started) Screen.DRIVE else Screen.OVERVIEW }
    fun finishRoute() { aborted = false; paid.clear(); agentPaid.clear(); handed.clear(); variants.clear(); askPaid = false; plan = null; stopIndex = 0; started = false; store.save(null); Notifier.cancel(app); uris.clear(); pages.clear(); screen = Screen.HOME }

    /** Досрочно прервать маршрут: всё, что осталось, не объезжаем. */
    var aborted by mutableStateOf(false)
    fun abortRoute() {
        val p = plan ?: return
        aborted = true; store.save(null)
        record(p, if (started) stopIndex else 0, true)
        if (p.end != null) Notifier.toWarehouse(app, p) else Notifier.cancel(app)
        screen = Screen.FINISH
    }

    // ---------- проверка позывного ----------
    fun linkCallsign(callsign: String, pointName: String) { if (callsign.isNotBlank()) { db.link(callsign.trim(), pointName); dbVer++ } }
    fun unlinkCallsign(callsign: String) { db.unlink(callsign); dbVer++ }

    // ---------- БД ----------
    /** Короткое сообщение об успехе (обновление базы и т.п.). */
    var info by mutableStateOf<String?>(null)

    /** Обновление базы из xlsx: совпавшие точки и позывные переписываются, новые добавляются. */
    /** Позывные, которые ждут подтверждения «запомнить за точкой» — чтобы ошибки распознавания не попадали в базу. */
    val pendingLinks = androidx.compose.runtime.mutableStateListOf<Pair<String, String>>()
    fun confirmLink(save: Boolean) {
        val p = pendingLinks.removeFirstOrNull() ?: return
        if (save) { db.link(p.first, p.second); dbVer++ }
    }

    /** Заставка с логотипом: подпись под знаком или null, если заставки нет. */
    var intro by mutableStateOf<String?>(null)
    /** Приложение возвращается из фона (или запускается) — показать заставку. Переживает поворот и сгиб экрана. */
    var fromBackground = true

    /** Выбранный файл базы ждёт решения: обновить или заменить целиком. */
    var pendingImport by mutableStateOf<Uri?>(null)
    fun replaceDb(u: Uri) {
        try {
            app.contentResolver.openInputStream(u)!!.use { db.replace(it) }
            db.save(); dbVer++; error = null
            info = "База заменена: ${db.points.size} " + ru.marshrut.ui.plural(db.points.size, "точка", "точки", "точек") +
                ", ${db.calls.size} " + ru.marshrut.ui.plural(db.calls.size, "позывной", "позывных", "позывных")
        } catch (e: Exception) { error = "Не удалось заменить базу: ${e.message}" }
    }

    fun importDb(u: Uri) {
        try {
            val r = app.contentResolver.openInputStream(u)!!.use { db.merge(it) }
            db.save(); dbVer++; error = null
            fun pts(n: Int) = "$n " + ru.marshrut.ui.plural(n, "точка", "точки", "точек")
            fun cs(n: Int) = "$n " + ru.marshrut.ui.plural(n, "позывной", "позывных", "позывных")
            val parts = listOfNotNull(
                if (r.pointsUpdated > 0) "обновлено ${pts(r.pointsUpdated)}" else null,
                if (r.pointsAdded > 0) "добавлено ${pts(r.pointsAdded)}" else null,
                if (r.callsUpdated > 0) "обновлено ${cs(r.callsUpdated)}" else null,
                if (r.callsAdded > 0) "добавлено ${cs(r.callsAdded)}" else null
            )
            info = if (parts.isEmpty()) "Изменений нет — база уже актуальна" else parts.joinToString(", ").replaceFirstChar { it.uppercase() }
        } catch (e: Exception) { error = "Не удалось обновить базу: ${e.message}" }
    }
    fun exportDb(u: Uri) {
        try { app.contentResolver.openOutputStream(u)!!.use { db.write(it) } } catch (e: Exception) { error = e.message }
    }
    fun geocode(addr: String, cb: (Pair<Double, Double>?) -> Unit) {
        viewModelScope.launch { cb(withContext(Dispatchers.IO) { runCatching { Net.geocode(addr) }.getOrNull() }) }
    }
    // ---------- резервная копия на Яндекс Диске ----------
    /** Время последней удачной копии и ошибка последней попытки — для экрана настроек. */
    var lastBackup by mutableStateOf(st.lastBackup)
    var backupError by mutableStateOf<String?>(null)
    private var cloudBusy = false

    private fun sha(parts: Collection<ByteArray>): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        parts.forEach { md.update(it) }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** Сама по себе: только если включено, вход задан и с прошлой копии что-то изменилось (или сегодня архива ещё нет). */
    fun autoBackup() { if (st.autoBackup && st.cloudReady) backup(manual = false) }

    /** Вход в Яндекс по коду: код, который пользователь вводит на ya.ru/device, пока ждём подтверждения. */
    var yaCode by mutableStateOf<Cloud.DeviceCode?>(null)
    var cloudConnected by mutableStateOf(st.cloudReady)
    private var loginJob: kotlinx.coroutines.Job? = null

    fun yandexLogin() {
        if (!Cloud.configured) { error = "В сборке нет ID приложения Яндекса — добавьте секреты YANDEX_OAUTH_CLIENT_ID и YANDEX_OAUTH_CLIENT_SECRET"; return }
        loginJob?.cancel()
        loginJob = viewModelScope.launch {
            try {
                val dc = withContext(Dispatchers.IO) { Cloud.deviceCode() }
                yaCode = dc
                val until = System.currentTimeMillis() + dc.expiresIn * 1000L
                while (System.currentTimeMillis() < until) {
                    kotlinx.coroutines.delay(dc.interval.coerceAtLeast(2) * 1000L)
                    // Обрыв связи во время ожидания — не повод бросать вход, спросим ещё раз
                    val t = (try { withContext(Dispatchers.IO) { Cloud.pollToken(dc.deviceCode) } } catch (e: java.io.IOException) { null }) ?: continue
                    st.yaToken = t.access; st.yaRefresh = t.refresh; st.backupHash = ""
                    cloudConnected = true; yaCode = null; backupError = null
                    info = "Яндекс Диск подключён"
                    backup(manual = false)
                    return@launch
                }
                yaCode = null; error = "Код устарел — нажмите «Войти через Яндекс» ещё раз"
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                yaCode = null; error = "Не удалось войти: ${Cloud.describe(e)}"
            }
        }
    }
    fun cancelLogin() { loginJob?.cancel(); yaCode = null }
    fun yandexLogout() { cancelLogin(); st.yaToken = ""; st.yaRefresh = ""; cloudConnected = false; backupError = null }

    fun backup(manual: Boolean) {
        if (!st.cloudReady) { if (manual) error = "Сначала войдите через Яндекс"; return }
        if (cloudBusy) { if (manual) info = "Копия уже сохраняется"; return }
        val files = linkedMapOf(Cloud.DB to db.bytes())
        store.historyBytes()?.let { files[Cloud.HISTORY] = it }
        val hash = sha(files.values)
        val today = java.time.LocalDate.now().toString()
        val archive = if (st.archiveDay != today) today else null
        if (!manual && hash == st.backupHash && archive == null) return
        cloudBusy = true
        if (manual) busy = "Сохраняем на Яндекс Диск"
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { Cloud.upload(st, files, archive) }
                val now = System.currentTimeMillis()
                st.backupHash = hash; st.archiveDay = today; st.lastBackup = now
                lastBackup = now; backupError = null
                if (manual) info = "Копия сохранена на Яндекс Диск"
            } catch (e: Exception) {
                backupError = Cloud.describe(e)
                if (e is Cloud.AuthError) { st.yaToken = ""; cloudConnected = false }
                if (manual) error = "Не удалось сохранить: ${Cloud.describe(e)}"
            } finally {
                cloudBusy = false
                if (manual) busy = null
            }
        }
    }

    /** Заменяет базу точек и историю маршрутов копией с Диска. Текущий маршрут не трогает. */
    fun restore() {
        if (!st.cloudReady) { error = "Сначала войдите через Яндекс"; return }
        if (cloudBusy) { info = "Подождите, идёт сохранение копии"; return }
        cloudBusy = true; busy = "Загружаем с Яндекс Диска"
        viewModelScope.launch {
            try {
                val (dbData, histData) = withContext(Dispatchers.IO) {
                    Cloud.download(st, Cloud.DB) to Cloud.download(st, Cloud.HISTORY)
                }
                if (dbData == null) error("На Диске ещё нет копии — сначала сохраните её с этого или старого телефона")
                db.replace(dbData.inputStream()); db.save(); dbVer++
                if (histData != null) { store.restoreHistory(histData); history.clear(); history.addAll(store.history()) }
                backupError = null; error = null
                info = "Восстановлено: ${db.points.size} " + ru.marshrut.ui.plural(db.points.size, "точка", "точки", "точек") +
                    ", ${history.size} " + ru.marshrut.ui.plural(history.size, "маршрут", "маршрута", "маршрутов") + " в истории"
            } catch (e: Exception) {
                if (e is Cloud.AuthError) { st.yaToken = ""; cloudConnected = false }
                error = "Не удалось восстановить: ${Cloud.describe(e)}"
            } finally {
                cloudBusy = false; busy = null
            }
        }
    }

    init {
        if (db.restored) info = "Загружена встроенная база. Если раньше вы её дополняли, верните правки: «Обновить из xlsx» → Загрузки/Маршрут/marshrut_db.xlsx"
    }
}

enum class Screen { HOME, CHECK, SETTINGS, REVIEW, MATCH, EQUIP, OVERVIEW, LOAD, DRIVE, FINISH, HISTORY, HISTORY_DETAIL }
