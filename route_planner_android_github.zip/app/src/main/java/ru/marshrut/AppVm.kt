package ru.marshrut

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

class AppVm(private val app: Application) : AndroidViewModel(app) {
    val st = Settings(app.getSharedPreferences("s", 0))
    val db = Db(app)
    private val store = Store(app)
    var dbVer by mutableIntStateOf(0)

    var screen by mutableStateOf(Screen.HOME)
    val uris = mutableStateListOf<Uri>()
    var busy by mutableStateOf<String?>(null)
    var error by mutableStateOf<String?>(null)
    val agents = mutableStateListOf<Agent>()
    var sortByAgent by mutableStateOf(false)
    var header by mutableStateOf("")
    var total by mutableStateOf<Double?>(null)
    var totalNoSg by mutableStateOf<Double?>(null)
    private fun k(s: String) = s.uppercase().filter { !it.isWhitespace() }
    fun agentFor(num: String): Agent? = k(num).let { n -> if (n.isEmpty()) null else agents.firstOrNull { k(it.num) == n } }
    fun contactsOf(r: Row): List<Agent> = listOfNotNull(agentFor(r.agent))
    /** Исключения из правила «факт/ЧЗ»: возврат, оборудование или агент Маврычев — идём по распознанному. */
    fun bypass(r: Row): Boolean = r.kind != Kind.GOODS ||
        agentFor(r.agent)?.name?.contains("маврыч", true) == true || r.agent.contains("маврыч", true)
    /** Нужен ли ручной выбор точки (позывной не ищем по базе). */
    fun manual(r: Row): Boolean = r.needsChoice && !bypass(r)
    val rows = mutableStateListOf<Row>()
    val queue = mutableStateListOf<Int>()
    var qi by mutableIntStateOf(0)
    private val assigned = HashMap<Int, String>()
    private val excludedRows = HashSet<Int>()
    /** Сомнительные строки с фактом, которые заберёт торговый представитель — в объезд не идут. */
    private val agentRows = HashSet<Int>()

    // ---------- ведение по маршруту ----------
    var plan by mutableStateOf<Plan?>(null)
    var stopIndex by mutableIntStateOf(0)
    var started by mutableStateOf(false)
    /** Направление последнего перехода между точками: 1 вперёд, -1 назад — для анимации. */
    var direction by mutableIntStateOf(1)
    /** Оплата наличных по точкам: индекс точки → оплатили / нет. */
    val paid = androidx.compose.runtime.mutableStateMapOf<Int, Boolean>()
    /** Показать вопрос «Оплатили?» перед переходом к следующей точке. */
    var askPaid by mutableStateOf(false)

    // ---------- история ----------
    val history = mutableStateListOf<HistoryEntry>()
    var historyItem by mutableStateOf<HistoryEntry?>(null)

    private fun record(p: Plan, done: Int, aborted: Boolean) {
        val now = System.currentTimeMillis()
        history.add(0, HistoryEntry(now, now, p, done, aborted))
        store.saveHistory(history)
    }

    fun openHistory(e: HistoryEntry) { historyItem = e; screen = Screen.HISTORY_DETAIL }
    fun deleteHistory(e: HistoryEntry) { history.removeAll { it.id == e.id }; store.saveHistory(history); historyItem = null; screen = Screen.HISTORY }

    /** Снова поехать по сохранённому маршруту (тот же порядок точек). */
    fun repeatRoute(e: HistoryEntry) {
        Notifier.cancel(app)
        plan = e.plan; stopIndex = 0; started = false; aborted = false
        store.save(Store.Session(e.plan, 0, false)); screen = Screen.OVERVIEW
    }

    init {
        history.addAll(store.history())
        store.load()?.let { s ->
            plan = s.plan; stopIndex = s.index.coerceIn(0, maxOf(0, s.plan.stops.size - 1)); started = s.started
            paid.putAll(s.paid)
            if (started) Notifier.stage(app, s.plan, stopIndex)
        }
    }

    val hasActiveRoute get() = plan != null && plan!!.stops.isNotEmpty()

    private fun persist() {
        plan?.let {
            store.save(Store.Session(it, stopIndex, started, paid.toMap()))
            if (started) Notifier.stage(app, it, stopIndex)
        }
    }

    /** Сгиб Galaxy Flip/Fold в положении «ноутбук»: верх и низ сгиба в пикселях окна, иначе null. */
    var fold by mutableStateOf<Pair<Int, Int>?>(null)

    /** Повторно показать уведомление (например, после выдачи разрешения). */
    fun refreshNotification() { plan?.let { if (started && screen != Screen.FINISH) Notifier.stage(app, it, stopIndex) } }

    // ---------- изображения ----------
    private fun jpeg(b: Bitmap): ByteArray {
        val m = 2000f / maxOf(b.width, b.height)
        val s = if (m < 1f) Bitmap.createScaledBitmap(b, (b.width * m).toInt(), (b.height * m).toInt(), true) else b
        return ByteArrayOutputStream().also { s.compress(Bitmap.CompressFormat.JPEG, 85, it) }.toByteArray()
    }

    private fun toJpegs(uri: Uri): List<ByteArray> {
        val cr = app.contentResolver
        val out = ArrayList<ByteArray>()
        if ((cr.getType(uri) ?: "").contains("pdf")) {
            cr.openFileDescriptor(uri, "r")!!.use { fd ->
                PdfRenderer(fd).use { r ->
                    for (i in 0 until r.pageCount) r.openPage(i).use { pg ->
                        val sc = 1800f / maxOf(pg.width, pg.height)
                        val bm = Bitmap.createBitmap((pg.width * sc).toInt(), (pg.height * sc).toInt(), Bitmap.Config.ARGB_8888)
                        bm.eraseColor(Color.WHITE)
                        pg.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        out.add(jpeg(bm))
                    }
                }
            }
        } else {
            var bm = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it) } ?: error("Не удалось открыть изображение")
            val rot = runCatching {
                cr.openInputStream(uri)!!.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) }
            }.getOrDefault(1)
            val deg = when (rot) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
            if (deg != 0f) bm = Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, Matrix().apply { postRotate(deg) }, true)
            out.add(jpeg(bm))
        }
        return out
    }

    // ---------- распознавание ----------
    fun recognize() {
        if (st.apiKey.isEmpty() || st.folder.isEmpty()) { error = "Укажите API-ключ и ID каталога в настройках"; return }
        viewModelScope.launch {
            busy = "Отправляем сканы в облако"; error = null
            try {
                val rec = withContext(Dispatchers.IO) { Net.recognize(st, uris.flatMap { toJpegs(it) }) { i, n -> busy = "Распознаём страницу $i из $n" } }
                agents.clear(); agents.addAll(rec.agents); rows.clear(); rows.addAll(rec.rows)
                header = rec.header; total = rec.total; totalNoSg = rec.totalNoSg; screen = Screen.REVIEW
                if (rec.truncated) error = "Ответ модели обрезан на одной из страниц — проверьте, что все строки на месте."
            } catch (e: Exception) { error = e.message ?: e.toString() } finally { busy = null }
        }
    }

    fun update(r: Row) { val i = rows.indexOfFirst { it.id == r.id }; if (i >= 0) rows[i] = r }
    fun addRow() { rows.add(Row((rows.maxOfOrNull { it.id } ?: -1) + 1)) }
    fun delRow(id: Int) { rows.removeAll { it.id == id } }

    /** Позывные, у которых в листе только возвраты без товара — в маршрут не идут. */
    private fun returnOnlyCallsigns(): Set<String> = rows.filter { it.callsign.isNotBlank() }
        .groupBy { db.norm(it.callsign) }.filterValues { g -> g.all { it.kind == Kind.RETURN } }.keys

    val returnOnlyCount get() = returnOnlyCallsigns().size

    // ---------- сопоставление ----------
    fun startMatch() {
        error = null; assigned.clear(); queue.clear(); excludedRows.clear(); agentRows.clear(); qi = 0
        val ro = returnOnlyCallsigns()
        for (r in rows) {
            if (r.callsign.isNotBlank() && db.norm(r.callsign) in ro) { excludedRows.add(r.id); continue }
            val p = if (r.callsign.isBlank() || manual(r)) null else db.pointFor(r.callsign)
            if (p == null) queue.add(r.id) else assigned[r.id] = p.name
        }
        if (queue.isEmpty()) afterMatch() else screen = Screen.MATCH
    }

    fun choose(rowId: Int, pointName: String) {
        val r = rows.first { it.id == rowId }
        assigned[rowId] = pointName
        if (!manual(r) && !r.needsChoice && r.callsign.isNotBlank() && db.calls[db.norm(r.callsign)] != pointName) { db.link(r.callsign, pointName); dbVer++ }
        next()
    }

    fun createPoint(rowId: Int, p: Point) { db.addPoint(p); dbVer++; choose(rowId, p.name) }
    fun skip() = next()
    fun agentTakes(rowId: Int) { assigned.remove(rowId); agentRows.add(rowId); next() }
    fun backMatch() { if (qi > 0) qi-- else screen = Screen.REVIEW }
    private fun next() { qi++; if (qi >= queue.size) afterMatch() }

    // ---------- оборудование ----------
    fun pointOf(rowId: Int): Point? = assigned[rowId]?.let { db.point(it) }
    val equipRows get() = rows.filter { it.kind == Kind.EQUIPMENT && assigned.containsKey(it.id) }

    private fun afterMatch() {
        if (equipRows.any { it.equip == EquipDir.UNKNOWN }) screen = Screen.EQUIP else buildRoute()
    }

    fun setEquip(id: Int, d: EquipDir) { rows.firstOrNull { it.id == id }?.let { update(it.copy(equip = d)) } }
    fun equipDone() { if (equipRows.all { it.equip != EquipDir.UNKNOWN }) buildRoute() }

    // ---------- маршрут ----------
    fun buildRoute() {
        viewModelScope.launch {
            busy = "Считаем дороги и время"; error = null
            try {
                val all = rows.filter { assigned.containsKey(it.id) }.groupBy { assigned[it.id]!! }
                // Правило: у точки только возврат(ы), накладных на товар нет — точку не объезжаем
                val excludedGroups = all.filterValues { g -> g.all { it.kind == Kind.RETURN } }
                val groups = all.filterKeys { it !in excludedGroups.keys }
                val excluded = ArrayList<Excluded>()
                rows.filter { it.id in excludedRows }.forEach { r ->
                    excluded.add(Excluded(db.pointFor(r.callsign)?.display ?: r.client.ifBlank { r.callsign }, r.callsign, r.invoiceLabel))
                }
                excludedGroups.forEach { (name, g) -> g.forEach { r -> excluded.add(Excluded(db.point(name)?.display ?: name, r.callsign, r.invoiceLabel)) } }
                rows.filter { it.id in agentRows }.forEach { r ->
                    val who = agentFor(r.agent)?.name?.ifBlank { null } ?: r.agent.ifBlank { null }
                    excluded.add(Excluded(db.pointFor(r.callsign)?.display ?: r.client.ifBlank { r.callsign.ifBlank { "Без позывного" } }, r.callsign,
                        listOfNotNull(if (r.factSum != 0.0) "факт ${money(r.factSum)}" else null, who).joinToString(", ").ifBlank { r.invoiceLabel },
                        Excluded.REASON_AGENT))
                }
                if (groups.isEmpty()) error("Нет точек для маршрута")
                val pts = groups.keys.map { db.point(it) ?: error("Точка «$it» не найдена в базе") }
                val noCoords = pts.filter { !it.hasCoords }
                if (noCoords.isNotEmpty()) error("Нет координат у точек: " + noCoords.joinToString { it.name } + ". Допишите в xlsx и импортируйте базу.")
                val depotNums = Regex("-?\\d+[.,]\\d+").findAll(st.depot).map { it.value.toD() ?: 0.0 }.toList()
                val warehouse = if (depotNums.size >= 2) Point("Склад", "", depotNums[0], depotNums[1], "Склад") else null
                // Старт — там, где вы стоите (иначе склад). Финиш — склад.
                val here = if (st.startFromGps) { busy = "Определяем, где вы"; currentLocation() } else null
                val startPt = here ?: warehouse
                val endPt = if (st.endAtDepot) warehouse else null
                busy = "Считаем дороги и время"
                val extra = ArrayList<Point>()
                var sIdx: Int? = null; var eIdx: Int? = null
                if (startPt != null) { extra.add(startPt); sIdx = pts.size }
                if (endPt != null) {
                    if (endPt === startPt) eIdx = sIdx else { extra.add(endPt); eIdx = pts.size + extra.size - 1 }
                }
                val nodes = pts + extra
                val w = DoubleArray(nodes.size) { i -> if (i < pts.size) groups[pts[i].name]!!.sumOf { it.weight } else 0.0 }
                val m = withContext(Dispatchers.IO) { Net.matrix(st, nodes) }
                busy = "Подбираем порядок объезда"
                val si = sIdx; val ei = eIdx
                val (order, opt) = withContext(Dispatchers.Default) {
                    val o = Optimizer(m.dur, m.dist, DoubleArray(nodes.size) { nodes[it].lat }, DoubleArray(nodes.size) { nodes[it].lon },
                        w, st.capacity.toD() ?: 0.0, si, ei)
                    o.solve() to o
                }
                busy = "Рисуем маршрут"
                val seq = listOfNotNull(startPt) + order.map { nodes[it] } + listOfNotNull(endPt)
                val path = withContext(Dispatchers.IO) { Net.geometry(st, seq) }
                var load = w.sum(); val stops = ArrayList<PlanStop>()
                var prev: Int? = si
                for (i in order) {
                    val g = groups[pts[i].name]!!
                    load -= w[i]
                    val p = prev
                    stops.add(PlanStop(pts[i], g.map { it.callsign }.filter { it.isNotBlank() }.distinct(),
                        g.flatMap { contactsOf(it) }.distinct(), w[i], g.sumOf { it.factSum }, load, g,
                        if (p == null) 0.0 else m.dist[p][i] / 1000.0, if (p == null) 0.0 else m.dur[p][i] / 60.0))
                    prev = i
                }
                val lastI = order.lastOrNull()
                val endKm = if (ei != null && lastI != null) m.dist[lastI][ei] / 1000.0 else 0.0
                val endMin = if (ei != null && lastI != null) m.dur[lastI][ei] / 60.0 else 0.0
                val links = run {
                    val l = ArrayList<String>(); var s = 0
                    while (s < seq.size - 1 || (s == 0 && seq.size == 1)) {
                        val part = seq.subList(s, minOf(s + 10, seq.size))
                        l.add("https://yandex.ru/maps/?rtext=" + part.joinToString("~") { "${it.lat},${it.lon}" } + "&rtt=auto")
                        s += 9
                    }
                    l
                }
                plan = Plan(stops, opt.distance(order) / 1000.0, opt.duration(order) / 60.0, links, path, startPt, excluded, header, endPt, endKm, endMin)
                stopIndex = 0; started = false; aborted = false; paid.clear(); persist()
                if (m.approximate) error = "Сервер дорог недоступен — расстояния оценены по прямой. Порядок всё равно оптимизирован."
                screen = Screen.OVERVIEW
            } catch (e: Exception) { error = e.message ?: e.toString(); screen = Screen.HOME } finally { busy = null }
        }
    }

    @android.annotation.SuppressLint("MissingPermission")
    private suspend fun currentLocation(): Point? = withContext(Dispatchers.Main) {
        val granted = listOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION)
            .any { app.checkSelfPermission(it) == android.content.pm.PackageManager.PERMISSION_GRANTED }
        if (!granted) return@withContext null
        val lm = app.getSystemService(android.location.LocationManager::class.java) ?: return@withContext null
        val providers = listOf(android.location.LocationManager.GPS_PROVIDER, android.location.LocationManager.NETWORK_PROVIDER)
            .filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }
        var best: android.location.Location? = providers.mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
        val stale = best == null || System.currentTimeMillis() - best.time > 5 * 60_000
        if (stale && android.os.Build.VERSION.SDK_INT >= 30 && providers.isNotEmpty()) {
            val fresh = kotlinx.coroutines.withTimeoutOrNull(8000) {
                kotlinx.coroutines.suspendCancellableCoroutine<android.location.Location?> { cont ->
                    val cs = android.os.CancellationSignal()
                    cont.invokeOnCancellation { cs.cancel() }
                    runCatching {
                        lm.getCurrentLocation(providers.first(), cs, app.mainExecutor) { l -> if (cont.isActive) cont.resumeWith(Result.success(l)) }
                    }.onFailure { if (cont.isActive) cont.resumeWith(Result.success(null)) }
                }
            }
            if (fresh != null) best = fresh
        }
        best?.let { Point("Старт", "", it.latitude, it.longitude, "Вы здесь") }
    }

    // ---------- ведение ----------
    fun go() { started = true; direction = 1; persist(); screen = Screen.DRIVE }
    fun nextStop() {
        val p = plan ?: return
        direction = 1
        if ((p.stops.getOrNull(stopIndex)?.fact ?: 0.0) > 0 && paid[stopIndex] == null) { askPaid = true; return }
        if (stopIndex >= p.stops.size - 1) {
            screen = Screen.FINISH; store.save(null)
            record(p, p.stops.size, false)
            if (p.end != null) Notifier.toWarehouse(app, p) else Notifier.cancel(app)
            return
        }
        stopIndex++; persist()
    }
    fun answerPaid(ok: Boolean) { paid[stopIndex] = ok; askPaid = false; persist(); nextStop() }
    /** Сколько наличных реально получено (только подтверждённые оплаты). */
    val cashCollected get() = plan?.stops?.withIndex()?.filter { paid[it.index] == true }?.sumOf { it.value.fact } ?: 0.0
    fun prevStop() { if (stopIndex > 0) { direction = -1; stopIndex--; persist() } }
    fun jumpTo(i: Int) { direction = if (i >= stopIndex) 1 else -1; stopIndex = i; started = true; persist(); screen = Screen.DRIVE }
    fun resume() { screen = if (started) Screen.DRIVE else Screen.OVERVIEW }
    fun finishRoute() { aborted = false; paid.clear(); askPaid = false; plan = null; stopIndex = 0; started = false; store.save(null); Notifier.cancel(app); uris.clear(); screen = Screen.HOME }

    /** Досрочно прервать маршрут: всё, что осталось, не объезжаем. */
    var aborted by mutableStateOf(false)
    fun abortRoute() {
        val p = plan ?: return
        aborted = true; store.save(null)
        record(p, if (started) stopIndex else 0, true)
        if (p.end != null) Notifier.toWarehouse(app, p) else Notifier.cancel(app)
        screen = Screen.FINISH
    }

    // ---------- БД ----------
    fun importDb(u: Uri) {
        try { app.contentResolver.openInputStream(u)!!.use { db.load(it) }; db.save(); dbVer++; error = null }
        catch (e: Exception) { error = "Не удалось импортировать базу (нужен .xlsx): ${e.message}" }
    }
    fun exportDb(u: Uri) {
        try { app.contentResolver.openOutputStream(u)!!.use { db.write(it) } } catch (e: Exception) { error = e.message }
    }
    fun geocode(addr: String, cb: (Pair<Double, Double>?) -> Unit) {
        viewModelScope.launch { cb(withContext(Dispatchers.IO) { runCatching { Net.geocode(addr) }.getOrNull() }) }
    }
}

enum class Screen { HOME, SETTINGS, REVIEW, MATCH, EQUIP, OVERVIEW, DRIVE, FINISH, HISTORY, HISTORY_DETAIL }
