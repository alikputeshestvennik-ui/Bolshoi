package ru.marshrut

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Журнал рейса: когда и в каком порядке водитель отметил точки, плюс трек GPS, где он ловит.
 * Главное — отметки «Готово» со временем: из них фактический порядок и реальное время между точками.
 * GPS только помогает (подсказка «вы на точке?», километры по факту) и в Крыму часто врёт, поэтому фильтруется.
 */
object Trip {
    /** Отметка точки: имя точки из базы, номер в плане, время. */
    data class Visit(val name: String, val idx: Int, val ts: Long)
    data class Fix(val lat: Double, val lon: Double, val ts: Long)

    @Volatile var startTs = 0L; private set
    /** Откуда выехали: «Склад» — время первого отрезка тоже учитывается. */
    @Volatile var startName = ""; private set
    val visits = java.util.Collections.synchronizedList(ArrayList<Visit>())
    val track = java.util.Collections.synchronizedList(ArrayList<Fix>())
    private var file: File? = null
    private var jumps = 0

    fun init(ctx: Context) {
        if (file != null) return
        file = File(ctx.filesDir, "trip.json")
        runCatching {
            val j = JSONObject(file!!.readText())
            startTs = j.optLong("s"); startName = j.optString("n")
            j.optJSONArray("v")?.let { a -> for (i in 0 until a.length()) a.getJSONArray(i).let { visits.add(Visit(it.getString(0), it.getInt(1), it.getLong(2))) } }
            j.optJSONArray("t")?.let { a -> for (i in 0 until a.length()) a.getJSONArray(i).let { track.add(Fix(it.getDouble(0), it.getDouble(1), it.getLong(2))) } }
        }
    }

    val active get() = startTs > 0

    fun begin(start: String) {
        startTs = System.currentTimeMillis(); startName = start; visits.clear(); track.clear(); save()
    }

    fun clear() { startTs = 0; startName = ""; visits.clear(); track.clear(); runCatching { file?.delete() } }

    fun visited(idx: Int) = synchronized(visits) { visits.any { it.idx == idx } }
    fun visitTime(idx: Int) = synchronized(visits) { visits.firstOrNull { it.idx == idx }?.ts }

    fun visit(name: String, idx: Int) {
        if (visited(idx)) return
        visits.add(Visit(name, idx, System.currentTimeMillis())); save()
    }

    /** Новая отметка GPS: отбрасываем неточные и «прыжки» (подмена сигнала, отражения в горах). */
    fun addFix(l: Location) {
        if (!active) return
        if (l.hasAccuracy() && l.accuracy > 100f) return
        val f = Fix(l.latitude, l.longitude, System.currentTimeMillis())
        val prev = synchronized(track) { track.lastOrNull() }
        if (prev != null) {
            val d = Net.haversine(prev.lat, prev.lon, f.lat, f.lon)
            val dt = (f.ts - prev.ts) / 1000.0
            if (d < 25) return                          // стоим — дрожание
            // Быстрее 150 км/ч — сигнал врёт. Но если «врёт» трижды подряд, ошибалась, видимо, прошлая отметка — принимаем новую
            if (dt > 0 && d / dt > 42 && ++jumps < 3) return
        }
        jumps = 0
        track.add(f)
        if (track.size % 10 == 0) save()
    }

    /** Километры по треку и доля рейса, когда GPS ловил (разрывы дольше 3 минут не считаем). */
    fun gpsKm(endTs: Long): Pair<Double, Double> = synchronized(track) {
        var m = 0.0; var covered = 0L
        for (i in 1 until track.size) {
            val a = track[i - 1]; val b = track[i]
            if (b.ts - a.ts <= 180_000) { m += Net.haversine(a.lat, a.lon, b.lat, b.lon); covered += b.ts - a.ts }
        }
        val total = (endTs - startTs).coerceAtLeast(1)
        m / 1000.0 to covered.toDouble() / total
    }

    /** Последняя хорошая отметка не старше maxAge. */
    fun lastFix(maxAgeMs: Long): Fix? = synchronized(track) { track.lastOrNull() }?.takeIf { System.currentTimeMillis() - it.ts <= maxAgeMs }

    @Synchronized fun save() {
        val f = file ?: return
        runCatching {
            val v = JSONArray(); synchronized(visits) { visits.forEach { v.put(JSONArray().put(it.name).put(it.idx).put(it.ts)) } }
            val t = JSONArray(); synchronized(track) { track.forEach { t.put(JSONArray().put(it.lat).put(it.lon).put(it.ts)) } }
            f.writeText(JSONObject().put("s", startTs).put("n", startName).put("v", v).put("t", t).toString())
        }
    }
}

/** Запись трека в рейсе: работает и под навигатором, пока водитель не закрыл маршрут. */
class TrackService : Service(), LocationListener {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Trip.init(this)
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null)
            nm.createNotificationChannel(NotificationChannel(CH, "Запись рейса", NotificationManager.IMPORTANCE_MIN).apply {
                description = "Трек рейса для обучения маршрутов"; setShowBadge(false)
            })
        val n = NotificationCompat.Builder(this, CH).setSmallIcon(R.drawable.ic_stat_route)
            .setContentTitle("Рейс записывается").setContentText("По нему приложение учится строить маршруты")
            .setOngoing(true).setSilent(true).build()
        val granted = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        try {
            if (!granted) error("нет доступа к геолокации")
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION) else startForeground(ID, n)
            val lm = getSystemService(LocationManager::class.java)
            lm.removeUpdates(this)
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER))
                if (runCatching { lm.isProviderEnabled(p) }.getOrDefault(false)) lm.requestLocationUpdates(p, 10_000L, 20f, this, mainLooper)
        } catch (_: Exception) { stopSelf() }
        return START_STICKY
    }

    override fun onLocationChanged(location: Location) { Trip.addFix(location) }
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
    @Deprecated("Deprecated in Java") override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}

    override fun onDestroy() {
        runCatching { getSystemService(LocationManager::class.java).removeUpdates(this) }
        Trip.save()
        super.onDestroy()
    }

    companion object {
        private const val CH = "trip_track"
        private const val ID = 4311
        fun start(ctx: Context) = runCatching { ctx.startForegroundService(Intent(ctx, TrackService::class.java)) }
        fun stop(ctx: Context) = runCatching { ctx.stopService(Intent(ctx, TrackService::class.java)) }
    }
}
