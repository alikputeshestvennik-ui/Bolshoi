package ru.marshrut

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Сохранение активного маршрута, чтобы ведение продолжалось после перезапуска приложения. */
class Store(ctx: Context) {
    private val file = File(ctx.filesDir, "route.json")
    private val hist = File(ctx.filesDir, "history.json")
    private val draftFile = File(ctx.filesDir, "draft.json")

    /** Распознанный лист: строки и всё, что уточнено на экране проверки, — чтобы распознавание не пропадало при выходе. */
    data class Draft(val header: String, val total: Double?, val totalNoSg: Double?, val rows: List<Row>, val agents: List<Agent>,
                     val merged: Map<Int, Int>, val pins: Map<String, Pair<Double, Double>>, val built: Boolean, val fresh: Set<String>)

    fun saveDraft(d: Draft?) {
        if (d == null) { draftFile.delete(); return }
        runCatching {
            val m = JSONObject().also { j -> d.merged.forEach { (k, v) -> j.put(k.toString(), v) } }
            val pn = JSONObject().also { j -> d.pins.forEach { (k, v) -> j.put(k, JSONArray().put(v.first).put(v.second)) } }
            draftFile.writeText(JSONObject().put("header", d.header).put("total", d.total ?: JSONObject.NULL).put("totalNoSg", d.totalNoSg ?: JSONObject.NULL)
                .put("rows", arr(d.rows) { row(it) }).put("agents", arr(d.agents) { agent(it) }).put("merged", m).put("pins", pn)
                .put("built", d.built).put("fresh", JSONArray(d.fresh.toList())).toString())
        }
    }

    fun loadDraft(): Draft? = runCatching {
        if (!draftFile.exists()) return null
        val j = JSONObject(draftFile.readText())
        val m = HashMap<Int, Int>(); j.optJSONObject("merged")?.let { o -> o.keys().forEach { k -> k.toIntOrNull()?.let { m[it] = o.getInt(k) } } }
        val pn = HashMap<String, Pair<Double, Double>>()
        j.optJSONObject("pins")?.let { o -> o.keys().forEach { k -> o.getJSONArray(k).let { a -> pn[k] = a.getDouble(0) to a.getDouble(1) } } }
        fun num(k: String) = if (j.isNull(k)) null else j.optDouble(k).takeIf { !it.isNaN() }
        Draft(j.optString("header"), num("total"), num("totalNoSg"), list(j.optJSONArray("rows")) { row(it) }, list(j.optJSONArray("agents")) { agent(it) },
            m, pn, j.optBoolean("built"), strs(j.optJSONArray("fresh")).toSet())
    }.getOrNull()

    fun history(): List<HistoryEntry> = runCatching {
        if (!hist.exists()) return emptyList()
        val a = JSONArray(hist.readText())
        (0 until a.length()).mapNotNull { i ->
            runCatching {
                val j = a.getJSONObject(i)
                HistoryEntry(j.getLong("id"), j.getLong("date"), plan(j.getJSONObject("plan")), j.optInt("done"), j.optBoolean("aborted"),
                    j.optJSONArray("scans")?.let { s -> List(s.length()) { s.getString(it) } }.orEmpty(), j.optBoolean("layout"))
            }.getOrNull()
        }
    }.getOrDefault(emptyList())

    fun saveHistory(list: List<HistoryEntry>) {
        runCatching {
            val a = JSONArray()
            list.take(300).forEach { e ->
                a.put(JSONObject().put("id", e.id).put("date", e.date).put("plan", plan(e.plan)).put("done", e.done).put("aborted", e.aborted)
                    .put("scans", JSONArray(e.scans)).put("layout", e.layout))
            }
            hist.writeText(a.toString())
        }
    }

    /** Файл истории как есть — для резервной копии. */
    fun historyBytes(): ByteArray? = runCatching { hist.takeIf { it.exists() }?.readBytes() }.getOrNull()

    /** История из резервной копии: сначала проверяем, что это наш формат, потом заменяем. */
    fun restoreHistory(data: ByteArray) {
        JSONArray(String(data, Charsets.UTF_8))
        hist.writeBytes(data)
    }

    data class Session(val plan: Plan, val index: Int, val started: Boolean, val paid: Map<Int, Boolean> = emptyMap(), val agentPaid: Map<Int, Boolean> = emptyMap(), val handed: Set<Int> = emptySet(),
        /** Сколько получено на точке, если оплатили не все фактовые накладные. */
        val paidAmount: Map<Int, Double> = emptyMap())

    fun save(s: Session?) {
        if (s == null) { file.delete(); return }
        runCatching {
            val paid = JSONObject().also { j -> s.paid.forEach { (k, v) -> j.put(k.toString(), v) } }
            val ap = JSONObject().also { j -> s.agentPaid.forEach { (k, v) -> j.put(k.toString(), v) } }
            val pa = JSONObject().also { j -> s.paidAmount.forEach { (k, v) -> j.put(k.toString(), v) } }
            file.writeText(JSONObject().put("plan", plan(s.plan)).put("index", s.index).put("started", s.started).put("paid", paid).put("paidAmt", pa)
                .put("agentPaid", ap).put("handed", JSONArray().also { a -> s.handed.forEach { a.put(it) } }).toString())
        }
    }

    fun load(): Session? = runCatching {
        if (!file.exists()) return null
        val j = JSONObject(file.readText())
        val pj = j.optJSONObject("paid")
        val paid = HashMap<Int, Boolean>()
        pj?.keys()?.forEach { k -> k.toIntOrNull()?.let { paid[it] = pj.optBoolean(k) } }
        val aj = j.optJSONObject("agentPaid")
        val ap = HashMap<Int, Boolean>()
        aj?.keys()?.forEach { k -> k.toIntOrNull()?.let { ap[it] = aj.optBoolean(k) } }
        val hj = j.optJSONArray("handed")
        val handed = if (hj == null) emptySet() else (0 until hj.length()).map { hj.optInt(it) }.toSet()
        val mj = j.optJSONObject("paidAmt")
        val amt = HashMap<Int, Double>()
        mj?.keys()?.forEach { k -> k.toIntOrNull()?.let { amt[it] = mj.optDouble(k) } }
        Session(plan(j.getJSONObject("plan")), j.optInt("index", 0), j.optBoolean("started", false), paid, ap, handed, amt)
    }.getOrNull()

    private fun point(p: Point) = JSONObject().put("name", p.name).put("address", p.address).put("lat", p.lat).put("lon", p.lon)
        .put("title", p.title).put("comment", p.comment)
    private fun point(j: JSONObject) = Point(j.optString("name"), j.optString("address"), j.optDouble("lat", 0.0), j.optDouble("lon", 0.0),
        j.optString("title"), j.optString("comment"))

    private fun row(r: Row) = JSONObject().put("id", r.id).put("callsign", r.callsign).put("weight", r.weight).put("fact", r.fact)
        .put("calc", r.calc).put("notes", r.notes).put("sum", r.sum).put("agent", r.agent).put("client", r.client)
        .put("address", r.address).put("invoice", r.invoice).put("equip", r.equip.name)
    private fun row(j: JSONObject) = Row(j.optInt("id"), j.optString("callsign"), j.optDouble("weight", 0.0), j.optString("fact"),
        j.optString("calc"), j.optString("notes"), j.optString("sum"), j.optString("agent"), j.optString("client"),
        j.optString("address"), j.optString("invoice"), runCatching { EquipDir.valueOf(j.optString("equip")) }.getOrDefault(EquipDir.UNKNOWN))

    private fun agent(a: Agent) = JSONObject().put("num", a.num).put("name", a.name).put("phone", a.phone)
    private fun agent(j: JSONObject) = Agent(j.optString("num"), j.optString("name"), j.optString("phone"))

    private fun <T> arr(l: List<T>, f: (T) -> Any): JSONArray = JSONArray().also { a -> l.forEach { a.put(f(it)) } }
    private fun <T> list(a: JSONArray?, f: (JSONObject) -> T): List<T> = if (a == null) emptyList() else (0 until a.length()).map { f(a.getJSONObject(it)) }
    private fun strs(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).map { a.optString(it) }

    private fun plan(p: Plan): JSONObject = JSONObject()
        .put("stops", arr(p.stops) { s ->
            JSONObject().put("point", point(s.point)).put("callsigns", arr(s.callsigns) { it }).put("contacts", arr(s.contacts) { agent(it) })
                .put("weight", s.weight).put("fact", s.fact).put("remaining", s.remaining).put("rows", arr(s.rows) { row(it) })
                .put("legKm", s.legKm).put("legMin", s.legMin)
        })
        .put("distanceKm", p.distanceKm).put("durationMin", p.durationMin)
        .put("links", arr(p.links) { it })
        .put("path", arr(p.path) { JSONArray().put(it.first).put(it.second) })
        .put("depot", p.depot?.let { point(it) } ?: JSONObject.NULL)
        .put("excluded", arr(p.excluded) { JSONObject().put("title", it.title).put("callsign", it.callsign).put("label", it.label).put("reason", it.reason)
            .put("cash", it.cash).put("agent", it.agent).put("phone", it.phone) })
        .put("header", p.header).put("end", p.end?.let { point(it) } ?: JSONObject.NULL).put("endKm", p.endKm).put("endMin", p.endMin).put("variant", p.variant)

    private fun plan(j: JSONObject): Plan {
        val pa = j.optJSONArray("path")
        return Plan(
            stops = list(j.optJSONArray("stops")) { s ->
                PlanStop(point(s.getJSONObject("point")), strs(s.optJSONArray("callsigns")), list(s.optJSONArray("contacts")) { agent(it) },
                    s.optDouble("weight", 0.0), s.optDouble("fact", 0.0), s.optDouble("remaining", 0.0), list(s.optJSONArray("rows")) { row(it) },
                    s.optDouble("legKm", 0.0), s.optDouble("legMin", 0.0))
            },
            distanceKm = j.optDouble("distanceKm", 0.0), durationMin = j.optDouble("durationMin", 0.0),
            links = strs(j.optJSONArray("links")),
            path = if (pa == null) emptyList() else (0 until pa.length()).map { val p = pa.getJSONArray(it); p.getDouble(0) to p.getDouble(1) },
            depot = j.optJSONObject("depot")?.let { point(it) },
            excluded = list(j.optJSONArray("excluded")) { Excluded(it.optString("title"), it.optString("callsign"), it.optString("label"), it.optString("reason", Excluded.REASON_RETURN),
                it.optDouble("cash", 0.0), it.optString("agent"), it.optString("phone")) },
            header = j.optString("header"), end = j.optJSONObject("end")?.let { point(it) },
            endKm = j.optDouble("endKm", 0.0), endMin = j.optDouble("endMin", 0.0), variant = j.optString("variant")
        )
    }
}
