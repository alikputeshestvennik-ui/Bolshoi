package ru.marshrut

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Сохранение активного маршрута, чтобы ведение продолжалось после перезапуска приложения. */
class Store(ctx: Context) {
    private val file = File(ctx.filesDir, "route.json")

    data class Session(val plan: Plan, val index: Int, val started: Boolean)

    fun save(s: Session?) {
        if (s == null) { file.delete(); return }
        runCatching { file.writeText(JSONObject().put("plan", plan(s.plan)).put("index", s.index).put("started", s.started).toString()) }
    }

    fun load(): Session? = runCatching {
        if (!file.exists()) return null
        val j = JSONObject(file.readText())
        Session(plan(j.getJSONObject("plan")), j.optInt("index", 0), j.optBoolean("started", false))
    }.getOrNull()

    private fun point(p: Point) = JSONObject().put("name", p.name).put("address", p.address).put("lat", p.lat).put("lon", p.lon)
        .put("title", p.title).put("comment", p.comment)
    private fun point(j: JSONObject) = Point(j.optString("name"), j.optString("address"), j.optDouble("lat", 0.0), j.optDouble("lon", 0.0),
        j.optString("title"), j.optString("comment"))

    private fun row(r: Row) = JSONObject().put("id", r.id).put("callsign", r.callsign).put("weight", r.weight).put("fact", r.fact)
        .put("calc", r.calc).put("notes", r.notes).put("sum", r.sum).put("agent", r.agent).put("client", r.client)
        .put("address", r.address).put("invoice", r.invoice).put("equip", r.equip.name)
    private fun row(j: JSONObject) = Row(j.optInt("id"), j.optString("callsign"), j.optDouble("weight", 0.0), j.optString("fact"),
        j.optString("calc"), j.optString("notes"), j.optString("sum"), j.optString("agent"), j.optString("client"),
        j.optString("address"), j.optString("invoice"), runCatching { EquipDir.valueOf(j.optString("equip")) }.getOrDefault(EquipDir.UNKNOWN))

    private fun agent(a: Agent) = JSONObject().put("num", a.num).put("name", a.name).put("phone", a.phone)
    private fun agent(j: JSONObject) = Agent(j.optString("num"), j.optString("name"), j.optString("phone"))

    private fun <T> arr(l: List<T>, f: (T) -> Any): JSONArray = JSONArray().also { a -> l.forEach { a.put(f(it)) } }
    private fun <T> list(a: JSONArray?, f: (JSONObject) -> T): List<T> = if (a == null) emptyList() else (0 until a.length()).map { f(a.getJSONObject(it)) }
    private fun strs(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).map { a.optString(it) }

    private fun plan(p: Plan): JSONObject = JSONObject()
        .put("stops", arr(p.stops) { s ->
            JSONObject().put("point", point(s.point)).put("callsigns", arr(s.callsigns) { it }).put("contacts", arr(s.contacts) { agent(it) })
                .put("weight", s.weight).put("fact", s.fact).put("remaining", s.remaining).put("rows", arr(s.rows) { row(it) })
                .put("legKm", s.legKm).put("legMin", s.legMin)
        })
        .put("distanceKm", p.distanceKm).put("durationMin", p.durationMin)
        .put("links", arr(p.links) { it })
        .put("path", arr(p.path) { JSONArray().put(it.first).put(it.second) })
        .put("depot", p.depot?.let { point(it) } ?: JSONObject.NULL)
        .put("excluded", arr(p.excluded) { JSONObject().put("title", it.title).put("callsign", it.callsign).put("label", it.label) })
        .put("header", p.header).put("roundTrip", p.roundTrip)

    private fun plan(j: JSONObject): Plan {
        val pa = j.optJSONArray("path")
        return Plan(
            stops = list(j.optJSONArray("stops")) { s ->
                PlanStop(point(s.getJSONObject("point")), strs(s.optJSONArray("callsigns")), list(s.optJSONArray("contacts")) { agent(it) },
                    s.optDouble("weight", 0.0), s.optDouble("fact", 0.0), s.optDouble("remaining", 0.0), list(s.optJSONArray("rows")) { row(it) },
                    s.optDouble("legKm", 0.0), s.optDouble("legMin", 0.0))
            },
            distanceKm = j.optDouble("distanceKm", 0.0), durationMin = j.optDouble("durationMin", 0.0),
            links = strs(j.optJSONArray("links")),
            path = if (pa == null) emptyList() else (0 until pa.length()).map { val p = pa.getJSONArray(it); p.getDouble(0) to p.getDouble(1) },
            depot = j.optJSONObject("depot")?.let { point(it) },
            excluded = list(j.optJSONArray("excluded")) { Excluded(it.optString("title"), it.optString("callsign"), it.optString("label")) },
            header = j.optString("header"), roundTrip = j.optBoolean("roundTrip", false)
        )
    }
}
