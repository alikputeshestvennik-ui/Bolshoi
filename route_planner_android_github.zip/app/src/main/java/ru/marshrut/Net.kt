package ru.marshrut

import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class Settings(private val sp: android.content.SharedPreferences) {
    private fun s(k: String, d: String) = sp.getString(k, d) ?: d

    init {
        // Версия 4.2: старт со склада и чтение клиента с адресом — по умолчанию и у тех, кто уже сохранял настройки
        if (sp.getInt("defaults", 0) < 42) sp.edit().putBoolean("gps", false).putBoolean("wc", true).putInt("defaults", 42).apply()
    }
    /** Ключи и модели вшиваются при сборке из секретов GitHub (YANDEX_API_KEY, DEEPSEEK_MODEL, QWEN_MODEL, ORS_API_KEY). */
    val apiKey: String get() = BuildConfig.YANDEX_API_KEY
    /** Выбранная модель распознавания: "deepseek", "qwen" или "gemini" (через gptunnel). */
    var modelChoice: String get() = s("mc", "deepseek"); set(v) { sp.edit().putString("mc", v).apply() }
    /** Gemini через gptunnel: ключ из секрета GPTUNNEL_KEY, название модели и цены правятся в настройках. */
    val gptKey: String get() = BuildConfig.GPTUNNEL_KEY.trim()
    var gptModel: String get() = s("gm", "gemini-3.5-flash-lite"); set(v) { sp.edit().putString("gm", v.trim()).apply() }
    var gptPriceIn: String get() = s("gpi", ""); set(v) { sp.edit().putString("gpi", v.trim()).apply() }
    var gptPriceOut: String get() = s("gpo", ""); set(v) { sp.edit().putString("gpo", v.trim()).apply() }
    /** Полный адрес модели: gpt://<каталог>/<модель>/latest у Яндекса, gptunnel:<модель> у gptunnel. */
    val model: String get() = when (modelChoice) {
        "qwen" -> BuildConfig.QWEN_MODEL; "gemini" -> GPTUNNEL + gptModel; else -> BuildConfig.DEEPSEEK_MODEL
    }.trim()
    /** Запасная модель: на неё переключаемся, если выбранная перегружена. У Gemini запасной — Qwen в Яндексе. */
    val otherModel: String get() = (if (modelChoice == "qwen") BuildConfig.DEEPSEEK_MODEL else BuildConfig.QWEN_MODEL).trim()
    val otherModelName: String get() = if (modelChoice == "qwen") "DeepSeek" else "Qwen"
    /** ID каталога Яндекса берётся из адреса модели Яндекса (нужен и при Gemini — для запасной модели). */
    val folder: String get() = Regex("^[a-z]+://([^/]+)/").find(BuildConfig.QWEN_MODEL.ifBlank { BuildConfig.DEEPSEEK_MODEL })?.groupValues?.get(1).orEmpty()
    companion object { const val GPTUNNEL = "gptunnel:" }
    val orsKey: String get() = BuildConfig.ORS_API_KEY.trim()
    /** Грузовик (категория C): дороги считаются по грузовому профилю OpenRouteService. */
    var truck: Boolean get() = sp.getBoolean("truck", true); set(v) { sp.edit().putBoolean("truck", v).apply() }
    var osrm: String get() = s("osrm", "https://router.project-osrm.org"); set(v) { sp.edit().putString("osrm", v.trim().trimEnd('/')).apply() }
    var depot: String get() = s("depot", ""); set(v) { sp.edit().putString("depot", v.trim()).apply() }
    var withClient: Boolean get() = sp.getBoolean("wc", true); set(v) { sp.edit().putBoolean("wc", v).apply() }
    var capacity: String get() = s("cap", "1500"); set(v) { sp.edit().putString("cap", v.trim()).apply() }
    /** Маршрут заканчивается на складе. */
    var endAtDepot: Boolean get() = sp.getBoolean("end", true); set(v) { sp.edit().putBoolean("end", v).apply() }
    /** Если старт не задан — начинать маршрут от текущего местоположения. */
    var startFromGps: Boolean get() = sp.getBoolean("gps", false); set(v) { sp.edit().putBoolean("gps", v).apply() }
    /** Резервная копия на Яндекс Диске: токены входа через Яндекс. */
    var yaToken: String get() = s("yt", ""); set(v) { sp.edit().putString("yt", v).apply() }
    var yaRefresh: String get() = s("yr", ""); set(v) { sp.edit().putString("yr", v).apply() }
    val cloudReady get() = yaToken.isNotBlank()
    /** Сохранять копию само — после маршрута и при сворачивании, если что-то изменилось. */
    var autoBackup: Boolean get() = sp.getBoolean("ab", true); set(v) { sp.edit().putBoolean("ab", v).apply() }
    /** Время последней удачной копии, отпечаток выгруженного и день последней архивной копии. */
    var lastBackup: Long get() = sp.getLong("lb", 0L); set(v) { sp.edit().putLong("lb", v).apply() }
    var backupHash: String get() = s("bh", ""); set(v) { sp.edit().putString("bh", v).apply() }
    var archiveDay: String get() = s("ad", ""); set(v) { sp.edit().putString("ad", v).apply() }
    /** Общая база: из секрета сборки SHARED_DB, а на телефоне владельца до пересборки — та, что он только что подготовил. */
    var localShared: String get() = s("lsh", ""); set(v) { sp.edit().putString("lsh", v).apply() }
    val shared: SharedKey.Parsed? get() = SharedKey.parse(BuildConfig.SHARED_DB.ifBlank { localShared })
    /** Ключ записи после ввода пароля редактора; пусто — телефон только читает. */
    var editorToken: String get() = s("et", ""); set(v) { sp.edit().putString("et", v).apply() }
    val isEditor get() = editorToken.isNotBlank() && shared != null
    /** Отпечаток версии общей базы, которую телефон уже взял. */
    var sharedMd5: String get() = s("sm", ""); set(v) { sp.edit().putString("sm", v).apply() }
    var lastSync: Long get() = sp.getLong("ls", 0L); set(v) { sp.edit().putLong("ls", v).apply() }
}

/** Матрицы времени (с) и расстояния (м) между узлами. */
class RoadMatrix(val dur: Array<DoubleArray>, val dist: Array<DoubleArray>, val approximate: Boolean)

object Net {
    val http: OkHttpClient = OkHttpClient.Builder()
        .callTimeout(240, TimeUnit.SECONDS).readTimeout(240, TimeUnit.SECONDS).build()
    private val JSON = "application/json".toMediaType()

    /** Расход текущего распознавания: копится в ask(), сбрасывается в начале recognize(). */
    @Volatile private var meter = Meter()
    /** Разбивка последнего распознавания по запросам — для экрана настроек. */
    val meterLog = java.util.Collections.synchronizedList(ArrayList<String>())
    /** Какой способ отключить рассуждение облако приняло для модели (номер варианта в ask). */
    private val thinkOff = java.util.concurrent.ConcurrentHashMap<String, Int>()

    /**
     * Подробное описание листа для нейросети. Каждое правило — от реальной ошибки распознавания:
     * номер «П/д» вместо позывного, позывной соседней точки на снятом под углом листе, сумма вместо факта,
     * «Документы на подпись» как обычные накладные, числа из шапки вместо итога веса.
     */
    private val P1 = """
Перед тобой маршрутный лист экспедитора (1–4 фото). Фото может быть повёрнуто на 90° или снято под углом: сначала мысленно выровняй таблицу и читай каждую строку целиком по горизонтали, сверяя ячейки одной строки по номеру накладной.
Колонки таблицы слева направо: «П/д», «Позывной», «Код», «Довоз», «Вид», «Накладная», «Клиент», «Адрес доставки», «Вес», «Сумма», «Факт», «Забрать долг», «Расчет», «Заметки», «Агент/СВ». На второй и следующих страницах шапка таблицы может быть обрезана или отсутствовать — колонки идут в том же порядке.
Правила:
1) «П/д» — порядковый номер точки маршрута (1, 2, 3…), стоит только в первой строке точки. Это НЕ позывной, в ответ его не выводи.
2) «позывной» — число вместе с буквами маршрута, например 3юс, 262юс, 436гвп, 1568ЯВ. Цифры позывного читай особенно внимательно: на скане 5 и 6, 3 и 8, 6 и буква «б» похожи. Позывной никогда не бывает просто числом: если в начале строки видишь только число (12, 13…), это «П/д», а позывной — в соседней ячейке правее. Если ячейка позывного в строке пуста, возьми позывной предыдущей строки, но только если клиент и адрес в строке те же; иначе оставь пустым.
3) «Код» (вида 0000054 833/1436), «Довоз» и «Вид» (б/н) не выводи.
4) «накладная» — номер документа из колонки «Накладная» (АСП-187049, НФ-0092129 Возврат, НФФ-032936, оборудование…) вместе с датой, если она есть в ячейке.
5) «вес» — брутто в кг; десятичный разделитель — точка, на скане она может быть плохо видна («40 2» → 40.2).
6) «сумма» — колонка «Сумма» (сумма накладной, заполнена почти всегда). «факт» — отдельная колонка «Факт» СТРОГО ПОСЛЕ «Суммы» и ДО «Забрать долг», это наличные; она почти всегда пустая. Пустую оставляй пустой строкой, не путай её с «Суммой» и «Забрать долг»; если не уверен, что число стоит именно в «Факте», оставь пустым.
7) «адрес»: номер дома часто с буквой после цифр — 1а, 3б, 58б, 9ж, 13Ф. Буква «б» на скане похожа на цифру 6: «3б» — это не «36», «58б» — не «586». «расчет» — буквенный код (ПМ, ЧЗ…) или пусто. «агент» — число до символа «/» в «Агент/СВ» («5/ SV3» → 5, «1/» → 1, «6/» → 6); в ячейке часто только число со «/» без SV — это тоже агент, не оставляй пустым.
8) Таблица доставки заканчивается строкой «ИТОГО ВЕС: … кг» — её саму не выводи. «итого_вес» — число из этой строки (обычно внизу последней страницы). Числа в шапке над таблицей (вес и «без СГ») — НЕ итог: выпиши их отдельно в «вес_сг» (первое число) и «вес_без_сг» (число после «без СГ»), если они есть на странице.
9) Под итогом может быть раздел «Документы на подпись», а ниже — «Документы по маршрутному листу»: это не доставка, их строки не выводи. Если сомневаешься, к какому разделу относится строка, выведи её с "раздел": "подпись" (у строк доставки "раздел" пустой).
Из шапки титульного листа возьми краткую строку (№ и дата листа, маршрут, транспортное средство, экспедитор); контакты ВСЕХ нумерованных агентов справа вверху (1, 2, 3…): номер, имя, телефон. Список бывает длинным (6 и больше пунктов), последний пункт может упираться в таблицу или быть бледным — выпиши его тоже. Контакты СВ (SV3, SV4…) и строки без номера пропусти.
Верни ТОЛЬКО json без пояснений и markdown: {"шапка": "", "итого_вес": "", "вес_сг": "", "вес_без_сг": "", "agents": [{"номер": "", "имя": "", "телефон": ""}], "rows": [""".trimIndent().replace("\n", " ")
    private const val P2 = "]}. Порядок строк как в документе, пустые ячейки — пустая строка, ничего не выдумывай и не пропускай строки, каждую строку выводи один раз."

    fun prompt(withClient: Boolean): String {
        // Ключи в порядке колонок документа: «сумма» перед «фактом», как на листе
        val cols = "{\"позывной\": \"\", \"накладная\": \"\", " + (if (withClient) "\"клиент\": \"\", \"адрес\": \"\", " else "") +
            "\"вес\": \"\", \"сумма\": \"\", \"факт\": \"\", \"расчет\": \"\", \"заметки\": \"\", \"агент\": \"\", \"раздел\": \"\"}"
        return P1 + cols + P2
    }


    /** Каждая страница уходит отдельным запросом (короткий ответ, не обрывается), затем результаты склеиваются. */
    fun recognize(st: Settings, jpegs: List<ByteArray>, onProgress: (Int, Int) -> Unit = { _, _ -> }, onStatus: (String) -> Unit = {}): Recognized {
        meter = Meter(); meterLog.clear()
        Meter.gptPrices = st.gptPriceIn.toD() to st.gptPriceOut.toD()
        val rec = fillAgents(st, jpegs, recognizeRows(st, jpegs, onProgress, onStatus), onStatus)
        fun k(s: String) = s.filter { it.isDigit() }.trimStart('0')
        val known = rec.agents.map { k(it.num) }.toSet()
        val missing = rec.rows.map { k(it.agent) }.filter { it.isNotEmpty() && it !in known }.distinct()
        if (missing.isEmpty() || jpegs.isEmpty()) return rec.copy(meter = meter)
        val more = runCatching { recognizeAgents(st, jpegs[0], missing, onStatus) }.getOrNull().orEmpty()
            .filter { it.phone.isNotBlank() && k(it.num) !in known }
        return (if (more.isEmpty()) rec else rec.copy(agents = rec.agents + more.distinctBy { k(it.num) })).copy(meter = meter)
    }

    /**
     * Строки без агента (ячейка «6/» без SV часто теряется) — дочитываем одну колонку «Агент/СВ» по каждой странице
     * и сопоставляем по номеру накладной. Строки, где агент уже есть, не трогаем.
     */
    private fun fillAgents(st: Settings, jpegs: List<ByteArray>, rec: Recognized, onStatus: (String) -> Unit): Recognized {
        // Номер документа без даты и приписок: «АСП-190864 от 08.10» и «асп 190864» — одна накладная
        fun inv(s: String) = s.uppercase().let { u -> Regex("[А-ЯЁA-Z]{2,4}\\s*-?\\s*\\d{4,}").find(u)?.value ?: u }.filter { it.isLetterOrDigit() }
        if (rec.rows.none { it.agent.isBlank() && it.invoice.isNotBlank() }) return rec
        val found = HashMap<String, String>()
        jpegs.forEachIndexed { i, j ->
            onStatus("Уточняем агентов — страница ${i + 1} из ${jpegs.size}")
            val text = "Перед тобой страница маршрутного листа (фото может быть повёрнуто). Для КАЖДОЙ строки таблицы доставки " +
                "выпиши номер накладной (колонка «Накладная», например АСП-190864 или НФФ-034196) и значение последней колонки «Агент/СВ» — " +
                "число до «/»: «2/ SV4» → 2, «6/» → 6. В ячейке часто только число со «/» без SV — это тоже агент. " +
                "Строки раздела «Документы на подпись» не нужны. Верни ТОЛЬКО компактный JSON: {\"rows\": [{\"накладная\": \"\", \"агент\": \"\"}]}"
            runCatching {
                val (msg, _) = ask(st, j, text, i + 1, onStatus, "агенты стр. ${i + 1}", 3000)
                val o = JSONObject(repair(msg.substring(msg.indexOf('{'), msg.lastIndexOf('}') + 1)).first)
                val arr = o.optJSONArray("rows") ?: JSONArray()
                for (n in 0 until arr.length()) {
                    val r = arr.optJSONObject(n) ?: continue
                    val a = r.optString("агент").substringBefore('/').filter { it.isDigit() }
                    val key = inv(r.optString("накладная"))
                    if (a.isNotEmpty() && key.isNotEmpty()) found.putIfAbsent(key, a)
                }
            }
        }
        if (found.isEmpty()) return rec
        return rec.copy(rows = rec.rows.map { r -> if (r.agent.isBlank()) found[inv(r.invoice)]?.let { r.copy(agent = it) } ?: r else r })
    }

    private fun recognizeRows(st: Settings, jpegs: List<ByteArray>, onProgress: (Int, Int) -> Unit, onStatus: (String) -> Unit): Recognized {
        val parts = jpegs.mapIndexed { i, j -> onProgress(i + 1, jpegs.size); recognizeOne(st, j, i + 1, jpegs.size, onStatus) }
        val first = assemble(parts)
        val total = first.total ?: return first
        val sum = first.rows.sumOf { it.weight }
        // Вес сошёлся с итогом — все строки на месте, даже если ответ упёрся в потолок на повторах
        if (Math.abs(sum - total) < 0.05) return first.copy(truncated = false)
        // Вес строк не сходится с «ИТОГО ВЕС» — строка пропущена или вес прочитан неверно. Перечитываем с подсказкой
        // и берём вариант, который сходится лучше: человеку не нужно искать потерянную накладную
        val hint = "ПРОВЕРКА: в прошлый раз сумма весов всех строк листа получилась ${fmt(sum)} кг, а в строке «ИТОГО ВЕС» — ${fmt(total)} кг " +
            "(разница ${fmt(Math.abs(total - sum))} кг). Значит, строка пропущена или вес прочитан неверно. Особенно проверь первую и последнюю " +
            "строки страницы: первая строка может быть продолжением точки с прошлой страницы — без «П/д», с обрезанным позывным, без шапки таблицы. "
        // Страница, где модель зациклилась (ответ упёрся в потолок), — перечитываем только её, с запретом повторов;
        // иначе не знаем, где ошибка, и перечитываем все
        val looped = parts.indices.filter { parts[it].truncated }
        val loopHint = "Каждую строку таблицы выводи ровно ОДИН раз, не повторяй строки; когда строки страницы закончились — сразу закрой JSON. "
        val second = runCatching {
            assemble(jpegs.mapIndexed { i, j ->
                if (looped.isNotEmpty() && i !in looped) parts[i] else {
                    onStatus("Вес не сошёлся с итогом — перечитываем страницу ${i + 1} из ${jpegs.size}")
                    recognizeOne(st, j, i + 1, jpegs.size, onStatus, (if (i in looped) loopHint else "") + hint)
                }
            })
        }.getOrNull() ?: return first
        val sum2 = second.rows.sumOf { it.weight }
        val total2 = second.total ?: total
        return if (Math.abs(sum2 - total2) < Math.abs(sum - total))
            second.copy(total = total2, reread = true, truncated = second.truncated && Math.abs(sum2 - total2) >= 0.05) else first
    }

    private fun assemble(parts: List<Recognized>): Recognized {
        val agents = parts.flatMap { it.agents }.filter { it.num.isNotBlank() || it.name.isNotBlank() }
            .distinctBy { it.num.ifBlank { it.name } }
        val (rows0, cleared) = fixFacts(parts.flatMap { it.rows }.mapIndexed { i, r -> r.copy(id = i) })
        val (rows, fixedCalls) = fixCallsigns(rows0)
        // Итог веса — со страницы, где он есть (обычно последней); число из шапки, заметно меньшее суммы строк, — не итог
        val sum = rows.sumOf { it.weight }
        val totals = parts.mapNotNull { it.total }; val heads = parts.mapNotNull { it.headerTotal }
        // Строки сошлись с итогом или с весом шапки — значит, это и есть итог (а одно из чисел прочитано не там);
        // иначе — «ИТОГО ВЕС» с последней страницы, где он есть, а если его нет — вес из шапки
        val total = (totals + heads).firstOrNull { Math.abs(it - sum) < 0.05 }
            ?: totals.lastOrNull { sum == 0.0 || it >= sum * 0.8 } ?: heads.lastOrNull()
        return Recognized(agents, rows, parts.map { it.header }.firstOrNull { it.isNotBlank() }.orEmpty(),
            total, null, parts.any { it.truncated }, cleared, fixedCalls)
    }

    /**
     * «Документы на подпись» (раздел под «ИТОГО ВЕС») — информация для офиса, водителю не нужна.
     * Узнаём по пометке нейросети или по виду: накладная с датой («АСП-130232 02.07.26») и нулевым весом.
     */
    private val DATED = Regex("\\d{2}\\.\\d{2}\\.\\d{2,4}")
    private fun isSignDoc(section: String, r: Row) =
        section.contains("подпис", true) || (r.weight == 0.0 && r.kind == Kind.GOODS && DATED.containsMatchIn(r.invoice))

    private val CALLSIGN = Regex("^\\d+\\s*[^\\d\\s]+$")

    /**
     * Позывной — это число с буквами (3юс, 436гвп). Голое число — номер «П/д», прочитанный вместо позывного.
     * Такой строке берём позывной соседней строки того же клиента (и адреса), иначе оставляем пустым —
     * дальше точку найдут по адресу.
     */
    private fun fixCallsigns(rows: List<Row>): Pair<List<Row>, Int> {
        fun same(a: Row, b: Row) = a.client.trim().equals(b.client.trim(), true) && a.client.isNotBlank() &&
            (a.address.isBlank() || b.address.isBlank() || a.address.trim().equals(b.address.trim(), true))
        var fixed = 0
        val out = rows.toMutableList()
        for (i in out.indices) {
            val r = out[i]
            val cs = r.callsign.trim()
            if (CALLSIGN.matches(cs)) continue
            if (cs.isNotEmpty() && !cs.all { it.isDigit() }) continue
            val donor = (out.subList(0, i).asReversed() + out.subList(i + 1, out.size))
                .firstOrNull { o -> CALLSIGN.matches(o.callsign.trim()) && same(o, r) }
            out[i] = r.copy(callsign = donor?.callsign.orEmpty())
            // Пустой позывной, достроенный по соседней строке того же клиента, — не ошибка, не считаем
            if (cs.isNotEmpty()) fixed++
        }
        return out to fixed
    }

    /**
     * Нейросеть иногда переносит колонку «Сумма» в «Факт». Настоящий факт бывает у немногих строк,
     * поэтому если он «заполнен» хотя бы у трёх строк и у трети листа — это перепутанные колонки:
     * у строк, где факт равен сумме (или суммы нет), факт очищаем, число остаётся суммой.
     */
    private fun fixFacts(rows: List<Row>): Pair<List<Row>, Int> {
        val filled = rows.filter { it.factSum != 0.0 }
        if (filled.size < 3 || filled.size * 3 < rows.size) return rows to 0
        fun misread(r: Row) = r.factSum != 0.0 && (r.sum.toD()?.let { Math.abs(it - r.factSum) < 0.01 } ?: true)
        val out = rows.map { r -> if (misread(r)) r.copy(fact = "", sum = r.sum.ifBlank { r.fact }) else r }
        return out to rows.count(::misread)
    }

    /** Облако занято или временно сломано — стоит подождать и повторить. */
    private val BUSY = setOf(429, 500, 502, 503, 504)

    private fun recognizeOne(st: Settings, jpeg: ByteArray, page: Int, pages: Int, onStatus: (String) -> Unit, hint: String = ""): Recognized {
        val note = hint + if (pages > 1) "ВАЖНО: в этом запросе одна страница листа (стр. $page из $pages). Выводи все строки таблицы, видимые на ней, " +
            "включая первую строку страницы, даже если у неё нет «П/д», позывной обрезан или шапки таблицы на странице нет; " +
            "шапку, агентов и итоговый вес — только если они есть на этой странице, иначе оставь пустыми. " else ""
        val text = note + prompt(st.withClient) + " Ответ — компактный JSON без отступов и переносов строк, без рассуждений."
        val (msg, finish) = ask(st, jpeg, text, page, onStatus, if (hint.isEmpty()) "стр. $page" else "перечитывание стр. $page")
        val rec = try { parse(msg, finish == "length") } catch (e: Exception) {
            error("Страница $page: ${e.message} (finish_reason=$finish, длина ответа ${msg.length})")
        }
        if (rec.truncated && rec.rows.isEmpty())
            error("Страница $page: ответ модели оборван (finish_reason=$finish)")
        // Зациклившаяся модель повторяет те же строки — одна накладная с тем же весом и позывным дважды не бывает
        return rec.copy(rows = rec.rows.distinctBy { r -> if (r.invoice.isBlank()) r.id.toString() else "${r.invoice}|${r.callsign}|${r.weight}" })
    }

    /**
     * Агенты, на которых ссылаются строки, но которых нет в прочитанном списке (последний пункт списка
     * часто упирается в таблицу и теряется), — отдельный короткий запрос только про список агентов.
     */
    private fun recognizeAgents(st: Settings, jpeg: ByteArray, missing: List<String>, onStatus: (String) -> Unit): List<Agent> {
        onStatus("Уточняем контакты агентов")
        val text = "Перед тобой маршрутный лист (фото может быть повёрнуто). Над таблицей справа вверху — нумерованный список агентов: " +
            "номер, имя, телефон (например «6 Мамедова Татьяна +79787759553»). Список бывает длинным, последние пункты могут упираться " +
            "в шапку таблицы или быть бледными. Выпиши ВСЕ пункты этого списка, обязательно номера ${missing.joinToString(", ")}. " +
            "Контакты СВ (SV1, SV3…) не нужны. Верни ТОЛЬКО компактный JSON: {\"agents\": [{\"номер\": \"\", \"имя\": \"\", \"телефон\": \"\"}]}"
        val (msg, _) = ask(st, jpeg, text, 1, onStatus, "список агентов", 1500)
        return parse(msg).agents
    }

    /** Как gptunnel принимает ключ: «Authorization: ключ» или «Bearer ключ» — запоминаем сработавший. */
    @Volatile private var gptBearer = false

    /** Запрос к Gemini через gptunnel (формат OpenAI): та же инструкция и картинка, ответ разбирается как у Яндекса. */
    private fun callGptunnel(st: Settings, model: String, text: String, url: String, maxTokens: Int): Pair<Int, String> {
        if (st.gptKey.isBlank()) error("В сборке нет ключа gptunnel — добавьте секрет GPTUNNEL_KEY на GitHub и пересоберите")
        val content = JSONArray()
            .put(JSONObject().put("type", "text").put("text", text))
            .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", url)))
        val body = JSONObject().put("model", model).put("temperature", 0).put("max_tokens", maxTokens)
            .put("useWalletBalance", true)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        fun send(bearer: Boolean) = http.newCall(Request.Builder().url("https://gptunnel.ru/v1/chat/completions")
            .header("Authorization", if (bearer) "Bearer ${st.gptKey}" else st.gptKey)
            .post(body.toString().toRequestBody(JSON)).build()).execute().use { it.code to it.body?.string().orEmpty() }
        var r = send(gptBearer)
        if (r.first == 401 || r.first == 403) { r = send(!gptBearer); if (r.first in 200..299) gptBearer = !gptBearer }
        return r
    }

    /** Один запрос к нейросети по фото: повторы при перегрузке облака и запасная модель. Возвращает текст ответа и finish_reason. */
    private fun ask(st: Settings, jpeg: ByteArray, text: String, page: Int, onStatus: (String) -> Unit,
                    kind: String = "страница $page", maxTokens: Int = 8000): Pair<String, String> {
        val url = "data:image/jpeg;base64," + Base64.encodeToString(jpeg, Base64.NO_WRAP)
        /**
         * Рассуждение для чтения таблицы не нужно, а оплачивается как выход (самые дорогие токены). Отключаем его
         * всеми способами по очереди: облако отвечает 400 на незнакомый параметр — пробуем следующий вариант
         * и запоминаем принятый, чтобы не тратить на это запросы каждый раз.
         * 0 — reasoning_effort + enable_thinking, 1 — только enable_thinking, 2 — только reasoning_effort, 3 — без параметров.
         */
        fun call(model: String, variant: Int): Pair<Int, String> {
            if (model.startsWith(Settings.GPTUNNEL)) return callGptunnel(st, model.removePrefix(Settings.GPTUNNEL), text, url, maxTokens)
            val qwen = model.contains("qwen", true)
            val content = JSONArray()
                .put(JSONObject().put("type", "text").put("text", if (qwen) "$text /no_think" else text))
                .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", url)))
            val body = JSONObject()
                .put("model", model.replace("{folder}", st.folder))
                .put("temperature", 0)
                .put("max_tokens", maxTokens)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
            if (variant == 0 || variant == 2) body.put("reasoning_effort", "none")
            if (variant == 0 || variant == 1) body.put("chat_template_kwargs", JSONObject().put("enable_thinking", false))
            val req = Request.Builder().url("https://llm.api.cloud.yandex.net/v1/chat/completions")
                .header("Authorization", "Api-Key " + st.apiKey)
                .header("x-folder-id", st.folder)
                .post(body.toString().toRequestBody(JSON)).build()
            return http.newCall(req).execute().use { it.code to it.body?.string().orEmpty() }
        }
        fun callModel(model: String): Pair<Int, String> {
            if (model.startsWith(Settings.GPTUNNEL)) return call(model, 3)
            var v = thinkOff[model] ?: 0
            while (true) {
                val r = call(model, v)
                if (r.first == 400 && v < 3) { v++; continue }
                if (r.first in 200..299) thinkOff[model] = v
                return r
            }
        }
        // Перегрузка облака: два повтора с паузой, потом — запасная модель
        val tries = listOf(st.model to 0L, st.model to 5_000L, st.model to 15_000L) +
            (if (st.otherModel.isNotBlank() && st.otherModel != st.model) listOf(st.otherModel to 0L) else emptyList())
        var code = 0; var txt = ""; var used = st.model
        var skipPrimary = false
        for ((i, t) in tries.withIndex()) {
            val (model, wait) = t; used = model
            if (skipPrimary && model == st.model) continue
            if (wait > 0) { onStatus("Облако перегружено, повторяем через ${wait / 1000} с — страница $page"); Thread.sleep(wait) }
            if (i > 0 && model != st.model) onStatus("Облако перегружено, пробуем модель ${st.otherModelName} — страница $page")
            val r = callModel(model); code = r.first; txt = r.second
            if (code in 200..299) break
            // gptunnel ответил ошибкой (нет денег, неверная модель или ключ) — сразу на запасную модель Яндекса
            if (model.startsWith(Settings.GPTUNNEL)) { skipPrimary = true; onStatus("Gemini недоступен (код $code) — читаем через Qwen"); continue }
            if (code !in BUSY) break
        }
        if (code in BUSY) error("Нейросеть Yandex сейчас перегружена (код $code) — это на стороне Яндекса. Подождите несколько минут и нажмите «Распознать» ещё раз.")
        run {
            if (code !in 200..299) error("Облако ответило $code: ${txt.take(300)}")
            val ch = JSONObject(txt).getJSONArray("choices").getJSONObject(0)
            val finish = ch.optString("finish_reason", "")
            val m = ch.getJSONObject("message")
            val msg = if (m.isNull("content")) "" else m.optString("content", "")
            // Учёт: токены из usage, а рассуждение видно и по полю reasoning_content, если облако его возвращает
            runCatching {
                val u = Meter.fromResponse(used, JSONObject(txt).optJSONObject("usage"))
                meter += u
                val think = m.optString("reasoning_content", "").length
                meterLog.add("$kind: вход ${u.input}, выход ${u.output}" +
                    (if (u.reasoning > 0) ", рассуждение ${u.reasoning}" else "") +
                    (if (think > 0) ", рассуждение ~${think / 3} ток." else "") +
                    (if (finish == "length") " — упёрся в потолок" else "") + " · ответ ${msg.length} симв.")
            }
            if (msg.isBlank()) error("Страница $page: модель не вернула текст (finish_reason=$finish) — весь лимит ушёл на рассуждения")
            return msg to finish
        }
    }

    /** Достраивает закрывающие скобки у оборванного JSON, оставляя только целые элементы. */
    private fun repair(t: String): Pair<String, Boolean> {
        try { JSONObject(t); return t to false } catch (_: Exception) {}
        var inStr = false; var esc = false
        val stack = ArrayList<Char>(); var good = -1; var stackAtGood: List<Char> = emptyList()
        for (i in t.indices) {
            val c = t[i]
            if (inStr) { if (esc) esc = false else if (c == '\\') esc = true else if (c == '"') inStr = false; continue }
            when (c) {
                '"' -> inStr = true
                '{', '[' -> stack.add(c)
                '}', ']' -> { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex); good = i; stackAtGood = stack.toList() }
            }
        }
        if (good < 0) error("В ответе нет целых элементов JSON")
        val sb = StringBuilder(t.substring(0, good + 1))
        stackAtGood.asReversed().forEach { sb.append(if (it == '{') '}' else ']') }
        return sb.toString() to true
    }

    fun parse(text: String, cut: Boolean = false): Recognized {
        val a = text.indexOf('{'); val b = text.lastIndexOf('}')
        if (a < 0 || b < a) error("В ответе нет JSON: ${text.take(200)}")
        val (fixed, repaired) = repair(text.substring(a, b + 1))
        val j = JSONObject(fixed)
        val ag = j.opt("agents") ?: j.opt("agent")
        val agents = when (ag) {
            is JSONArray -> (0 until ag.length()).mapNotNull { parseAgent(ag.opt(it)) }
            null, JSONObject.NULL -> emptyList()
            else -> listOfNotNull(parseAgent(ag))
        }
        val arr = j.optJSONArray("rows") ?: JSONArray()
        val rows = (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            fun g(k: String) = o.optString(k, "").let { if (it == "null") "" else it.trim() }
            val ag = g("агент").substringBefore('/').trim()
            Row(
                id = i, callsign = g("позывной"), weight = g("вес").toD() ?: 0.0, fact = g("факт"), calc = g("расчет"),
                notes = g("заметки"), sum = g("сумма"), agent = ag, client = g("клиент"), address = g("адрес"), invoice = g("накладная")
            ).takeUnless { isSignDoc(g("раздел"), it) }
        }
        fun top(k: String) = j.optString(k, "").let { if (it == "null") "" else it.trim() }
        // Вес в шапке: СГ + «без СГ» = весь груз листа — запасной итог, если строку «ИТОГО ВЕС» не прочитали
        val headTotal = top("вес_сг").toD()?.let { a -> top("вес_без_сг").toD()?.let { b -> a + b } }
        return Recognized(agents, rows, top("шапка"), top("итого_вес").toD(), null, repaired || cut, headerTotal = headTotal)
    }

    private fun parseAgent(x: Any?): Agent? {
        if (x is JSONObject) {
            fun g(vararg k: String) = k.firstNotNullOfOrNull { x.optString(it, "").takeIf { s -> s.isNotBlank() && s != "null" } }?.trim().orEmpty()
            return Agent(g("номер", "num", "number"), g("имя", "name", "фио"), g("телефон", "phone"))
        }
        val s = x?.toString()?.trim().orEmpty()
        if (s.isEmpty() || s == "null") return null
        val num = Regex("^(?:[Ss][Vv])?\\d+").find(s)?.value.orEmpty()
        val rest = s.removePrefix(num)
        val phone = Regex("\\+?\\d[\\d\\s()\\-]{8,}\\d").find(rest)?.value.orEmpty()
        val name = rest.replace(phone, "").trim(' ', '.', ')', ',', '-', ':')
        return Agent(num, name, phone.trim())
    }

    /** Матрицы времени и расстояния через OSRM table; при недоступности — оценка по прямой с коэффициентом извилистости. */
    /**
     * curbCount — первые N узлов это точки выгрузки: к ним подъезжаем только «своей» стороной (approaches=curb),
     * чтобы точка оказывалась по ходу движения, а не через дорогу. Если сервер не принял параметр — повтор без него.
     */
    fun matrix(st: Settings, pts: List<Point>, curbCount: Int = 0): RoadMatrix {
        if (!st.truck || pts.indices.none { i -> pts.indices.any { k -> crossesRidge(pts[i], pts[k]) } })
            return rawMatrix(st, pts, curbCount)
        // Грузовик: пары «побережье ↔ Байдарская долина» пересчитываем через Ласпинский перевал,
        // чтобы оптимизатор не строил порядок в расчёте на Байдарские ворота
        val full = rawMatrix(st, pts + LASPI, curbCount)
        val n = pts.size; val l = n
        val dur = Array(n) { i -> DoubleArray(n) { k -> full.dur[i][k] } }
        val dist = Array(n) { i -> DoubleArray(n) { k -> full.dist[i][k] } }
        for (i in 0 until n) for (k in 0 until n) if (crossesRidge(pts[i], pts[k])) {
            dur[i][k] = maxOf(dur[i][k], full.dur[i][l] + full.dur[l][k])
            dist[i][k] = maxOf(dist[i][k], full.dist[i][l] + full.dist[l][k])
        }
        return RoadMatrix(dur, dist, full.approximate)
    }

    private fun rawMatrix(st: Settings, pts: List<Point>, curbCount: Int = 0): RoadMatrix {
        val n = pts.size
        // Сначала OpenRouteService (грузовой или легковой профиль), при любой ошибке — OSRM как раньше
        if (st.orsKey.isNotBlank() && n in 2..59) runCatching { return orsMatrix(st, pts) }
        val ap = if (curbCount > 0) "&approaches=" + (0 until n).joinToString(";") { if (it < curbCount) "curb" else "unrestricted" } else ""
        try {
            val coords = pts.joinToString(";") { "${it.lon},${it.lat}" }
            val req = Request.Builder().url("${st.osrm}/table/v1/driving/$coords?annotations=duration,distance$ap").build()
            http.newCall(req).execute().use { r ->
                val txt = r.body?.string().orEmpty()
                if (!r.isSuccessful) error("OSRM ${r.code}")
                val j = JSONObject(txt)
                val du = j.getJSONArray("durations"); val di = j.getJSONArray("distances")
                fun read(a: JSONArray, i: Int, k: Int): Double = a.getJSONArray(i).optDouble(k, Double.NaN)
                val dur = Array(n) { i -> DoubleArray(n) { k -> read(du, i, k) } }
                val dist = Array(n) { i -> DoubleArray(n) { k -> read(di, i, k) } }
                for (i in 0 until n) for (k in 0 until n) {
                    if (dist[i][k].isNaN()) dist[i][k] = straight(pts[i], pts[k]) * 1.4
                    if (dur[i][k].isNaN()) dur[i][k] = dist[i][k] / 7.0
                }
                return RoadMatrix(dur, dist, false)
            }
        } catch (_: Exception) {
            if (curbCount > 0) return rawMatrix(st, pts, 0)
            val dist = Array(n) { i -> DoubleArray(n) { k -> straight(pts[i], pts[k]) * 1.4 } }
            val dur = Array(n) { i -> DoubleArray(n) { k -> dist[i][k] / 7.0 + if (i != k) 45.0 else 0.0 } }
            return RoadMatrix(dur, dist, true)
        }
    }

    /** Геометрия маршрута по дорогам для схемы. Пустой список, если OSRM недоступен. */
    fun geometry(st: Settings, pts: List<Point>, curb: List<Boolean>? = null): List<Pair<Double, Double>> = runCatching {
        if (pts.size < 2) return emptyList()
        if (st.orsKey.isNotBlank() && pts.size <= 50)
            runCatching { orsGeometry(st, pts) }.getOrNull()?.takeIf { it.isNotEmpty() }?.let { return it }
        // Запасной OSRM не знает про грузовик: для него вставляем Ласпинский перевал между побережьем и долиной
        val via = withDetours(st, pts)
        if (via.size != pts.size) return osrmGeometry(st, via, null)
        return osrmGeometry(st, pts, curb)
    }.getOrDefault(emptyList())

    private fun osrmGeometry(st: Settings, pts: List<Point>, curb: List<Boolean>?): List<Pair<Double, Double>> = runCatching {
        val coords = pts.joinToString(";") { "${it.lon},${it.lat}" }
        val ap = if (curb != null && curb.size == pts.size) "&approaches=" + curb.joinToString(";") { if (it) "curb" else "unrestricted" } else ""
        val req = Request.Builder().url("${st.osrm}/route/v1/driving/$coords?overview=full&geometries=geojson$ap").build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return if (curb != null) osrmGeometry(st, pts, null) else emptyList()
            val c = JSONObject(r.body?.string().orEmpty()).getJSONArray("routes").getJSONObject(0)
                .getJSONObject("geometry").getJSONArray("coordinates")
            (0 until c.length()).map { val p = c.getJSONArray(it); p.getDouble(1) to p.getDouble(0) }
        }
    }.getOrDefault(emptyList())

    // ---------- Горные дороги для грузовика ----------
    /** Ласпинский перевал — штатный проезд между Байдарской долиной и побережьем у Фороса. */
    val LASPI = Point("Ласпинский перевал", "", 44.42889, 33.70704, "Ласпинский перевал")

    /** Небольшой участок вокруг Байдарских ворот (44.4069, 33.7828), запрещённый для грузовика. */
    private val BAYDAR_AVOID: JSONObject get() = JSONObject().put("type", "Polygon").put("coordinates", JSONArray().put(
        JSONArray().apply {
            listOf(33.7775 to 44.4045, 33.7880 to 44.4045, 33.7880 to 44.4100, 33.7775 to 44.4100, 33.7775 to 44.4045)
                .forEach { (lo, la) -> put(JSONArray().put(lo).put(la)) }
        }))

    /** Байдарская долина: Орлиное, Передовое, Широкое, Гончарное, Родниковое и соседние сёла. */
    private fun valley(p: Point) = p.lat in 44.42..44.52 && p.lon in 33.66..33.86
    /** Южный берег восточнее Ласпи: Форос, Санаторное, Симеиз … Ялта (граница хребта поднимается к востоку). */
    private fun coast(p: Point) = !valley(p) && p.lon in 33.72..34.40 && p.lat < 44.40 + (p.lon - 33.72) * 0.27
    fun crossesRidge(a: Point, b: Point) = (valley(a) && coast(b)) || (coast(a) && valley(b))

    /** Для грузовика вставляет Ласпинский перевал между соседними точками по разные стороны хребта. */
    fun withDetours(st: Settings, seq: List<Point>): List<Point> {
        if (!st.truck || seq.size < 2) return seq
        val out = ArrayList<Point>(seq.size + 2)
        seq.forEachIndexed { i, p -> if (i > 0 && crossesRidge(seq[i - 1], p)) out.add(LASPI); out.add(p) }
        return out
    }

    // ---------- OpenRouteService ----------
    private const val ORS = "https://api.openrouteservice.org"
    private fun orsProfile(st: Settings) = if (st.truck) "driving-hgv" else "driving-car"
    private fun lonLat(pts: List<Point>) = JSONArray().also { a -> pts.forEach { a.put(JSONArray().put(it.lon).put(it.lat)) } }

    private fun orsMatrix(st: Settings, pts: List<Point>): RoadMatrix {
        val n = pts.size
        val body = JSONObject().put("locations", lonLat(pts)).put("metrics", JSONArray().put("duration").put("distance"))
        val req = Request.Builder().url("$ORS/v2/matrix/${orsProfile(st)}")
            .header("Authorization", st.orsKey)
            .post(body.toString().toRequestBody(JSON)).build()
        http.newCall(req).execute().use { r ->
            val txt = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("ORS ${r.code}")
            val j = JSONObject(txt)
            val du = j.getJSONArray("durations"); val di = j.getJSONArray("distances")
            fun read(a: JSONArray, i: Int, k: Int): Double = a.getJSONArray(i).optDouble(k, Double.NaN)
            val dur = Array(n) { i -> DoubleArray(n) { k -> read(du, i, k) } }
            val dist = Array(n) { i -> DoubleArray(n) { k -> read(di, i, k) } }
            for (i in 0 until n) for (k in 0 until n) {
                if (dist[i][k].isNaN()) dist[i][k] = straight(pts[i], pts[k]) * 1.4
                if (dur[i][k].isNaN()) dur[i][k] = dist[i][k] / 7.0
            }
            return RoadMatrix(dur, dist, false)
        }
    }

    private fun orsGeometry(st: Settings, pts: List<Point>): List<Pair<Double, Double>> {
        val body = JSONObject().put("coordinates", lonLat(pts))
        if (st.truck) body.put("options", JSONObject().put("avoid_polygons", BAYDAR_AVOID))
        val req = Request.Builder().url("$ORS/v2/directions/${orsProfile(st)}/geojson")
            .header("Authorization", st.orsKey)
            .post(body.toString().toRequestBody(JSON)).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return emptyList()
            val c = JSONObject(r.body?.string().orEmpty()).getJSONArray("features").getJSONObject(0)
                .getJSONObject("geometry").getJSONArray("coordinates")
            return (0 until c.length()).map { val p = c.getJSONArray(it); p.getDouble(1) to p.getDouble(0) }
        }
    }

    fun straight(a: Point, b: Point): Double = haversine(a.lat, a.lon, b.lat, b.lon)

    fun haversine(la1: Double, lo1: Double, la2: Double, lo2: Double): Double {
        val r = 6371000.0
        val dLa = Math.toRadians(la2 - la1); val dLo = Math.toRadians(lo2 - lo1)
        val h = Math.sin(dLa / 2).let { it * it } + Math.cos(Math.toRadians(la1)) * Math.cos(Math.toRadians(la2)) * Math.sin(dLo / 2).let { it * it }
        return 2 * r * Math.asin(Math.sqrt(h.coerceIn(0.0, 1.0)))
    }

    // ---------- поиск адреса ----------
    /** Насколько точно найден адрес: дом, улица или только населённый пункт. */
    enum class Precision { HOUSE, STREET, PLACE }
    data class Geo(val lat: Double, val lon: Double, val precision: Precision) {
        val pair get() = lat to lon
        /** Пояснение для неточного результата, null — найден дом. */
        val note: String? get() = when (precision) {
            Precision.HOUSE -> null
            Precision.STREET -> "найдена только улица, без дома"
            Precision.PLACE -> "найден только населённый пункт"
        }
    }

    /** Адрес по частям: населённый пункт, улица, дом. */
    data class AddressParts(val place: String?, val street: String?, val house: String?)

    /** Сокращения, которые поиск не понимает: «ул», «д.», «г.» и т.п. — отдельными словами. */
    private val ABBR = Regex("(?iu)(^|(?<=[\\s,.]))(ул|улица|д|дом|г|гор|город|пгт|пос|посёлок|поселок|п|с|село|корп|корпус|стр|строение)\\.?(?=[\\s,]|$)")
    private val STREET_WORDS = Regex("(?iu)(шоссе|улиц|переул|пер\\.|проспект|пр-т|бульвар|набережн|проезд|тупик|площад|спуск|аллея|дорога|тракт|линия|квартал|микрорайон|мкр)")
    // Дом: 12, 14а, 13-Ф, 5/2, 48М
    private val HOUSE = Regex("(?iu)^\\d+(\\s*-?\\s*[а-яa-z])?(\\s*[/-]\\s*\\d+[а-яa-z]?)?$")
    private val TRAILING_HOUSE = Regex("(?iu)^(.*\\D)\\s+(\\d+(\\s*-?\\s*[а-яa-z])?(\\s*[/-]\\s*\\d+[а-яa-z]?)?)$")
    private val SKIP = Regex("(?iu)^(россия|рф|республика крым|респ\\.? крым|крым|\\d{6}|кв\\.?\\s*\\d+.*|квартира.*|офис.*|помещ.*)$")

    /** «Партенит, ул Фрунзенское шоссе, д. 12» → место «Партенит», улица «Фрунзенское шоссе», дом «12». */
    fun splitAddress(raw: String): AddressParts {
        var place: String? = null; var street: String? = null; var house: String? = null
        val parts = raw.split(',', ';').map { it.replace(ABBR, " ").replace(Regex("\\s+"), " ").trim(' ', '.') }
            .filter { it.isNotBlank() && !SKIP.matches(it) }
        for (p in parts) {
            val tail = TRAILING_HOUSE.find(p)
            when {
                HOUSE.matches(p) -> if (house == null) house = p.replace(" ", "")
                tail != null && street == null && (STREET_WORDS.containsMatchIn(p) || place != null) -> {
                    street = tail.groupValues[1].trim(); if (house == null) house = tail.groupValues[2].replace(" ", "")
                }
                street == null && STREET_WORDS.containsMatchIn(p) -> street = p
                place == null -> place = p
                street == null -> street = p
            }
        }
        return AddressParts(place, street, house)
    }

    private var lastNominatim = 0L
    /** OpenStreetMap просит не чаще запроса в секунду. */
    @Synchronized private fun nominatimPause() {
        val wait = 1100 - (System.currentTimeMillis() - lastNominatim)
        if (wait > 0) Thread.sleep(wait)
        lastNominatim = System.currentTimeMillis()
    }

    private fun nominatim(q: String, near: Pair<Double, Double>?, level: Precision): Geo? {
        nominatimPause()
        val box = near?.let { (la, lo) -> "&viewbox=${lo - 1.5},${la + 1.0},${lo + 1.5},${la - 1.0}&bounded=1" }.orEmpty()
        val req = Request.Builder()
            .url("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&accept-language=ru$box&q=" + URLEncoder.encode(q, "UTF-8"))
            .header("User-Agent", "MarshrutApp/1.0 (route planner for delivery drivers)").build()
        return http.newCall(req).execute().use { r ->
            val a = runCatching { JSONArray(r.body?.string().orEmpty()) }.getOrNull() ?: return null
            if (a.length() == 0) return null
            val o = a.getJSONObject(0)
            val kind = o.optString("addresstype")
            val got = when (kind) {
                "road" -> Precision.STREET
                "city", "town", "village", "hamlet", "suburb", "neighbourhood", "quarter", "municipality", "county", "state", "isolated_dwelling" -> Precision.PLACE
                else -> level
            }
            Geo(o.getString("lat").toDouble(), o.getString("lon").toDouble(), maxOf(got, level))
        }
    }

    /** Photon — второй поиск по данным OpenStreetMap, терпимее к опечаткам и лишним словам. */
    private fun photon(q: String, near: Pair<Double, Double>?, level: Precision): Geo? {
        val bias = near?.let { (la, lo) -> "&lat=$la&lon=$lo" }.orEmpty()
        val req = Request.Builder().url("https://photon.komoot.io/api/?limit=1$bias&q=" + URLEncoder.encode(q, "UTF-8"))
            .header("User-Agent", "MarshrutApp/1.0").build()
        return http.newCall(req).execute().use { r ->
            val f = runCatching { JSONObject(r.body?.string().orEmpty()).getJSONArray("features") }.getOrNull() ?: return null
            if (f.length() == 0) return null
            val o = f.getJSONObject(0)
            val c = o.getJSONObject("geometry").getJSONArray("coordinates")
            val got = when (o.optJSONObject("properties")?.optString("type")) {
                "house" -> Precision.HOUSE
                "street" -> Precision.STREET
                "city", "district", "locality", "county", "state" -> Precision.PLACE
                else -> level
            }
            Geo(c.getDouble(1), c.getDouble(0), maxOf(got, level))
        }
    }

    /**
     * Координаты по адресу. Адрес чистится от «ул», «д.» и т.п., затем ищется по шагам:
     * дом → улица → населённый пункт, каждый шаг в OpenStreetMap (Nominatim), потом в Photon.
     * near — склад: ищем рядом с ним, найденное дальше 150 км считается ошибкой.
     */
    fun geocode(address: String, near: Pair<Double, Double>? = null): Geo? {
        val a = splitAddress(address)
        val tries = ArrayList<Pair<String, Precision>>()
        fun q(vararg x: String?) = x.filterNotNull().filter { it.isNotBlank() }.joinToString(", ")
        if (a.street != null && a.house != null) {
            tries.add(q("${a.street} ${a.house}", a.place) to Precision.HOUSE)
            // «36» на скане могло быть «3б», «586» — «58б»
            if (Regex("^\\d+6$").matches(a.house)) tries.add(q("${a.street} ${a.house.dropLast(1)}б", a.place) to Precision.HOUSE)
        }
        if (a.street != null) tries.add(q(a.street, a.place) to Precision.STREET)
        if (a.place != null) tries.add(q(a.place) to Precision.PLACE)
        if (tries.isEmpty()) tries.add(address.trim() to Precision.HOUSE)
        fun ok(g: Geo?) = g != null && (near == null || haversine(near.first, near.second, g.lat, g.lon) <= 150_000.0)
        // Нашлось грубее, чем искали (вместо дома — улица), — пробуем следующий вариант, а грубое держим про запас
        var best: Geo? = null
        for ((text, level) in tries.distinctBy { it.first }) {
            for (g in listOf({ nominatim(text, near, level) }, { photon(text, near, level) })) {
                val r = runCatching { g() }.getOrNull() ?: continue
                if (!ok(r)) continue
                if (r.precision <= level) return r
                if (best == null || r.precision < best.precision) best = r
            }
        }
        return best
    }

}
