package ru.marshrut

import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class Settings(private val sp: android.content.SharedPreferences) {
    private fun s(k: String, d: String) = sp.getString(k, d) ?: d

    init {
        // Версия 4.2: старт со склада и чтение клиента с адресом — по умолчанию и у тех, кто уже сохранял настройки
        if (sp.getInt("defaults", 0) < 42) sp.edit().putBoolean("gps", false).putBoolean("wc", true).putInt("defaults", 42).apply()
    }
    /** Ключи и модели вшиваются при сборке из секретов GitHub (YANDEX_API_KEY, DEEPSEEK_MODEL, QWEN_MODEL, ORS_API_KEY). */
    val apiKey: String get() = BuildConfig.YANDEX_API_KEY
    /** Выбранная модель распознавания: "deepseek" или "qwen". */
    var modelChoice: String get() = s("mc", "deepseek"); set(v) { sp.edit().putString("mc", v).apply() }
    /** Полный адрес модели вида gpt://<каталог>/<модель>/latest. */
    val model: String get() = (if (modelChoice == "qwen") BuildConfig.QWEN_MODEL else BuildConfig.DEEPSEEK_MODEL).trim()
    /** ID каталога берётся из адреса модели. */
    val folder: String get() = Regex("^[a-z]+://([^/]+)/").find(model)?.groupValues?.get(1).orEmpty()
    val orsKey: String get() = BuildConfig.ORS_API_KEY.trim()
    /** Грузовик (категория C): дороги считаются по грузовому профилю OpenRouteService. */
    var truck: Boolean get() = sp.getBoolean("truck", true); set(v) { sp.edit().putBoolean("truck", v).apply() }
    var osrm: String get() = s("osrm", "https://router.project-osrm.org"); set(v) { sp.edit().putString("osrm", v.trim().trimEnd('/')).apply() }
    var depot: String get() = s("depot", ""); set(v) { sp.edit().putString("depot", v.trim()).apply() }
    var withClient: Boolean get() = sp.getBoolean("wc", true); set(v) { sp.edit().putBoolean("wc", v).apply() }
    var capacity: String get() = s("cap", "1500"); set(v) { sp.edit().putString("cap", v.trim()).apply() }
    /** Маршрут заканчивается на складе. */
    var endAtDepot: Boolean get() = sp.getBoolean("end", true); set(v) { sp.edit().putBoolean("end", v).apply() }
    /** Если старт не задан — начинать маршрут от текущего местоположения. */
    var startFromGps: Boolean get() = sp.getBoolean("gps", false); set(v) { sp.edit().putBoolean("gps", v).apply() }
    /** Резервная копия на Яндекс Диске: токены входа через Яндекс. */
    var yaToken: String get() = s("yt", ""); set(v) { sp.edit().putString("yt", v).apply() }
    var yaRefresh: String get() = s("yr", ""); set(v) { sp.edit().putString("yr", v).apply() }
    val cloudReady get() = yaToken.isNotBlank()
    /** Сохранять копию само — после маршрута и при сворачивании, если что-то изменилось. */
    var autoBackup: Boolean get() = sp.getBoolean("ab", true); set(v) { sp.edit().putBoolean("ab", v).apply() }
    /** Время последней удачной копии, отпечаток выгруженного и день последней архивной копии. */
    var lastBackup: Long get() = sp.getLong("lb", 0L); set(v) { sp.edit().putLong("lb", v).apply() }
    var backupHash: String get() = s("bh", ""); set(v) { sp.edit().putString("bh", v).apply() }
    var archiveDay: String get() = s("ad", ""); set(v) { sp.edit().putString("ad", v).apply() }
    /** Общая база: из секрета сборки SHARED_DB, а на телефоне владельца до пересборки — та, что он только что подготовил. */
    var localShared: String get() = s("lsh", ""); set(v) { sp.edit().putString("lsh", v).apply() }
    val shared: SharedKey.Parsed? get() = SharedKey.parse(BuildConfig.SHARED_DB.ifBlank { localShared })
    /** Ключ записи после ввода пароля редактора; пусто — телефон только читает. */
    var editorToken: String get() = s("et", ""); set(v) { sp.edit().putString("et", v).apply() }
    val isEditor get() = editorToken.isNotBlank() && shared != null
    /** Отпечаток версии общей базы, которую телефон уже взял. */
    var sharedMd5: String get() = s("sm", ""); set(v) { sp.edit().putString("sm", v).apply() }
    var lastSync: Long get() = sp.getLong("ls", 0L); set(v) { sp.edit().putLong("ls", v).apply() }
}

/** Матрицы времени (с) и расстояния (м) между узлами. */
class RoadMatrix(val dur: Array<DoubleArray>, val dist: Array<DoubleArray>, val approximate: Boolean)

object Net {
    val http: OkHttpClient = OkHttpClient.Builder()
        .callTimeout(240, TimeUnit.SECONDS).readTimeout(240, TimeUnit.SECONDS).build()
    private val JSON = "application/json".toMediaType()

    private const val P1 = "Это маршрутный лист (1–4 скана). Объедини таблицы со всех листов в одну, строго до строки «ИТОГО ВЕС» (саму итоговую строку не включай). Правила: пуст" +
        "ая ячейка «П/д» означает продолжение предыдущей точки, но это всё равно отдельная строка (накладная); десятичный разделитель — точка, на скане она мож" +
        "ет быть плохо видна («40 2» → 40.2); «агент» — число до символа «/» в колонке «Агент/СВ» («5/ SV3» → 5, «1/» → 1; часть после «/» не нужна); «вес» — б" +
        "рутто в кг; порядок колонок слева направо: Вес, Сумма, Факт, Забрать долг, Расчет, Заметки, Агент/СВ — «Факт» стоит СТРОГО ПОСЛЕ «Суммы» и ДО «Забрать долг»; «факт» — отдельная колонка «Факт» с наличными, которые забрали с точки; она почти всегда пустая, пустую оставляй пустой строкой; НЕ путай её с соседней колонкой «Сумма» (сумма накладной, заполнена почти всегда) и с «Забрать долг»; «сумма» выведи отдельно из колонки «Сумма», «накладная» — текст из колонки с номером накладной (АСП, возврат, оборудование и т.п.); «расчет» — буквенный код (ПМ, ЧЗ…) или пусто. Остальные колонки (код, довоз, вид, забрать долг) не нужны — не выводи их. Из шапки титульного листа возьми: краткую строку (№ и дата листа, маршрут, транспортное средство, экспе" +
        "дитор); из итоговой строки — число после «ИТОГО ВЕС» (кг); контакты только нумерованных агентов справа вверху (1, 2, 3…): номер, имя, телефон. Контакт" +
        "ы СВ (SV3, SV4…) и строки без номера пропусти. Верни ТОЛЬКО json без пояснений и markdown: {\"шапка\": \"\", \"итого_вес\": \"\", \"agents\": [{\"номе" +
        "р\": \"\", \"имя\": \"\", \"телефон\": \"\"}], \"rows\": ["
    private const val P2 = "]}. Порядок строк как в документе, пустые ячейки — пустая строка, ничего не выдумывай и не пропускай строки."

    fun prompt(withClient: Boolean): String {
        val cols = "{\"позывной\": \"\", \"вес\": \"\", \"факт\": \"\", \"расчет\": \"\", \"заметки\": \"\", \"агент\": \"\", \"накладная\": \"\", \"сумма\": \"\"" +
            (if (withClient) ", \"клиент\": \"\", \"адрес\": \"\"" else "") + "}"
        return P1 + cols + P2
    }

    /** Каждая страница уходит отдельным запросом (короткий ответ, не обрывается), затем результаты склеиваются. */
    fun recognize(st: Settings, jpegs: List<ByteArray>, onProgress: (Int, Int) -> Unit = { _, _ -> }): Recognized {
        val parts = jpegs.mapIndexed { i, j -> onProgress(i + 1, jpegs.size); recognizeOne(st, j, i + 1, jpegs.size) }
        val agents = parts.flatMap { it.agents }.filter { it.num.isNotBlank() || it.name.isNotBlank() }
            .distinctBy { it.num.ifBlank { it.name } }
        val rows = parts.flatMap { it.rows }.mapIndexed { i, r -> r.copy(id = i) }
        return Recognized(agents, rows, parts.map { it.header }.firstOrNull { it.isNotBlank() }.orEmpty(),
            parts.mapNotNull { it.total }.lastOrNull(), null, parts.any { it.truncated })
    }

    private fun recognizeOne(st: Settings, jpeg: ByteArray, page: Int, pages: Int): Recognized {
        val note = if (pages > 1) "ВАЖНО: в этом запросе одна страница листа (стр. $page из $pages). Выводи только строки таблицы, видимые на ней; " +
            "шапку, агентов и итоговый вес — только если они есть на этой странице, иначе оставь пустыми. " else ""
        val text = note + prompt(st.withClient) + " Ответ — компактный JSON без отступов и переносов строк, без рассуждений."
        val content = JSONArray().put(JSONObject().put("type", "text").put("text", text))
        val url = "data:image/jpeg;base64," + Base64.encodeToString(jpeg, Base64.NO_WRAP)
        content.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", url)))
        fun call(withEffort: Boolean): Pair<Int, String> {
            val body = JSONObject()
                .put("model", st.model.replace("{folder}", st.folder))
                .put("temperature", 0)
                .put("max_tokens", 40000)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
            if (withEffort) body.put("reasoning_effort", "none")
            val req = Request.Builder().url("https://llm.api.cloud.yandex.net/v1/chat/completions")
                .header("Authorization", "Api-Key " + st.apiKey)
                .header("x-folder-id", st.folder)
                .post(body.toString().toRequestBody(JSON)).build()
            return http.newCall(req).execute().use { it.code to it.body?.string().orEmpty() }
        }
        var (code, txt) = call(true)
        // если модель не принимает reasoning_effort — повторяем без него
        if (code == 400 && txt.contains("reasoning", true)) { val r2 = call(false); code = r2.first; txt = r2.second }
        run {
            if (code !in 200..299) error("Облако ответило $code: ${txt.take(300)}")
            val ch = JSONObject(txt).getJSONArray("choices").getJSONObject(0)
            val finish = ch.optString("finish_reason", "")
            val m = ch.getJSONObject("message")
            val msg = if (m.isNull("content")) "" else m.optString("content", "")
            if (msg.isBlank()) error("Страница $page: модель не вернула текст (finish_reason=$finish) — весь лимит ушёл на рассуждения")
            val rec = try { parse(msg, finish == "length") } catch (e: Exception) {
                error("Страница $page: ${e.message} (finish_reason=$finish, длина ответа ${msg.length})")
            }
            if (rec.truncated && rec.rows.isEmpty())
                error("Страница $page: ответ модели оборван (finish_reason=$finish)")
            return rec
        }
    }

    /** Достраивает закрывающие скобки у оборванного JSON, оставляя только целые элементы. */
    private fun repair(t: String): Pair<String, Boolean> {
        try { JSONObject(t); return t to false } catch (_: Exception) {}
        var inStr = false; var esc = false
        val stack = ArrayList<Char>(); var good = -1; var stackAtGood: List<Char> = emptyList()
        for (i in t.indices) {
            val c = t[i]
            if (inStr) { if (esc) esc = false else if (c == '\\') esc = true else if (c == '"') inStr = false; continue }
            when (c) {
                '"' -> inStr = true
                '{', '[' -> stack.add(c)
                '}', ']' -> { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex); good = i; stackAtGood = stack.toList() }
            }
        }
        if (good < 0) error("В ответе нет целых элементов JSON")
        val sb = StringBuilder(t.substring(0, good + 1))
        stackAtGood.asReversed().forEach { sb.append(if (it == '{') '}' else ']') }
        return sb.toString() to true
    }

    fun parse(text: String, cut: Boolean = false): Recognized {
        val a = text.indexOf('{'); val b = text.lastIndexOf('}')
        if (a < 0 || b < a) error("В ответе нет JSON: ${text.take(200)}")
        val (fixed, repaired) = repair(text.substring(a, b + 1))
        val j = JSONObject(fixed)
        val ag = j.opt("agents") ?: j.opt("agent")
        val agents = when (ag) {
            is JSONArray -> (0 until ag.length()).mapNotNull { parseAgent(ag.opt(it)) }
            null, JSONObject.NULL -> emptyList()
            else -> listOfNotNull(parseAgent(ag))
        }
        val arr = j.optJSONArray("rows") ?: JSONArray()
        val rows = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            fun g(k: String) = o.optString(k, "").let { if (it == "null") "" else it.trim() }
            val ag = g("агент").substringBefore('/').trim()
            Row(
                id = i, callsign = g("позывной"), weight = g("вес").toD() ?: 0.0, fact = g("факт"), calc = g("расчет"),
                notes = g("заметки"), sum = g("сумма"), agent = ag, client = g("клиент"), address = g("адрес"), invoice = g("накладная")
            )
        }
        fun top(k: String) = j.optString(k, "").let { if (it == "null") "" else it.trim() }
        return Recognized(agents, rows, top("шапка"), top("итого_вес").toD(), null, repaired || cut)
    }

    private fun parseAgent(x: Any?): Agent? {
        if (x is JSONObject) {
            fun g(vararg k: String) = k.firstNotNullOfOrNull { x.optString(it, "").takeIf { s -> s.isNotBlank() && s != "null" } }?.trim().orEmpty()
            return Agent(g("номер", "num", "number"), g("имя", "name", "фио"), g("телефон", "phone"))
        }
        val s = x?.toString()?.trim().orEmpty()
        if (s.isEmpty() || s == "null") return null
        val num = Regex("^(?:[Ss][Vv])?\\d+").find(s)?.value.orEmpty()
        val rest = s.removePrefix(num)
        val phone = Regex("\\+?\\d[\\d\\s()\\-]{8,}\\d").find(rest)?.value.orEmpty()
        val name = rest.replace(phone, "").trim(' ', '.', ')', ',', '-', ':')
        return Agent(num, name, phone.trim())
    }

    /** Матрицы времени и расстояния через OSRM table; при недоступности — оценка по прямой с коэффициентом извилистости. */
    /**
     * curbCount — первые N узлов это точки выгрузки: к ним подъезжаем только «своей» стороной (approaches=curb),
     * чтобы точка оказывалась по ходу движения, а не через дорогу. Если сервер не принял параметр — повтор без него.
     */
    fun matrix(st: Settings, pts: List<Point>, curbCount: Int = 0): RoadMatrix {
        if (!st.truck || pts.indices.none { i -> pts.indices.any { k -> crossesRidge(pts[i], pts[k]) } })
            return rawMatrix(st, pts, curbCount)
        // Грузовик: пары «побережье ↔ Байдарская долина» пересчитываем через Ласпинский перевал,
        // чтобы оптимизатор не строил порядок в расчёте на Байдарские ворота
        val full = rawMatrix(st, pts + LASPI, curbCount)
        val n = pts.size; val l = n
        val dur = Array(n) { i -> DoubleArray(n) { k -> full.dur[i][k] } }
        val dist = Array(n) { i -> DoubleArray(n) { k -> full.dist[i][k] } }
        for (i in 0 until n) for (k in 0 until n) if (crossesRidge(pts[i], pts[k])) {
            dur[i][k] = maxOf(dur[i][k], full.dur[i][l] + full.dur[l][k])
            dist[i][k] = maxOf(dist[i][k], full.dist[i][l] + full.dist[l][k])
        }
        return RoadMatrix(dur, dist, full.approximate)
    }

    private fun rawMatrix(st: Settings, pts: List<Point>, curbCount: Int = 0): RoadMatrix {
        val n = pts.size
        // Сначала OpenRouteService (грузовой или легковой профиль), при любой ошибке — OSRM как раньше
        if (st.orsKey.isNotBlank() && n in 2..59) runCatching { return orsMatrix(st, pts) }
        val ap = if (curbCount > 0) "&approaches=" + (0 until n).joinToString(";") { if (it < curbCount) "curb" else "unrestricted" } else ""
        try {
            val coords = pts.joinToString(";") { "${it.lon},${it.lat}" }
            val req = Request.Builder().url("${st.osrm}/table/v1/driving/$coords?annotations=duration,distance$ap").build()
            http.newCall(req).execute().use { r ->
                val txt = r.body?.string().orEmpty()
                if (!r.isSuccessful) error("OSRM ${r.code}")
                val j = JSONObject(txt)
                val du = j.getJSONArray("durations"); val di = j.getJSONArray("distances")
                fun read(a: JSONArray, i: Int, k: Int): Double = a.getJSONArray(i).optDouble(k, Double.NaN)
                val dur = Array(n) { i -> DoubleArray(n) { k -> read(du, i, k) } }
                val dist = Array(n) { i -> DoubleArray(n) { k -> read(di, i, k) } }
                for (i in 0 until n) for (k in 0 until n) {
                    if (dist[i][k].isNaN()) dist[i][k] = straight(pts[i], pts[k]) * 1.4
                    if (dur[i][k].isNaN()) dur[i][k] = dist[i][k] / 7.0
                }
                return RoadMatrix(dur, dist, false)
            }
        } catch (_: Exception) {
            if (curbCount > 0) return rawMatrix(st, pts, 0)
            val dist = Array(n) { i -> DoubleArray(n) { k -> straight(pts[i], pts[k]) * 1.4 } }
            val dur = Array(n) { i -> DoubleArray(n) { k -> dist[i][k] / 7.0 + if (i != k) 45.0 else 0.0 } }
            return RoadMatrix(dur, dist, true)
        }
    }

    /** Геометрия маршрута по дорогам для схемы. Пустой список, если OSRM недоступен. */
    fun geometry(st: Settings, pts: List<Point>, curb: List<Boolean>? = null): List<Pair<Double, Double>> = runCatching {
        if (pts.size < 2) return emptyList()
        if (st.orsKey.isNotBlank() && pts.size <= 50)
            runCatching { orsGeometry(st, pts) }.getOrNull()?.takeIf { it.isNotEmpty() }?.let { return it }
        // Запасной OSRM не знает про грузовик: для него вставляем Ласпинский перевал между побережьем и долиной
        val via = withDetours(st, pts)
        if (via.size != pts.size) return osrmGeometry(st, via, null)
        return osrmGeometry(st, pts, curb)
    }.getOrDefault(emptyList())

    private fun osrmGeometry(st: Settings, pts: List<Point>, curb: List<Boolean>?): List<Pair<Double, Double>> = runCatching {
        val coords = pts.joinToString(";") { "${it.lon},${it.lat}" }
        val ap = if (curb != null && curb.size == pts.size) "&approaches=" + curb.joinToString(";") { if (it) "curb" else "unrestricted" } else ""
        val req = Request.Builder().url("${st.osrm}/route/v1/driving/$coords?overview=full&geometries=geojson$ap").build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return if (curb != null) osrmGeometry(st, pts, null) else emptyList()
            val c = JSONObject(r.body?.string().orEmpty()).getJSONArray("routes").getJSONObject(0)
                .getJSONObject("geometry").getJSONArray("coordinates")
            (0 until c.length()).map { val p = c.getJSONArray(it); p.getDouble(1) to p.getDouble(0) }
        }
    }.getOrDefault(emptyList())

    // ---------- Горные дороги для грузовика ----------
    /** Ласпинский перевал — штатный проезд между Байдарской долиной и побережьем у Фороса. */
    val LASPI = Point("Ласпинский перевал", "", 44.42889, 33.70704, "Ласпинский перевал")

    /** Небольшой участок вокруг Байдарских ворот (44.4069, 33.7828), запрещённый для грузовика. */
    private val BAYDAR_AVOID: JSONObject get() = JSONObject().put("type", "Polygon").put("coordinates", JSONArray().put(
        JSONArray().apply {
            listOf(33.7775 to 44.4045, 33.7880 to 44.4045, 33.7880 to 44.4100, 33.7775 to 44.4100, 33.7775 to 44.4045)
                .forEach { (lo, la) -> put(JSONArray().put(lo).put(la)) }
        }))

    /** Байдарская долина: Орлиное, Передовое, Широкое, Гончарное, Родниковое и соседние сёла. */
    private fun valley(p: Point) = p.lat in 44.42..44.52 && p.lon in 33.66..33.86
    /** Южный берег восточнее Ласпи: Форос, Санаторное, Симеиз … Ялта (граница хребта поднимается к востоку). */
    private fun coast(p: Point) = !valley(p) && p.lon in 33.72..34.40 && p.lat < 44.40 + (p.lon - 33.72) * 0.27
    fun crossesRidge(a: Point, b: Point) = (valley(a) && coast(b)) || (coast(a) && valley(b))

    /** Для грузовика вставляет Ласпинский перевал между соседними точками по разные стороны хребта. */
    fun withDetours(st: Settings, seq: List<Point>): List<Point> {
        if (!st.truck || seq.size < 2) return seq
        val out = ArrayList<Point>(seq.size + 2)
        seq.forEachIndexed { i, p -> if (i > 0 && crossesRidge(seq[i - 1], p)) out.add(LASPI); out.add(p) }
        return out
    }

    // ---------- OpenRouteService ----------
    private const val ORS = "https://api.openrouteservice.org"
    private fun orsProfile(st: Settings) = if (st.truck) "driving-hgv" else "driving-car"
    private fun lonLat(pts: List<Point>) = JSONArray().also { a -> pts.forEach { a.put(JSONArray().put(it.lon).put(it.lat)) } }

    private fun orsMatrix(st: Settings, pts: List<Point>): RoadMatrix {
        val n = pts.size
        val body = JSONObject().put("locations", lonLat(pts)).put("metrics", JSONArray().put("duration").put("distance"))
        val req = Request.Builder().url("$ORS/v2/matrix/${orsProfile(st)}")
            .header("Authorization", st.orsKey)
            .post(body.toString().toRequestBody(JSON)).build()
        http.newCall(req).execute().use { r ->
            val txt = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("ORS ${r.code}")
            val j = JSONObject(txt)
            val du = j.getJSONArray("durations"); val di = j.getJSONArray("distances")
            fun read(a: JSONArray, i: Int, k: Int): Double = a.getJSONArray(i).optDouble(k, Double.NaN)
            val dur = Array(n) { i -> DoubleArray(n) { k -> read(du, i, k) } }
            val dist = Array(n) { i -> DoubleArray(n) { k -> read(di, i, k) } }
            for (i in 0 until n) for (k in 0 until n) {
                if (dist[i][k].isNaN()) dist[i][k] = straight(pts[i], pts[k]) * 1.4
                if (dur[i][k].isNaN()) dur[i][k] = dist[i][k] / 7.0
            }
            return RoadMatrix(dur, dist, false)
        }
    }

    private fun orsGeometry(st: Settings, pts: List<Point>): List<Pair<Double, Double>> {
        val body = JSONObject().put("coordinates", lonLat(pts))
        if (st.truck) body.put("options", JSONObject().put("avoid_polygons", BAYDAR_AVOID))
        val req = Request.Builder().url("$ORS/v2/directions/${orsProfile(st)}/geojson")
            .header("Authorization", st.orsKey)
            .post(body.toString().toRequestBody(JSON)).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return emptyList()
            val c = JSONObject(r.body?.string().orEmpty()).getJSONArray("features").getJSONObject(0)
                .getJSONObject("geometry").getJSONArray("coordinates")
            return (0 until c.length()).map { val p = c.getJSONArray(it); p.getDouble(1) to p.getDouble(0) }
        }
    }

    fun straight(a: Point, b: Point): Double = haversine(a.lat, a.lon, b.lat, b.lon)

    fun haversine(la1: Double, lo1: Double, la2: Double, lo2: Double): Double {
        val r = 6371000.0
        val dLa = Math.toRadians(la2 - la1); val dLo = Math.toRadians(lo2 - lo1)
        val h = Math.sin(dLa / 2).let { it * it } + Math.cos(Math.toRadians(la1)) * Math.cos(Math.toRadians(la2)) * Math.sin(dLo / 2).let { it * it }
        return 2 * r * Math.asin(Math.sqrt(h.coerceIn(0.0, 1.0)))
    }

    /**
     * Координаты по адресу (OpenStreetMap Nominatim). near — склад: поиск сначала рядом с ним,
     * а найденное дальше 150 км считается ошибкой (одноимённая улица в другом городе).
     */
    fun geocode(address: String, near: Pair<Double, Double>? = null): Pair<Double, Double>? {
        val box = near?.let { (la, lo) -> "&viewbox=${lo - 1.5},${la + 1.0},${lo + 1.5},${la - 1.0}" }.orEmpty()
        val req = Request.Builder()
            .url("https://nominatim.openstreetmap.org/search?format=json&limit=1&accept-language=ru$box&q=" + URLEncoder.encode(address, "UTF-8"))
            .header("User-Agent", "MarshrutApp/1.0").build()
        val found = http.newCall(req).execute().use { r ->
            val a = JSONArray(r.body?.string().orEmpty())
            if (a.length() == 0) null else a.getJSONObject(0).let { it.getString("lat").toDouble() to it.getString("lon").toDouble() }
        } ?: return null
        if (near != null && haversine(near.first, near.second, found.first, found.second) > 150_000.0) return null
        return found
    }
}
