package ru.marshrut

import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class Settings(private val sp: android.content.SharedPreferences) {
    private fun s(k: String, d: String) = sp.getString(k, d) ?: d
    var apiKey: String get() = s("key", ""); set(v) { sp.edit().putString("key", v.trim()).apply() }
    var folder: String get() = s("folder", ""); set(v) { sp.edit().putString("folder", v.trim()).apply() }
    /** Точный ID модели берите из консоли AI Studio; {folder} подставится автоматически. */
    var model: String get() = s("model2", "gpt://{folder}/deepseek-v4.1-flash/latest"); set(v) { sp.edit().putString("model2", v.trim()).apply() }
    var osrm: String get() = s("osrm", "https://router.project-osrm.org"); set(v) { sp.edit().putString("osrm", v.trim().trimEnd('/')).apply() }
    var depot: String get() = s("depot", ""); set(v) { sp.edit().putString("depot", v.trim()).apply() }
    var withClient: Boolean get() = sp.getBoolean("wc", false); set(v) { sp.edit().putBoolean("wc", v).apply() }
    var capacity: String get() = s("cap", "1500"); set(v) { sp.edit().putString("cap", v.trim()).apply() }
}

object Net {
    val http: OkHttpClient = OkHttpClient.Builder()
        .callTimeout(240, TimeUnit.SECONDS).readTimeout(240, TimeUnit.SECONDS).build()
    private val JSON = "application/json".toMediaType()

    private const val P1 = "Это маршрутный лист (1–4 скана). Объедини таблицы со всех листов в одну, строго до строки «ИТОГО ВЕС» (саму итоговую строку не включай). Правила: пуст" +
        "ая ячейка «П/д» означает продолжение предыдущей точки, но это всё равно отдельная строка (накладная); десятичный разделитель — точка, на скане она мож" +
        "ет быть плохо видна («40 2» → 40.2); «агент» — число до символа «/» в колонке «Агент/СВ» («5/ SV3» → 5, «1/» → 1; часть после «/» не нужна); «вес» — б" +
        "рутто в кг; порядок колонок слева направо: Вес, Сумма, Факт, Забрать долг, Расчет, Заметки, Агент/СВ — «Факт» стоит СТРОГО ПОСЛЕ «Суммы» и ДО «Забрать долг»; «факт» — отдельная колонка «Факт» с наличными, которые забрали с точки; она почти всегда пустая, пустую оставляй пустой строкой; НЕ путай её с соседней колонкой «Сумма» (сумма накладной, заполнена почти всегда) и с «Забрать долг»; «сумма» выведи отдельно из колонки «Сумма», «накладная» — текст из колонки с номером накладной (АСП, возврат, оборудование и т.п.); «расчет» — буквенный код (ПМ, ЧЗ…) или пусто. Остальные колонки (код, довоз, вид, забрать долг) не нужны — не выводи их. Из шапки титульного листа возьми: краткую строку (№ и дата листа, маршрут, транспортное средство, экспе" +
        "дитор); из итоговой строки — число после «ИТОГО ВЕС» (кг); контакты только нумерованных агентов справа вверху (1, 2, 3…): номер, имя, телефон. Контакт" +
        "ы СВ (SV3, SV4…) и строки без номера пропусти. Верни ТОЛЬКО json без пояснений и markdown: {\"шапка\": \"\", \"итого_вес\": \"\", \"agents\": [{\"номе" +
        "р\": \"\", \"имя\": \"\", \"телефон\": \"\"}], \"rows\": ["
    private const val P2 = "]}. Порядок строк как в документе, пустые ячейки — пустая строка, ничего не выдумывай и не пропускай строки."

    fun prompt(withClient: Boolean): String {
        val cols = "{\"позывной\": \"\", \"вес\": \"\", \"факт\": \"\", \"расчет\": \"\", \"заметки\": \"\", \"агент\": \"\", \"накладная\": \"\", \"сумма\": \"\"" +
            (if (withClient) ", \"клиент\": \"\", \"адрес\": \"\"" else "") + "}"
        return P1 + cols + P2
    }

    /** Каждая страница уходит отдельным запросом (короткий ответ, не обрывается), затем результаты склеиваются. */
    fun recognize(st: Settings, jpegs: List<ByteArray>, onProgress: (Int, Int) -> Unit = { _, _ -> }): Recognized {
        val parts = jpegs.mapIndexed { i, j -> onProgress(i + 1, jpegs.size); recognizeOne(st, j, i + 1, jpegs.size) }
        val agents = parts.flatMap { it.agents }.filter { it.num.isNotBlank() || it.name.isNotBlank() }
            .distinctBy { it.num.ifBlank { it.name } }
        val rows = parts.flatMap { it.rows }.mapIndexed { i, r -> r.copy(id = i) }
        return Recognized(agents, rows, parts.map { it.header }.firstOrNull { it.isNotBlank() }.orEmpty(),
            parts.mapNotNull { it.total }.lastOrNull(), null, parts.any { it.truncated })
    }

    private fun recognizeOne(st: Settings, jpeg: ByteArray, page: Int, pages: Int): Recognized {
        val note = if (pages > 1) "ВАЖНО: в этом запросе одна страница листа (стр. $page из $pages). Выводи только строки таблицы, видимые на ней; " +
            "шапку, агентов и итоговый вес — только если они есть на этой странице, иначе оставь пустыми. " else ""
        val text = note + prompt(st.withClient) + " Ответ — компактный JSON без отступов и переносов строк, без рассуждений."
        val content = JSONArray().put(JSONObject().put("type", "text").put("text", text))
        val url = "data:image/jpeg;base64," + Base64.encodeToString(jpeg, Base64.NO_WRAP)
        content.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", url)))
        val body = JSONObject()
            .put("model", st.model.replace("{folder}", st.folder))
            .put("temperature", 0)
            .put("max_tokens", 12000)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val req = Request.Builder().url("https://llm.api.cloud.yandex.net/v1/chat/completions")
            .header("Authorization", "Api-Key " + st.apiKey)
            .header("x-folder-id", st.folder)
            .post(body.toString().toRequestBody(JSON)).build()
        http.newCall(req).execute().use { r ->
            val txt = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("Облако ответило ${r.code}: ${txt.take(300)}")
            val ch = JSONObject(txt).getJSONArray("choices").getJSONObject(0)
            val finish = ch.optString("finish_reason", "")
            val msg = ch.getJSONObject("message").optString("content", "")
            val rec = try { parse(msg, finish == "length") } catch (e: Exception) {
                error("Страница $page: ${e.message} (finish_reason=$finish, длина ответа ${msg.length})")
            }
            if (rec.truncated && rec.rows.isEmpty())
                error("Страница $page: ответ модели оборван (finish_reason=$finish)")
            return rec
        }
    }

    /** Достраивает закрывающие скобки у оборванного JSON, оставляя только целые элементы. */
    private fun repair(t: String): Pair<String, Boolean> {
        try { JSONObject(t); return t to false } catch (_: Exception) {}
        var inStr = false; var esc = false
        val stack = ArrayList<Char>(); var good = -1; var stackAtGood: List<Char> = emptyList()
        for (i in t.indices) {
            val c = t[i]
            if (inStr) { if (esc) esc = false else if (c == '\\') esc = true else if (c == '"') inStr = false; continue }
            when (c) {
                '"' -> inStr = true
                '{', '[' -> stack.add(c)
                '}', ']' -> { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex); good = i; stackAtGood = stack.toList() }
            }
        }
        if (good < 0) error("В ответе нет целых элементов JSON")
        val sb = StringBuilder(t.substring(0, good + 1))
        stackAtGood.asReversed().forEach { sb.append(if (it == '{') '}' else ']') }
        return sb.toString() to true
    }

    fun parse(text: String, cut: Boolean = false): Recognized {
        val a = text.indexOf('{'); val b = text.lastIndexOf('}')
        if (a < 0 || b < a) error("В ответе нет JSON: ${text.take(200)}")
        val (fixed, repaired) = repair(text.substring(a, b + 1))
        val j = JSONObject(fixed)
        val ag = j.opt("agents") ?: j.opt("agent")
        val agents = when (ag) {
            is JSONArray -> (0 until ag.length()).mapNotNull { parseAgent(ag.opt(it)) }
            null, JSONObject.NULL -> emptyList()
            else -> listOfNotNull(parseAgent(ag))
        }
        val arr = j.optJSONArray("rows") ?: JSONArray()
        val rows = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            fun g(k: String) = o.optString(k, "").let { if (it == "null") "" else it.trim() }
            val ag = g("агент").substringBefore('/').trim()
            Row(i, g("позывной"), g("вес").toD() ?: 0.0, g("факт"), g("расчет"),
                listOf(g("заметки"), g("сумма").let { s -> if (s.isBlank()) "" else "сумма $s" }).filter { it.isNotBlank() }.joinToString(" · "), ag, g("клиент"), g("адрес"), g("накладная"))
        }
        fun top(k: String) = j.optString(k, "").let { if (it == "null") "" else it.trim() }
        return Recognized(agents, rows, top("шапка"), top("итого_вес").toD(), null, repaired || cut)
    }

    private fun parseAgent(x: Any?): Agent? {
        if (x is JSONObject) {
            fun g(vararg k: String) = k.firstNotNullOfOrNull { x.optString(it, "").takeIf { s -> s.isNotBlank() && s != "null" } }?.trim().orEmpty()
            return Agent(g("номер", "num", "number"), g("имя", "name", "фио"), g("телефон", "phone"))
        }
        val s = x?.toString()?.trim().orEmpty()
        if (s.isEmpty() || s == "null") return null
        val num = Regex("^(?:[Ss][Vv])?\\d+").find(s)?.value.orEmpty()
        val rest = s.removePrefix(num)
        val phone = Regex("\\+?\\d[\\d\\s()\\-]{8,}\\d").find(rest)?.value.orEmpty()
        val name = rest.replace(phone, "").trim(' ', '.', ')', ',', '-', ':')
        return Agent(num, name, phone.trim())
    }

    /** Матрица расстояний (м) через OSRM table. */
    fun matrix(st: Settings, pts: List<Point>): Array<DoubleArray> {
        val coords = pts.joinToString(";") { "${it.lon},${it.lat}" }
        val req = Request.Builder().url("${st.osrm}/table/v1/driving/$coords?annotations=distance").build()
        http.newCall(req).execute().use { r ->
            val txt = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("OSRM ${r.code}: ${txt.take(200)}")
            val d = JSONObject(txt).getJSONArray("distances")
            return Array(pts.size) { i -> DoubleArray(pts.size) { j -> d.getJSONArray(i).optDouble(j, 1e9).let { v -> if (v.isNaN()) 1e9 else v } } }
        }
    }

    /** Координаты по адресу (OpenStreetMap Nominatim). */
    fun geocode(address: String): Pair<Double, Double>? {
        val req = Request.Builder()
            .url("https://nominatim.openstreetmap.org/search?format=json&limit=1&q=" + URLEncoder.encode(address, "UTF-8"))
            .header("User-Agent", "MarshrutApp/1.0").build()
        http.newCall(req).execute().use { r ->
            val a = JSONArray(r.body?.string().orEmpty())
            if (a.length() == 0) return null
            val o = a.getJSONObject(0)
            return o.getString("lat").toDouble() to o.getString("lon").toDouble()
        }
    }
}
