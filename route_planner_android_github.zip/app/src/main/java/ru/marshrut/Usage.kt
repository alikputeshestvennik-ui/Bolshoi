package ru.marshrut

import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Расход нейросети: запросы и токены из поля usage ответа Yandex AI Studio, переведённые в рубли.
 * input — все входящие токены (картинка и правила), из них cached — кешированные (дешевле);
 * reasoning — часть output, ушедшая на скрытые рассуждения модели.
 */
data class Meter(
    val sheets: Int = 0, val requests: Int = 0, val input: Long = 0, val cached: Long = 0,
    val output: Long = 0, val reasoning: Long = 0, val rub: Double = 0.0
) {
    operator fun plus(o: Meter) = Meter(sheets + o.sheets, requests + o.requests, input + o.input, cached + o.cached,
        output + o.output, reasoning + o.reasoning, rub + o.rub)

    fun json(): String = JSONObject().put("s", sheets).put("q", requests).put("i", input).put("c", cached)
        .put("o", output).put("r", reasoning).put("rub", rub).toString()

    companion object {
        fun of(s: String?): Meter = runCatching {
            val j = JSONObject(s ?: return Meter())
            Meter(j.optInt("s"), j.optInt("q"), j.optLong("i"), j.optLong("c"), j.optLong("o"), j.optLong("r"), j.optDouble("rub", 0.0))
        }.getOrDefault(Meter())

        /**
         * Цены Yandex AI Studio, ₽ за 1000 токенов, синхронный режим: вход, кешированные, выход.
         * Взяты из детализации Billing (октябрь 2026): Qwen 3.6 35B — 0,20 / 0,05 / 0,30; DeepSeek v4.1 Flash — 0,30 / 0,075 / 0,50.
         */
        private fun prices(model: String) =
            if (model.contains("deepseek", true)) Triple(0.30, 0.075, 0.50) else Triple(0.20, 0.05, 0.30)

        /** Один ответ нейросети → расход. */
        fun fromResponse(model: String, usage: JSONObject?): Meter {
            if (usage == null) return Meter(requests = 1)
            val input = usage.optLong("prompt_tokens")
            val cached = usage.optJSONObject("prompt_tokens_details")?.optLong("cached_tokens") ?: 0L
            val output = usage.optLong("completion_tokens")
            val reasoning = usage.optJSONObject("completion_tokens_details")?.optLong("reasoning_tokens") ?: 0L
            val (pIn, pCached, pOut) = prices(model)
            val rub = ((input - cached).coerceAtLeast(0) * pIn + cached * pCached + output * pOut) / 1000.0
            return Meter(0, 1, input, cached, output, reasoning, rub)
        }
    }
}

/** Накопленный расход в настройках телефона: последний лист, сегодня и текущий месяц. */
class UsageLog(private val sp: android.content.SharedPreferences) {
    private fun day() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun month() = day().take(7)

    val last: Meter get() = Meter.of(sp.getString("u_last", null))
    val today: Meter get() = if (sp.getString("u_day_k", "") == day()) Meter.of(sp.getString("u_day", null)) else Meter()
    val thisMonth: Meter get() = Meter.of(sp.getString("u_m_" + month(), null))

    /** Один распознанный лист со всеми его запросами, включая перечитывания и дочитывания. */
    fun add(m: Meter) {
        val sheet = m.copy(sheets = 1)
        sp.edit()
            .putString("u_last", sheet.json())
            .putString("u_day_k", day()).putString("u_day", (today + sheet).json())
            .putString("u_m_" + month(), (thisMonth + sheet).json())
            .apply()
    }
}
