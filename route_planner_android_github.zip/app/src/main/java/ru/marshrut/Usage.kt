package ru.marshrut

import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Расход нейросети: запросы и токены из поля usage ответа Yandex AI Studio, переведённые в рубли.
 * input — все входящие токены (картинка и правила), из них cached — кешированные (дешевле);
 * reasoning — часть output, ушедшая на скрытые рассуждения модели.
 */
data class Meter(
    val sheets: Int = 0, val requests: Int = 0, val input: Long = 0, val cached: Long = 0,
    val output: Long = 0, val reasoning: Long = 0, val rub: Double = 0.0
) {
    operator fun plus(o: Meter) = Meter(sheets + o.sheets, requests + o.requests, input + o.input, cached + o.cached,
        output + o.output, reasoning + o.reasoning, rub + o.rub)

    fun json(): String = JSONObject().put("s", sheets).put("q", requests).put("i", input).put("c", cached)
        .put("o", output).put("r", reasoning).put("rub", rub).toString()

    companion object {
        fun of(s: String?): Meter = runCatching {
            val j = JSONObject(s ?: return Meter())
            Meter(j.optInt("s"), j.optInt("q"), j.optLong("i"), j.optLong("c"), j.optLong("o"), j.optLong("r"), j.optDouble("rub", 0.0))
        }.getOrDefault(Meter())

        /**
         * Цены Yandex AI Studio, ₽ за 1000 токенов, синхронный режим: вход, кешированные, выход.
         * Взяты из детализации Billing (октябрь 2026): Qwen 3.6 35B — 0,20 / 0,05 / 0,30; DeepSeek v4.1 Flash — 0,30 / 0,075 / 0,50.
         */
        private fun prices(model: String) = when {
            model.startsWith(Settings.GPTUNNEL) -> (gptPrices.first ?: 0.0).let { Triple(it, it, gptPrices.second ?: 0.0) }
            model.contains("deepseek", true) -> Triple(0.30, 0.075, 0.50)
            else -> Triple(0.20, 0.05, 0.30)
        }
        /** Цены gptunnel (₽ за 1000 токенов: вход, выход) — из настроек, со страницы модели на gptunnel. */
        @Volatile var gptPrices: Pair<Double?, Double?> = null to null

        /** Один ответ нейросети → расход. */
        fun fromResponse(model: String, usage: JSONObject?): Meter {
            if (usage == null) return Meter(requests = 1)
            val input = usage.optLong("prompt_tokens")
            val cached = usage.optJSONObject("prompt_tokens_details")?.optLong("cached_tokens") ?: 0L
            val output = usage.optLong("completion_tokens")
            val reasoning = usage.optJSONObject("completion_tokens_details")?.optLong("reasoning_tokens") ?: 0L
            val (pIn, pCached, pOut) = prices(model)
            val rub = ((input - cached).coerceAtLeast(0) * pIn + cached * pCached + output * pOut) / 1000.0
            return Meter(0, 1, input, cached, output, reasoning, rub)
        }
    }
}

/** Накопленный расход в настройках телефона: последний лист, сегодня и текущий месяц. */
class UsageLog(private val sp: android.content.SharedPreferences) {
    private fun day() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun month() = day().take(7)

    val last: Meter get() = Meter.of(sp.getString("u_last", null))
    /** Разбивка последнего листа по запросам. */
    val lastLog: List<String> get() = sp.getString("u_last_log", "").orEmpty().split('\n').filter { it.isNotBlank() }
    val today: Meter get() = if (sp.getString("u_day_k", "") == day()) Meter.of(sp.getString("u_day", null)) else Meter()
    val thisMonth: Meter get() = Meter.of(sp.getString("u_m_" + month(), null))

    /** Расход по моделям за день: «Gemini» → Meter. */
    private fun dayByModel(d: String): Map<String, Meter> = runCatching {
        val j = JSONObject(sp.getString("u_dm_$d", null) ?: return emptyMap())
        j.keys().asSequence().associateWith { Meter.of(j.getString(it)) }
    }.getOrDefault(emptyMap())

    private fun days(n: Int): List<String> {
        val f = SimpleDateFormat("yyyy-MM-dd", Locale.US); val c = java.util.Calendar.getInstance()
        return (0 until n).map { if (it > 0) c.add(java.util.Calendar.DAY_OF_YEAR, -1); f.format(c.time) }
    }

    private fun sum(ds: List<String>): Map<String, Meter> {
        val out = LinkedHashMap<String, Meter>()
        ds.forEach { d -> dayByModel(d).forEach { (k, v) -> out[k] = (out[k] ?: Meter()) + v } }
        return out
    }

    /** Сегодня по моделям. */
    val todayByModel: Map<String, Meter> get() = dayByModel(day())
    /** Последние 7 дней по моделям. */
    val weekByModel: Map<String, Meter> get() = sum(days(7))
    /** Текущий месяц по моделям. */
    val monthByModel: Map<String, Meter> get() = sum(days(31).filter { it.startsWith(month()) })
    /** Модель последнего листа. */
    val lastModel: String get() = sp.getString("u_last_model", "").orEmpty()

    /** Один распознанный лист со всеми его запросами, включая перечитывания и дочитывания. */
    fun add(m: Meter, log: List<String> = emptyList(), model: String = "") {
        val sheet = m.copy(sheets = 1)
        val byModel = JSONObject(); dayByModel(day()).forEach { (k, v) -> byModel.put(k, v.json()) }
        if (model.isNotBlank()) byModel.put(model, ((dayByModel(day())[model] ?: Meter()) + sheet).json())
        sp.edit()
            .putString("u_dm_" + day(), byModel.toString())
            .putString("u_last_model", model)
            .putString("u_last_log", log.joinToString("\n"))
            .putString("u_last", sheet.json())
            .putString("u_day_k", day()).putString("u_day", (today + sheet).json())
            .putString("u_m_" + month(), (thisMonth + sheet).json())
            .apply()
    }
}
