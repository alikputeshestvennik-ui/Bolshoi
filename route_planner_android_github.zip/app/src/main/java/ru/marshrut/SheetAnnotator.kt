package ru.marshrut

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

/**
 * Одна строка листа для разметки.
 * invoice  — номер накладной как на листе («АСП-191490», «возврат 0092204»)
 * order    — номер точки в порядке объезда
 * fact     — «Факт», если наличные есть
 * isReturn — строка-возврат
 */
data class SheetRow(val invoice: String, val order: Int, val fact: String? = null, val isReturn: Boolean = false)

/**
 * Пометки «от руки» на фото листа, как водитель ставит их ручкой: номер точки в кружке справа от строк,
 * фигурная скобка, если у точки несколько накладных, обводка «Факта», возвратов и итога к сдаче.
 * Строки ищет ML Kit на телефоне — бесплатно и без интернета. Возвращает новую картинку.
 */
class SheetAnnotator(context: Context) {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    /** Рукописный Caveat (кладётся в assets при сборке), без него — курсив с засечками. */
    private val hand: Typeface = runCatching {
        Typeface.Builder(context.assets, "fonts/caveat.ttf").setFontVariationSettings("'wght' 700").build()
            ?: error("no font")
    }.getOrElse { Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC) }

    private val blue = Color.rgb(20, 40, 175)
    private val red = Color.rgb(215, 25, 25)
    private var rnd = Random(7)

    private data class Word(val digits: String, val box: Rect)

    /**
     * @param photo     страница листа (уже выровненная перед распознаванием; повёрнутую тоже поймёт)
     * @param rows      все строки маршрута — тех, что не на этой странице, просто не найдёт
     * @param totalFact итог «Факт» к сдаче, например "34103.20"
     * Вызывать не в главном потоке.
     */
    fun annotate(photo: Bitmap, rows: List<SheetRow>, totalFact: String? = null): Bitmap {
        rnd = Random(photo.width * 31 + photo.height)

        // 1. Страница обычно уже стоит прямо; другие повороты пробуем, только если накладные не нашлись
        var bestBmp = photo
        var best = ocr(photo)
        var bestHits = rows.count { findInvoice(best.words, it.invoice) != null }
        if (bestHits == 0) for (deg in listOf(270, 90, 180)) {
            val bmp = rotate(photo, deg)
            val o = ocr(bmp)
            val hits = rows.count { findInvoice(o.words, it.invoice) != null }
            if (hits > bestHits) { bestHits = hits; bestBmp = bmp; best = o }
        }
        // 2. Лист снят с наклоном — выпрямляем, чтобы строки шли ровно и пометки легли к своим строкам
        if (abs(best.skew) > 0.6f) {
            val bmp = rotateFree(bestBmp, -best.skew)
            val o = ocr(bmp)
            if (rows.count { findInvoice(o.words, it.invoice) != null } >= bestHits) { bestBmp = bmp; best = o }
        }
        val words = best.words

        data class Hit(val row: SheetRow, val box: Rect)
        val hits = rows.mapNotNull { r -> findInvoice(words, r.invoice)?.let { Hit(r, it.box) } }
        if (hits.isEmpty()) return bestBmp

        val rowH = hits.map { it.box.height() }.sorted()[hits.size / 2].toFloat()
        val r = rowH * 0.85f                                   // радиус кружка с номером
        val stroke = max(2.5f, rowH * 0.12f)

        // Границы таблицы — по тексту на листе, без крайних выбросов
        fun pct(v: List<Int>, q: Double) = v.sorted()[(v.size * q).toInt().coerceIn(0, v.size - 1)].toFloat()
        val tableRight = pct(words.map { it.box.right }, 0.97)
        val tableLeft = pct(words.map { it.box.left }, 0.02)
        val tableTop = pct(words.map { it.box.top }, 0.02)
        val tableBottom = pct(words.map { it.box.bottom }, 0.98)
        val markW = rowH * 1.3f + r * 3.4f

        // Справа от таблицы часто нет места — добавляем белое поле под номера
        val need = (tableRight + markW - bestBmp.width).coerceAtLeast(0f).toInt()
        val out = Bitmap.createBitmap(bestBmp.width + need, bestBmp.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.WHITE)
        c.drawBitmap(bestBmp, 0f, 0f, null)

        // 3. Обводим «Факт» (самое правое совпадение в строке — левее стоит такая же «Сумма»)
        for (h in hits) {
            val fact = h.row.fact ?: continue
            val box = findInRow(words, fact, h.box, rowH) ?: continue
            wobblyEllipse(c, RectF(box).padded(rowH * 0.5f, rowH * 0.3f), red, stroke)
        }

        // 4. Возвраты: обводка накладной и подпись
        for (h in hits.filter { it.row.isReturn }) {
            val rf = RectF(h.box).padded(rowH * 0.8f, rowH * 0.35f)
            wobblyEllipse(c, rf, red, stroke * 1.2f)
            handText(c, "ВОЗВРАТ!", rf.left, rf.top - rowH * 0.2f, rowH * 1.1f, red)
        }

        // 5. Номера точек у правого края своих строк; несколько строк одной точки — фигурная скобка
        for ((order, group) in hits.groupBy { it.row.order }) {
            val top = group.minOf { it.box.top }.toFloat()
            val bottom = group.maxOf { it.box.bottom }.toFloat()
            val cy = (top + bottom) / 2f
            val localRight = words.filter { it.box.exactCenterY() in top..bottom && it.box.right <= tableRight + rowH }
                .maxOfOrNull { it.box.right }?.toFloat() ?: tableRight
            val braceX = localRight + rowH * 0.4f
            var numX = braceX + r * 1.3f
            if (group.size > 1) {
                curlyBrace(c, braceX, top, bottom, rowH * 0.9f, blue, stroke)
                numX = braceX + rowH * 0.9f + r * 1.2f
            }
            numX = numX.coerceAtMost(out.width - r * 1.1f)
            numberInCircle(c, order.toString(), numX, cy, r, blue, stroke)
        }

        // 6. Итог «Факт» к сдаче — самое нижнее совпадение на странице
        totalFact?.let { t ->
            val keys = digitKeys(t)
            words.filter { it.digits in keys }.maxByOrNull { it.box.bottom }?.let {
                wobblyEllipse(c, RectF(it.box).padded(rowH * 0.5f, rowH * 0.3f), red, stroke)
            }
        }

        // 7. Обрезаем по таблице с пометками: на телефоне лист займёт весь экран, а не уголок фото
        val m = rowH * 2f
        val crop = Rect(
            (tableLeft - m).toInt().coerceIn(0, out.width - 1),
            (tableTop - m * 2).toInt().coerceIn(0, out.height - 1),
            (tableRight + markW + m).toInt().coerceIn(1, out.width),
            (tableBottom + m).toInt().coerceIn(1, out.height)
        )
        if (crop.width() < out.width * 0.3f || crop.height() < out.height * 0.2f) return out
        return Bitmap.createBitmap(out, crop.left, crop.top, crop.width(), crop.height())
    }

    // ---------- распознавание ----------

    /** Слова с цифрами и наклон строк (градусы, по часовой). */
    private class Ocr(val words: List<Word>, val skew: Float)

    /**
     * Читаем лист по четвертинкам, каждую увеличиваем вдвое: на фото издалека цифры мелкие,
     * и целиком ML Kit их не видит. Края четвертинок заходят друг на друга, повторы убираем.
     */
    private fun ocr(b: Bitmap): Ocr {
        val all = ArrayList<Word>()
        val angles = ArrayList<Pair<Float, Float>>()
        val ov = 0.12f
        val tw = (b.width * (0.5f + ov)).toInt(); val th = (b.height * (0.5f + ov)).toInt()
        for ((x0, y0) in listOf(0 to 0, b.width - tw to 0, 0 to b.height - th, b.width - tw to b.height - th)) {
            val tile = Bitmap.createBitmap(b, x0, y0, tw, th)
            val k = (2200f / max(tw, th)).coerceIn(1f, 2f)
            val big = if (k > 1f) Bitmap.createScaledBitmap(tile, (tw * k).toInt(), (th * k).toInt(), true) else tile
            val text = runCatching { Tasks.await(recognizer.process(InputImage.fromBitmap(big, 0)), 20, TimeUnit.SECONDS) }.getOrNull() ?: continue
            for (line in text.textBlocks.flatMap { it.lines }) {
                line.cornerPoints?.takeIf { it.size >= 2 }?.let { cp ->
                    val dx = (cp[1].x - cp[0].x).toFloat(); val dy = (cp[1].y - cp[0].y).toFloat()
                    val len = kotlin.math.hypot(dx, dy)
                    if (len > 40) angles.add(Math.toDegrees(kotlin.math.atan2(dy, dx).toDouble()).toFloat() to len)
                }
                for (e in line.elements) {
                    val bb = e.boundingBox ?: continue
                    val d = e.text.filter(Char::isDigit)
                    if (d.isEmpty()) continue
                    val box = Rect((bb.left / k).toInt() + x0, (bb.top / k).toInt() + y0, (bb.right / k).toInt() + x0, (bb.bottom / k).toInt() + y0)
                    // Слово, разрезанное краем четвертинки, — неполное: берём его из соседней
                    val cut = (x0 > 0 && box.left <= x0 + 2) || (y0 > 0 && box.top <= y0 + 2) ||
                        (x0 + tw < b.width && box.right >= x0 + tw - 2) || (y0 + th < b.height && box.bottom >= y0 + th - 2)
                    if (!cut) all.add(Word(d, box))
                }
            }
        }
        val words = ArrayList<Word>()
        for (w in all) if (words.none { it.digits == w.digits && abs(it.box.centerX() - w.box.centerX()) < w.box.height() && abs(it.box.centerY() - w.box.centerY()) < w.box.height() }) words.add(w)
        // Наклон — взвешенная медиана углов почти горизонтальных строк
        val near = angles.filter { abs(it.first) < 15f }.sortedBy { it.first }
        var acc = 0f; val half = near.sumOf { it.second.toDouble() }.toFloat() / 2f
        val skew = near.firstOrNull { acc += it.second; acc >= half }?.first ?: 0f
        return Ocr(words, skew)
    }

    /** Накладная по цифрам: "АСП-191490" → "191490" (буквы ML Kit может прочитать криво). */
    private fun findInvoice(words: List<Word>, invoice: String): Word? {
        val key = Regex("\\d+").findAll(invoice).map { it.value }.maxByOrNull { it.length }.orEmpty()
        if (key.length < 5) return null
        return words.firstOrNull { it.digits == key } ?: words.firstOrNull { it.digits.endsWith(key) }
    }

    /** «4679» на листе может стоять как «4679,00»: ищем оба варианта. */
    private fun digitKeys(v: String): Set<String> {
        val d = v.filter(Char::isDigit)
        val n = v.toD()
        return setOfNotNull(d, n?.let { String.format(java.util.Locale.US, "%.2f", it).filter(Char::isDigit) })
    }

    /** Число в той же строке правее накладной; самое правое — это «Факт», а не «Сумма». */
    private fun findInRow(words: List<Word>, value: String, rowBox: Rect, rowH: Float): Rect? {
        val keys = digitKeys(value)
        val cy = rowBox.exactCenterY()
        return words.filter {
            it.digits in keys && it.box.left > rowBox.right && abs(it.box.exactCenterY() - cy) < rowH * 0.9f
        }.maxByOrNull { it.box.left }?.box
    }

    private fun rotate(b: Bitmap, deg: Int): Bitmap =
        Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg.toFloat()) }, true)

    /** Поворот на небольшой угол вокруг центра, углы заливаем белым. */
    private fun rotateFree(b: Bitmap, deg: Float): Bitmap {
        val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.WHITE)
        c.rotate(deg, b.width / 2f, b.height / 2f)
        c.drawBitmap(b, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        return out
    }

    // ---------- «рукописная» отрисовка ----------

    private fun pen(color: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color; style = Paint.Style.STROKE; strokeWidth = w
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; alpha = 225
    }

    private fun rand(a: Float, b: Float) = a + rnd.nextFloat() * (b - a)

    /** Кривой овал «от руки»: неровный край, наклон, заход линии за начало. */
    private fun wobblyEllipse(c: Canvas, rf: RectF, color: Int, w: Float) {
        val cx = rf.centerX(); val cy = rf.centerY()
        val rx = rf.width() / 2f; val ry = rf.height() / 2f
        val phase = rand(0f, 6.28f); val tilt = rand(-0.06f, 0.06f); val over = rand(0.15f, 0.35f)
        val n = 80
        val p = Path()
        for (i in 0..n) {
            val t = phase + (2 * Math.PI.toFloat() + over) * i / n
            val k = 1f + 0.05f * sin(3 * t + phase) + rand(-0.01f, 0.01f) + 0.04f * i / n
            val x = rx * k * cos(t); val y = ry * k * sin(t)
            val xr = x * cos(tilt) - y * sin(tilt); val yr = x * sin(tilt) + y * cos(tilt)
            if (i == 0) p.moveTo(cx + xr, cy + yr) else p.lineTo(cx + xr, cy + yr)
        }
        c.drawPath(p, pen(color, w))
    }

    /** Текст по буквам: каждая чуть повёрнута и сдвинута. */
    private fun handText(c: Canvas, text: String, x: Float, y: Float, size: Float, color: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; typeface = hand; textSize = size; alpha = 235 }
        var cx = x
        for (ch in text) {
            val s = ch.toString()
            val w = paint.measureText(s)
            c.save()
            c.rotate(rand(-6f, 6f), cx + w / 2, y)
            c.drawText(s, cx, y + rand(-size * 0.04f, size * 0.04f), paint)
            c.restore()
            cx += w * rand(0.97f, 1.03f)
        }
    }

    private fun numberInCircle(c: Canvas, s: String, cx: Float, cy: Float, r: Float, color: Int, w: Float) {
        val size = r * 1.35f
        val paint = Paint().apply { typeface = hand; textSize = size }
        val tw = paint.measureText(s)
        handText(c, s, cx - tw / 2f, cy + size * 0.35f, size, color)
        val rx = max(r, tw / 2f + r * 0.45f)
        wobblyEllipse(c, RectF(cx - rx, cy - r, cx + rx, cy + r), color, w)
    }

    /** Фигурная скобка «}» от top до bottom. */
    private fun curlyBrace(c: Canvas, x: Float, top: Float, bottom: Float, w: Float, color: Int, sw: Float) {
        val mid = (top + bottom) / 2f
        val j = { rand(-w * 0.08f, w * 0.08f) }
        val p = Path().apply {
            moveTo(x, top)
            cubicTo(x + w * 0.55f + j(), top, x + w * 0.45f + j(), mid, x + w, mid)
            cubicTo(x + w * 0.45f + j(), mid, x + w * 0.55f + j(), bottom, x, bottom)
        }
        c.drawPath(p, pen(color, sw))
    }

    private fun RectF.padded(dx: Float, dy: Float) = RectF(left - dx, top - dy, right + dx, bottom + dy)
}
