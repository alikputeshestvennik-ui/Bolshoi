package ru.marshrut

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

/**
 * Одна строка листа для разметки.
 * invoice  — номер накладной как на листе («АСП-191490», «возврат 0092204»)
 * order    — номер точки в порядке объезда
 * fact     — «Факт», если наличные есть
 * isReturn — строка-возврат
 */
data class SheetRow(val invoice: String, val order: Int, val fact: String? = null, val isReturn: Boolean = false, val weight: Double = 0.0)

/**
 * Пометки «от руки» на фото листа, как водитель ставит их ручкой: номер точки в кружке справа от строк,
 * фигурная скобка, если у точки несколько накладных подряд, общий вес точки, обводка «Факта», возвратов
 * и итога к сдаче. Части одной точки, разнесённые по листу, соединены линией, которая обходит
 * другие пометки и перескакивает через чужие линии; продолжение на другой странице — линия к краю листа.
 * Строки ищет ML Kit на телефоне — бесплатно и без интернета.
 */
class SheetAnnotator(context: Context) {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    /** Рукописный Caveat (кладётся в assets при сборке), без него — курсив с засечками. */
    private val hand: Typeface = runCatching {
        Typeface.Builder(context.assets, "fonts/caveat.ttf").setFontVariationSettings("'wght' 700").build()
            ?: error("no font")
    }.getOrElse { Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC) }

    private val blue = Color.rgb(20, 40, 175)
    private val red = Color.rgb(215, 25, 25)
    private var rnd = Random(7)

    class Word(val digits: String, val box: Rect)

    /** Страница, прочитанная и выровненная: картинка и найденные на ней числа. */
    class Page(val bmp: Bitmap, val words: List<Word>)

    /**
     * Шаг 1: читает страницу. Обычно она уже стоит прямо; другие повороты пробуем, только если
     * накладные не нашлись. Наклон листа выпрямляем. Вызывать не в главном потоке.
     */
    fun prepare(photo: Bitmap, rows: List<SheetRow>): Page {
        var bestBmp = photo
        var best = ocr(photo)
        var bestHits = rows.count { findInvoice(best.words, it.invoice) != null }
        if (bestHits == 0) for (deg in listOf(270, 90, 180)) {
            val bmp = rotate(photo, deg)
            val o = ocr(bmp)
            val hits = rows.count { findInvoice(o.words, it.invoice) != null }
            if (hits > bestHits) { bestHits = hits; bestBmp = bmp; best = o }
        }
        if (abs(best.skew) > 0.6f) {
            val bmp = rotateFree(bestBmp, -best.skew)
            val o = ocr(bmp)
            if (rows.count { findInvoice(o.words, it.invoice) != null } >= bestHits) { bestBmp = bmp; best = o }
        }
        return Page(bestBmp, best.words)
    }

    /** Номера точек, строки которых нашлись на странице. */
    fun ordersOn(page: Page, rows: List<SheetRow>): Set<Int> =
        rows.filter { findInvoice(page.words, it.invoice) != null }.map { it.order }.toSet()

    private class Hit(val row: SheetRow, val box: Rect)
    private class Circle(val x: Float, val y: Float, val rad: Float)

    /**
     * Шаг 2: рисует пометки.
     * @param totalFact итог «Факт» к сдаче, например "34103.20"
     * @param weights   общий вес точки (по номеру), пишется у точек из нескольких строк
     * @param up        точки, у которых есть строки на предыдущих страницах
     * @param down      точки, у которых есть строки на следующих страницах
     */
    fun draw(page: Page, rows: List<SheetRow>, totalFact: String?, weights: Map<Int, Double>, up: Set<Int>, down: Set<Int>): Bitmap {
        val src = page.bmp
        val words = page.words
        rnd = Random(src.width * 31 + src.height)
        val hits = rows.mapNotNull { r -> findInvoice(words, r.invoice)?.let { Hit(r, it.box) } }
        if (hits.isEmpty()) return src
        val rowsPerStop = rows.groupingBy { it.order }.eachCount()

        val rowH = hits.map { it.box.height() }.sorted()[hits.size / 2].toFloat()
        val r = rowH * 1.15f                                   // радиус кружка с номером
        val stroke = max(3f, rowH * 0.15f)
        val small = rowH * 1.0f                                // размер подписей веса и возврата

        // Границы таблицы — по тексту на листе, без крайних выбросов
        fun pct(v: List<Int>, q: Double) = v.sorted()[(v.size * q).toInt().coerceIn(0, v.size - 1)].toFloat()
        val tableRight = pct(words.map { it.box.right }, 0.97)
        val tableLeft = pct(words.map { it.box.left }, 0.02)
        val tableTop = pct(words.map { it.box.top }, 0.02)
        val tableBottom = pct(words.map { it.box.bottom }, 0.98)
        val cropTop = (tableTop - rowH * 4f).coerceAtLeast(0f)
        val cropBottom = (tableBottom + rowH * 2f).coerceAtMost(src.height.toFloat())

        val textPaint = Paint().apply { typeface = hand; textSize = small }
        fun weightText(order: Int): String? {
            if ((rowsPerStop[order] ?: 0) < 2) return null
            val w = weights[order] ?: return null
            if (w <= 0) return null
            val t = if (w >= 100) String.format(java.util.Locale("ru"), "%.0f", w) else String.format(java.util.Locale("ru"), "%.1f", w).removeSuffix(",0")
            return "$t кг"
        }

        // Строки идут подряд одной точкой — один кусок со скобкой
        val runs = ArrayList<MutableList<Hit>>()
        for (h in hits.sortedBy { it.box.exactCenterY() }) {
            val last = runs.lastOrNull()
            if (last != null && last.last().row.order == h.row.order) last.add(h) else runs.add(mutableListOf(h))
        }
        class Run(val part: List<Hit>) {
            val order = part.first().row.order
            val top = part.minOf { it.box.top }.toFloat()
            val bottom = part.maxOf { it.box.bottom }.toFloat()
            val cy = (top + bottom) / 2f
            val right = words.filter { it.box.exactCenterY() in top..bottom && it.box.right <= tableRight + rowH }
                .maxOfOrNull { it.box.right }?.toFloat() ?: tableRight
            val braceX = right + rowH * 0.4f
            /** Откуда выходит линия: остриё скобки или конец строки. */
            val anchorX = braceX + if (part.size > 1) rowH * 0.9f else 0f
        }
        val allRuns = runs.map { Run(it) }
        val byOrder = allRuns.groupBy { it.order }
        // Точка «разнесена»: несколько кусков на странице или продолжение на другой странице
        val linked = byOrder.filter { (o, rs) -> rs.size > 1 || o in up || o in down }.keys

        // --- Раскладка: номера обычных точек у своих строк (с весом и «возвратом» справа) ---
        class Label(val run: Run, val x: Float, val lines: List<Pair<String, Int>>)
        val labels = ArrayList<Label>()
        val boxes = ArrayList<RectF>()
        for (run in allRuns.filter { it.order !in linked }) {
            val lines = listOfNotNull(if (run.part.any { it.row.isReturn }) "возврат" to red else null)
            val tw = lines.maxOfOrNull { textPaint.measureText(it.first) } ?: 0f
            var x = run.anchorX + r * 1.3f
            fun box(x: Float) = RectF(x - r, run.cy - r, x + r + (if (tw > 0) r * 0.3f + tw else 0f), run.cy + r)
            while (boxes.any { RectF.intersects(it, box(x)) }) x += r * 2.4f
            boxes.add(box(x)); labels.add(Label(run, x, lines))
        }

        // --- Полосы для линий разнесённых точек: правее всех номеров; короткие ближе к таблице ---
        val laneX0 = max(boxes.maxOfOrNull { it.right } ?: 0f, allRuns.maxOf { it.anchorX } + r * 1.3f) + r * 1.6f
        val laneStep = r * 2.9f
        class Span(val order: Int, val top: Float, val bottom: Float, var lane: Int = 0)
        val spans = linked.map { o ->
            val rs = byOrder.getValue(o)
            Span(o, if (o in up) cropTop else rs.minOf { it.cy }, if (o in down) cropBottom else rs.maxOf { it.cy })
        }.sortedBy { it.bottom - it.top }
        val laneBusy = ArrayList<MutableList<Span>>()
        for (sp in spans) {
            val pad = r * 2.4f
            var i = laneBusy.indexOfFirst { l -> l.none { sp.top < it.bottom + pad && it.top < sp.bottom + pad } }
            if (i < 0) { laneBusy.add(mutableListOf()); i = laneBusy.lastIndex }
            laneBusy[i].add(sp); sp.lane = i
        }
        fun laneX(i: Int) = laneX0 + i * laneStep
        // Кружок разнесённой точки — на её линии, у самого крупного куска
        val laneCircles = spans.associate { sp ->
            val main = byOrder.getValue(sp.order).maxBy { it.part.size * 1000 - abs(it.cy - (sp.top + sp.bottom) / 2f) }
            sp.order to Circle(laneX(sp.lane), main.cy, r)
        }

        val width = max(src.width.toFloat(), (if (spans.isEmpty()) boxes.maxOfOrNull { it.right } ?: 0f else laneX(laneBusy.lastIndex) + r * 1.6f) + rowH)
        val out = Bitmap.createBitmap(width.toInt(), src.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.WHITE)
        c.drawBitmap(src, 0f, 0f, null)

        // 1. Обводим «Факт» (самое правое совпадение в строке — левее стоит такая же «Сумма»)
        for (h in hits) {
            val fact = h.row.fact ?: continue
            val box = findInRow(words, fact, h.box, rowH) ?: continue
            wobblyEllipse(c, RectF(box).padded(rowH * 0.5f, rowH * 0.3f), red, stroke)
        }
        // 2. Возвраты: обводка накладной
        for (h in hits.filter { it.row.isReturn }) wobblyEllipse(c, RectF(h.box).padded(rowH * 0.8f, rowH * 0.35f), red, stroke * 1.2f)

        // 3. Скобки у кусков из нескольких строк
        for (run in allRuns) if (run.part.size > 1) curlyBrace(c, run.braceX, run.top, run.bottom, rowH * 0.9f, blue, stroke)

        // 4. Линии разнесённых точек: вдоль полосы и от каждого куска к ней
        // Препятствия для горизонталей: кружки обычных точек с подписями и кружки на других полосах
        val obstacles = boxes.map { RectF(it).padded(rowH * 0.2f, rowH * 0.2f) } +
            laneCircles.values.map { RectF(it.x - r, it.y - r, it.x + r, it.y + r).padded(rowH * 0.3f, rowH * 0.3f) }
        val hop = rowH * 0.55f
        for (sp in spans) {
            val lx = laneX(sp.lane)
            // Вертикаль; через неё перескакивают горизонтали других точек
            val pts = listOf(lx to sp.top, lx to sp.bottom)
            handLine(c, pts, blue, stroke)
            if (sp.order in up) arrow(c, lx, sp.top, -1f, rowH, blue, stroke)
            if (sp.order in down) arrow(c, lx, sp.bottom, 1f, rowH, blue, stroke)
            // Горизонтали от кусков к полосе: обходят кружки, перескакивают через полосы ближе к таблице
            for (run in byOrder.getValue(sp.order)) {
                val y = run.cy
                val x1 = run.anchorX + rowH * 0.2f
                val h = ArrayList<Pair<Float, Float>>()
                h.add(x1 to y)
                val events = ArrayList<Pair<Float, () -> Unit>>()
                for (o in obstacles) if (o.left > x1 && o.right < lx && y > o.top && y < o.bottom) {
                    events.add(o.left to {
                        val g = rowH * 0.4f
                        val above = y <= o.centerY()
                        val yy = if (above) o.top - g else o.bottom + g
                        h.add(o.left - g to y); h.add(o.left to yy); h.add(o.right to yy); h.add(o.right + g to y)
                    })
                }
                for (other in spans) if (other !== sp && other.lane < sp.lane && y > other.top && y < other.bottom) {
                    val ox = laneX(other.lane)
                    if (obstacles.any { ox in it.left..it.right && y > it.top && y < it.bottom }) continue
                    events.add(ox to { h.add(ox - hop to y); h.add(ox - hop * 0.6f to y - hop * 0.8f); h.add(ox to y - hop); h.add(ox + hop * 0.6f to y - hop * 0.8f); h.add(ox + hop to y) })
                }
                events.sortedBy { it.first }.forEach { it.second() }
                h.add(lx to y)
                handLine(c, h, blue, stroke)
            }
        }

        // 5. Кружки с номерами, вес и «возврат»
        for (l in labels) {
            numberInCircle(c, l.run.order.toString(), l.x, l.run.cy, r, blue, stroke)
            val n = l.lines.size
            l.lines.forEachIndexed { i, (t, col) ->
                val y = l.run.cy + small * 0.35f + (i - (n - 1) / 2f) * small * 1.05f
                handText(c, t, l.x + r * 1.3f, y, small, col)
            }
        }
        for (sp in spans) {
            val ci = laneCircles.getValue(sp.order)
            numberInCircle(c, sp.order.toString(), ci.x, ci.y, r, blue, stroke)
            val under = listOfNotNull(
                if (byOrder.getValue(sp.order).any { run -> run.part.any { it.row.isReturn } }) "возврат" to red else null)
            under.forEachIndexed { i, (t, col) ->
                val tw = textPaint.measureText(t)
                val y = ci.y + r + small * (1.0f + i * 1.05f)
                c.drawRect(ci.x - tw / 2f - rowH * 0.15f, y - small * 0.8f, ci.x + tw / 2f + rowH * 0.15f, y + small * 0.25f, Paint().apply { color = Color.WHITE })
                handText(c, t, ci.x - tw / 2f, y, small, col)
            }
        }

        // 6. Общий вес точки из нескольких строк — справа от колонки «Вес», со скобкой по её строкам.
        // Колонку находим по весам строк; у разнесённой точки вес пишем один раз — у самой крупной части.
        val weightBox = HashMap<Hit, Rect>()
        for (h in hits) {
            val keys = weightKeys(h.row.weight)
            if (keys.isEmpty()) continue
            words.filter { it.digits in keys && it.box.left > h.box.right && abs(it.box.exactCenterY() - h.box.exactCenterY()) < rowH * 0.9f }
                .minByOrNull { it.box.left }?.let { weightBox[h] = it.box }
        }
        if (weightBox.isNotEmpty()) {
            val colRight = weightBox.values.map { it.right }.sorted()[weightBox.size / 2].toFloat()
            val wPaint = Paint().apply { typeface = hand; textSize = rowH * 0.95f }
            for ((order, rs) in byOrder) {
                val text = weightText(order) ?: continue
                val main = rs.maxBy { it.part.size * 1000 - it.top / 1000f }
                for (run in rs) {
                    val x = colRight + rowH * 0.15f
                    if (run.part.size > 1) curlyBrace(c, x, run.top + rowH * 0.2f, run.bottom - rowH * 0.2f, rowH * 0.5f, blue, stroke * 0.8f)
                    if (run !== main) continue
                    val tx = x + rowH * (if (run.part.size > 1) 0.65f else 0.2f)
                    val tw = wPaint.measureText(text)
                    c.drawRoundRect(RectF(tx - rowH * 0.1f, run.cy - rowH * 0.6f, tx + tw + rowH * 0.15f, run.cy + rowH * 0.55f), rowH * 0.3f, rowH * 0.3f,
                        Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; alpha = 235 })
                    handText(c, text, tx, run.cy + rowH * 0.35f, rowH * 0.95f, blue)
                }
            }
        }

        // 7. «Всего к сдаче» (правее всех совпадений внизу) — жирно и дважды; итог в колонке «Факт» — один раз
        totalFact?.let { t ->
            val keys = digitKeys(t)
            val lastRow = hits.maxOf { it.box.bottom }
            val matches = words.filter { it.digits in keys && it.box.top > lastRow - rowH * 0.3f }
            val total = matches.maxByOrNull { it.box.right }
            total?.let {
                wobblyEllipse(c, RectF(it.box).padded(rowH * 0.55f, rowH * 0.35f), red, stroke * 1.8f)
                wobblyEllipse(c, RectF(it.box).padded(rowH * 0.85f, rowH * 0.6f), red, stroke * 1.8f)
            }
            matches.filter { it !== total }.forEach {
                wobblyEllipse(c, RectF(it.box).padded(rowH * 0.5f, rowH * 0.3f), red, stroke)
            }
        }

        // 8. Обрезаем по таблице с пометками: на телефоне лист займёт весь экран, а не уголок фото
        val m = rowH * 2f
        val crop = Rect(
            (tableLeft - m).toInt().coerceIn(0, out.width - 1),
            cropTop.toInt().coerceIn(0, out.height - 1),
            out.width,
            cropBottom.toInt().coerceIn(1, out.height)
        )
        if (crop.width() < out.width * 0.3f || crop.height() < out.height * 0.2f) return out
        return Bitmap.createBitmap(out, crop.left, crop.top, crop.width(), crop.height())
    }

    /** Линия «от руки» через точки: чуть дрожит, углы скруглены. */
    private fun handLine(c: Canvas, pts: List<Pair<Float, Float>>, color: Int, w: Float) {
        if (pts.size < 2) return
        val p = Path()
        p.moveTo(pts[0].first, pts[0].second)
        for (i in 1 until pts.size) {
            val (x0, y0) = pts[i - 1]; val (x1, y1) = pts[i]
            val len = kotlin.math.hypot(x1 - x0, y1 - y0)
            val steps = (len / (w * 12f)).toInt().coerceAtLeast(1)
            for (k in 1..steps) {
                val t = k.toFloat() / steps
                val j = if (k == steps) 0f else rand(-w * 0.35f, w * 0.35f)
                // дрожь поперёк направления
                val nx = if (len > 0) -(y1 - y0) / len else 0f; val ny = if (len > 0) (x1 - x0) / len else 0f
                p.lineTo(x0 + (x1 - x0) * t + nx * j, y0 + (y1 - y0) * t + ny * j)
            }
        }
        c.drawPath(p, pen(color, w).apply { pathEffect = android.graphics.CornerPathEffect(w * 3f) })
    }

    /** Стрелка на конце линии: dir −1 — вверх (предыдущая страница), +1 — вниз (следующая). */
    private fun arrow(c: Canvas, x: Float, y: Float, dir: Float, size: Float, color: Int, w: Float) {
        val p = Path().apply {
            moveTo(x - size * 0.6f, y - dir * size * 0.9f); lineTo(x, y); lineTo(x + size * 0.6f, y - dir * size * 0.9f)
        }
        c.drawPath(p, pen(color, w))
    }

    // ---------- распознавание ----------

    /** Слова с цифрами и наклон строк (градусы, по часовой). */
    private class Ocr(val words: List<Word>, val skew: Float)

    /**
     * Читаем лист по четвертинкам, каждую увеличиваем вдвое: на фото издалека цифры мелкие,
     * и целиком ML Kit их не видит. Края четвертинок заходят друг на друга, повторы убираем.
     */
    private fun ocr(b: Bitmap): Ocr {
        val all = ArrayList<Word>()
        val angles = ArrayList<Pair<Float, Float>>()
        val ov = 0.12f
        val tw = (b.width * (0.5f + ov)).toInt(); val th = (b.height * (0.5f + ov)).toInt()
        for ((x0, y0) in listOf(0 to 0, b.width - tw to 0, 0 to b.height - th, b.width - tw to b.height - th)) {
            val tile = Bitmap.createBitmap(b, x0, y0, tw, th)
            val k = (2200f / max(tw, th)).coerceIn(1f, 2f)
            val big = if (k > 1f) Bitmap.createScaledBitmap(tile, (tw * k).toInt(), (th * k).toInt(), true) else tile
            val text = runCatching { Tasks.await(recognizer.process(InputImage.fromBitmap(big, 0)), 20, TimeUnit.SECONDS) }.getOrNull() ?: continue
            for (line in text.textBlocks.flatMap { it.lines }) {
                line.cornerPoints?.takeIf { it.size >= 2 }?.let { cp ->
                    val dx = (cp[1].x - cp[0].x).toFloat(); val dy = (cp[1].y - cp[0].y).toFloat()
                    val len = kotlin.math.hypot(dx, dy)
                    if (len > 40) angles.add(Math.toDegrees(kotlin.math.atan2(dy, dx).toDouble()).toFloat() to len)
                }
                for (e in line.elements) {
                    val bb = e.boundingBox ?: continue
                    val d = e.text.filter(Char::isDigit)
                    if (d.isEmpty()) continue
                    val box = Rect((bb.left / k).toInt() + x0, (bb.top / k).toInt() + y0, (bb.right / k).toInt() + x0, (bb.bottom / k).toInt() + y0)
                    // Слово, разрезанное краем четвертинки, — неполное: берём его из соседней
                    val cut = (x0 > 0 && box.left <= x0 + 2) || (y0 > 0 && box.top <= y0 + 2) ||
                        (x0 + tw < b.width && box.right >= x0 + tw - 2) || (y0 + th < b.height && box.bottom >= y0 + th - 2)
                    if (!cut) all.add(Word(d, box))
                }
            }
        }
        val words = ArrayList<Word>()
        for (w in all) if (words.none { it.digits == w.digits && abs(it.box.centerX() - w.box.centerX()) < w.box.height() && abs(it.box.centerY() - w.box.centerY()) < w.box.height() }) words.add(w)
        // Наклон — взвешенная медиана углов почти горизонтальных строк
        val near = angles.filter { abs(it.first) < 15f }.sortedBy { it.first }
        var acc = 0f; val half = near.sumOf { it.second.toDouble() }.toFloat() / 2f
        val skew = near.firstOrNull { acc += it.second; acc >= half }?.first ?: 0f
        return Ocr(words, skew)
    }

    /** Накладная по цифрам: "АСП-191490" → "191490" (буквы ML Kit может прочитать криво). */
    private fun findInvoice(words: List<Word>, invoice: String): Word? {
        val key = Regex("\\d+").findAll(invoice).map { it.value }.maxByOrNull { it.length }.orEmpty()
        if (key.length < 5) return null
        return words.firstOrNull { it.digits == key } ?: words.firstOrNull { it.digits.endsWith(key) }
    }

    /** Вес «42.0» на листе — «42», «60.246» — «60.246»: варианты записи цифрами. */
    private fun weightKeys(w: Double): Set<String> {
        if (w <= 0) return emptySet()
        val plain = runCatching { java.math.BigDecimal(w.toString()).stripTrailingZeros().toPlainString() }.getOrDefault(w.toString())
        return setOf(plain, String.format(java.util.Locale.US, "%.2f", w), String.format(java.util.Locale.US, "%.1f", w))
            .map { it.filter(Char::isDigit) }.filter { it.length >= 2 }.toSet()
    }

    /** «4679» на листе может стоять как «4679,00»: ищем оба варианта. */
    private fun digitKeys(v: String): Set<String> {
        val d = v.filter(Char::isDigit)
        val n = v.toD()
        return setOfNotNull(d, n?.let { String.format(java.util.Locale.US, "%.2f", it).filter(Char::isDigit) })
    }

    /** Число в той же строке правее накладной; самое правое — это «Факт», а не «Сумма». */
    private fun findInRow(words: List<Word>, value: String, rowBox: Rect, rowH: Float): Rect? {
        val keys = digitKeys(value)
        val cy = rowBox.exactCenterY()
        return words.filter {
            it.digits in keys && it.box.left > rowBox.right && abs(it.box.exactCenterY() - cy) < rowH * 0.9f
        }.maxByOrNull { it.box.left }?.box
    }

    private fun rotate(b: Bitmap, deg: Int): Bitmap =
        Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg.toFloat()) }, true)

    /** Поворот на небольшой угол вокруг центра, углы заливаем белым. */
    private fun rotateFree(b: Bitmap, deg: Float): Bitmap {
        val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.WHITE)
        c.rotate(deg, b.width / 2f, b.height / 2f)
        c.drawBitmap(b, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        return out
    }

    // ---------- «рукописная» отрисовка ----------

    private fun pen(color: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color; style = Paint.Style.STROKE; strokeWidth = w
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; alpha = 225
    }

    private fun rand(a: Float, b: Float) = a + rnd.nextFloat() * (b - a)

    /** Кривой овал «от руки»: неровный край, наклон, заход линии за начало. */
    private fun wobblyEllipse(c: Canvas, rf: RectF, color: Int, w: Float) {
        val cx = rf.centerX(); val cy = rf.centerY()
        val rx = rf.width() / 2f; val ry = rf.height() / 2f
        val phase = rand(0f, 6.28f); val tilt = rand(-0.06f, 0.06f); val over = rand(0.15f, 0.35f)
        val n = 80
        val p = Path()
        for (i in 0..n) {
            val t = phase + (2 * Math.PI.toFloat() + over) * i / n
            val k = 1f + 0.05f * sin(3 * t + phase) + rand(-0.01f, 0.01f) + 0.04f * i / n
            val x = rx * k * cos(t); val y = ry * k * sin(t)
            val xr = x * cos(tilt) - y * sin(tilt); val yr = x * sin(tilt) + y * cos(tilt)
            if (i == 0) p.moveTo(cx + xr, cy + yr) else p.lineTo(cx + xr, cy + yr)
        }
        c.drawPath(p, pen(color, w))
    }

    /** Текст по буквам: каждая чуть повёрнута и сдвинута. */
    private fun handText(c: Canvas, text: String, x: Float, y: Float, size: Float, color: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; typeface = hand; textSize = size; alpha = 235 }
        var cx = x
        for (ch in text) {
            val s = ch.toString()
            val w = paint.measureText(s)
            c.save()
            c.rotate(rand(-6f, 6f), cx + w / 2, y)
            c.drawText(s, cx, y + rand(-size * 0.04f, size * 0.04f), paint)
            c.restore()
            cx += w * rand(0.97f, 1.03f)
        }
    }

    private fun numberInCircle(c: Canvas, s: String, cx: Float, cy: Float, r: Float, color: Int, w: Float) {
        val size = r * 1.35f
        val paint = Paint().apply { typeface = hand; textSize = size }
        val tw = paint.measureText(s)
        // Белая подложка: линия, проходящая через кружок, не мешает читать номер
        c.drawOval(RectF(cx - max(r, tw / 2f + r * 0.45f), cy - r, cx + max(r, tw / 2f + r * 0.45f), cy + r), Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = Color.WHITE })
        handText(c, s, cx - tw / 2f, cy + size * 0.35f, size, color)
        val rx = max(r, tw / 2f + r * 0.45f)
        wobblyEllipse(c, RectF(cx - rx, cy - r, cx + rx, cy + r), color, w)
    }

    /** Фигурная скобка «}» от top до bottom. */
    private fun curlyBrace(c: Canvas, x: Float, top: Float, bottom: Float, w: Float, color: Int, sw: Float) {
        val mid = (top + bottom) / 2f
        val j = { rand(-w * 0.08f, w * 0.08f) }
        val p = Path().apply {
            moveTo(x, top)
            cubicTo(x + w * 0.55f + j(), top, x + w * 0.45f + j(), mid, x + w, mid)
            cubicTo(x + w * 0.45f + j(), mid, x + w * 0.55f + j(), bottom, x, bottom)
        }
        c.drawPath(p, pen(color, sw))
    }

    private fun RectF.padded(dx: Float, dy: Float) = RectF(left - dx, top - dy, right + dx, bottom + dy)
}
