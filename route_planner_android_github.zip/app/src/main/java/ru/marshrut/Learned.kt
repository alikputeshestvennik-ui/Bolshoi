package ru.marshrut

import android.content.SharedPreferences
import org.json.JSONObject

/**
 * Память исправлений с экрана проверки. Ключ — клиент и адрес строки, как их прочитала нейросеть.
 * calls  — какой позывной поставил человек;
 * addrs  — каким адресом заменил прочитанный;
 * merges — с какой строкой (её ключом) объединил.
 * При следующем листе те же исправления применяются сами.
 */
class Learned(private val sp: SharedPreferences) {
    val calls = HashMap<String, String>()
    val addrs = HashMap<String, String>()
    val merges = HashMap<String, String>()
    /** Порядок объезда: «A|B» — точку A водитель ставит раньше B (сколько раз). */
    val order = HashMap<String, Int>()
    /** Добавлено вручную в настройках — только на этом телефоне, в общую память не уходит («c:ключ», «a:», «m:», «o:»). */
    val manual = HashSet<String>()
    /** Удалено вручную — из общей памяти обратно не подтягиваем. */
    val hidden = HashSet<String>()
    /**
     * Отрезки из рейсов: «A|B» — водитель отметил A, а следующей B. Замер: [секунды от отметки A до отметки B
     * (дорога + разгрузка на B), час выезда, минута замера — она же отличает замеры при слиянии общей памяти].
     */
    val legs = HashMap<String, MutableList<LongArray>>()
    /** Порядки, которые водители выставили руками («Переставить», «Нарисовать»): названия точек по порядку. */
    val routes = ArrayList<List<String>>()
    /** Точки у трассы: подъезд только своей стороной (через встречку не переходим) — названия точек базы. */
    val curb = HashSet<String>()
    /** «Забыть всё» по рейсам: замеры старше этой минуты из общей памяти не берём. */
    var legsFrom = 0L

    init {
        runCatching {
            val j = JSONObject(sp.getString("learned", null) ?: return@runCatching)
            fun read(k: String, m: HashMap<String, String>) = j.optJSONObject(k)?.let { o -> o.keys().forEach { m[it] = o.getString(it) } }
            read("c", calls); read("a", addrs); read("m", merges)
            j.optJSONObject("o")?.let { o -> o.keys().forEach { order[it] = o.getInt(it) } }
            j.optJSONArray("man")?.let { a -> for (i in 0 until a.length()) manual.add(a.getString(i)) }
            j.optJSONArray("hid")?.let { a -> for (i in 0 until a.length()) hidden.add(a.getString(i)) }
            j.optJSONObject("l")?.let { readLegs(it, legs) }
            legsFrom = j.optLong("lf")
            j.optJSONArray("sd")?.let { a -> for (i in 0 until a.length()) curb.add(a.getString(i)) }
            j.optJSONArray("r")?.let { readRoutes(it, routes) }
        }
    }

    private fun readLegs(o: JSONObject, into: HashMap<String, MutableList<LongArray>>): Int {
        var n = 0
        o.keys().forEach { k ->
            val a = o.optJSONArray(k) ?: return@forEach
            val list = into.getOrPut(k) { ArrayList() }
            for (i in 0 until a.length()) {
                val x = a.optJSONArray(i) ?: continue
                val v = longArrayOf(x.optLong(0), x.optLong(1), x.optLong(2))
                if (v[2] < legsFrom || list.any { it[2] == v[2] }) continue
                list.add(v); n++
            }
            list.sortBy { it[2] }
            while (list.size > MAX_LEG) list.removeAt(0)
            if (list.isEmpty()) into.remove(k)
        }
        return n
    }

    private fun legsJson(m: Map<String, List<LongArray>>) = JSONObject().also { o ->
        m.forEach { (k, l) -> o.put(k, org.json.JSONArray().also { a -> l.forEach { a.put(org.json.JSONArray().put(it[0]).put(it[1]).put(it[2])) } }) }
    }

    private fun readRoutes(a: org.json.JSONArray, into: ArrayList<List<String>>): Int {
        var n = 0
        for (i in 0 until a.length()) {
            val x = a.optJSONArray(i) ?: continue
            val r = List(x.length()) { x.getString(it) }
            if (r.size >= 2 && into.none { it == r }) { into.add(r); n++ }
        }
        while (into.size > MAX_ROUTES) into.removeAt(0)
        return n
    }
    private fun routesJson(l: List<List<String>>) = org.json.JSONArray().also { a -> l.forEach { a.put(org.json.JSONArray(it)) } }

    /** Порядок, выставленный водителем руками: свежий в конце, такой же старый убираем. */
    fun addRoute(r: List<String>) {
        if (r.size < 2) return
        routes.removeAll { it == r }; routes.add(r)
        while (routes.size > MAX_ROUTES) routes.removeAt(0)
    }

    /** Замер отрезка из рейса. */
    fun addLeg(a: String, b: String, sec: Long, hour: Int, tsMin: Long) {
        val list = legs.getOrPut("$a|$b") { ArrayList() }
        if (list.any { it[2] == tsMin }) return
        list.add(longArrayOf(sec, hour.toLong(), tsMin))
        while (list.size > MAX_LEG) list.removeAt(0)
    }

    /** Сколько раз водители ехали из a прямо в b. */
    fun legCount(a: String, b: String) = legs["$a|$b"]?.size ?: 0

    /** Типичное время a→b по факту, секунды (медиана; при 2+ замерах в это же время дня ±2 ч — по ним). Null — мало данных. */
    fun legSec(a: String, b: String, hour: Int): Long? {
        val l = legs["$a|$b"] ?: return null
        if (l.size < 2) return null
        val near = l.filter { Math.abs(it[1] - hour) <= 2 }
        val use = (if (near.size >= 2) near else l).map { it[0] }.sorted()
        return use[use.size / 2]
    }

    companion object { const val MAX_LEG = 20; const val MAX_ROUTES = 200 }

    val size get() = calls.size + addrs.size + merges.size + order.size

    fun save() {
        val j = JSONObject().put("c", JSONObject(calls as Map<*, *>)).put("a", JSONObject(addrs as Map<*, *>)).put("m", JSONObject(merges as Map<*, *>)).put("o", JSONObject(order as Map<*, *>))
            .put("man", org.json.JSONArray(manual.toList())).put("hid", org.json.JSONArray(hidden.toList()))
            .put("l", legsJson(legs)).put("lf", legsFrom).put("sd", org.json.JSONArray(curb.toList()))
            .put("r", routesJson(routes))
        sp.edit().putString("learned", j.toString()).apply()
    }

    fun clear() {
        // «Забыть всё»: общие записи больше не подтягиваем, пока их не добавят заново
        calls.keys.forEach { hidden.add("c:$it") }; addrs.keys.forEach { hidden.add("a:$it") }
        merges.keys.forEach { hidden.add("m:$it") }; order.keys.forEach { hidden.add("o:$it") }
        calls.clear(); addrs.clear(); merges.clear(); order.clear(); manual.clear()
        legs.clear(); legsFrom = System.currentTimeMillis() / 60_000; save()
    }

    /** Свои (не ручные, не скрытые) записи — для общей памяти. */
    fun sharedJson(base: JSONObject?): JSONObject {
        fun obj(name: String) = base?.optJSONObject(name) ?: JSONObject()
        val c = obj("c"); val a = obj("a"); val m = obj("m"); val o = obj("o")
        calls.forEach { (k, v) -> if ("c:$k" !in manual && "c:$k" !in hidden) c.put(k, v) }
        addrs.forEach { (k, v) -> if ("a:$k" !in manual && "a:$k" !in hidden) a.put(k, v) }
        merges.forEach { (k, v) -> if ("m:$k" !in manual && "m:$k" !in hidden) m.put(k, v) }
        order.forEach { (k, v) -> if ("o:$k" !in manual && "o:$k" !in hidden) {
            o.put(k, maxOf(v, o.optInt(k, 0)))
            val rev = k.split('|').let { if (it.size == 2) "${it[1]}|${it[0]}" else "" }
            if (rev.isNotEmpty()) o.remove(rev)
        } }
        // Замеры рейсов: объединение своих и общих (одинаковая минута замера — один и тот же замер)
        val l = HashMap<String, MutableList<LongArray>>()
        base?.optJSONObject("l")?.let { readLegs(it, l) }
        legs.forEach { (k, v) -> val t = l.getOrPut(k) { ArrayList() }; v.forEach { x -> if (t.none { it[2] == x[2] }) t.add(x) }
            t.sortBy { it[2] }; while (t.size > MAX_LEG) t.removeAt(0) }
        // Точки «своей стороной»: общий список; снятые вручную («sd:имя» в скрытых) убираем
        val sd = HashSet<String>(); base?.optJSONArray("sd")?.let { x -> for (i in 0 until x.length()) sd.add(x.getString(i)) }
        sd.addAll(curb); sd.removeAll { "sd:$it" in hidden }
        val r = ArrayList<List<String>>(); base?.optJSONArray("r")?.let { readRoutes(it, r) }
        routes.forEach { x -> if (r.none { it == x }) r.add(x) }
        while (r.size > MAX_ROUTES) r.removeAt(0)
        return JSONObject().put("c", c).put("a", a).put("m", m).put("o", o).put("l", legsJson(l)).put("sd", org.json.JSONArray(sd.toList()))
            .put("r", routesJson(r))
    }

    /** Подтянуть общую память: чужие записи добавляются, свои ручные и скрытые не трогаем. Возвращает, сколько новых. */
    fun mergeShared(j: JSONObject): Int {
        var n = 0
        fun take(name: String, prefix: String, into: HashMap<String, String>) = j.optJSONObject(name)?.let { o ->
            o.keys().forEach { k -> if ("$prefix:$k" !in hidden && "$prefix:$k" !in manual && into[k] != o.getString(k)) { into[k] = o.getString(k); n++ } }
        }
        take("c", "c", calls); take("a", "a", addrs); take("m", "m", merges)
        j.optJSONObject("o")?.let { o -> o.keys().forEach { k ->
            if ("o:$k" in hidden || "o:$k" in manual) return@forEach
            val rev = k.split('|').let { if (it.size == 2) "${it[1]}|${it[0]}" else "" }
            if (rev in order && "o:$rev" in manual) return@forEach
            val v = o.getInt(k)
            if ((order[k] ?: 0) < v) { if (k !in order) n++; order[k] = v; order.remove(rev) }
        } }
        j.optJSONObject("l")?.let { readLegs(it, legs) }
        j.optJSONArray("r")?.let { n += readRoutes(it, routes) }
        j.optJSONArray("sd")?.let { x -> for (i in 0 until x.length()) { val v = x.getString(i); if ("sd:$v" !in hidden && curb.add(v)) n++ } }
        return n
    }
}
