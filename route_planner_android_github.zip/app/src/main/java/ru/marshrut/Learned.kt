package ru.marshrut

import android.content.SharedPreferences
import org.json.JSONObject

/**
 * Память исправлений с экрана проверки. Ключ — клиент и адрес строки, как их прочитала нейросеть.
 * calls  — какой позывной поставил человек;
 * addrs  — каким адресом заменил прочитанный;
 * merges — с какой строкой (её ключом) объединил.
 * При следующем листе те же исправления применяются сами.
 */
class Learned(private val sp: SharedPreferences) {
    val calls = HashMap<String, String>()
    val addrs = HashMap<String, String>()
    val merges = HashMap<String, String>()
    /** Порядок объезда: «A|B» — точку A водитель ставит раньше B (сколько раз). */
    val order = HashMap<String, Int>()
    /** Добавлено вручную в настройках — только на этом телефоне, в общую память не уходит («c:ключ», «a:», «m:», «o:»). */
    val manual = HashSet<String>()
    /** Удалено вручную — из общей памяти обратно не подтягиваем. */
    val hidden = HashSet<String>()

    init {
        runCatching {
            val j = JSONObject(sp.getString("learned", null) ?: return@runCatching)
            fun read(k: String, m: HashMap<String, String>) = j.optJSONObject(k)?.let { o -> o.keys().forEach { m[it] = o.getString(it) } }
            read("c", calls); read("a", addrs); read("m", merges)
            j.optJSONObject("o")?.let { o -> o.keys().forEach { order[it] = o.getInt(it) } }
            j.optJSONArray("man")?.let { a -> for (i in 0 until a.length()) manual.add(a.getString(i)) }
            j.optJSONArray("hid")?.let { a -> for (i in 0 until a.length()) hidden.add(a.getString(i)) }
        }
    }

    val size get() = calls.size + addrs.size + merges.size + order.size

    fun save() {
        val j = JSONObject().put("c", JSONObject(calls as Map<*, *>)).put("a", JSONObject(addrs as Map<*, *>)).put("m", JSONObject(merges as Map<*, *>)).put("o", JSONObject(order as Map<*, *>))
            .put("man", org.json.JSONArray(manual.toList())).put("hid", org.json.JSONArray(hidden.toList()))
        sp.edit().putString("learned", j.toString()).apply()
    }

    fun clear() {
        // «Забыть всё»: общие записи больше не подтягиваем, пока их не добавят заново
        calls.keys.forEach { hidden.add("c:$it") }; addrs.keys.forEach { hidden.add("a:$it") }
        merges.keys.forEach { hidden.add("m:$it") }; order.keys.forEach { hidden.add("o:$it") }
        calls.clear(); addrs.clear(); merges.clear(); order.clear(); manual.clear(); save()
    }

    /** Свои (не ручные, не скрытые) записи — для общей памяти. */
    fun sharedJson(base: JSONObject?): JSONObject {
        fun obj(name: String) = base?.optJSONObject(name) ?: JSONObject()
        val c = obj("c"); val a = obj("a"); val m = obj("m"); val o = obj("o")
        calls.forEach { (k, v) -> if ("c:$k" !in manual && "c:$k" !in hidden) c.put(k, v) }
        addrs.forEach { (k, v) -> if ("a:$k" !in manual && "a:$k" !in hidden) a.put(k, v) }
        merges.forEach { (k, v) -> if ("m:$k" !in manual && "m:$k" !in hidden) m.put(k, v) }
        order.forEach { (k, v) -> if ("o:$k" !in manual && "o:$k" !in hidden) {
            o.put(k, maxOf(v, o.optInt(k, 0)))
            val rev = k.split('|').let { if (it.size == 2) "${it[1]}|${it[0]}" else "" }
            if (rev.isNotEmpty()) o.remove(rev)
        } }
        return JSONObject().put("c", c).put("a", a).put("m", m).put("o", o)
    }

    /** Подтянуть общую память: чужие записи добавляются, свои ручные и скрытые не трогаем. Возвращает, сколько новых. */
    fun mergeShared(j: JSONObject): Int {
        var n = 0
        fun take(name: String, prefix: String, into: HashMap<String, String>) = j.optJSONObject(name)?.let { o ->
            o.keys().forEach { k -> if ("$prefix:$k" !in hidden && "$prefix:$k" !in manual && into[k] != o.getString(k)) { into[k] = o.getString(k); n++ } }
        }
        take("c", "c", calls); take("a", "a", addrs); take("m", "m", merges)
        j.optJSONObject("o")?.let { o -> o.keys().forEach { k ->
            if ("o:$k" in hidden || "o:$k" in manual) return@forEach
            val rev = k.split('|').let { if (it.size == 2) "${it[1]}|${it[0]}" else "" }
            if (rev in order && "o:$rev" in manual) return@forEach
            val v = o.getInt(k)
            if ((order[k] ?: 0) < v) { if (k !in order) n++; order[k] = v; order.remove(rev) }
        } }
        return n
    }
}
