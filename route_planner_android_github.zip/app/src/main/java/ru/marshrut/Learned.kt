package ru.marshrut

import android.content.SharedPreferences
import org.json.JSONObject

/**
 * Память исправлений с экрана проверки. Ключ — клиент и адрес строки, как их прочитала нейросеть.
 * calls  — какой позывной поставил человек;
 * addrs  — каким адресом заменил прочитанный;
 * merges — с какой строкой (её ключом) объединил.
 * При следующем листе те же исправления применяются сами.
 */
class Learned(private val sp: SharedPreferences) {
    val calls = HashMap<String, String>()
    val addrs = HashMap<String, String>()
    val merges = HashMap<String, String>()

    init {
        runCatching {
            val j = JSONObject(sp.getString("learned", null) ?: return@runCatching)
            fun read(k: String, m: HashMap<String, String>) = j.optJSONObject(k)?.let { o -> o.keys().forEach { m[it] = o.getString(it) } }
            read("c", calls); read("a", addrs); read("m", merges)
        }
    }

    val size get() = calls.size + addrs.size + merges.size

    fun save() {
        val j = JSONObject().put("c", JSONObject(calls as Map<*, *>)).put("a", JSONObject(addrs as Map<*, *>)).put("m", JSONObject(merges as Map<*, *>))
        sp.edit().putString("learned", j.toString()).apply()
    }

    fun clear() { calls.clear(); addrs.clear(); merges.clear(); save() }
}
