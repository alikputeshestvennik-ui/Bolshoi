package ru.marshrut

import okhttp3.FormBody
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Рельеф и дороги у точек — то, что водитель знает, а карта «по времени» не учитывает.
 *  1. Подъёмы: сколько метров набирается по дороге между районами (OSRM-маршрут + высоты Open-Meteo).
 *     Подъём с тонной в кузове на Транзите — плохо: оптимизатор старается выгрузиться до подъёма.
 *  2. Ширина дороги у точки (OpenStreetMap): на магистрали и широкой улице подъезжаем только своей стороной —
 *     не носить ящики через несколько полос; на узкой улочке — с любой стороны.
 * Всё считается один раз и хранится в файле: районы и точки повторяются из рейса в рейс.
 */
class Terrain(dir: File) {
    private val file = File(dir, "terrain.json")
    /** «lat,lon» района → «lat,lon» района: набор высоты туда и обратно, м. */
    private val climbs = HashMap<String, Pair<Double, Double>>()
    /** «lat,lon» точки → широкая дорога рядом. */
    private val wide = HashMap<String, Boolean>()
    /** «lat,lon» → высота, м. */
    private val elev = HashMap<String, Double>()

    init {
        runCatching {
            val j = JSONObject(file.readText())
            j.optJSONObject("c")?.let { o -> o.keys().forEach { k -> o.getJSONArray(k).let { climbs[k] = it.getDouble(0) to it.getDouble(1) } } }
            j.optJSONObject("w2")?.let { o -> o.keys().forEach { wide[it] = o.getBoolean(it) } }
            j.optJSONObject("e")?.let { o -> o.keys().forEach { elev[it] = o.getDouble(it) } }
        }
    }

    @Synchronized private fun save() = runCatching {
        val c = JSONObject(); climbs.forEach { (k, v) -> c.put(k, JSONArray().put(v.first).put(v.second)) }
        file.writeText(JSONObject().put("c", c).put("w2", JSONObject(wide as Map<*, *>)).put("e", JSONObject(elev as Map<*, *>)).toString())
    }

    private fun key(lat: Double, lon: Double, d: Int = 4) = String.format(Locale.US, "%.${d}f,%.${d}f", lat, lon)

    // ---------- высоты ----------
    /** Высоты над морем, м (Open-Meteo, бесплатно, до 100 точек за запрос). */
    private fun heights(pts: List<Pair<Double, Double>>): DoubleArray? = runCatching {
        val out = DoubleArray(pts.size)
        pts.chunked(100).forEachIndexed { ci, ch ->
            val url = "https://api.open-meteo.com/v1/elevation?latitude=" + ch.joinToString(",") { String.format(Locale.US, "%.5f", it.first) } +
                "&longitude=" + ch.joinToString(",") { String.format(Locale.US, "%.5f", it.second) }
            Net.http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (!r.isSuccessful) error("elevation ${r.code}")
                val a = JSONObject(r.body?.string().orEmpty()).getJSONArray("elevation")
                for (i in 0 until a.length()) out[ci * 100 + i] = a.getDouble(i)
            }
        }
        out
    }.getOrNull()

    /** Высоты точек (с кешем). */
    fun pointHeights(pts: List<Point>): DoubleArray? {
        val miss = pts.filter { key(it.lat, it.lon) !in elev }
        if (miss.isNotEmpty()) {
            val h = heights(miss.map { it.lat to it.lon }) ?: return null
            synchronized(this) { miss.forEachIndexed { i, p -> elev[key(p.lat, p.lon)] = h[i] } }
        }
        return DoubleArray(pts.size) { elev[key(pts[it].lat, pts[it].lon)] ?: 0.0 }
    }

    /** Набор и сброс высоты вдоль дороги a→b: профиль через ~250 м, мелкий шум рельефа (< 6 м) не считаем. */
    private fun profile(st: Settings, a: Point, b: Point): Pair<Double, Double>? = runCatching {
        val line = Net.geometry(st, listOf(a, b))
        if (line.size < 2) return null
        val samples = ArrayList<Pair<Double, Double>>(); var acc = 0.0
        samples.add(line[0])
        for (i in 1 until line.size) {
            acc += Net.haversine(line[i - 1].first, line[i - 1].second, line[i].first, line[i].second)
            if (acc >= 250.0) { samples.add(line[i]); acc = 0.0 }
        }
        samples.add(line.last())
        val step = maxOf(1, samples.size / 100)
        val s = samples.filterIndexed { i, _ -> i % step == 0 || i == samples.lastIndex }
        val h = heights(s) ?: return null
        var up = 0.0; var down = 0.0; var anchor = h[0]
        for (x in h) {
            val d = x - anchor
            if (d > 6) { up += d; anchor = x } else if (d < -6) { down -= d; anchor = x }
        }
        up to down
    }.getOrNull()

    /**
     * Матрица подъёмов, м: сколько в гору по дороге из точки i в точку j.
     * Точки в пределах ~1,5 км — один район, внутри района — по разнице высот самих точек.
     */
    fun climbMatrix(st: Settings, pts: List<Point>, onStatus: (String) -> Unit = {}): Array<DoubleArray>? {
        val h = pointHeights(pts) ?: return null
        val rep = ArrayList<Point>(); val cl = IntArray(pts.size)
        for ((i, p) in pts.withIndex()) {
            val c = rep.indexOfFirst { Net.haversine(it.lat, it.lon, p.lat, p.lon) < 1500.0 }
            cl[i] = if (c >= 0) c else { rep.add(p); rep.lastIndex }
        }
        fun rk(p: Point) = key(p.lat, p.lon, 2)
        val pairs = ArrayList<Pair<Int, Int>>()
        for (a in rep.indices) for (b in a + 1 until rep.size)
            if ("${rk(rep[a])}|${rk(rep[b])}" !in climbs && "${rk(rep[b])}|${rk(rep[a])}" !in climbs) pairs.add(a to b)
        if (pairs.isNotEmpty()) {
            onStatus("Считаем подъёмы между районами")
            val pool = Executors.newFixedThreadPool(6)
            pairs.forEach { (a, b) ->
                pool.submit {
                    profile(st, rep[a], rep[b])?.let { synchronized(this) { climbs["${rk(rep[a])}|${rk(rep[b])}"] = it } }
                }
            }
            pool.shutdown(); pool.awaitTermination(60, TimeUnit.SECONDS)
            save()
        }
        fun up(a: Int, b: Int): Double {
            climbs["${rk(rep[a])}|${rk(rep[b])}"]?.let { return it.first }
            climbs["${rk(rep[b])}|${rk(rep[a])}"]?.let { return it.second }
            return maxOf(0.0, h[pts.indexOfFirst { it === rep[b] }] - h[pts.indexOfFirst { it === rep[a] }])
        }
        return Array(pts.size) { i ->
            DoubleArray(pts.size) { j ->
                if (i == j) 0.0
                else if (cl[i] == cl[j]) maxOf(0.0, h[j] - h[i])
                // Между районами: дорога района + подъём от центра района до самой точки
                else up(cl[i], cl[j]) + maxOf(0.0, h[j] - h[pts.indexOfFirst { it === rep[cl[j]] }])
            }
        }
    }

    // ---------- ширина дороги ----------
    private val WIDE = setOf("motorway", "trunk", "primary", "secondary", "motorway_link", "trunk_link", "primary_link")

    /** Для каждой точки: стоит ли она на широкой дороге (магистраль, крупная улица или 4+ полос). */
    fun wideRoads(pts: List<Point>): BooleanArray {
        val miss = pts.filter { it.hasCoords && key(it.lat, it.lon) !in wide }.distinctBy { key(it.lat, it.lon) }
        if (miss.isNotEmpty()) runCatching {
            // Один запрос на все точки: после каждой — разделитель, чтобы разложить ответ по точкам
            val q = StringBuilder("[out:json][timeout:25];")
            miss.forEach { p ->
                q.append(String.format(Locale.US, "way(around:45,%.6f,%.6f)[highway];out tags;make sep n=\"1\";out;", p.lat, p.lon))
            }
            val req = Request.Builder().url("https://overpass-api.de/api/interpreter")
                .post(FormBody.Builder().add("data", q.toString()).build()).build()
            Net.http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) error("overpass ${r.code}")
                val els = JSONObject(r.body?.string().orEmpty()).getJSONArray("elements")
                var cur = ArrayList<JSONObject>(); var idx = 0
                for (e in 0 until els.length()) {
                    val o = els.getJSONObject(e)
                    if (o.optString("type") == "sep") {
                        val isWide = cur.any { w ->
                            val t = w.optJSONObject("tags") ?: return@any false
                            t.optString("highway") in WIDE || (t.optString("lanes").toIntOrNull() ?: 0) >= 4
                        }
                        miss.getOrNull(idx)?.let { synchronized(this) { wide[key(it.lat, it.lon)] = isWide } }
                        cur = ArrayList(); idx++
                    } else cur.add(o)
                }
            }
            save()
        }
        return BooleanArray(pts.size) { wide[key(pts[it].lat, pts[it].lon)] ?: false }
    }

}
