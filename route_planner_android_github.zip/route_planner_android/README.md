# Маршрут — Android prototype

## v0.9.0 — PaddleOCR

OCR engine заменён с Tesseract на официальный PaddleOCR Android SDK, работающий локально через ONNX Runtime. Для маршрутных листов используется PP-OCRv5 mobile detector и отдельная Cyrillic recognition model. PaddleOCR сначала детектирует текстовые области, затем распознаёт каждую строку отдельно и возвращает координаты + confidence. Это принципиально отличается от прежнего Tesseract-прохода по всей странице.

Модели скачиваются GitHub Actions при сборке, чтобы архив проекта не раздувать бинарными файлами.

Источники моделей: PaddleOCR Android deployment и PP-OCRv5 Cyrillic recognition.


## v1.0.0-qwen

Основной OCR переведён на Qwen3.6-35B через Yandex AI Studio Responses API. Фото страниц передаются мультимодальной модели одним запросом в Base64. Tesseract/PaddleOCR, ручной поиск ориентации, deskew и бинаризация удалены из основного OCR-контура. После ответа Qwen приложение разбирает машинно-размеченные строки и проверяет позывные по локальной базе.

Для запуска укажите API-ключ Yandex AI Studio и ID каталога.


## Qwen3.6-35B

В приложении пользователь вводит только ID каталога Yandex Cloud. Полный model URI не вводится: приложение само формирует `gpt://<folderId>/qwen3.6-35b-a3b`.

Для Qwen3.6-35B Yandex документирует именно этот формат model URI.
