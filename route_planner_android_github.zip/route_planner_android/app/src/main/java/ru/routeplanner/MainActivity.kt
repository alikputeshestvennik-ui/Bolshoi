package ru.routeplanner

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.lifecycleScope
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var runOcr: Button
    private var selected: List<Uri> = emptyList()

    private var callsignsMap: Map<String, String> = emptyMap()

    private data class Point(val id: String, val name: String, val address: String)

    private val picker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        selected = uris
        runOcr.isEnabled = uris.isNotEmpty()
        status.text = if (uris.isEmpty()) "Фото не выбраны." else "Выбрано страниц: ${uris.size}"
        result.text = ""
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        result = findViewById(R.id.result)
        runOcr = findViewById(R.id.runOcr)

        findViewById<Button>(R.id.selectPhotos).setOnClickListener {
            picker.launch(arrayOf("image/jpeg", "image/png", "image/webp"))
        }
        runOcr.setOnClickListener { runOcr() }
    }

    private fun publish(msg: String) = runOnUiThread { status.text = msg }

    private fun runOcr() {
        runOcr.isEnabled = false
        status.text = "Распознавание… (до минуты на страницу)"
        lifecycleScope.launch {
            try {
                val text = withContext(Dispatchers.IO) { recognizeAll() }
                result.text = text
                status.text = "Готово. Страниц: ${selected.size}"
            } catch (e: Throwable) {
                status.text = "Ошибка OCR"
                result.text = e.stackTraceToString()
            } finally {
                runOcr.isEnabled = selected.isNotEmpty()
            }
        }
    }

    // =====================================================================
    //  Основной конвейер: фото → ориентация → наклон → OCR → строки → точки
    // =====================================================================

    private fun recognizeAll(): String {
        prepareTessdata()
        val points = loadDatabase()
        val api = TessBaseAPI()
        try {
            val ok = api.init(filesDir.absolutePath + File.separator, "rus+eng", TessBaseAPI.OEM_LSTM_ONLY)
            if (!ok) error("Не удалось инициализировать русский OCR")
            api.setVariable("preserve_interword_spaces", "1")
            api.setVariable("user_defined_dpi", "300")

            class Shot(val n: Int, val words: List<Word>, val imgW: Int, val rot: Float, val skew: Float, val ocrScore: Int, val ocrConfidence: Int)
            val shots = ArrayList<Shot>()

            selected.forEachIndexed { index, uri ->
                val n = index + 1
                publish("Страница $n: определяю ориентацию…")
                val oriented = loadBitmap(uri)
                val rot = detectRotation(api, oriented)
                val rotated = rotateBitmap(oriented, rot)
                if (rotated !== oriented) oriented.recycle()

                val cropped = cropToDocument(rotated)
                if (cropped !== rotated) rotated.recycle()

                publish("Страница $n: выравниваю наклон…")
                val skew = estimateSkew(cropped)
                val straight = deskew(cropped, skew)
                if (straight !== cropped) cropped.recycle()

                publish("Страница $n: OCR — исходник + адаптивная бинаризация + табличные режимы…")
                var bestWords: List<Word> = emptyList()
                var bestScore = Int.MIN_VALUE
                var bestConfidence = 0
                var bestName = "?"

                fun tryVariant(name: String, bitmap: Bitmap) {
                    try {
                        for (psm in intArrayOf(
                            TessBaseAPI.PageSegMode.PSM_AUTO,
                            TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK,
                            TessBaseAPI.PageSegMode.PSM_SPARSE_TEXT
                        )) {
                            api.setPageSegMode(psm)
                            api.setImage(bitmap)
                            api.getUTF8Text() // запускает распознавание
                            val words = readWords(api)
                            val confidence = api.meanConfidence()
                            val score = ocrStructuralScore(words, confidence)
                            if (score > bestScore) {
                                bestScore = score
                                bestConfidence = confidence
                                bestWords = words
                                bestName = "$name/psm$psm"
                            }
                            api.clear()
                        }
                    } finally {
                        bitmap.recycle()
                    }
                }

                // Не держим несколько больших Bitmap одновременно. Важный момент: для
                // маршрутного листа обычный PSM_AUTO/PSM_SINGLE_BLOCK заметно стабильнее
                // разреженного OCR, потому что строки образуют плотную таблицу.
                tryVariant("gray", grayscaleBitmap(straight))
                tryVariant("bin55", preprocessForOcr(straight, 55))
                tryVariant("bin62", preprocessForOcr(straight, 62))

                // Критический второй проход: таблица разбирается на реальные строки и
                // ячейки. Для накладной это надёжнее единого OCR всей страницы: номер,
                // вес, факт и агент больше не «перетекают» между соседними колонками.
                publish("Страница $n: OCR по строкам и ячейкам таблицы…")
                val cellWords = recognizeTableCells(api, straight)
                if (cellWords.size > bestWords.size / 3) {
                    // Сохраняем также небольшой общий OCR для текста вне таблицы, но
                    // табличные слова считаем приоритетным источником.
                    bestWords = mergeWords(cellWords, bestWords, straight.width, straight.height)
                    bestScore += cellWords.size * 2
                }

                val imgW = straight.width
                straight.recycle()
                shots.add(Shot(n, bestWords, imgW, rot, skew, bestScore, bestConfidence))
                publish("Страница $n: выбран табличный OCR, confidence $bestConfidence")
            }

            // Заголовок таблицы есть не на каждой странице: берём колонки с любой, где он нашёлся.
            val own = shots.map { detectColumns(it.words, it.imgW) }
            val anyCols = own.firstOrNull { it != null }

            val entries = ArrayList<Entry>()
            val contacts = LinkedHashMap<Int, String>()
            val totals = Totals()
            val dump = StringBuilder()
            shots.forEachIndexed { i, shot ->
                val mine = own[i]
                val page = parsePage(shot.n, shot.words, shot.imgW, mine?.first ?: anyCols?.first, mine?.second)
                entries.addAll(page.entries)
                page.contacts.forEach { (k, v) -> contacts.putIfAbsent(k, v) }
                page.sheetKg?.let { totals.kg = it }
                page.sheetCash?.let { totals.cash = it }

                dump.append("— страница ${shot.n}: поворот ${shot.rot.toInt()}°, наклон ${"%.1f".format(Locale.US, shot.skew)}°, слов ${shot.words.size}, OCR-score ${shot.ocrScore}, confidence ${shot.ocrConfidence}, ")
                dump.append(if (mine != null) "заголовок найден" else if (anyCols != null) "заголовок с другой страницы" else "заголовок НЕ найден")
                dump.append(", строк накладных ${page.entries.size} —\n")
                page.entries.forEach {
                    dump.append("${it.callsign ?: "?"} | ${it.invoice ?: "?"} | вес ${it.weight ?: "?"} | факт ${it.cash} | ${it.type ?: "?"} | агент ${it.agent ?: "?"}\n")
                    dump.append("   ${it.raw.take(170)}\n")
                }
                dump.append('\n')
            }
            return formatReport(entries, points, contacts, totals) +
                "\n──────── Отладка ────────\n" + dump
        } finally {
            api.recycle()
        }
    }

    // =====================================================================
    //  Слова
    // =====================================================================

    private class Word(val text: String, val rect: Rect, val confidence: Float = 0f) {
        val cx: Float get() = (rect.left + rect.right) / 2f
        val cy: Float get() = (rect.top + rect.bottom) / 2f
    }

    /** Сводная оценка варианта OCR: структура документа важнее просто количества символов. */
    private fun ocrStructuralScore(words: List<Word>, confidence: Int): Int {
        var invoices = 0
        var callsigns = 0
        var headers = 0
        var numbers = 0
        var russianWords = 0
        for (w in words) {
            val t = norm(w.text)
            if (invoiceRegex.matches(t)) invoices++
            if (callsignOf(t) != null) callsigns++
            if (t in setOf("вес", "сумма", "факт", "забрать", "долг", "расчет", "заметки", "агент")) headers++
            if (num(t) != null) numbers++
            if (t.count { it in 'а'..'я' } >= 3) russianWords++
        }
        return invoices * 40 + callsigns * 30 + headers * 8 + minOf(numbers, 80) + minOf(russianWords, 200) / 2 + confidence / 2
    }

    private fun grayscaleBitmap(src: Bitmap): Bitmap {
        val scaled = scaleLong(src, 3200)
        val (gray, w, h) = toGray(scaled)
        if (scaled !== src) scaled.recycle()
        val px = IntArray(w * h)
        for (i in px.indices) {
            val v = gray[i].toInt() and 0xFF
            px[i] = Color.rgb(v, v, v)
        }
        return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { it.setPixels(px, 0, w, 0, 0, w, h) }
    }

    private fun readWords(api: TessBaseAPI): List<Word> {
        val words = ArrayList<Word>()
        val iter = api.resultIterator ?: return words
        try {
            iter.begin()
            do {
                val t = iter.getUTF8Text(TessBaseAPI.PageIteratorLevel.RIL_WORD)?.trim()
                if (!t.isNullOrEmpty()) {
                    words.add(Word(t, iter.getBoundingRect(TessBaseAPI.PageIteratorLevel.RIL_WORD), iter.confidence(TessBaseAPI.PageIteratorLevel.RIL_WORD)))
                }
            } while (iter.next(TessBaseAPI.PageIteratorLevel.RIL_WORD))
        } finally {
            iter.delete()
        }
        return words
    }

    /** Грубая группировка слов в строки: нужна для заголовка, итогов и контактов. */
    private fun buildRows(words: List<Word>): List<List<Word>> {
        if (words.isEmpty()) return emptyList()
        val heights = words.map { it.rect.height() }.sorted()
        val tol = (heights[heights.size / 2] * 0.6f).coerceAtLeast(6f)
        val groups = ArrayList<MutableList<Word>>()
        for (w in words.sortedBy { it.cy }) {
            val last = groups.lastOrNull()
            if (last != null && Math.abs(w.cy - last.map { it.cy }.average()) <= tol) last.add(w)
            else groups.add(mutableListOf(w))
        }
        return groups.map { g -> g.sortedBy { it.rect.left } }
    }

    // =====================================================================
    //  Разбор страницы маршрутного листа
    // =====================================================================

    private class Entry(
        val page: Int,
        val callsign: String?,
        val invoice: String?,
        val weight: Double?,
        val cash: Double,
        val type: String?,
        val agent: Int?,
        val raw: String,
    )

    private class Totals { var kg: Double? = null; var cash: Double? = null }

    private class Page(
        val entries: List<Entry>,
        val columns: Map<String, Float>?,
        val contacts: Map<Int, String>,
        val sheetKg: Double?,
        val sheetCash: Double?,
    )

    private val callsignRegex = Regex("""(?<![0-9a-zа-я])([0-9зобеli|qgse]{1,4})(яв|юс|юв)""")
    private val invoiceRegex = Regex("""^(асп|нфф)[-–—]?(\d{5,7})$""")
    private val numRegex = Regex("""^\d{1,7}([.,]\d{1,2})?$""")
    private val agentRegex = Regex("""^(?<![\d.,])(\d)\s?/""")
    private val contactRegex = Regex(
        """(?<![\d+])([1-9])\s+([А-ЯЁ][а-яё]+\s+[А-ЯЁ][а-яё]+(?:\s*\([^)]{1,15}\))?(?:\s+(?:ПУД|сев|СВ|юг))*)\s*\+?(7\d{10})"""
    )

    private fun fixLookalikes(line: String): String {
        val sb = StringBuilder()
        for (ch in line) {
            sb.append(
                when (ch) {
                    'A', 'a' -> 'а'; 'B' -> 'В'; 'C', 'c' -> 'с'; 'E', 'e' -> 'е'
                    'H' -> 'Н'; 'K', 'k' -> 'к'; 'M' -> 'М'; 'O', 'o' -> 'о'
                    'P', 'p' -> 'р'; 'T' -> 'Т'; 'X', 'x' -> 'х'; 'y', 'Y' -> 'у'
                    else -> ch
                }
            )
        }
        return sb.toString()
    }

    private fun norm(s: String) = fixLookalikes(s).lowercase().replace('ё', 'е')
        .trim('.', ',', ':', ';', '|', ' ')

    /** Позывной из слова: допускает типичные «двойники» цифр (З→3, О→0, б→6, l→1) только перед суффиксом юс/яв/юв. */
    private fun callsignOf(raw: String): String? {
        val n = norm(raw)
        val exact = callsignRegex.find(n)
        if (exact != null) {
            val digits = exact.groupValues[1].map {
                when (it) {
                    'з', 'е' -> '3'; 's' -> '5'; 'о' -> '0'; 'б' -> '6';
                    'l', 'i', '|' -> '1'; 'q', 'g' -> '9'; else -> it
                }
            }.joinToString("")
            if (digits.isNotEmpty() && digits.all { it.isDigit() }) return digits + exact.groupValues[2]
        }

        // Второй шанс: если OCR ошибся ровно в одном символе позывного,
        // восстанавливаем его по локальной базе. Это безопаснее широкого fuzzy-match.
        if (callsignsMap.isNotEmpty()) {
            val suffix = listOf("яв", "юс", "юв").firstOrNull { n.endsWith(it) } ?: return null
            val body = n.removeSuffix(suffix)
            if (body.length !in 1..4) return null
            val normalizedBody = body.map {
                when (it) {
                    'з', 'е' -> '3'; 's' -> '5'; 'о' -> '0'; 'б' -> '6';
                    'l', 'i', '|' -> '1'; 'q', 'g' -> '9'; else -> it
                }
            }.joinToString("")
            if (!normalizedBody.all { it.isDigit() }) return null
            val target = normalizedBody + suffix
            val best = callsignsMap.keys
                .filter { it.endsWith(suffix) }
                .map { it to editDistance(target, it) }
                .minByOrNull { it.second }
            if (best != null && best.second <= 1) return best.first
        }
        return null
    }

    private fun editDistance(a: String, b: String): Int {
        val prev = IntArray(b.length + 1) { it }
        val cur = IntArray(b.length + 1)
        for (i in a.indices) {
            cur[0] = i + 1
            for (j in b.indices) {
                cur[j + 1] = minOf(
                    cur[j] + 1,
                    prev[j + 1] + 1,
                    prev[j] + if (a[i] == b[j]) 0 else 1,
                )
            }
            for (j in cur.indices) prev[j] = cur[j]
        }
        return prev[b.length]
    }

    private fun num(t: String): Double? =
        if (numRegex.matches(t)) t.replace(',', '.').toDoubleOrNull() else null

    /**
     * Специализированный OCR маршрутного листа.
     *
     * У листа стабильная структура: 13 колонок. Сначала находим внешний прямоугольник
     * таблицы и горизонтальные разделители строк, затем каждую ячейку распознаём отдельно.
     * Границы колонок задаются относительными долями шаблона листа — это устойчивее OCR
     * заголовков, особенно когда слово «Забрать» распознаётся с ошибкой.
     */
    private fun recognizeTableCells(api: TessBaseAPI, source: Bitmap): List<Word> {
        val w = source.width
        val h = source.height
        if (w < 900 || h < 500) return emptyList()

        // Координаты шаблона: Код | Довоз | Вид | Накладная | Клиент | Адрес |
        // Вес | Сумма | Факт | Забрать долг | Расчет | Заметки | Агент/СВ.
        val fractions = floatArrayOf(
            0.0000f, 0.03987f, 0.07124f, 0.09346f, 0.14706f, 0.21765f,
            0.38562f, 0.42222f, 0.49281f, 0.53333f, 0.57190f, 0.62026f,
            0.93660f, 1.0000f
        )
        val left = (w * 0.090f).toInt().coerceAtLeast(0)
        val right = (w * 0.910f).toInt().coerceAtMost(w)
        if (right - left < 700) return emptyList()

        val x = IntArray(fractions.size) { i -> left + ((right - left) * fractions[i]).toInt() }
        val lines = detectHorizontalTableLines(source, left, right)
        if (lines.size < 4) return emptyList()

        val out = ArrayList<Word>()
        // Каждая полоса между линиями — потенциальная строка таблицы. Очень тонкие
        // интервалы от двойных границ объединяем.
        for (ri in 0 until lines.lastIndex) {
            val y0 = lines[ri]
            val y1 = lines[ri + 1]
            if (y1 - y0 < 18) continue
            val padY = minOf(5, maxOf(2, (y1 - y0) / 10))
            val top = (y0 + padY).coerceAtLeast(0)
            val bottom = (y1 - padY).coerceAtMost(h)
            if (bottom - top < 12) continue

            for (ci in 0 until x.lastIndex) {
                val padX = if (ci == 0 || ci == x.lastIndex - 1) 4 else 3
                val l = (x[ci] + padX).coerceAtLeast(0)
                val r = (x[ci + 1] - padX).coerceAtMost(w)
                if (r - l < 10) continue
                val cell = Rect(l, top, r, bottom)
                val kind = cellKind(ci)
                val words = ocrCellBest(api, source, cell, kind)
                out.addAll(words)
            }
        }
        return out
    }

    private fun cellKind(column: Int): String = when (column) {
        0 -> "callsign"
        1 -> "code"
        2 -> "type"
        3 -> "invoice"
        4 -> "client"
        5 -> "address"
        6 -> "weight"
        7 -> "sum"
        8 -> "fact"
        9 -> "debt"
        10 -> "calc"
        11 -> "notes"
        12 -> "agent"
        else -> "text"
    }

    /** Находит горизонтальные линии таблицы по доле сильных вертикальных границ. */
    private fun detectHorizontalTableLines(src: Bitmap, left: Int, right: Int): List<Int> {
        val gray = toGray(src).first
        val w = src.width
        val h = src.height
        val l = left.coerceAtLeast(0)
        val r = right.coerceAtMost(w - 1)
        if (r - l < 500) return emptyList()

        val yStart = (h * 0.07f).toInt()
        val yEnd = (h * 0.90f).toInt().coerceAtMost(h - 2)
        val score = FloatArray(yEnd - yStart)
        for (y in yStart until yEnd) {
            var strong = 0
            var total = 0
            val base = y * w
            val next = (y + 1) * w
            for (xx in l until r step 2) {
                val a = gray[base + xx].toInt() and 0xFF
                val b = gray[next + xx].toInt() and 0xFF
                if (kotlin.math.abs(a - b) >= 24) strong++
                total++
            }
            score[y - yStart] = strong.toFloat() / total.coerceAtLeast(1)
        }

        val candidates = ArrayList<Pair<Int, Float>>()
        for (i in 2 until score.lastIndex - 1) {
            if (score[i] >= score[i - 1] && score[i] >= score[i + 1] && score[i] >= 0.085f) {
                candidates.add(yStart + i to score[i])
            }
        }
        if (candidates.isEmpty()) return emptyList()

        // Сливаем соседние пиксели одной физической линии.
        val clustered = ArrayList<Pair<Int, Float>>()
        for ((yy, ss) in candidates) {
            val last = clustered.lastOrNull()
            if (last != null && yy - last.first <= 8) {
                if (ss > last.second) clustered[clustered.lastIndex] = yy to ss
            } else clustered.add(yy to ss)
        }

        // У первой таблицы есть две близкие границы: верх заголовка и низ заголовка.
        // Их нельзя сливать — между ними находится отдельная строка шапки.
        val chosen = ArrayList<Int>()
        var startIndex = 1
        chosen.add(clustered.first().first)
        // После верхней границы часто есть ещё один локальный пик от самой линии
        // заголовка. Ищем следующую физическую границу на 18–45 px ниже и сохраняем
        // обе, даже если между ними встречаются слабые текстовые пики.
        for (i in 1 until clustered.size) {
            val gap0 = clustered[i].first - clustered.first().first
            if (gap0 in 18..45) {
                chosen.add(clustered[i].first)
                startIndex = i + 1
                break
            }
            if (gap0 > 45) break
        }

        var last = chosen.last()
        for (c in clustered.drop(startIndex)) {
            val gap = c.first - last
            if (gap in 28..105) {
                chosen.add(c.first)
                last = c.first
            } else if (gap < 28) {
                val prevScore = score[(last - yStart).coerceIn(0, score.lastIndex)]
                if (c.second > prevScore) {
                    chosen[chosen.lastIndex] = c.first
                    last = c.first
                }
            } else {
                // Большой разрыв допустим между двумя таблицами/блоками.
                chosen.add(c.first)
                last = c.first
            }
        }

        return chosen.distinct().sorted()
    }

    private data class CellOcr(val words: List<Word>, val confidence: Int, val score: Int)

    private fun ocrCellBest(api: TessBaseAPI, source: Bitmap, rect: Rect, kind: String): List<Word> {
        val crop = Bitmap.createBitmap(source, rect.left, rect.top, rect.width(), rect.height())
        val variants = ArrayList<Pair<String, Bitmap>>()
        // Увеличение маленькой ячейки критично: исходные цифры на фотографии имеют
        // высоту порядка 10–15 px. 2.5x даёт Tesseract намного больше деталей.
        val up = Bitmap.createScaledBitmap(crop, crop.width * 2, crop.height * 2, true)
        crop.recycle()
        variants.add("gray" to makeGray(up))
        variants.add("bin" to makeCellBinary(up))
        up.recycle()

        var best = CellOcr(emptyList(), -1, Int.MIN_VALUE)
        for ((name, bmp) in variants) {
            try {
                val psm = if (kind in setOf("callsign", "invoice", "weight", "sum", "fact", "debt", "agent"))
                    TessBaseAPI.PageSegMode.PSM_SINGLE_LINE
                else TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK
                api.setPageSegMode(psm)
                api.setImage(bmp)
                api.getUTF8Text()
                val words = readWords(api).map { Word(it.text, Rect(it.rect.left / 2 + rect.left, it.rect.top / 2 + rect.top, it.rect.right / 2 + rect.left, it.rect.bottom / 2 + rect.top), it.confidence) }
                val conf = api.meanConfidence()
                val score = cellScore(words, conf, kind)
                if (score > best.score) best = CellOcr(words, conf, score)
                api.clear()
            } finally {
                bmp.recycle()
            }
        }
        return best.words
    }

    private fun cellScore(words: List<Word>, confidence: Int, kind: String): Int {
        val text = words.joinToString(" ") { norm(it.text) }
        var s = confidence
        when (kind) {
            "callsign" -> if (words.any { callsignOf(it.text) != null }) s += 120
            "invoice" -> if (words.any { invoiceRegex.matches(norm(it.text)) }) s += 140
            "weight", "sum", "fact", "debt" -> if (words.any { num(norm(it.text)) != null }) s += 80
            "agent" -> if (Regex("\\d").containsMatchIn(text)) s += 40
            "client", "address", "notes" -> s += minOf(30, text.count { it in 'а'..'я' })
        }
        return s
    }

    private fun makeGray(src: Bitmap): Bitmap {
        val (gray, w, h) = toGray(src)
        val px = IntArray(w * h)
        for (i in px.indices) {
            val v = gray[i].toInt() and 0xFF
            px[i] = Color.rgb(v, v, v)
        }
        return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { it.setPixels(px, 0, w, 0, 0, w, h) }
    }

    private fun makeCellBinary(src: Bitmap): Bitmap {
        val (gray, w, h) = toGray(src)
        val bin = normalizedBinary(gray, w, h, 58)
        val px = IntArray(w * h)
        for (i in px.indices) px[i] = if (bin[i].toInt() == 1) Color.BLACK else Color.WHITE
        return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { it.setPixels(px, 0, w, 0, 0, w, h) }
    }

    /** Удаляет из общего OCR слова, которые лежат внутри табличного прямоугольника. */
    private fun mergeWords(cells: List<Word>, general: List<Word>, w: Int, h: Int): List<Word> {
        if (cells.isEmpty()) return general
        val l = w * 0.085f
        val r = w * 0.915f
        val t = h * 0.10f
        val b = h * 0.88f
        val result = ArrayList<Word>(general.size + cells.size)
        for (g in general) {
            val inside = g.cx in l..r && g.cy in t..b
            if (!inside) result.add(g)
        }
        result.addAll(cells)
        return result
    }

    /** Положение колонок (доли ширины фото) и y заголовка таблицы. */
    private fun detectColumns(words: List<Word>, imgW: Int): Pair<Map<String, Float>, Float>? {
        val keyMap = listOf(
            "вес" to "вес", "сумма" to "сумма", "факт" to "факт", "забрать" to "долг",
            "расчет" to "расчет", "замет" to "заметки", "агент" to "агент",
        )
        for (row in buildRows(words)) {
            val found = HashMap<String, Float>()
            for (w in row) {
                val t = norm(w.text)
                for ((prefix, name) in keyMap) {
                    if (t.startsWith(prefix) && !found.containsKey(name)) found[name] = w.cx / imgW
                }
            }
            if (found.size >= 4 && found.containsKey("вес")) {
                return found to row.map { it.cy }.average().toFloat()
            }
        }
        return null
    }

    private fun parsePage(pageNo: Int, words: List<Word>, imgW: Int, cols: Map<String, Float>?, headerY: Float?): Page {
        val rows = buildRows(words)
        val columns = cols

        // --- итоги, граница таблицы, контакты ---
        var cutY = Float.MAX_VALUE
        var sheetKg: Double? = null
        var sheetCash: Double? = null
        val contacts = LinkedHashMap<Int, String>()
        val numAfter = Regex("""\d+[.,]\d+""")
        for (row in rows) {
            val text = row.joinToString(" ") { it.text }
            val low = norm(text)
            val y = row.map { it.cy }.average().toFloat()
            if (low.contains("итого") && low.contains("вес")) {
                cutY = minOf(cutY, y - 4f)
                sheetKg = numAfter.find(low.substringAfter("вес"))?.value?.replace(',', '.')?.toDoubleOrNull()
            }
            if (low.contains("сдаче")) {
                sheetCash = numAfter.find(low.substringAfter("сдаче"))?.value?.replace(',', '.')?.toDoubleOrNull()
            }
            if (low.contains("документ")) cutY = minOf(cutY, y - 4f)
            contactRegex.find(text)?.let { m ->
                val agentNo = m.groupValues[1].toInt()
                contacts.putIfAbsent(agentNo, "${m.groupValues[2].trim()} +${m.groupValues[3]}")
            }
        }

        // --- якоря строк: номера накладных (АСП-…, НФФ-…) ---
        val data = words.filter { it.cy < cutY && (headerY == null || it.cy > headerY) }
        val invoiceWords = data.filter { invoiceRegex.matches(norm(it.text)) }.sortedBy { it.cy }
        val callsignWords = data.filter { callsignOf(it.text) != null }

        class Anchor(val cy: Float, val invoice: Word?)
        val anchors = ArrayList<Anchor>()
        invoiceWords.forEach { anchors.add(Anchor(it.cy, it)) }
        if (anchors.size >= 2) {
            val pitch = anchors.zipWithNext { a, b -> b.cy - a.cy }.sorted().let { it[it.size / 2] }
            val invX = invoiceWords.map { it.cx }.sorted()[invoiceWords.size / 2]
            for (c in callsignWords) {
                if (c.cx < invX && anchors.none { Math.abs(it.cy - c.cy) < pitch * 0.6f }) anchors.add(Anchor(c.cy, null))
            }
        } else {
            callsignWords.forEach { anchors.add(Anchor(it.cy, null)) }
        }
        anchors.sortBy { it.cy }

        val numericCols = listOf("вес", "сумма", "факт", "долг")
        val entries = ArrayList<Entry>()
        for ((i, a) in anchors.withIndex()) {
            val top = if (i == 0) -Float.MAX_VALUE else (anchors[i - 1].cy + a.cy) / 2f
            val bottom = if (i == anchors.lastIndex) Float.MAX_VALUE else (a.cy + anchors[i + 1].cy) / 2f
            val block = data.filter { it.cy >= top && it.cy < bottom }
            val raw = block.sortedWith(compareBy({ Math.round(it.cy / 6f) }, { it.rect.left })).joinToString(" ") { it.text }

            val invText = a.invoice?.let { norm(it.text) }
            val invM = invText?.let { invoiceRegex.find(it) }
            val prefix = invM?.groupValues?.get(1)
            val invoiceStr = invM?.let { it.groupValues[1].uppercase() + "-" + it.groupValues[2] }
            val invX = a.invoice?.cx ?: Float.MAX_VALUE

            // позывной: ближайший слева от накладной
            val cs = block.filter { it.cx < invX && callsignOf(it.text) != null }
                .minByOrNull { Math.abs(it.cy - a.cy) }
                ?.let { callsignOf(it.text) }

            // числа по колонкам
            var weight: Double? = null
            var cash = 0.0
            val numbers = block.mapNotNull { w -> num(w.text.trim('|', ' '))?.let { w to it } }
            if (cols != null && cols.containsKey("вес")) {
                val avail = numericCols.filter { cols.containsKey(it) }
                val weightCands = ArrayList<Pair<Word, Double>>()
                for ((w, v) in numbers) {
                    val x = w.cx / imgW
                    val nearest = avail.minByOrNull { Math.abs(x - cols.getValue(it)) } ?: continue
                    if (Math.abs(x - cols.getValue(nearest)) > 0.05f) continue
                    when (nearest) {
                        "вес" -> weightCands.add(w to v)
                        "факт" -> cash += v
                    }
                }
                weight = weightCands.minByOrNull { Math.abs(it.first.cy - a.cy) }?.second
            } else {
                weight = null // без заголовка колонки не определить
            }

            val low = norm(raw)
            val type = when {
                low.contains("возвр") -> "ВОЗВРАТ"
                low.contains("оборуд") -> "ОБОРУДОВАНИЕ"
                prefix == "асп" -> "АСП"
                prefix == "нфф" -> "НФФ"
                else -> null
            }

            val agentX = cols?.get("агент")
            val agent = block.filter { agentX == null || it.cx / imgW >= agentX - 0.03f }
                .mapNotNull { w -> agentRegex.find(norm(w.text))?.groupValues?.get(1)?.toIntOrNull()?.let { w to it } }
                .minByOrNull { Math.abs(it.first.cy - a.cy) }?.second

            entries.add(Entry(pageNo, cs, invoiceStr, weight, cash, type, agent, raw))
        }
        return Page(entries, columns, contacts, sheetKg, sheetCash)
    }

    // =====================================================================
    //  Проверка маршрута: физические точки
    // =====================================================================

    private class Acc {
        var delivery = 0.0
        var ret = 0.0
        var cash = 0.0
        var invoices = 0
        var equipment = false
        var hasReturn = false
        val parts = ArrayList<String>()
    }

    private fun f(v: Double) = String.format(Locale.US, "%.2f", v)

    private fun formatReport(
        entries: List<Entry>,
        points: Map<String, Point>,
        contacts: Map<Int, String>,
        totals: Totals,
    ): String {
        val acc = LinkedHashMap<String, Acc>()
        val doubtful = ArrayList<String>()
        var doubtfulKg = 0.0

        // Агенты, чей номер ведёт к Маврычеву: доверяем локальной базе без подтверждения.
        val mavAgents = contacts.filterValues { it.lowercase().contains("маврыч") }.keys
            .ifEmpty { setOf(1) }

        for (e in entries) {
            val w = e.weight?.let { f(it) + " кг" } ?: "вес ?"
            val head = "стр.${e.page} · ${e.invoice ?: "накл.?"} · $w"
            val cs = e.callsign
            val pid = cs?.let { callsignsMap[it] }
            val point = pid?.let { points[it] }

            // Подтверждение нужно, если в накладной нет АСП/возврат/оборудование и/или заполнен «Факт».
            // Исключение: агент — Маврычев.
            val typeOk = e.type == "АСП" || e.type == "ВОЗВРАТ" || e.type == "ОБОРУДОВАНИЕ"
            val needConfirm = (!typeOk || e.cash > 0) && e.agent !in mavAgents

            val problem: String? = when {
                cs == null -> "позывной не распознан"
                point == null -> "$cs нет в базе позывных"
                needConfirm -> {
                    val why = ArrayList<String>()
                    if (!typeOk) why.add("в накладной нет АСП/возврат/оборудование (${e.type ?: "тип не распознан"})")
                    if (e.cash > 0) why.add("заполнен «Факт» ${f(e.cash)}")
                    "$cs → ${point.id} ${point.name}: подтвердите, т.к. ${why.joinToString(" и ")}"
                }
                e.weight == null -> "$cs → ${point.id}: вес не распознан"
                else -> null
            }
            if (problem != null) {
                doubtful.add("⚠ $head\n     $problem")
                doubtfulKg += e.weight ?: 0.0
                continue
            }
            val a = acc.getOrPut(point!!.id) { Acc() }
            a.invoices++
            a.cash += e.cash
            a.parts.add("$cs ${e.weight?.let { f(it) } ?: "?"}")
            when (e.type) {
                "ВОЗВРАТ" -> { a.hasReturn = true; a.ret += e.weight ?: 0.0 }
                "ОБОРУДОВАНИЕ" -> a.equipment = true
                else -> a.delivery += e.weight ?: 0.0
            }
        }

        val sb = StringBuilder("ПРОВЕРКА МАРШРУТА\n\n")
        if (contacts.isNotEmpty()) {
            sb.append("📞 Контакты агентов\n")
            contacts.toSortedMap().forEach { (k, v) -> sb.append("   №$k  $v\n") }
            sb.append("   (номера телефонов OCR читает неточно — сверьте с листом)\n")
            sb.append('\n')
        }
        val ordered = acc.keys.sortedWith(compareBy({ it.takeLast(1) }, { it.dropLast(1).toIntOrNull() ?: 0 }))
        var totalKg = 0.0
        var totalCash = 0.0
        for (pid in ordered) {
            val a = acc.getValue(pid)
            val p = points.getValue(pid)
            totalKg += a.delivery
            totalCash += a.cash
            sb.append("✓ $pid  ${p.name}\n")
            sb.append("    ${p.address}\n")
            sb.append("    📦 ${f(a.delivery)} кг · накладных: ${a.invoices}")
            sb.append(if (a.cash > 0) " · 💵 ${f(a.cash)}" else " · 💳 безнал")
            sb.append('\n')
            if (a.hasReturn) sb.append("    ↩ возврат: ${f(a.ret)} кг\n")
            if (a.equipment) sb.append("    🔧 ОБОРУДОВАНИЕ (см. заметки)\n")
            if (a.invoices > 1) sb.append("    └ ${a.parts.joinToString("; ")}\n")
        }
        if (doubtful.isNotEmpty()) {
            sb.append("\n❓ ТРЕБУЕТ ПОДТВЕРЖДЕНИЯ / РЕШЕНИЯ (в точки не включено)\n")
            doubtful.forEach { sb.append(it).append('\n') }
        }
        sb.append("\nТочек: ${ordered.size} · сомнительных строк: ${doubtful.size}\n")
        sb.append("Товар в точках: ${f(totalKg)} кг · в сомнительных: ${f(doubtfulKg)} кг\n")
        sb.append("Наличные в точках: ${f(totalCash)}\n")
        totals.kg?.let { kg ->
            val sum = totalKg + doubtfulKg
            val ok = Math.abs(sum - kg) < 0.05
            sb.append("Контроль веса: по листу ${f(kg)} кг, распознано ${f(sum)} кг ${if (ok) "✓" else "⚠ не сходится"}\n")
        }
        totals.cash?.let { c -> sb.append("Всего к сдаче по листу: ${f(c)}\n") }
        return sb.toString().trimEnd()
    }

    // =====================================================================
    //  База
    // =====================================================================

    private fun loadDatabase(): Map<String, Point> {
        val points = HashMap<String, Point>()
        assets.open("points.csv").bufferedReader(Charsets.UTF_8).useLines { seq ->
            seq.drop(1).forEach { l ->
                val p = l.split(';')
                if (p.size >= 3) points[p[0].trim()] = Point(p[0].trim(), p[1].trim(), p[2].trim())
            }
        }
        val map = HashMap<String, String>()
        assets.open("callsigns.csv").bufferedReader(Charsets.UTF_8).useLines { seq ->
            seq.forEach { l ->
                val p = l.split(',')
                if (p.size >= 2) {
                    val key = p[0].trim().lowercase()
                    map[key] = p[1].trim().lowercase()
                }
            }
        }
        callsignsMap = map
        return points
    }

    // =====================================================================
    //  Модель и изображение
    // =====================================================================

    private val modelVersion = "tessdata_best-4.1.0-rus-eng-osd-v4-cells"

    private fun prepareTessdata() {
        val dir = File(filesDir, "tessdata")
        if (!dir.exists()) dir.mkdirs()
        val marker = File(dir, "models.version")
        val models = listOf(
            "rus.traineddata" to 5_000_000L,
            "eng.traineddata" to 5_000_000L,
            "osd.traineddata" to 500_000L,
        )
        if (!marker.exists() || marker.readText() != modelVersion || models.any { (name, minSize) ->
                val f = File(dir, name)
                !f.exists() || f.length() < minSize
            }) {
            for ((name, _) in models) {
                val dst = File(dir, name)
                dst.delete()
                assets.open("tessdata/$name").use { input ->
                    FileOutputStream(dst).use { output -> input.copyTo(output) }
                }
            }
            marker.writeText(modelVersion)
        }
        for ((name, minSize) in models) {
            val file = File(dir, name)
            if (file.length() < minSize) {
                error("В APK отсутствует корректная $name (размер: ${file.length()} байт)")
            }
        }
    }

    private fun loadBitmap(uri: Uri): Bitmap {
        val input = contentResolver.openInputStream(uri) ?: error("Не удалось открыть $uri")
        val original = input.use { BitmapFactory.decodeStream(it) }
            ?: error("Не удалось декодировать изображение")
        return rotateFromExif(uri, original)
    }

    private fun rotateFromExif(uri: Uri, bitmap: Bitmap): Bitmap {
        return try {
            val orientation = contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            rotateBitmap(bitmap, degrees).also { if (it !== bitmap) bitmap.recycle() }
        } catch (_: Exception) {
            bitmap
        }
    }

    /**
     * Убирает фон вокруг бумажного листа до OCR. Для наших фото это особенно важно:
     * тёмные бутылки/стол после бинаризации превращаются в «текстоподобные» пятна.
     * Это намеренно консервативный crop: если уверенности мало, исходник не трогаем.
     */
    private fun cropToDocument(src: Bitmap): Bitmap {
        val probe = scaleLong(src, 1000)
        val (gray, w, h) = toGray(probe)
        if (probe !== src) probe.recycle()
        val threshold = 180
        val rowLimit = w * 0.40
        val colLimit = h * 0.40
        var top = h
        var bottom = -1
        var left = w
        var right = -1
        for (y in 0 until h) {
            var bright = 0
            for (x in 0 until w) if ((gray[y * w + x].toInt() and 0xFF) >= threshold) bright++
            if (bright >= rowLimit) { top = minOf(top, y); bottom = maxOf(bottom, y) }
        }
        for (x in 0 until w) {
            var bright = 0
            for (y in 0 until h) if ((gray[y * w + x].toInt() and 0xFF) >= threshold) bright++
            if (bright >= colLimit) { left = minOf(left, x); right = maxOf(right, x) }
        }
        if (right <= left || bottom <= top) return src
        val sx = src.width.toFloat() / w
        val sy = src.height.toFloat() / h
        val marginX = (45 * sx).toInt()
        val marginY = (45 * sy).toInt()
        val l = (left * sx - marginX).toInt().coerceAtLeast(0)
        val t = (top * sy - marginY).toInt().coerceAtLeast(0)
        val r = (right * sx + marginX).toInt().coerceAtMost(src.width - 1)
        val b = (bottom * sy + marginY).toInt().coerceAtMost(src.height - 1)
        val area = (r - l).toLong() * (b - t).toLong()
        val originalArea = src.width.toLong() * src.height.toLong()
        if (area < originalArea * 0.45 || area > originalArea * 0.98) return src
        return Bitmap.createBitmap(src, l, t, r - l + 1, b - t + 1)
    }

    private fun scaleLong(src: Bitmap, target: Int): Bitmap {
        val k = target.toFloat() / maxOf(src.width, src.height)
        if (k >= 1f) return src
        return Bitmap.createScaledBitmap(src, (src.width * k).toInt().coerceAtLeast(1), (src.height * k).toInt().coerceAtLeast(1), true)
    }

    private fun rotateBitmap(src: Bitmap, deg: Float): Bitmap {
        if (deg == 0f) return src
        val m = Matrix().apply { postRotate(deg) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    /**
     * Лист часто снят «боком» или вверх ногами (в том числе из-за EXIF). Пробуем 4 поворота
     * на уменьшенной копии и берём тот, где OCR находит больше осмысленных русских слов.
     */
    /**
     * Для маршрутных листов фотография обычно сделана боком. Старый алгоритм сначала
     * кормил Tesseract всей фотографией вместе с бутылками/столом, поэтому иногда
     * выбиралась неверная ориентация. Теперь сначала сравниваем только 90/270 градусов,
     * затем обрезаем до листа и лишь после этого спрашиваем OCR.
     */
    private fun detectRotation(api: TessBaseAPI, bmp: Bitmap): Float {
        val small = scaleLong(bmp, 1800)
        var best = 90f
        var bestScore = Int.MIN_VALUE
        for (deg in floatArrayOf(90f, 270f)) {
            val r = rotateBitmap(small, deg)
            val cropped = cropToDocument(r)
            val probe = scaleLong(cropped, 1500)
            var score = Int.MIN_VALUE
            for (psm in intArrayOf(
                TessBaseAPI.PageSegMode.PSM_AUTO,
                TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK
            )) {
                api.setPageSegMode(psm)
                api.setImage(probe)
                val text = api.getUTF8Text() ?: ""
                score = maxOf(score, orientationScore(text) + api.meanConfidence())
                api.clear()
            }
            if (probe !== cropped) probe.recycle()
            if (cropped !== r) cropped.recycle()
            if (r !== small) r.recycle()
            if (score > bestScore) { bestScore = score; best = deg }
        }
        if (small !== bmp) small.recycle()
        return best
    }

    private fun orientationScore(text: String): Int {
        val low = fixLookalikes(text).lowercase()
        val words = Regex("""[а-яё]{4,}""").findAll(low).count()
        val keys = Regex("""асп[-–—]?\d{4,7}|нфф[-–—]?\d{4,7}|накладн|клиент|адрес|итого|\d{1,4}(юс|яв|юв)""").findAll(low).count()
        val headers = listOf("вес", "сумма", "факт", "агент", "заметки", "забрать", "расчет").count { low.contains(it) }
        val routeWords = listOf("маршрутный", "лист", "позывной", "клиент", "адрес").count { low.contains(it) }
        return words + 18 * keys + 10 * headers + 8 * routeWords
    }

    private fun toGray(bmp: Bitmap): Triple<ByteArray, Int, Int> {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val gray = ByteArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            gray[i] = ((299 * Color.red(c) + 587 * Color.green(c) + 114 * Color.blue(c)) / 1000).toByte()
        }
        return Triple(gray, w, h)
    }

    /**
     * Бинаризация с нормализацией фона: фон оценивается локальным максимумом яркости (окно ~±12 px),
     * пиксель — текст, если он темнее 55% фона. Серые полосы таблицы и тени не превращаются в чёрные пятна.
     */
    private fun normalizedBinary(gray: ByteArray, w: Int, h: Int, thresholdPercent: Int = 55): ByteArray {
        val f = 2
        val rad = 6
        val bw = (w + f - 1) / f
        val bh = (h + f - 1) / f
        val bm = ByteArray(bw * bh)
        for (by in 0 until bh) for (bx in 0 until bw) {
            var m = 0
            for (dy in 0 until f) {
                val y = by * f + dy
                if (y >= h) break
                for (dx in 0 until f) {
                    val x = bx * f + dx
                    if (x >= w) break
                    val v = gray[y * w + x].toInt() and 0xFF
                    if (v > m) m = v
                }
            }
            bm[by * bw + bx] = m.toByte()
        }
        val tmp = ByteArray(bw * bh)
        for (y in 0 until bh) for (x in 0 until bw) {
            var m = 0
            for (xx in (x - rad).coerceAtLeast(0)..(x + rad).coerceAtMost(bw - 1)) {
                val v = bm[y * bw + xx].toInt() and 0xFF
                if (v > m) m = v
            }
            tmp[y * bw + x] = m.toByte()
        }
        val bg = ByteArray(bw * bh)
        for (y in 0 until bh) for (x in 0 until bw) {
            var m = 0
            for (yy in (y - rad).coerceAtLeast(0)..(y + rad).coerceAtMost(bh - 1)) {
                val v = tmp[yy * bw + x].toInt() and 0xFF
                if (v > m) m = v
            }
            bg[y * bw + x] = m.toByte()
        }
        val out = ByteArray(w * h)
        for (y in 0 until h) {
            val row = (y / f) * bw
            for (x in 0 until w) {
                val b = bg[row + x / f].toInt() and 0xFF
                if ((gray[y * w + x].toInt() and 0xFF) * 100 < thresholdPercent.coerceIn(35, 85) * b) out[y * w + x] = 1
            }
        }
        return out
    }

    /** Угол наклона строк по профилю проекции тёмных точек (градусы, по часовой стрелке для Matrix.postRotate). */
    private fun estimateSkew(src: Bitmap): Float {
        val t = scaleLong(src, 1400)
        val (gray, w, h) = toGray(t)
        if (t !== src) t.recycle()
        val bin = normalizedBinary(gray, w, h, 62)
        removeLines(bin, w, h, (w / 45).coerceAtLeast(35))
        var n = 0
        for (b in bin) if (b.toInt() == 1) n++
        if (n == 0) return 0f
        val dx = IntArray(n)
        val dy = IntArray(n)
        var k = 0
        for (y in 0 until h) for (x in 0 until w) if (bin[y * w + x].toInt() == 1) { dx[k] = x; dy[k] = y; k++ }

        fun score(deg: Float): Double {
            val rad = Math.toRadians(deg.toDouble())
            val s = Math.sin(rad)
            val c = Math.cos(rad)
            val off = w + 10
            val hist = IntArray(h + 2 * off)
            for (i in 0 until n) hist[(dx[i] * s + dy[i] * c + off).toInt()]++
            var sc = 0.0
            for (v in hist) sc += v.toDouble() * v
            return sc
        }

        var best = 0f
        var bestScore = score(0f)
        var a = -6f
        while (a <= 6f) { val s = score(a); if (s > bestScore) { bestScore = s; best = a }; a += 0.5f }
        val center = best
        a = center - 0.5f
        while (a <= center + 0.5f) { val s = score(a); if (s > bestScore) { bestScore = s; best = a }; a += 0.1f }
        return best
    }

    private fun deskew(src: Bitmap, deg: Float): Bitmap {
        if (Math.abs(deg) < 0.15f) return src
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawColor(Color.WHITE)
        val m = Matrix().apply { postRotate(deg, src.width / 2f, src.height / 2f) }
        canvas.drawBitmap(src, m, null)
        return out
    }

    /** Стирает длинные горизонтальные и вертикальные чёрные отрезки (линии таблицы), чтобы они не склеивали текст. */
    private fun removeLines(bin: ByteArray, w: Int, h: Int, minRun: Int) {
        for (y in 0 until h) {
            var x = 0
            while (x < w) {
                if (bin[y * w + x].toInt() == 1) {
                    var e = x
                    while (e < w && bin[y * w + e].toInt() == 1) e++
                    if (e - x >= minRun) for (i in x until e) bin[y * w + i] = 0
                    x = e
                } else x++
            }
        }
        for (x in 0 until w) {
            var y = 0
            while (y < h) {
                if (bin[y * w + x].toInt() == 1) {
                    var e = y
                    while (e < h && bin[e * w + x].toInt() == 1) e++
                    if (e - y >= minRun) for (i in y until e) bin[i * w + x] = 0
                    y = e
                } else y++
            }
        }
    }

    /** Масштаб (только вниз) до 3200 px + адаптивная бинаризация: убирает тени и серые полосы таблицы. */
    private fun preprocessForOcr(source: Bitmap, thresholdPercent: Int = 55): Bitmap {
        val scaled = scaleLong(source, 3600)
        val (gray, w, h) = toGray(scaled)
        if (scaled !== source) scaled.recycle()
        val bin = normalizedBinary(gray, w, h, thresholdPercent)
        removeLines(bin, w, h, (w / 45).coerceAtLeast(45))
        val px = IntArray(w * h)
        for (i in px.indices) px[i] = if (bin[i].toInt() == 1) Color.BLACK else Color.WHITE
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }
}
