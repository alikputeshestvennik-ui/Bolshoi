package ru.routeplanner

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var runOcr: Button
    private lateinit var apiKeyInput: EditText
    private lateinit var folderInput: EditText
    private var selected: List<Uri> = emptyList()

    private var callsignsMap: Map<String, String> = emptyMap()
    private data class Point(val id: String, val name: String, val address: String)

    private val picker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        selected = uris
        runOcr.isEnabled = uris.isNotEmpty()
        status.text = if (uris.isEmpty()) "Фото не выбраны." else "Выбрано страниц: ${uris.size}"
        result.text = ""
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        result = findViewById(R.id.result)
        runOcr = findViewById(R.id.runOcr)
        apiKeyInput = findViewById(R.id.apiKey)
        folderInput = findViewById(R.id.folderId)

        val prefs = getSharedPreferences("qwen", MODE_PRIVATE)
        apiKeyInput.setText(prefs.getString("apiKey", ""))
        folderInput.setText(prefs.getString("folderId", ""))

        findViewById<Button>(R.id.selectPhotos).setOnClickListener {
            picker.launch(arrayOf("image/jpeg", "image/png", "image/webp"))
        }
        runOcr.setOnClickListener { runQwen() }
    }

    private fun publish(msg: String) = runOnUiThread { status.text = msg }

    private fun runQwen() {
        val apiKey = apiKeyInput.text.toString().trim()
        val folderId = folderInput.text.toString().trim()
        if (apiKey.isBlank() || folderId.isBlank()) {
            status.text = "Введите API-ключ Yandex AI Studio и ID каталога."
            return
        }
        if (selected.isEmpty()) return

        getSharedPreferences("qwen", MODE_PRIVATE).edit()
            .putString("apiKey", apiKey)
            .putString("folderId", folderId)
            .apply()

        runOcr.isEnabled = false
        status.text = "Отправляю фото в Qwen3.6-35B…"
        lifecycleScope.launch {
            try {
                val report = withContext(Dispatchers.IO) { recognizeWithQwen(apiKey, folderId) }
                result.text = report
                status.text = "Готово. Qwen обработал страниц: ${selected.size}"
            } catch (e: Throwable) {
                status.text = "Ошибка Qwen API"
                result.text = e.message ?: e.stackTraceToString()
            } finally {
                runOcr.isEnabled = selected.isNotEmpty()
            }
        }
    }

    private fun recognizeWithQwen(apiKey: String, folderId: String): String {
        val points = loadDatabase()
        val images = selected.mapIndexed { index, uri ->
            publish("Страница ${index + 1}/${selected.size}: подготавливаю фото…")
            imageToDataUri(uri)
        }

        val prompt = """
Ты — высокоточный оператор распознавания русских маршрутных листов. На входе одна или несколько фотографий таблицы.

Главная задача — ЧИТАТЬ ТО, ЧТО ВИДНО НА ФОТО, а не угадывать смысл.
Не выполняй ручное выравнивание и не требуй от пользователя обрезать или поворачивать фото.
Сохраняй порядок страниц и порядок строк таблицы.
Не исправляй сомнительные символы по смыслу. Если значение действительно невозможно прочитать, используй NULL.

Верни ТОЛЬКО строки следующего формата, без Markdown, комментариев и пояснений:
PAGE|номер страницы
CONTACT|номер агента|имя|телефон
TOTAL|вес|сумма
ROW|позывной|накладная|вес|факт|тип|агент|исходная строка

Правила:
- Для пустого или нечитабельного поля используй NULL.
- Позывной копируй точно как на фото, включая кириллицу и цифры.
- Накладную сохраняй с префиксом АСП- или НФФ-, если он виден.
- Вес и факт — только число, десятичный разделитель точка. Не добавляй кг или руб.
- Тип: АСП, НФФ, ВОЗВРАТ, ОБОРУДОВАНИЕ или NULL.
- Агент — номер агента, если он указан в строке.
- В поле «исходная строка» дай максимально точную транскрипцию строки, включая видимые дополнительные колонки/заметки.
- Заголовки, строки «Итого», «Документы на подпись» и прочий служебный текст не оформляй как ROW.
- Не создавай ROW, если в строке нет признаков записи маршрутного листа.
- Если страниц несколько, перед данными каждой страницы выведи PAGE|N.
""".trimIndent()

        val content = JSONArray()
        content.put(JSONObject().put("type", "input_text").put("text", prompt))
        images.forEach { dataUri ->
            content.put(
                JSONObject()
                    .put("type", "input_image")
                    .put("image_url", dataUri)
                    .put("detail", "auto")
            )
        }

        val input = JSONArray().put(
            JSONObject()
                .put("role", "user")
                .put("content", content)
        )

        val body = JSONObject()
            .put("model", "gpt://$folderId/qwen3.6-35b-a3b")
            .put("input", input)

        publish("Qwen3.6-35B распознаёт ${selected.size} ${pageWord(selected.size)}…")
        val raw = postResponses(apiKey, folderId, body.toString())
        val text = extractOutputText(raw)
        if (text.isBlank()) error("Qwen вернул пустой ответ. Полный ответ: $raw")

        return buildRouteReport(text, points)
    }

    private fun postResponses(apiKey: String, folderId: String, json: String): String {
        val conn = (URL("https://ai.api.cloud.yandex.net/v1/responses").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout = 180_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Api-Key $apiKey")
            setRequestProperty("OpenAI-Project", folderId)
        }
        try {
            conn.outputStream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) error("HTTP $code: $response")
            return response
        } finally {
            conn.disconnect()
        }
    }

    private fun extractOutputText(raw: String): String {
        val root = JSONObject(raw)
        root.optString("output_text").takeIf { it.isNotBlank() }?.let { return it }
        val output = root.optJSONArray("output") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val c = content.optJSONObject(j) ?: continue
                val t = c.optString("text")
                if (t.isNotBlank()) {
                    if (sb.isNotEmpty()) sb.append('\n')
                    sb.append(t)
                }
            }
        }
        return sb.toString()
    }

    private data class Entry(
        val page: Int,
        val callsign: String?,
        val invoice: String?,
        val weight: Double?,
        val cash: Double,
        val type: String?,
        val agent: Int?,
        val raw: String,
    )

    private data class Totals(var kg: Double? = null, var cash: Double? = null)

    private fun buildRouteReport(text: String, points: Map<String, Point>): String {
        val entries = ArrayList<Entry>()
        val contacts = LinkedHashMap<Int, String>()
        val totals = Totals()
        var page = 1
        val rawLines = ArrayList<String>()

        text.replace("```", "").lines().forEach { original ->
            val line = original.trim()
            if (line.isBlank()) return@forEach
            rawLines.add(line)
            val p = line.split('|')
            when (p.firstOrNull()?.uppercase(Locale.ROOT)) {
                "PAGE" -> p.getOrNull(1)?.toIntOrNull()?.let { page = it }
                "CONTACT" -> {
                    val n = p.getOrNull(1)?.toIntOrNull()
                    if (n != null) {
                        val name = p.getOrNull(2)?.trim().orEmpty()
                        val phone = p.getOrNull(3)?.trim().orEmpty()
                        contacts.putIfAbsent(n, listOf(name, phone).filter { it.isNotBlank() }.joinToString(" "))
                    }
                }
                "TOTAL" -> {
                    totals.kg = parseNum(p.getOrNull(1)) ?: totals.kg
                    totals.cash = parseNum(p.getOrNull(2)) ?: totals.cash
                }
                "ROW" -> {
                    val cs = cleanField(p.getOrNull(1))
                    val inv = cleanField(p.getOrNull(2))
                    val weight = parseNum(p.getOrNull(3))
                    val cash = parseNum(p.getOrNull(4)) ?: 0.0
                    val type = cleanField(p.getOrNull(5))
                    val agent = cleanField(p.getOrNull(6))?.toIntOrNull()
                    val raw = p.drop(7).joinToString("|").trim()
                    entries.add(Entry(page, cs, inv, weight, cash, type, agent, raw))
                }
            }
        }

        val report = formatReport(entries, points, contacts, totals)
        return report + "\n──────── Ответ Qwen (как получен) ────────\n" + rawLines.joinToString("\n")
    }

    private fun cleanField(s: String?): String? = s?.trim()?.takeIf { it.isNotEmpty() && !it.equals("NULL", true) }

    private fun parseNum(s: String?): Double? = s?.trim()?.replace(',', '.')?.toDoubleOrNull()

    private class Acc {
        var delivery = 0.0
        var ret = 0.0
        var cash = 0.0
        var invoices = 0
        var equipment = false
        var hasReturn = false
        val parts = ArrayList<String>()
    }

    private fun f(v: Double) = String.format(Locale.US, "%.2f", v)

    private fun formatReport(
        entries: List<Entry>,
        points: Map<String, Point>,
        contacts: Map<Int, String>,
        totals: Totals,
    ): String {
        val acc = LinkedHashMap<String, Acc>()
        val doubtful = ArrayList<String>()
        var doubtfulKg = 0.0

        for (e in entries) {
            val w = e.weight?.let { f(it) + " кг" } ?: "вес ?"
            val head = "стр.${e.page} · ${e.invoice ?: "накл.?"} · $w"
            val cs = e.callsign
            val normalizedCs = cs?.let { normalizeCallsign(it) }
            val pid = normalizedCs?.let { callsignsMap[it] }
            val point = pid?.let { points[it] }
            val typeOk = e.type == "АСП" || e.type == "ВОЗВРАТ" || e.type == "ОБОРУДОВАНИЕ" || e.type == "НФФ"
            val needConfirm = (!typeOk || e.cash > 0) && e.agent != 1

            val problem: String? = when {
                cs == null -> "позывной не распознан"
                point == null -> "$cs нет в базе позывных"
                needConfirm -> {
                    val why = ArrayList<String>()
                    if (!typeOk) why.add("тип не распознан")
                    if (e.cash > 0) why.add("заполнен «Факт» ${f(e.cash)}")
                    "$cs → ${point.id} ${point.name}: подтвердите, т.к. ${why.joinToString(" и ") }"
                }
                e.weight == null -> "$cs → ${point.id}: вес не распознан"
                else -> null
            }
            if (problem != null) {
                doubtful.add("⚠ $head\n     $problem\n     ${e.raw}")
                doubtfulKg += e.weight ?: 0.0
                continue
            }
            val a = acc.getOrPut(point!!.id) { Acc() }
            a.invoices++
            a.cash += e.cash
            a.parts.add("${e.callsign} ${e.weight?.let { f(it) } ?: "?"}")
            when (e.type) {
                "ВОЗВРАТ" -> { a.hasReturn = true; a.ret += e.weight ?: 0.0 }
                "ОБОРУДОВАНИЕ" -> a.equipment = true
                else -> a.delivery += e.weight ?: 0.0
            }
        }

        val sb = StringBuilder("ПРОВЕРКА МАРШРУТА\n\n")
        if (contacts.isNotEmpty()) {
            sb.append("📞 Контакты агентов\n")
            contacts.toSortedMap().forEach { (k, v) -> sb.append("   №$k  $v\n") }
            sb.append('\n')
        }
        val ordered = acc.keys.sortedWith(compareBy({ it.takeLast(1) }, { it.dropLast(1).toIntOrNull() ?: 0 }))
        var totalKg = 0.0
        var totalCash = 0.0
        for (pid in ordered) {
            val a = acc.getValue(pid)
            val p = points.getValue(pid)
            totalKg += a.delivery
            totalCash += a.cash
            sb.append("✓ $pid  ${p.name}\n")
            sb.append("    ${p.address}\n")
            sb.append("    📦 ${f(a.delivery)} кг · накладных: ${a.invoices}")
            sb.append(if (a.cash > 0) " · 💵 ${f(a.cash)}" else " · 💳 безнал")
            sb.append('\n')
            if (a.hasReturn) sb.append("    ↩ возврат: ${f(a.ret)} кг\n")
            if (a.equipment) sb.append("    🔧 ОБОРУДОВАНИЕ (см. заметки)\n")
            if (a.invoices > 1) sb.append("    └ ${a.parts.joinToString("; ")}\n")
        }
        if (doubtful.isNotEmpty()) {
            sb.append("\n❓ ТРЕБУЕТ ПОДТВЕРЖДЕНИЯ / РЕШЕНИЯ (в точки не включено)\n")
            doubtful.forEach { sb.append(it).append('\n') }
            sb.append("   Сомнительный вес: ${f(doubtfulKg)} кг\n")
        }
        sb.append("\nИТОГ ПО ПРИНЯТЫМ ТОЧКАМ: ${f(totalKg)} кг")
        if (totalCash > 0) sb.append(" · наличные ${f(totalCash)}")
        totals.kg?.let { sb.append("\nИТОГО ВЕС НА ЛИСТЕ: ${f(it)} кг") }
        totals.cash?.let { sb.append("\nВСЕГО К СДАЧЕ НА ЛИСТЕ: ${f(it)}") }
        if (totals.kg != null) sb.append("\nСВЕРКА ВЕСА: ${f(totalKg)} / ${f(totals.kg!!)} кг")
        return sb.toString()
    }

    private fun normalizeCallsign(raw: String): String {
        val s = raw.lowercase(Locale.ROOT).replace('ё', 'е').trim()
            .replace('—', '-').replace('–', '-')
        return s.removePrefix("позывной").trim().replace(" ", "")
    }

    private fun loadDatabase(): Map<String, Point> {
        val points = HashMap<String, Point>()
        assets.open("points.csv").bufferedReader(Charsets.UTF_8).useLines { seq ->
            seq.drop(1).forEach { l ->
                val p = l.split(';')
                if (p.size >= 3) points[p[0].trim()] = Point(p[0].trim(), p[1].trim(), p[2].trim())
            }
        }
        val map = HashMap<String, String>()
        assets.open("callsigns.csv").bufferedReader(Charsets.UTF_8).useLines { seq ->
            seq.forEach { l ->
                val p = l.split(',')
                if (p.size >= 2) map[normalizeCallsign(p[0])] = p[1].trim()
            }
        }
        callsignsMap = map
        return points
    }

    private fun imageToDataUri(uri: Uri): String {
        val bitmap = loadBitmap(uri)
        val maxLong = 5200
        val scaled = scaleLong(bitmap, maxLong)
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 92, out)
        if (scaled !== bitmap) scaled.recycle()
        bitmap.recycle()
        val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        return "data:image/jpeg;base64,$b64"
    }

    private fun loadBitmap(uri: Uri): Bitmap {
        val input = contentResolver.openInputStream(uri) ?: error("Не удалось открыть $uri")
        val original = input.use { BitmapFactory.decodeStream(it) }
            ?: error("Не удалось декодировать изображение")
        return rotateFromExif(uri, original)
    }

    private fun rotateFromExif(uri: Uri, bitmap: Bitmap): Bitmap {
        return try {
            val orientation = contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (degrees == 0f) bitmap else rotateBitmap(bitmap, degrees).also { bitmap.recycle() }
        } catch (_: Exception) {
            bitmap
        }
    }

    private fun scaleLong(src: Bitmap, target: Int): Bitmap {
        val k = target.toFloat() / maxOf(src.width, src.height)
        if (k >= 1f) return src
        return Bitmap.createScaledBitmap(
            src,
            (src.width * k).toInt().coerceAtLeast(1),
            (src.height * k).toInt().coerceAtLeast(1),
            true
        )
    }

    private fun rotateBitmap(src: Bitmap, deg: Float): Bitmap {
        val m = Matrix().apply { postRotate(deg) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    private fun pageWord(n: Int): String = when {
        n % 10 == 1 && n % 100 != 11 -> "страницу"
        n % 10 in 2..4 && n % 100 !in 12..14 -> "страницы"
        else -> "страниц"
    }
}
