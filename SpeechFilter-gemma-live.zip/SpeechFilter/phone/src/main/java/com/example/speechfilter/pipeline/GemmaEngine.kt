package com.example.speechfilter.pipeline

import android.content.Context
import android.net.Uri
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Offline Gemma engine backed by Google's MediaPipe LLM Inference API
 * (com.google.mediapipe:tasks-genai). Runs a locally imported Gemma
 * checkpoint (.task / .bin, and .gguf as a raw path passthrough) entirely
 * on-device — no network calls, no server round-trip.
 *
 * Expected model path: filesDir/models/gemma-model.{task|gguf|bin}
 *
 * The native model is expensive to load (a multi-hundred-MB to multi-GB
 * file), so it is kept in a process-wide singleton shared across every
 * GemmaEngine(context) instance/worker run instead of being reloaded from
 * disk each time RefineWorker/ImportantWorker/DailySummaryWorker fire.
 */
class GemmaEngine(private val context: Context) {

    companion object {
        // Sanity floor so a wrong/partial file pick doesn't get accepted as a model.
        // Real quantized Gemma checkpoints (.task/.gguf/.bin) are realistically
        // >100MB; 20MB just rejects obviously-wrong picks (images, docs, etc).
        private const val MIN_MODEL_BYTES = 20L * 1024L * 1024L
        private val EXTS = setOf("task", "gguf", "bin")

        private const val MAX_TOKENS = 1024
        private const val TOP_K = 40
        private const val TEMPERATURE = 0.7f

        private val initLock = Any()

        // Shared across all GemmaEngine instances/threads in this process.
        @Volatile private var sharedInference: LlmInference? = null
        @Volatile private var sharedInferenceModelPath: String? = null
        @Volatile private var sharedInferenceError: String? = null
    }

    private val warmed = AtomicBoolean(false)

    fun modelDir(): File = File(context.filesDir, "models").apply { mkdirs() }

    private fun isGemmaFile(f: File): Boolean {
        val n = f.name.lowercase()
        return n.startsWith("gemma") && EXTS.any { n.endsWith(".$it") }
    }

    private fun existingModelFile(): File? = modelDir().listFiles()?.firstOrNull(::isGemmaFile)

    fun modelReady(): Boolean = existingModelFile()?.let { it.length() > MIN_MODEL_BYTES } == true

    fun modelFile(): File? = existingModelFile()

    /** Import a user-selected Gemma model (.task / .gguf / .bin) into app-private storage. */
    @Synchronized
    fun importModel(uri: Uri, displayName: String?): Result<File> = runCatching {
        release(dropShared = true)
        val ext = displayName
            ?.substringAfterLast('.', "")
            ?.lowercase()
            ?.takeIf { it in EXTS } ?: "task"

        // Replace any previously imported Gemma model (whatever extension it had).
        modelDir().listFiles()?.forEach { if (isGemmaFile(it)) it.delete() }

        val out = File(modelDir(), "gemma-model.$ext")
        val tmp = File(modelDir(), "gemma-model.$ext.tmp")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(tmp).use { output -> input.copyTo(output) }
        } ?: error("Не удалось открыть выбранный файл")
        if (tmp.length() < MIN_MODEL_BYTES) {
            tmp.delete()
            error("Файл слишком маленький для модели Gemma: ${tmp.length()} байт")
        }
        if (!tmp.renameTo(out)) {
            tmp.copyTo(out, overwrite = true)
            tmp.delete()
        }
        out
    }

    /** Loads (or reuses) the shared native LlmInference engine for [modelPath]. */
    private fun ensureLoaded(modelPath: String) {
        synchronized(initLock) {
            if (sharedInference != null && sharedInferenceModelPath == modelPath) return
            sharedInference?.let { runCatching { it.close() } }
            sharedInference = null
            sharedInferenceModelPath = null
            sharedInferenceError = null
            try {
                val options = LlmInferenceOptions.builder()
                    .setModelPath(modelPath)
                    .setMaxTokens(MAX_TOKENS)
                    .setMaxTopK(TOP_K)
                    .build()
                sharedInference = LlmInference.createFromOptions(context.applicationContext, options)
                sharedInferenceModelPath = modelPath
            } catch (t: Throwable) {
                sharedInferenceError = t.message ?: t.toString()
                throw t
            }
        }
    }

    @Synchronized
    fun warmUp(): String {
        val model = existingModelFile()
        if (model == null) {
            warmed.set(false)
            return "Gemma: модель не найдена в ${modelDir().absolutePath}"
        }
        return try {
            ensureLoaded(model.absolutePath)
            warmed.set(true)
            "Gemma: модель загружена (${model.name})"
        } catch (t: Throwable) {
            warmed.set(false)
            "Gemma: ошибка загрузки модели — ${t.message ?: t.toString()}"
        }
    }

    /**
     * Runs prompt+text through the real on-device Gemma model via MediaPipe's
     * LLM Inference API and returns the generated text.
     */
    @Synchronized
    fun generate(promptTemplate: String, text: String): Result<String> {
        if (text.isBlank()) return Result.success("")
        val model = existingModelFile()
            ?: return Result.failure(IllegalStateException("Нет модели Gemma в ${modelDir()}"))
        return try {
            ensureLoaded(model.absolutePath)
            warmed.set(true)
            val engine = sharedInference
                ?: return Result.failure(IllegalStateException("Gemma engine не инициализирован"))
            val prompt = PromptStore.fill(promptTemplate, text)
            val response = engine.generateResponse(prompt)
            Result.success(response?.trim().orEmpty())
        } catch (t: Throwable) {
            warmed.set(false)
            Result.failure(t)
        }
    }

    /**
     * Marks this handle as not-warm. The shared native model stays resident
     * (loading it is expensive) unless [dropShared] is true, e.g. right
     * before importing a different model file.
     */
    fun release(dropShared: Boolean = false) {
        warmed.set(false)
        if (dropShared) {
            synchronized(initLock) {
                sharedInference?.let { runCatching { it.close() } }
                sharedInference = null
                sharedInferenceModelPath = null
            }
        }
    }
}
