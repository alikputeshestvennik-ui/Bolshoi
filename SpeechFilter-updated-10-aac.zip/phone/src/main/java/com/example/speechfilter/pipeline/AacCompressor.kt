package com.example.speechfilter.pipeline

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import com.example.speechfilter.AppPrefs
import com.example.speechfilter.data.AppDatabase
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * Compresses transcribed WAV files to AAC-LC (M4A container) while charging,
 * then deletes the original WAV and rewrites DB paths.
 *
 * 16 kHz mono PCM16 WAV ≈ 256 kbps → AAC-LC speech at 32 kbps ≈ 8× smaller by bitrate.
 * Media3/ExoPlayer plays M4A/AAC natively.
 */
object AacCompressor {

    private const val MIME = "audio/mp4a-latm"
    private const val BITRATE = 32_000
    private const val SAMPLE_RATE = 16_000
    private const val CHANNELS = 1

    private val executor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "aac-compress").apply { isDaemon = true }
    }
    private val inFlight = AtomicInteger(0)

    fun enqueue(context: Context) {
        if (!AppPrefs.isCompressOnCharge(context)) {
            PipelineLog.add(context, "compress", "Сжатие выключено в настройках — пропуск")
            return
        }
        // Only run while charging (PowerMode.AC) — keeps CPU off battery.
        if (PowerMode.effective(context) != PowerMode.AC) return
        val app = context.applicationContext
        if (inFlight.get() > 0) return
        inFlight.incrementAndGet()
        try {
            executor.execute {
                try {
                    runPending(app)
                } catch (t: Throwable) {
                    PipelineProgress.clearAllForStage("Сжатие")
                    PipelineLog.add(app, "compress", "crash: ${t.javaClass.simpleName}: ${t.message}")
                } finally {
                    inFlight.decrementAndGet()
                }
            }
        } catch (t: Throwable) {
            inFlight.decrementAndGet()
            PipelineLog.add(app, "compress", "очередь: ${t.message}")
        }
    }

    private fun runPending(context: Context) {
        val dir = File(context.getExternalFilesDir(null), "SpeechFilter")
        if (!dir.isDirectory) return
        val db = AppDatabase.get(context)

        val wavs = dir.listFiles { f ->
            f.isFile && f.name.endsWith(".wav", ignoreCase = true)
        }?.sortedBy { it.lastModified() } ?: emptyList()

        var ok = 0
        var skip = 0
        var fail = 0
        val eligible = wavs.filter { wav ->
            val transcript = runBlocking { db.transcripts().byPath(wav.absolutePath) }
            transcript != null &&
                transcript.status != "failed" &&
                wav.name != com.example.speechfilter.RecordingService.recordingFileName &&
                isFinalizedWav(wav)
        }
        val total = eligible.size
        var current = 0
        if (total > 0) {
            PipelineLog.add(context, "compress", "Запуск сжатия: ${total} " + if (total == 1) "запись" else "записей")
        }
        for (wav in wavs) {
            if (PowerMode.effective(context) != PowerMode.AC) {
                PipelineLog.add(context, "compress", "Зарядка отключена — сжатие остановлено")
                break
            }
            if (!AppPrefs.isCompressOnCharge(context)) break

            // Only compress files that already have a successful transcript.
            val transcript = runBlocking {
                db.transcripts().byPath(wav.absolutePath)
            }
            if (transcript == null || transcript.status == "failed") {
                skip++
                continue
            }
            // Skip open recording file
            if (wav.name == com.example.speechfilter.RecordingService.recordingFileName) {
                skip++
                continue
            }
            if (!isFinalizedWav(wav)) {
                skip++
                continue
            }

            current++
            PipelineProgress.update(
                wav.absolutePath,
                "Сжатие",
                current,
                total.coerceAtLeast(1),
                0f
            )
            PipelineLog.add(
                context, "compress",
                if (total > 1) "Сжимаю: ${wav.name} ($current/$total)" else "Сжимаю: ${wav.name}"
            )

            val compressed = File(dir, wav.nameWithoutExtension + ".m4a")
            if (compressed.exists() && compressed.length() > 500L) {
                // Already compressed somehow — still replace path & drop wav
                remapAndDelete(context, wav, compressed)
                PipelineProgress.clear(wav.absolutePath)
                ok++
                continue
            }

            val sourceBytes = wav.length()
            val result = compressWavToAac(wav, compressed)
            if (result.isSuccess) {
                val out = result.getOrThrow()
                val ratio = if (sourceBytes > 0) "×${"%.1f".format(sourceBytes.toDouble() / out.length().coerceAtLeast(1))}" else ""
                remapAndDelete(context, wav, out)
                PipelineProgress.update(wav.absolutePath, "Сжатие", current, total.coerceAtLeast(1), 1f)
                PipelineLog.add(
                    context, "compress",
                    "Готово: ${out.name} (${out.length() / 1024} КБ $ratio)" +
                        if (total > 1) " · $current/$total" else ""
                )
                PipelineProgress.clear(wav.absolutePath)
                ok++
            } else {
                PipelineLog.add(
                    context, "compress",
                    "Ошибка ${wav.name}: ${result.exceptionOrNull()?.message}" +
                        if (total > 1) " · $current/$total" else ""
                )
                PipelineProgress.clear(wav.absolutePath)
                if (compressed.exists()) compressed.delete()
                fail++
            }
        }
        PipelineProgress.clearAllForStage("Сжатие")
        if (ok + fail > 0) {
            PipelineLog.add(context, "compress", "Сжатие: ok=$ok fail=$fail skip=$skip")
        }
    }

    private fun remapAndDelete(context: Context, wav: File, compressed: File) {
        val db = AppDatabase.get(context)
        runBlocking {
            db.transcripts().updatePath(wav.absolutePath, compressed.absolutePath, compressed.name)
            if (db.important().isMarked(wav.absolutePath)) {
                db.important().unmark(wav.absolutePath)
                db.important().mark(
                    com.example.speechfilter.data.ImportantRecordingEntity(compressed.absolutePath)
                )
            }
        }
        // Stop playback of the WAV if it was playing
        com.example.speechfilter.PlaybackController.stopIfPlaying(wav)
        if (wav.exists()) wav.delete()
    }

    /**
     * Encode 16-bit mono WAV → AAC-LC in an M4A/MP4 container.
     * Uses the platform MP4 muxer; no external codec library is required.
     */
    fun compressWavToAac(wav: File, out: File): Result<File> = runCatching {
        

        val pcm = readPcm16Mono(wav)
        if (pcm.isEmpty()) error("empty PCM")

        val format = MediaFormat.createAudioFormat(MIME, SAMPLE_RATE, CHANNELS).apply {
            setInteger(MediaFormat.KEY_BIT_RATE, BITRATE)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 4096)
            setInteger(
                MediaFormat.KEY_AAC_PROFILE,
                MediaCodecInfo.CodecProfileLevel.AACObjectLC
            )
        }

        val codec = MediaCodec.createEncoderByType(MIME)
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()

        if (out.exists()) out.delete()
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1
        var muxerStarted = false

        try {
            var offset = 0
            val frameBytes = (SAMPLE_RATE / 50) * 2 // 20 ms frames
            var inputDone = false
            var outputDone = false
            val bufferInfo = MediaCodec.BufferInfo()
            var presentationUs = 0L

            while (!outputDone) {
                if (!inputDone) {
                    val inIndex = codec.dequeueInputBuffer(10_000)
                    if (inIndex >= 0) {
                        val inBuf = codec.getInputBuffer(inIndex)!!
                        inBuf.clear()
                        if (offset >= pcm.size) {
                            codec.queueInputBuffer(
                                inIndex, 0, 0, presentationUs,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            inputDone = true
                        } else {
                            val toCopy = minOf(frameBytes, pcm.size - offset, inBuf.remaining())
                            inBuf.put(pcm, offset, toCopy)
                            val pts = presentationUs
                            val samples = toCopy / 2
                            presentationUs += samples * 1_000_000L / SAMPLE_RATE
                            codec.queueInputBuffer(inIndex, 0, toCopy, pts, 0)
                            offset += toCopy
                            // Compression progress is based on consumed PCM input.
                            PipelineProgress.update(
                                wav.absolutePath,
                                "Сжатие",
                                PipelineProgress.get(wav.absolutePath)?.current ?: 1,
                                PipelineProgress.get(wav.absolutePath)?.total ?: 1,
                                (offset.toFloat() / pcm.size.toFloat()).coerceIn(0f, 0.99f)
                            )
                        }
                    }
                }

                val outIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000)
                when {
                    outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        if (muxerStarted) error("format changed twice")
                        track = muxer.addTrack(codec.outputFormat)
                        muxer.start()
                        muxerStarted = true
                    }
                    outIndex >= 0 -> {
                        val outBuf = codec.getOutputBuffer(outIndex)!!
                        if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                            bufferInfo.size = 0
                        }
                        if (bufferInfo.size > 0 && muxerStarted) {
                            outBuf.position(bufferInfo.offset)
                            outBuf.limit(bufferInfo.offset + bufferInfo.size)
                            muxer.writeSampleData(track, outBuf, bufferInfo)
                        }
                        codec.releaseOutputBuffer(outIndex, false)
                        if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                            outputDone = true
                        }
                    }
                }
            }
        } finally {
            try { codec.stop() } catch (_: Throwable) {}
            try { codec.release() } catch (_: Throwable) {}
            try {
                if (muxerStarted) muxer.stop()
            } catch (_: Throwable) {}
            try { muxer.release() } catch (_: Throwable) {}
        }

        if (!out.exists() || out.length() < 200L) error("AAC output too small")
        out
    }

    /** Read PCM16 little-endian mono samples after the WAV header. */
    private fun readPcm16Mono(wav: File): ByteArray {
        RandomAccessFile(wav, "r").use { raf ->
            if (raf.length() < 44) return ByteArray(0)
            val hdr = ByteArray(12)
            raf.readFully(hdr)
            if (String(hdr, 0, 4) != "RIFF" || String(hdr, 8, 4) != "WAVE") {
                // Not a standard WAV — treat whole file after 44 as PCM (legacy)
                raf.seek(44)
                val rest = ByteArray((raf.length() - 44).toInt().coerceAtLeast(0))
                raf.readFully(rest)
                return rest
            }
            var dataOffset = -1L
            var dataSize = 0
            var pos = 12L
            while (pos + 8 <= raf.length()) {
                raf.seek(pos)
                val id = ByteArray(4)
                raf.readFully(id)
                val sizeBytes = ByteArray(4)
                raf.readFully(sizeBytes)
                val size = (sizeBytes[0].toInt() and 0xff) or
                    ((sizeBytes[1].toInt() and 0xff) shl 8) or
                    ((sizeBytes[2].toInt() and 0xff) shl 16) or
                    ((sizeBytes[3].toInt() and 0xff) shl 24)
                val chunk = String(id)
                if (chunk == "data") {
                    dataOffset = pos + 8
                    dataSize = size
                    break
                }
                pos += 8 + size + (size and 1) // word-aligned
            }
            if (dataOffset < 0) return ByteArray(0)
            raf.seek(dataOffset)
            val n = minOf(dataSize.toLong(), raf.length() - dataOffset).toInt().coerceAtLeast(0)
            val pcm = ByteArray(n)
            raf.readFully(pcm)
            return pcm
        }
    }

    private fun isFinalizedWav(f: File): Boolean {
        if (f.length() < 44) return false
        return try {
            RandomAccessFile(f, "r").use { raf ->
                val b = ByteArray(4)
                raf.readFully(b)
                String(b) == "RIFF"
            }
        } catch (_: Throwable) {
            false
        }
    }

    private fun <T> runBlocking(block: suspend () -> T): T =
        kotlinx.coroutines.runBlocking { block() }
}
