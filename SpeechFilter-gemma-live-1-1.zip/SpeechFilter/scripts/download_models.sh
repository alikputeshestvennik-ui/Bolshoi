#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ASSETS="$ROOT/shared/src/main/assets"
WHISPER_DIR="$ROOT/.whisper"
WHISPER_VERSION="v1.9.4"
mkdir -p "$ASSETS" "$WHISPER_DIR"

curl -L --fail --retry 3 \
  "https://github.com/snakers4/silero-vad/raw/master/src/silero_vad/data/silero_vad.onnx" \
  -o "$ASSETS/silero_vad.onnx"

curl -L --fail --retry 3 \
  "https://tfhub.dev/google/lite-model/yamnet/tflite/1?lite-format=tflite" \
  -o "$ASSETS/yamnet.tflite"

curl -L --fail --retry 3 \
  "https://raw.githubusercontent.com/tensorflow/models/master/research/audioset/yamnet/yamnet_class_map.csv" \
  -o "$ASSETS/yamnet_class_map.csv"

if [ ! -f "$WHISPER_DIR/whisper.cpp/CMakeLists.txt" ]; then
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' EXIT
  curl -L --fail --retry 3 \
    "https://github.com/ggml-org/whisper.cpp/archive/refs/tags/${WHISPER_VERSION}.tar.gz" \
    -o "$tmp/whisper.tar.gz"
  tar -xzf "$tmp/whisper.tar.gz" -C "$tmp"
  rm -rf "$WHISPER_DIR/whisper.cpp"
  mv "$tmp/whisper.cpp-${WHISPER_VERSION#v}" "$WHISPER_DIR/whisper.cpp"
fi

echo "whisper.cpp $WHISPER_VERSION prepared at $WHISPER_DIR/whisper.cpp"
