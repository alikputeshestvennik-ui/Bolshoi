package com.example.speechfilter

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.File
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var button: Button
    private lateinit var recordingsContainer: LinearLayout
    private lateinit var playerView: PlayerView
    private lateinit var sourceLabel: TextView
    private lateinit var sourceDot: TextView
    private lateinit var sourceIndicator: LinearLayout
    private var player: ExoPlayer? = null
    private var running = false
    private var playingFile: File? = null
    private var currentSource: String = "IDLE"

    private val uiHandler = Handler(Looper.getMainLooper())
    private val refreshRunnable = object : Runnable {
        override fun run() {
            refreshRecordings()
            if (running) uiHandler.postDelayed(this, 2000L)
        }
    }

    private val sourceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val src = intent?.getStringExtra(RecordingService.EXTRA_SOURCE) ?: return
            val detail = intent.getStringExtra(RecordingService.EXTRA_DETAIL) ?: ""
            updateSourceIndicator(src, detail)
            if (src == "IDLE" || src == "STOPPED") {
                running = false
                button.text = "START"
            } else {
                running = true
                button.text = "STOP"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        button = findViewById(R.id.startStop)
        recordingsContainer = findViewById(R.id.recordingsContainer)
        playerView = findViewById(R.id.playerView)
        sourceLabel = findViewById(R.id.sourceLabel)
        sourceDot = findViewById(R.id.sourceDot)
        sourceIndicator = findViewById(R.id.sourceIndicator)
        playerView.visibility = android.view.View.GONE
        findViewById<RadioButton>(R.id.autoSource).isChecked = true
        button.setOnClickListener {
            if (!running) startRecording() else stopRecording()
        }
        updateSourceIndicator("IDLE", "")
        refreshRecordings()
    }

    override fun onStart() {
        super.onStart()
        val f = IntentFilter(RecordingService.ACTION_SOURCE)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(sourceReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(sourceReceiver, f)
        }
    }

    override fun onStop() {
        try { unregisterReceiver(sourceReceiver) } catch (_: Exception) {}
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        refreshRecordings()
    }

    private fun updateSourceIndicator(src: String, detail: String) {
        currentSource = src
        val (label, color, bg) = when (src) {
            "WATCH" -> Triple(
                "⌚ Источник: Galaxy Watch 8",
                Color.parseColor("#1B5E20"),
                Color.parseColor("#C8E6C9")
            )
            "PHONE" -> Triple(
                "📱 Источник: микрофон телефона",
                Color.parseColor("#0D47A1"),
                Color.parseColor("#BBDEFB")
            )
            "AUTO" -> Triple(
                "🔄 Авто: ожидание часов…",
                Color.parseColor("#E65100"),
                Color.parseColor("#FFE0B2")
            )
            "STOPPED", "IDLE" -> Triple(
                "Источник: не активен",
                Color.parseColor("#616161"),
                Color.parseColor("#E8E8E8")
            )
            else -> Triple(
                "Источник: $src",
                Color.parseColor("#616161"),
                Color.parseColor("#E8E8E8")
            )
        }
        sourceLabel.text = if (detail.isNotBlank()) "$label · $detail" else label
        sourceLabel.setTextColor(color)
        sourceIndicator.setBackgroundColor(bg)
        sourceDot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
        status.text = when (src) {
            "WATCH" -> "Идёт запись с часов"
            "PHONE" -> "Идёт запись с телефона"
            "AUTO" -> "Ожидание источника…"
            "STOPPED" -> "Запись завершена"
            else -> status.text
        }
        // Sync radio buttons to live source
        when (src) {
            "WATCH" -> findViewById<RadioButton>(R.id.watchSource).isChecked = true
            "PHONE" -> findViewById<RadioButton>(R.id.phoneSource).isChecked = true
        }
    }

    private fun startRecording() {
        val need = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, need.toTypedArray(), 10)
            status.text = "Нужно разрешение микрофона"
            return
        }
        val source = when {
            findViewById<RadioButton>(R.id.watchSource).isChecked -> "WATCH"
            findViewById<RadioButton>(R.id.phoneSource).isChecked -> "PHONE"
            else -> "AUTO"
        }
        ContextCompat.startForegroundService(
            this, Intent(this, RecordingService::class.java).putExtra("source", source)
        )
        running = true
        button.text = "STOP"
        updateSourceIndicator(source, "запуск…")
        uiHandler.removeCallbacks(refreshRunnable)
        uiHandler.post(refreshRunnable)
    }

    private fun stopRecording() {
        stopService(Intent(this, RecordingService::class.java))
        running = false
        button.text = "START"
        updateSourceIndicator("STOPPED", "")
        uiHandler.removeCallbacks(refreshRunnable)
        uiHandler.postDelayed({ refreshRecordings() }, 400)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.isNotEmpty() &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        ) startRecording()
    }

    private fun recordingsDir(): File =
        File(getExternalFilesDir(null), "SpeechFilter")

    private fun refreshRecordings() {
        recordingsContainer.removeAllViews()
        val files = recordingsDir()
            .listFiles { f -> f.isFile && f.extension.equals("wav", true) }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()

        if (files.isEmpty()) {
            recordingsContainer.addView(TextView(this).apply {
                text = "Записей пока нет"
                textSize = 16f
                setPadding(0, 12, 0, 12)
            })
            return
        }
        files.forEach { addRecordingRow(it) }
    }

    private fun addRecordingRow(file: File) {
        val fromWatch = file.name.contains("_watch_")
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 12, 0, 12)
        }
        val isPlayingThis = playingFile?.absolutePath == file.absolutePath &&
            player?.isPlaying == true
        val title = TextView(this).apply {
            val mark = if (fromWatch) "⌚ с часов · " else "📱 "
            val playMark = if (isPlayingThis) "⏸ " else "▶ "
            text = playMark + mark + file.name.removeSuffix(".wav")
            textSize = 17f
            setPadding(0, 8, 0, 4)
            setOnClickListener { togglePlay(file) }
        }
        val meta = TextView(this).apply {
            val src = if (fromWatch) "с часов" else "с телефона"
            text = "$src · ${formatSize(file.length())} · ${formatDate(file.lastModified())}"
            textSize = 13f
        }
        val share = Button(this).apply {
            text = "Экспорт"
            setOnClickListener { shareFile(file) }
        }
        row.addView(title)
        row.addView(meta)
        row.addView(share)
        recordingsContainer.addView(row)
    }

    private fun togglePlay(file: File) {
        val same = playingFile?.absolutePath == file.absolutePath
        if (same && player != null) {
            if (player!!.isPlaying) {
                player!!.pause()
                status.text = "Пауза: ${file.name}"
            } else {
                player!!.play()
                status.text = "Воспроизведение: ${file.name}"
            }
            refreshRecordings()
            return
        }
        releasePlayer()
        playingFile = file
        player = ExoPlayer.Builder(this).build().also { exo ->
            exo.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
            exo.prepare()
            exo.play()
            exo.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_ENDED) {
                        playingFile = null
                        refreshRecordings()
                    }
                }
            })
        }
        status.text = "Воспроизведение: ${file.name}"
        refreshRecordings()
    }

    private fun shareFile(file: File) {
        val uri = FileProvider.getUriForFile(
            this, "${BuildConfig.APPLICATION_ID}.fileprovider", file
        )
        startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).apply {
                    type = "audio/wav"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                },
                "Экспорт записи"
            )
        )
    }

    private fun releasePlayer() {
        player?.release()
        player = null
        playingFile = null
    }

    override fun onDestroy() {
        uiHandler.removeCallbacks(refreshRunnable)
        releasePlayer()
        super.onDestroy()
    }

    private fun formatSize(bytes: Long): String = when {
        bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB", bytes / 1024f / 1024f)
        else -> String.format(Locale.US, "%.0f KB", bytes / 1024f)
    }

    private fun formatDate(ms: Long): String {
        val fmt = java.text.SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        return fmt.format(java.util.Date(ms))
    }
}
