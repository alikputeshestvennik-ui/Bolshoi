package com.example.speechfilter

import android.content.Intent
import androidx.core.content.ContextCompat
import com.google.android.gms.wearable.ChannelClient
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService

class PhoneWearListenerService : WearableListenerService() {

    override fun onMessageReceived(event: MessageEvent) {
        when (event.path) {
            "/watch/ready", "/source/watch", "/control/start" -> {
                startServiceWith("WATCH")
            }
            "/source/phone" -> {
                startServiceWith("PHONE")
            }
        }
    }

    override fun onChannelOpened(channel: ChannelClient.Channel) {
        if (channel.path == "/speech-audio") {
            startServiceWith("WATCH")
        }
    }

    private fun startServiceWith(source: String) {
        val i = Intent(this, RecordingService::class.java)
            .putExtra("source", source)
        ContextCompat.startForegroundService(this, i)
    }
}
