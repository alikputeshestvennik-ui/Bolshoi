package com.example.speechfilter.wear

import android.app.*
import android.content.Intent
import android.media.*
import android.os.IBinder
import android.os.PowerManager
import android.os.Build
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import com.example.speechfilter.shared.AudioConfig
import com.example.speechfilter.shared.AudioPacket
import com.google.android.gms.tasks.Tasks
import com.google.android.gms.wearable.*
import java.io.OutputStream
import kotlin.concurrent.thread

/**
 * Watch mic → Channel /speech-audio → phone.
 * Retries until phone accepts the channel (so START on watch works even if phone starts later).
 */
class WatchRecordingService : Service() {
    @Volatile private var stopping = false
    private var worker: Thread? = null
    private var record: AudioRecord? = null
    private var output: OutputStream? = null
    private var channel: ChannelClient.Channel? = null
    private var sequence = 0
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("watch_speech", "Speech Filter", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val n = notification("Galaxy Watch: подготовка")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(7, n)
        }
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SpeechFilter:WatchRec").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopping = false
        worker?.interrupt()
        worker = thread(name = "watch-audio") { runCapture() }
        return START_STICKY
    }

    private fun findPhone(): Node? {
        return try {
            val nodes = Tasks.await(Wearable.getNodeClient(this).connectedNodes)
            nodes.firstOrNull { it.isNearby } ?: nodes.firstOrNull()
        } catch (_: Throwable) {
            null
        }
    }

    private fun openChannelWithRetry(): Boolean {
        val client = Wearable.getChannelClient(this)
        var attempt = 0
        while (!stopping && attempt < 60) {
            attempt++
            val phone = findPhone()
            if (phone == null) {
                update("Нет телефона (BT?)… $attempt")
                Thread.sleep(1000)
                continue
            }
            // Ask phone to start listening
            try {
                Wearable.getMessageClient(this)
                    .sendMessage(phone.id, "/watch/ready", byteArrayOf(1))
            } catch (_: Throwable) {}

            update("Канал к ${phone.displayName}… ($attempt)")
            try {
                val ch = Tasks.await(client.openChannel(phone.id, "/speech-audio"))
                val out = Tasks.await(client.getOutputStream(ch))
                channel = ch
                output = out
                update("Канал открыт")
                return true
            } catch (t: Throwable) {
                update("Жду телефон… ${t.message ?: ""}".take(40))
                try { Thread.sleep(1000) } catch (_: InterruptedException) { return false }
            }
        }
        return false
    }

    private fun runCapture() {
        try {
            if (!openChannelWithRetry()) {
                update("Не удалось открыть канал")
                return
            }

            val min = AudioRecord.getMinBufferSize(
                AudioConfig.SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            if (min <= 0) {
                update("AudioRecord недоступен")
                return
            }
            val r = AudioRecord(
                MediaRecorder.AudioSource.MIC, AudioConfig.SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                (min * 2).coerceAtLeast(AudioConfig.FRAME_SAMPLES * 4 * 2)
            )
            if (r.state != AudioRecord.STATE_INITIALIZED) {
                update("Микрофон не инициализирован")
                r.release()
                return
            }
            record = r
            update("ЗАПИСЬ с часов")
            r.startRecording()
            val buf = ShortArray(AudioConfig.FRAME_SAMPLES)
            var frames = 0
            while (!stopping) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0) {
                    val pcm = if (n == buf.size) buf else buf.copyOf(n)
                    try {
                        output?.write(AudioPacket.encode(sequence++, pcm))
                        if (frames % 20 == 0) output?.flush()
                    } catch (_: Throwable) {
                        update("Канал оборвался, переподключение…")
                        closeChannel()
                        if (!openChannelWithRetry()) break
                    }
                    frames++
                } else if (n < 0) {
                    update("Ошибка чтения: $n")
                    break
                }
            }
            try { r.stop() } catch (_: Exception) {}
            try { r.release() } catch (_: Exception) {}
            update("Стоп")
        } catch (t: Throwable) {
            update("Ошибка: ${t.message ?: t.javaClass.simpleName}")
        } finally {
            closeChannel()
        }
    }

    private fun closeChannel() {
        try { output?.flush() } catch (_: Exception) {}
        try { output?.close() } catch (_: Exception) {}
        channel?.let { ch ->
            try { Wearable.getChannelClient(this).close(ch) } catch (_: Exception) {}
        }
        output = null
        channel = null
    }

    override fun onDestroy() {
        stopping = true
        try { record?.stop() } catch (_: Exception) {}
        worker?.interrupt()
        worker = null
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun notification(text: String) =
        NotificationCompat.Builder(this, "watch_speech")
            .setContentTitle("Speech Filter")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()

    private fun update(text: String) {
        getSystemService(NotificationManager::class.java).notify(7, notification(text))
    }
}
