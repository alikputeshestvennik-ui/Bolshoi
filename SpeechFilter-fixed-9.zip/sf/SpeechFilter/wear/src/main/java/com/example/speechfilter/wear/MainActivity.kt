package com.example.speechfilter.wear

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.tasks.Tasks
import com.google.android.gms.wearable.Wearable
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var sourceBadge: TextView
    private var watchActive = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        toggle = findViewById(R.id.toggle)
        sourceBadge = findViewById(R.id.sourceBadge)
        setBadgePhone()
        status.text = "Нажмите ▶"
        toggle.text = "▶"
        toggle.setOnClickListener { onToggle() }
    }

    private fun badgeBackground(color: Int) =
        GradientDrawable().apply {
            cornerRadius = 24f
            setColor(color)
        }

    private fun setBadgeWatch() {
        sourceBadge.text = "● с часов"
        sourceBadge.setTextColor(Color.WHITE)
        sourceBadge.background = badgeBackground(Color.parseColor("#2E7D32"))
    }

    private fun setBadgePhone() {
        sourceBadge.text = "○ телефон"
        sourceBadge.setTextColor(Color.WHITE)
        sourceBadge.background = badgeBackground(Color.parseColor("#424242"))
    }

    private fun onToggle() {
        if (!watchActive) {
            val need = mutableListOf<String>()
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED
            ) need += Manifest.permission.RECORD_AUDIO
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) need += Manifest.permission.POST_NOTIFICATIONS
            if (need.isNotEmpty()) {
                ActivityCompat.requestPermissions(this, need.toTypedArray(), 20)
                status.text = "Микрофон?"
                return
            }
            activateWatch()
        } else {
            deactivateWatchToPhone()
        }
    }

    private fun activateWatch() {
        thread {
            try {
                val nodes = Tasks.await(Wearable.getNodeClient(this).connectedNodes)
                val phone = nodes.firstOrNull { it.isNearby } ?: nodes.firstOrNull()
                if (phone != null) {
                    Tasks.await(
                        Wearable.getMessageClient(this)
                            .sendMessage(phone.id, "/source/watch", byteArrayOf(1))
                    )
                }
            } catch (_: Throwable) {}
        }
        ContextCompat.startForegroundService(
            this, Intent(this, WatchRecordingService::class.java)
        )
        watchActive = true
        toggle.text = "■"
        status.text = "Стрим с часов"
        setBadgeWatch()
    }

    private fun deactivateWatchToPhone() {
        stopService(Intent(this, WatchRecordingService::class.java))
        thread {
            try {
                val nodes = Tasks.await(Wearable.getNodeClient(this).connectedNodes)
                val phone = nodes.firstOrNull { it.isNearby } ?: nodes.firstOrNull()
                if (phone != null) {
                    Tasks.await(
                        Wearable.getMessageClient(this)
                            .sendMessage(phone.id, "/source/phone", byteArrayOf(1))
                    )
                }
            } catch (_: Throwable) {}
        }
        watchActive = false
        toggle.text = "▶"
        status.text = "→ телефон"
        setBadgePhone()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode == 20 && grantResults.isNotEmpty() &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        ) {
            activateWatch()
        } else {
            status.text = "Нет разрешения"
            Toast.makeText(this, "Нужен микрофон", Toast.LENGTH_SHORT).show()
        }
    }
}
