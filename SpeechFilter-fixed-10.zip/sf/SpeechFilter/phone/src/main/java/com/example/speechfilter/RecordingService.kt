package com.example.speechfilter

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.speechfilter.shared.*
import com.google.android.gms.wearable.*
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * Stable recording session. Avoids restart storms from Wear messages.
 */
class RecordingService : Service() {

    companion object {
        const val ACTION_SOURCE = "com.example.speechfilter.SOURCE"
        const val EXTRA_SOURCE = "source"
        const val EXTRA_DETAIL = "detail"
        const val EXTRA_STOP = "stop"

        @Volatile var sessionActive: Boolean = false
            private set
        @Volatile var activeSource: String = "IDLE"
            private set
        /** Ignore wear auto-start briefly after user pressed STOP */
        @Volatile var suppressAutoStartUntil: Long = 0L
    }

    private val io = Executors.newSingleThreadExecutor()
    private var source = "AUTO"
    private val stopping = AtomicBoolean(false)
    private var localThread: Thread? = null
    private var audioRecord: AudioRecord? = null
    private var wav: WavWriter? = null
    private var wavFile: File? = null
    private var bytesWritten = 0L
    private var segmentBytes = 0L
    @Volatile private var lastSpeechAt = 0L
    private var watchStarted = false
    private var channelClient: ChannelClient? = null
    private var channel: ChannelClient.Channel? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var channelRegistered = false

    private val channelCallback = object : ChannelClient.ChannelCallback() {
        override fun onChannelOpened(ch: ChannelClient.Channel) {
            if (ch.path != "/speech-audio") return
            if (stopping.get()) return
            // Already reading a channel — ignore duplicates
            if (channel != null && channel?.nodeId == ch.nodeId) return
            channel = ch
            watchStarted = true
            source = "WATCH"
            activeSource = "WATCH"
            publishSource("WATCH", "поток")
            updateNotification("Galaxy Watch 8: поток")
            Wearable.getChannelClient(this@RecordingService).getInputStream(ch)
                .addOnSuccessListener { input ->
                    thread(name = "watch-pcm-reader", isDaemon = true) {
                        try {
                            val models = ModelFiles
                            val vad = SileroVad(models.silero(this@RecordingService))
                            val yam = try {
                                YamnetClassifier(
                                    models.yamnet(this@RecordingService),
                                    models.labels(this@RecordingService)
                                )
                            } catch (_: Throwable) { null }
                            val engine = SpeechEngine(
                                vad = vad,
                                yamnet = yam,
                                requireYamnet = false,
                                onSpeechPcm = { pcm -> appendSpeech(pcm) }
                            )
                            val parser = AudioPacket.Parser { _, pcm ->
                                if (!stopping.get()) engine.acceptPcm16(pcm)
                            }
                            val buf = ByteArray(16 * 1024)
                            while (!stopping.get()) {
                                val n = try { input.read(buf) } catch (_: Exception) { break }
                                if (n <= 0) break
                                parser.push(buf.copyOf(n))
                            }
                            try { vad.close() } catch (_: Exception) {}
                            try { yam?.close() } catch (_: Exception) {}
                        } catch (t: Throwable) {
                            updateNotification("Канал: ${t.message}")
                        } finally {
                            try { input.close() } catch (_: Exception) {}
                        }
                    }
                }
                .addOnFailureListener {
                    updateNotification("Канал: нет входного потока")
                }
        }

        override fun onChannelClosed(
            ch: ChannelClient.Channel,
            closeReason: Int,
            appSpecificErrorCode: Int
        ) {
            if (ch.path == "/speech-audio") {
                channel = null
                watchStarted = false
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        enterForeground("Ожидание источника")
        acquireWakeLock()
        channelClient = Wearable.getChannelClient(this)
        if (!channelRegistered) {
            channelClient?.registerChannelCallback(channelCallback)
            channelRegistered = true
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Explicit stop
        if (intent?.getBooleanExtra(EXTRA_STOP, false) == true) {
            userStop()
            return START_NOT_STICKY
        }

        val requested = intent?.getStringExtra("source") ?: "AUTO"

        // Already running same mode — ignore (stops restart storm)
        if (sessionActive && !stopping.get()) {
            when {
                requested == activeSource -> {
                    updateNotification("Уже запись: $activeSource")
                    return START_STICKY
                }
                requested == "WATCH" && activeSource == "WATCH" -> return START_STICKY
                requested == "PHONE" && activeSource == "PHONE" -> return START_STICKY
                // Source switch: stop local mic or wait for watch without full teardown
                requested == "PHONE" && activeSource != "PHONE" -> {
                    switchToPhone()
                    return START_STICKY
                }
                requested == "WATCH" && activeSource != "WATCH" -> {
                    switchToWatch()
                    return START_STICKY
                }
                requested == "AUTO" -> return START_STICKY
            }
        }

        stopping.set(false)
        sessionActive = true
        source = requested
        activeSource = requested
        bytesWritten = 0L
        segmentBytes = 0L
        lastSpeechAt = 0L
        watchStarted = false

        when (requested) {
            "PHONE" -> startPhone()
            "WATCH" -> switchToWatch()
            else -> startAuto()
        }
        return START_STICKY
    }

    private fun startAuto() {
        publishSource("AUTO", "поиск часов")
        updateNotification("Поиск Galaxy Watch…")
        Wearable.getNodeClient(this).connectedNodes
            .addOnSuccessListener { nodes ->
                if (stopping.get()) return@addOnSuccessListener
                val nearby = nodes.firstOrNull { it.isNearby } ?: nodes.firstOrNull()
                if (nearby == null) {
                    updateNotification("Часы не найдены → телефон")
                    startPhone()
                    return@addOnSuccessListener
                }
                Wearable.getMessageClient(this)
                    .sendMessage(nearby.id, "/control/start", byteArrayOf())
                    .addOnSuccessListener {
                        if (!stopping.get()) {
                            publishSource("AUTO", "ждём часы")
                            updateNotification("Сигнал на часы отправлен")
                        }
                    }
                // Fallback once after 12s if no watch channel
                io.execute {
                    try { Thread.sleep(12_000) } catch (_: InterruptedException) { return@execute }
                    if (!stopping.get() && !watchStarted && activeSource != "PHONE" && activeSource != "WATCH") {
                        updateNotification("Таймаут часов → телефон")
                        startPhone()
                    }
                }
            }
            .addOnFailureListener {
                if (!stopping.get()) startPhone()
            }
    }

    private fun switchToWatch() {
        // Stop phone mic if running; keep session for channel
        stopPhoneMicOnly()
        source = "WATCH"
        activeSource = "WATCH"
        publishSource("WATCH", "ожидание")
        updateNotification("Ожидание потока с часов…")
        Wearable.getNodeClient(this).connectedNodes
            .addOnSuccessListener { nodes ->
                val nearby = nodes.firstOrNull { it.isNearby } ?: nodes.firstOrNull()
                if (nearby != null) {
                    Wearable.getMessageClient(this)
                        .sendMessage(nearby.id, "/control/start", byteArrayOf())
                }
            }
    }

    private fun switchToPhone() {
        // Close watch channel read; start phone mic
        source = "PHONE"
        stopPhoneMicOnly()
        startPhone()
    }

    private fun stopPhoneMicOnly() {
        try { audioRecord?.stop() } catch (_: Exception) {}
        try { audioRecord?.release() } catch (_: Exception) {}
        audioRecord = null
        localThread?.interrupt()
        localThread = null
    }

    private fun startPhone() {
        if (localThread?.isAlive == true) return
        if (stopping.get()) return
        source = "PHONE"
        activeSource = "PHONE"
        watchStarted = false
        publishSource("PHONE", "микрофон")
        updateNotification("Телефон: микрофон")
        localThread = thread(name = "phone-audio", isDaemon = true) {
            try {
                val min = AudioRecord.getMinBufferSize(
                    AudioConfig.SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                if (min <= 0) {
                    updateNotification("AudioRecord недоступен")
                    return@thread
                }
                val record = AudioRecord(
                    MediaRecorder.AudioSource.MIC, AudioConfig.SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    (min * 2).coerceAtLeast(AudioConfig.FRAME_SAMPLES * 4 * 2)
                )
                if (record.state != AudioRecord.STATE_INITIALIZED) {
                    updateNotification("Микрофон не инициализирован")
                    record.release()
                    return@thread
                }
                audioRecord = record
                val models = ModelFiles
                val vad = SileroVad(models.silero(this))
                val yam = try {
                    YamnetClassifier(models.yamnet(this), models.labels(this))
                } catch (_: Throwable) { null }
                val e = SpeechEngine(
                    vad = vad,
                    yamnet = yam,
                    requireYamnet = false,
                    onSpeechPcm = { pcm -> appendSpeech(pcm) }
                )
                record.startRecording()
                publishSource("PHONE", "слушаю")
                updateNotification("Слушаю микрофон…")
                val buf = ShortArray(AudioConfig.FRAME_SAMPLES)
                while (!stopping.get() && activeSource == "PHONE") {
                    val n = record.read(buf, 0, buf.size)
                    if (n > 0) {
                        e.acceptPcm16(if (n == buf.size) buf else buf.copyOf(n))
                    } else if (n < 0) break
                }
                try { record.stop() } catch (_: Exception) {}
                try { record.release() } catch (_: Exception) {}
                try { vad.close() } catch (_: Exception) {}
                try { yam?.close() } catch (_: Exception) {}
            } catch (t: Throwable) {
                updateNotification("Ошибка: ${t.message}")
            }
        }
    }

    @Synchronized
    private fun appendSpeech(pcm: ShortArray) {
        if (stopping.get()) return
        val now = System.currentTimeMillis()
        val gapMs = if (lastSpeechAt == 0L) 0L else now - lastSpeechAt
        if (wav != null && lastSpeechAt != 0L && gapMs >= AudioConfig.FILE_GAP_MS.toLong()) {
            closeCurrentWav()
        }
        ensureWav().appendPcm16(pcm)
        val add = pcm.size * 2L
        bytesWritten += add
        segmentBytes += add
        lastSpeechAt = now
    }

    @Synchronized
    private fun ensureWav(): WavWriter {
        wav?.let { return it }
        val dir = File(getExternalFilesDir(null), "SpeechFilter").apply { mkdirs() }
        val tag = if (activeSource == "WATCH" || watchStarted) "watch" else "phone"
        val file = File(dir, "speech_${tag}_${System.currentTimeMillis()}.wav")
        wavFile = file
        segmentBytes = 0L
        return WavWriter(file).also { it.start(); wav = it }
    }

    @Synchronized
    private fun closeCurrentWav() {
        try { wav?.close() } catch (_: Exception) {}
        wavFile?.let { f ->
            if (segmentBytes < 2000 && f.exists()) {
                // drop tiny noise blips (< ~0.06s)
                try { f.delete() } catch (_: Exception) {}
            }
        }
        wav = null
        wavFile = null
        segmentBytes = 0L
    }

    private fun userStop() {
        suppressAutoStartUntil = System.currentTimeMillis() + 8_000L
        stopping.set(true)
        sessionActive = false
        activeSource = "IDLE"
        stopPhoneMicOnly()
        channel?.let { ch ->
            try { channelClient?.close(ch) } catch (_: Exception) {}
        }
        channel = null
        closeCurrentWav()
        publishSource("STOPPED")
        updateNotification("Остановлено")
        releaseWakeLock()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopping.set(true)
        sessionActive = false
        activeSource = "IDLE"
        stopPhoneMicOnly()
        channel?.let { ch ->
            try { channelClient?.close(ch) } catch (_: Exception) {}
        }
        channel = null
        closeCurrentWav()
        if (channelRegistered) {
            try { channelClient?.unregisterChannelCallback(channelCallback) } catch (_: Exception) {}
            channelRegistered = false
        }
        releaseWakeLock()
        io.shutdownNow()
        publishSource("STOPPED")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun enterForeground(text: String) {
        val n = notification(text)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(42, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(42, n)
        }
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SpeechFilter:Recording").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {}
        wakeLock = null
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("speech", "Speech Filter", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    private fun notification(text: String) =
        NotificationCompat.Builder(this, "speech")
            .setContentTitle("Speech Filter")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()

    private fun updateNotification(text: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(42, notification(text))
        } catch (_: Exception) {}
    }

    private fun publishSource(src: String, detail: String = "") {
        try {
            sendBroadcast(
                Intent(ACTION_SOURCE)
                    .setPackage(packageName)
                    .putExtra(EXTRA_SOURCE, src)
                    .putExtra(EXTRA_DETAIL, detail)
            )
        } catch (_: Exception) {}
    }
}
