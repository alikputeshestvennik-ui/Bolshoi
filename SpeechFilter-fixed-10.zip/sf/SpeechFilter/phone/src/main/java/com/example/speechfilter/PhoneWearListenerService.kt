package com.example.speechfilter

import android.content.Intent
import androidx.core.content.ContextCompat
import com.google.android.gms.wearable.ChannelClient
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService

class PhoneWearListenerService : WearableListenerService() {

    override fun onMessageReceived(event: MessageEvent) {
        if (System.currentTimeMillis() < RecordingService.suppressAutoStartUntil) return
        when (event.path) {
            "/watch/ready", "/source/watch", "/control/start" -> {
                // Only start/switch if not already on WATCH
                if (RecordingService.activeSource != "WATCH") {
                    startServiceWith("WATCH")
                }
            }
            "/source/phone" -> {
                if (RecordingService.activeSource != "PHONE") {
                    startServiceWith("PHONE")
                }
            }
        }
    }

    override fun onChannelOpened(channel: ChannelClient.Channel) {
        if (channel.path != "/speech-audio") return
        if (System.currentTimeMillis() < RecordingService.suppressAutoStartUntil) return
        if (RecordingService.activeSource != "WATCH" || !RecordingService.sessionActive) {
            startServiceWith("WATCH")
        }
    }

    private fun startServiceWith(source: String) {
        val i = Intent(this, RecordingService::class.java)
            .putExtra("source", source)
        try {
            ContextCompat.startForegroundService(this, i)
        } catch (_: Exception) {}
    }
}
