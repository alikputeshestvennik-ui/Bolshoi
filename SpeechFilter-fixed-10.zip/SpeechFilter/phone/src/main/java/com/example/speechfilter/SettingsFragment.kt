package com.example.speechfilter

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.data.PipelineLogEntity
import com.example.speechfilter.pipeline.GemmaEngine
import com.example.speechfilter.pipeline.ReadinessCheck
import com.example.speechfilter.pipeline.WhisperEngine

/** Models, readiness check, and the raw worker log window. */
class SettingsFragment : Fragment(R.layout.fragment_settings) {

    private lateinit var whisperModelStatus: TextView
    private lateinit var gemmaModelStatus: TextView
    private lateinit var pipelineLogText: TextView
    private val whisper by lazy { WhisperEngine(requireContext().applicationContext) }
    private val gemma by lazy { GemmaEngine(requireContext().applicationContext) }

    private val uiHandler = Handler(Looper.getMainLooper())
    private val logRefreshRunnable = object : Runnable {
        override fun run() {
            refreshLog()
            uiHandler.postDelayed(this, 5000L)
        }
    }

    private val whisperModelPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        whisperModelStatus.text = "Whisper: импортирую…"
        lifecycleScope.launch {
            val message = withContext(Dispatchers.IO) {
                whisper.importModel(uri).fold(
                    onSuccess = {
                        val backend = try { whisper.backendInfo() } catch (_: Throwable) { "?" }
                        "Whisper: модель импортирована (${it.length() / (1024 * 1024)} MB) · $backend"
                    },
                    onFailure = { "Whisper: ошибка импорта — ${it.message}" }
                )
            }
            if (isAdded) whisperModelStatus.text = message
        }
    }

    private val gemmaModelPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        gemmaModelStatus.text = "Gemma: импортирую… (может занять минуту)"
        val name = displayNameOf(uri)
        lifecycleScope.launch {
            val message = withContext(Dispatchers.IO) {
                gemma.importModel(uri, name).fold(
                    onSuccess = { "Gemma: модель импортирована (${it.name}, ${it.length() / (1024 * 1024)} MB)" },
                    onFailure = { "Gemma: ошибка импорта — ${it.message}" }
                )
            }
            if (isAdded) gemmaModelStatus.text = message
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        whisperModelStatus = view.findViewById(R.id.whisperModelStatus)
        gemmaModelStatus = view.findViewById(R.id.gemmaModelStatus)
        pipelineLogText = view.findViewById(R.id.pipelineLogText)

        view.findViewById<Button>(R.id.importWhisperModel).setOnClickListener {
            whisperModelPicker.launch(arrayOf("application/octet-stream", "application/x-binary", "*/*"))
        }
        view.findViewById<Button>(R.id.importGemmaModel).setOnClickListener {
            gemmaModelPicker.launch(arrayOf("*/*"))
        }
        view.findViewById<Button>(R.id.runReadinessTest).setOnClickListener { runReadinessTest() }

        updateWhisperModelStatus()
        updateGemmaModelStatus()
        refreshLog()
    }

    override fun onStart() {
        super.onStart()
        uiHandler.removeCallbacks(logRefreshRunnable)
        uiHandler.post(logRefreshRunnable)
    }

    override fun onStop() {
        uiHandler.removeCallbacks(logRefreshRunnable)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        updateWhisperModelStatus()
        updateGemmaModelStatus()
    }

    private fun displayNameOf(uri: Uri): String? =
        requireContext().contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
        }

    private fun updateWhisperModelStatus() {
        whisperModelStatus.text = if (whisper.modelReady()) {
            val mb = whisper.modelDir().resolve("whisper.base").length() / (1024 * 1024)
            val backend = try { whisper.backendInfo() } catch (_: Throwable) { "?" }
            "Whisper: модель готова ($mb MB) · $backend"
        } else {
            "Whisper: модель не импортирована"
        }
    }

    private fun updateGemmaModelStatus() {
        gemmaModelStatus.text = if (gemma.modelReady()) {
            val f = gemma.modelFile()
            val mb = (f?.length() ?: 0L) / (1024 * 1024)
            "Gemma: модель готова (${f?.name}, $mb MB)"
        } else {
            "Gemma: модель не импортирована"
        }
    }

    private fun runReadinessTest() {
        val btn = requireView().findViewById<Button>(R.id.runReadinessTest)
        val out = requireView().findViewById<TextView>(R.id.readinessStatus)
        btn.isEnabled = false
        btn.text = "ПРОВЕРКА…"
        out.text = "Проверка готовности…"
        lifecycleScope.launch {
            val items = withContext(Dispatchers.IO) { ReadinessCheck.run(requireContext().applicationContext) }
            val report = ReadinessCheck.format(items)
            if (!isAdded) return@launch
            out.text = report
            btn.isEnabled = true
            btn.text = "ПРОВЕРКА ГОТОВНОСТИ"
            AlertDialog.Builder(requireContext())
                .setTitle("Готовность приложения")
                .setMessage(report)
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun refreshLog() {
        val ctx = context ?: return
        lifecycleScope.launch {
            val logs = withContext(Dispatchers.IO) { AppDatabase.get(ctx).logs().recent(30) }
            if (!isAdded) return@launch
            pipelineLogText.text = if (logs.isEmpty()) {
                "Пока нет данных от воркеров"
            } else {
                logs.joinToString("\n") { log: PipelineLogEntity ->
                    "[${formatTime(log.at)}] ${workerLabel(log.worker)}: ${log.message}"
                }
            }
        }
    }

    private fun workerLabel(worker: String): String = when (worker) {
        "record" -> "Запись"
        "transcribe" -> "Транскрипция"
        "refine" -> "Обработка"
        "important" -> "Важное"
        "daily" -> "Сводка дня"
        else -> worker
    }

    private fun formatTime(ms: Long): String {
        val fmt = java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        return fmt.format(java.util.Date(ms))
    }
}
