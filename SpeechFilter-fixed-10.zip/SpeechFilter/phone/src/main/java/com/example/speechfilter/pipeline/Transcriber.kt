package com.example.speechfilter.pipeline

import android.content.Context
import android.os.Process
import com.example.speechfilter.data.AppDatabase
import com.example.speechfilter.data.PipelineLogEntity
import com.example.speechfilter.data.RefinedTextEntity
import com.example.speechfilter.data.TranscriptEntity
import java.io.File
import java.io.RandomAccessFile

/**
 * The actual transcription pass, extracted out of TranscribeWorker so it can
 * be run two ways:
 *
 *  - directly, on RecordingService's own single-thread [java.util.concurrent.ExecutorService],
 *    the moment a WAV segment closes. This is the normal path while the app
 *    is alive: the foreground service is already running, so there is no
 *    reason to hand the job to WorkManager and hope it gets scheduled soon.
 *    WorkManager's GreedyScheduler is a "run when the system feels like it"
 *    contract, not an "run now" one, even for an unconstrained OneTimeWork
 *    request from a foreground process \u2014 which is exactly why this used to
 *    only ever seem to run after STOP: leaving the foreground session is
 *    what nudged WorkManager into flushing its backlog, it wasn't the
 *    trigger actually firing on its own.
 *  - via TranscribeWorker, kept only as the startup sweep's safety net for
 *    whatever a process death swallowed before it could run directly.
 *
 * Directory-scan + FIFO order is unchanged: sortedBy { lastModified } means
 * oldest-closed file first, newest last, exactly as requested.
 */
object Transcriber {

    /**
     * Process-wide single-thread queue for transcription. It deliberately
     * does NOT belong to RecordingService: the service used to run this on
     * its own `io` executor and call io.shutdownNow() in onDestroy(), so
     * pressing STOP (userStop -> closeCurrentWav -> stopSelf -> onDestroy)
     * dropped/interrupted the run that closeCurrentWav() had just queued.
     * That is the "crash: null" (InterruptedException has no message) in the
     * worker log and the recordings stuck on "ожидает расшифровки".
     */
    private val executor = java.util.concurrent.Executors.newSingleThreadExecutor { r ->
        Thread(r, "transcriber").apply { isDaemon = true }
    }
    private val inFlight = java.util.concurrent.atomic.AtomicInteger(0)
    private val idleCallbacks = java.util.concurrent.CopyOnWriteArrayList<() -> Unit>()

    /** Queue a pass right behind whatever is running now (oldest file first). */
    fun enqueue(context: Context, worker: String = "transcribe") {
        val app = context.applicationContext
        inFlight.incrementAndGet()
        try {
            executor.execute {
                try {
                    runPending(app, worker)
                } catch (t: Throwable) {
                    PipelineLog.add(app, worker, "crash: ${t.javaClass.simpleName}: ${t.message}")
                } finally {
                    if (inFlight.decrementAndGet() == 0) fireIdle()
                }
            }
        } catch (t: Throwable) {
            inFlight.decrementAndGet()
            PipelineLog.add(app, worker, "не удалось поставить в очередь: ${t.message}")
        }
    }

    /** Runs [cb] once, as soon as the queue is empty (immediately if it already is). */
    fun whenIdle(cb: () -> Unit) {
        idleCallbacks.add(cb)
        if (inFlight.get() == 0) fireIdle()
    }

    private fun fireIdle() {
        val list = idleCallbacks.toList()
        idleCallbacks.clear()
        list.forEach { try { it() } catch (_: Throwable) {} }
    }

    /**
     * Scans SpeechFilter/ for WAVs missing a transcript row and processes
     * all of them, oldest first. Safe to call from any background thread;
     * callers on RecordingService's `io` executor get natural mutual
     * exclusion because that executor is single-threaded, so a run in
     * progress can't overlap with the next closeCurrentWav() trigger \u2014 it
     * simply queues behind it, oldest-to-newest, the same guarantee
     * WorkManager's APPEND_OR_REPLACE was trying to give but with everything
     * running immediately instead of whenever the scheduler gets to it.
     */
    fun runPending(context: Context, worker: String = "transcribe") {
        try { Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND) } catch (_: Throwable) {}
        val db = AppDatabase.get(context)
        val whisper = WhisperEngine(context)
        try {
            val dir = File(context.getExternalFilesDir(null), "SpeechFilter")
            val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".wav", true) }
                ?.sortedBy { it.lastModified() } // oldest \u2192 newest, FIFO
                ?: emptyList()

            // WavWriter reserves a 44-byte all-zero header at start() and only
            // fills in the real "RIFF"/"WAVE"/... bytes in close(). While a
            // segment is still being recorded, its .wav already exists here
            // but the header is still zeroed \u2014 whisper.cpp correctly rejects
            // that. Not an error: the next run (chained right behind this one
            // on the same executor, or the startup sweep) will see the real
            // header once RecordingService.closeCurrentWav() has written it.
            val notFinalized = mutableListOf<File>()
            val pendingRaw = files.filter { runBlockingIO { db.transcripts().byPath(it.absolutePath) } == null }
            val pending = pendingRaw.filter { f ->
                if (isFinalizedWav(f)) true else { notFinalized += f; false }
            }
            if (pending.isEmpty()) {
                val extra = if (notFinalized.isEmpty()) "" else ", \u0435\u0449\u0451 \u043f\u0438\u0448\u0435\u0442\u0441\u044f: ${notFinalized.size}"
                runBlockingIO {
                    db.logs().insert(
                        PipelineLogEntity(worker = worker, message = "\u041d\u0435\u0442 \u043d\u043e\u0432\u044b\u0445 \u0444\u0430\u0439\u043b\u043e\u0432 (\u0432\u0441\u0435\u0433\u043e ${files.size}$extra)")
                    )
                }
                return
            }
            if (notFinalized.isNotEmpty()) {
                runBlockingIO {
                    db.logs().insert(
                        PipelineLogEntity(
                            worker = worker,
                            message = "\u0415\u0449\u0451 \u043f\u0438\u0448\u0435\u0442\u0441\u044f (\u043f\u0440\u043e\u043f\u0443\u0449\u0435\u043d\u043e \u0434\u043e \u0441\u043b\u0435\u0434. \u0437\u0430\u043f\u0443\u0441\u043a\u0430): ${notFinalized.joinToString { it.name }}"
                        )
                    )
                }
            }

            PipelineLog.add(context, worker, "Запуск распознавания, в очереди: ${pending.size}")
            val warm = whisper.warmUp()
            val already = if (whisper.isLoaded()) " (\u0432 RAM)" else ""
            runBlockingIO { db.logs().insert(PipelineLogEntity(worker = worker, message = "$warm$already")) }
            if (!whisper.isLoaded()) return

            var ok = 0
            var fail = 0
            for (f in pending) {
                val source = when {
                    f.name.contains("_watch_") -> "watch"
                    f.name.contains("_phone_") -> "phone"
                    else -> "unknown"
                }
                val started = System.currentTimeMillis()
                PipelineLog.add(context, worker, "Распознаю: ${f.name} (${f.length() / 1024} КБ)")
                val r = whisper.transcribeFile(f)
                val ms = System.currentTimeMillis() - started
                if (r.isSuccess) {
                    val text = r.getOrDefault("").trim()
                    val tid = runBlockingIO {
                        db.transcripts().insert(
                            TranscriptEntity(
                                filePath = f.absolutePath,
                                fileName = f.name,
                                sourceTag = source,
                                text = text,
                                createdAt = f.lastModified(),
                                transcribedAt = System.currentTimeMillis(),
                                status = "refined"
                            )
                        )
                    }
                    if (tid > 0 && text.isNotEmpty()) {
                        runBlockingIO {
                            db.refined().insert(
                                RefinedTextEntity(
                                    transcriptId = tid,
                                    text = text,
                                    processedAt = System.currentTimeMillis(),
                                    dayKey = DayKeys.of(f.lastModified())
                                )
                            )
                        }
                    }
                    ok++
                    val preview = if (text.isEmpty()) "(пусто)" else "«${text.take(60)}${if (text.length > 60) "…" else ""}»"
                    runBlockingIO {
                        db.logs().insert(
                            PipelineLogEntity(worker = worker, message = "Готово: ${f.name}, ${ms} мс → $preview")
                        )
                    }
                } else {
                    fail++
                    runBlockingIO {
                        db.logs().insert(
                            PipelineLogEntity(worker = worker, message = "${f.name}: ${r.exceptionOrNull()?.message}")
                        )
                    }
                }
            }
            runBlockingIO {
                db.logs().insert(
                    PipelineLogEntity(worker = worker, message = "\u0413\u043e\u0442\u043e\u0432\u043e: +$ok, \u043e\u0448\u0438\u0431\u043a\u0430=$fail, \u043d\u043e\u0432\u044b\u0445=${pending.size}")
                )
            }
        } catch (t: Throwable) {
            runBlockingIO {
                db.logs().insert(PipelineLogEntity(worker = worker, message = "crash: ${t.javaClass.simpleName}: ${t.message}"))
            }
        } finally {
            // Keep the model resident \u2014 only dropped on import / explicit unload.
            whisper.release(dropShared = false)
        }
    }

    private fun isFinalizedWav(f: File): Boolean {
        if (f.length() < 44L) return false
        return try {
            RandomAccessFile(f, "r").use { raf ->
                val magic = ByteArray(4)
                raf.readFully(magic)
                String(magic, Charsets.US_ASCII) == "RIFF"
            }
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * This whole object runs on a plain background thread (RecordingService's
     * `io` executor, or a Worker's dispatcher), never on Main, so blocking
     * here for a Room suspend call is fine \u2014 it's the same thing
     * `kotlinx.coroutines.runBlocking` would do, spelled out locally to
     * avoid pulling a coroutine scope through a plain Executor task.
     */
    private fun <T> runBlockingIO(block: suspend () -> T): T =
        kotlinx.coroutines.runBlocking { block() }
}
