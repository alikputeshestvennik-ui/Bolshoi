package com.example.speechfilter.data

import android.content.Context
import java.io.File

/** One recording as shown in the UI: the WAV file plus whatever the pipeline
 *  has produced from it so far. Audio and text are always looked up together
 *  through this class, so the two never drift apart in the UI. */
data class RecordingRow(
    val file: File,
    val transcript: TranscriptEntity?,
    val refinedText: String?
) {
    val fromWatch: Boolean get() = file.name.contains("_watch_")
    val displayText: String?
        get() = refinedText?.takeIf { it.isNotBlank() }
            ?: transcript?.text?.takeIf { it.isNotBlank() }
    val statusLabel: String
        get() = when {
            transcript == null -> "⏳ ожидает расшифровки"
            transcript.status == "refined" -> "✅ обработано"
            transcript.status == "failed" -> "❌ ошибка"
            else -> "⏳ в обработке"
        }
}

/** Loads the merged recording+text rows and performs the linked delete:
 *  removing a recording always removes its WAV file, its Whisper transcript,
 *  its text row, and any "important" snippets pulled from that text, in one
 *  call — never just one piece of it. */
object RecordingsRepository {

    fun recordingsDir(context: Context): File =
        File(context.getExternalFilesDir(null), "SpeechFilter")

    suspend fun loadRows(context: Context): List<RecordingRow> {
        val db = AppDatabase.get(context)
        val files = recordingsDir(context)
            .listFiles { f -> f.isFile && f.extension.equals("wav", true) }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
        return files.map { f ->
            val transcript = db.transcripts().byPath(f.absolutePath)
            val refined = transcript?.let { db.refined().forTranscript(it.id)?.text }
            RecordingRow(f, transcript, refined)
        }
    }

    suspend fun deleteRecording(context: Context, row: RecordingRow) {
        val db = AppDatabase.get(context)
        val transcript = row.transcript
        if (transcript != null) {
            db.refined().allForTranscript(transcript.id).forEach { refined ->
                db.important().deleteBySourceRefined(refined.id)
            }
            db.refined().deleteForTranscript(transcript.id)
            db.transcripts().deleteById(transcript.id)
        }
        if (row.file.exists()) row.file.delete()
    }
}
