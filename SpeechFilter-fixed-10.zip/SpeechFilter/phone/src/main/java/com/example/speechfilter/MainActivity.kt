package com.example.speechfilter

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

/**
 * Thin shell that hosts three screens: Launch (start/stop recording),
 * Records (audio + transcript together, with linked delete), and Settings
 * (models, readiness check, worker log window).
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (savedInstanceState == null) {
            showScreen(LaunchFragment())
            requestIgnoreBatteryOptimizations()
        }

        findViewById<BottomNavigationView>(R.id.bottomNav).setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_launch -> { showScreen(LaunchFragment()); true }
                R.id.nav_records -> { showScreen(RecordsFragment()); true }
                R.id.nav_settings -> { showScreen(SettingsFragment()); true }
                else -> false
            }
        }
    }

    /**
     * For "start and forget, 24/7, just keep it charged" to actually hold up,
     * Android's own Doze battery optimization must not be allowed to kill
     * RecordingService in the background. This asks for the standard
     * exemption once, on first launch.
     *
     * NOTE this does NOT cover Samsung's separate OneUI "Sleeping apps" /
     * "Deep sleeping apps" battery manager — that's a Samsung-specific list
     * with no public API to set programmatically. If recording still stops
     * unexpectedly after granting this, also open Settings → Battery →
     * Background usage limits and move this app to "Never sleeping apps".
     */
    private fun requestIgnoreBatteryOptimizations() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        try {
            val pm = getSystemService(PowerManager::class.java)
            if (pm?.isIgnoringBatteryOptimizations(packageName) == true) return
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {}
    }

    private fun showScreen(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.screenContainer, fragment)
            .commit()
    }

    override fun onDestroy() {
        PlaybackController.release()
        super.onDestroy()
    }
}
